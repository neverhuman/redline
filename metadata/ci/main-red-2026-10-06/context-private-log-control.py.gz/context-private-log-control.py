import datetime,hashlib,json,pathlib,shutil,subprocess,tempfile
root=pathlib.Path('/home/ubuntu/redlineDB');proof=root/'target/review/main-red'
work=pathlib.Path(tempfile.mkdtemp(prefix='context-private-log-',dir=proof))
old='927688460cc005fd832ba091a8de8419de9d4d6f';ignore='ops/ci/arm64-packages.Dockerfile.dockerignore'
paths=subprocess.check_output(['git','-C',str(root),'ls-files','subrepos/redline-split-ops/release-evidence/*.log'],text=True).splitlines()
private=pathlib.Path('subrepos/redline-split-ops/release-evidence/8.0.0/private-context-control.log')
record={'startedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'oldHead':old,'oldIgnoreSha256':hashlib.sha256(subprocess.check_output(['git','-C',str(root),'show',old+':'+ignore])).hexdigest(),'fixedIgnoreSha256':hashlib.sha256((root/ignore).read_bytes()).hexdigest(),'publicPaths':paths,'privateControlPath':str(private),'scope':'Synthetic harmless private marker in a private Git fixture; production Docker ignore files copied byte-exactly. Tests context routing only, not full ARM qualification.','cases':[]}
try:
 source=work/'fixture';source.mkdir();(source/'.gitignore').write_text('*.log\n.env\n.env.*\n')
 (source/'Dockerfile').write_text('FROM scratch\nCOPY . /context/\n')
 for name in paths+['subrepos/redline-central/.env.example']:
  p=source/name;p.parent.mkdir(parents=True,exist_ok=True);p.write_text('Public test fixture for '+name+'\n')
 subprocess.run(['git','-C',str(source),'init','--quiet'],check=True)
 subprocess.run(['git','-C',str(source),'add','--force','.'],check=True)
 subprocess.run(['git','-C',str(source),'-c','user.name=Fixture','-c','user.email=fixture@example.invalid','commit','--quiet','-m','public context fixture'],check=True)
 (source/private).write_text('Harmless ignored PRIVATE marker; must never enter corrected context.\n')
 (source/'subrepos/redline-central/.env').write_text('PRIVATE_FIXTURE=harmless\n')
 assert not subprocess.check_output(['git','-C',str(source),'status','--porcelain'],text=True).strip()
 record['fixtureCleanWithIgnoredPrivateFiles']=True
 for label,data,expected_private in [('reviewed-parent',subprocess.check_output(['git','-C',str(root),'show',old+':'+ignore]),True),('fixed-head',(root/ignore).read_bytes(),False)]:
  (source/'Dockerfile.dockerignore').write_bytes(data)
  output=work/label;log=proof/f'context-private-log-{label}.log';assert not log.exists()
  cmd=['timeout','180','docker','buildx','build','--builder','redline-packages-arm64','--progress','plain','--file','Dockerfile','--output','type=local,dest='+str(output),'.']
  with log.open('wb') as f: result=subprocess.run(cmd,cwd=source,stdout=f,stderr=subprocess.STDOUT)
  case={'label':label,'exit':result.returncode,'ignoreSha256':hashlib.sha256(data).hexdigest(),'log':str(log.relative_to(root)),'logSha256':hashlib.sha256(log.read_bytes()).hexdigest()}
  record['cases'].append(case);assert result.returncode==0,(label,result.returncode)
  context=output/'context';case['privateLogPresent']=(context/private).exists();case['privateEnvPresent']=(context/'subrepos/redline-central/.env').exists();case['publicFilesPresent']=sum((context/name).exists() for name in paths+['subrepos/redline-central/.env.example'])
  assert case['privateLogPresent']==expected_private and not case['privateEnvPresent'] and case['publicFilesPresent']==len(paths)+1
 record['passed']=True
finally:
 record['finishedAt']=datetime.datetime.now(datetime.timezone.utc).isoformat();(proof/'context-private-log-control.json').write_text(json.dumps(record,indent=2)+'\n')
 # Only generated fixture files live here; raw logs/receipt are outside it.
 shutil.rmtree(work)
print(json.dumps(record),flush=True)

#define _GNU_SOURCE
#include <unistd.h>
#include <sys/syscall.h>
#include <stdlib.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
ssize_t write(int fd,const void *buf,size_t len){
 ssize_t result=syscall(SYS_write,fd,buf,len);
 const char *marker=getenv("REDLINE_CI_REPRO_READY_MARKER");
 if(marker && fd==1 && len==6 && memcmp(buf,"READY\n",6)==0){
  int out=open(marker,O_WRONLY|O_CREAT|O_APPEND|O_CLOEXEC,0600);
  if(out>=0){char line[80];int n=snprintf(line,sizeof line,"pid=%ld delayed_after_ready_ms=1000\n",(long)getpid());syscall(SYS_write,out,line,n);close(out);}
  usleep(1000000);
 }
 return result;
}

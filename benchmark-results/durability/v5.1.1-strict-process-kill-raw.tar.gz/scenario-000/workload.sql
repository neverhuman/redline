.print @@mode
PRAGMA redline_durability;
CREATE TABLE kv(k INTEGER PRIMARY KEY, tenant INTEGER, v BLOB, version INTEGER);
CREATE INDEX kv_tenant_idx ON kv(tenant);
CREATE TABLE crash_progress(id INTEGER PRIMARY KEY, scenario TEXT, note TEXT);
.print @@ready
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (0, 0, X'76616C75652D3030303030303030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (0, 'wal', 'ack-0');
COMMIT;
SELECT 'ack', 0;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1, 1, X'76616C75652D3030303030303031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1, 'wal', 'ack-1');
COMMIT;
SELECT 'ack', 1;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2, 2, X'76616C75652D3030303030303032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2, 'wal', 'ack-2');
COMMIT;
SELECT 'ack', 2;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3, 3, X'76616C75652D3030303030303033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3, 'wal', 'ack-3');
COMMIT;
SELECT 'ack', 3;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4, 4, X'76616C75652D3030303030303034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4, 'wal', 'ack-4');
COMMIT;
SELECT 'ack', 4;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (5, 5, X'76616C75652D3030303030303035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (5, 'wal', 'ack-5');
COMMIT;
SELECT 'ack', 5;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (6, 6, X'76616C75652D3030303030303036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (6, 'wal', 'ack-6');
COMMIT;
SELECT 'ack', 6;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (7, 7, X'76616C75652D3030303030303037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (7, 'wal', 'ack-7');
COMMIT;
SELECT 'ack', 7;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (8, 8, X'76616C75652D3030303030303038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (8, 'wal', 'ack-8');
COMMIT;
SELECT 'ack', 8;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (9, 9, X'76616C75652D3030303030303039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (9, 'wal', 'ack-9');
COMMIT;
SELECT 'ack', 9;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (10, 10, X'76616C75652D3030303030303130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (10, 'wal', 'ack-10');
COMMIT;
SELECT 'ack', 10;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (11, 11, X'76616C75652D3030303030303131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (11, 'wal', 'ack-11');
COMMIT;
SELECT 'ack', 11;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (12, 12, X'76616C75652D3030303030303132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (12, 'wal', 'ack-12');
COMMIT;
SELECT 'ack', 12;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (13, 13, X'76616C75652D3030303030303133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (13, 'wal', 'ack-13');
COMMIT;
SELECT 'ack', 13;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (14, 14, X'76616C75652D3030303030303134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (14, 'wal', 'ack-14');
COMMIT;
SELECT 'ack', 14;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (15, 15, X'76616C75652D3030303030303135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (15, 'wal', 'ack-15');
COMMIT;
SELECT 'ack', 15;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (16, 16, X'76616C75652D3030303030303136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (16, 'wal', 'ack-16');
COMMIT;
SELECT 'ack', 16;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (17, 17, X'76616C75652D3030303030303137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (17, 'wal', 'ack-17');
COMMIT;
SELECT 'ack', 17;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (18, 18, X'76616C75652D3030303030303138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (18, 'wal', 'ack-18');
COMMIT;
SELECT 'ack', 18;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (19, 19, X'76616C75652D3030303030303139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (19, 'wal', 'ack-19');
COMMIT;
SELECT 'ack', 19;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (20, 20, X'76616C75652D3030303030303230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (20, 'wal', 'ack-20');
COMMIT;
SELECT 'ack', 20;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (21, 21, X'76616C75652D3030303030303231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (21, 'wal', 'ack-21');
COMMIT;
SELECT 'ack', 21;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (22, 22, X'76616C75652D3030303030303232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (22, 'wal', 'ack-22');
COMMIT;
SELECT 'ack', 22;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (23, 23, X'76616C75652D3030303030303233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (23, 'wal', 'ack-23');
COMMIT;
SELECT 'ack', 23;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (24, 24, X'76616C75652D3030303030303234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (24, 'wal', 'ack-24');
COMMIT;
SELECT 'ack', 24;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (25, 25, X'76616C75652D3030303030303235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (25, 'wal', 'ack-25');
COMMIT;
SELECT 'ack', 25;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (26, 26, X'76616C75652D3030303030303236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (26, 'wal', 'ack-26');
COMMIT;
SELECT 'ack', 26;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (27, 27, X'76616C75652D3030303030303237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (27, 'wal', 'ack-27');
COMMIT;
SELECT 'ack', 27;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (28, 28, X'76616C75652D3030303030303238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (28, 'wal', 'ack-28');
COMMIT;
SELECT 'ack', 28;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (29, 29, X'76616C75652D3030303030303239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (29, 'wal', 'ack-29');
COMMIT;
SELECT 'ack', 29;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (30, 30, X'76616C75652D3030303030303330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (30, 'wal', 'ack-30');
COMMIT;
SELECT 'ack', 30;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (31, 31, X'76616C75652D3030303030303331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (31, 'wal', 'ack-31');
COMMIT;
SELECT 'ack', 31;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (32, 0, X'76616C75652D3030303030303332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (32, 'wal', 'ack-32');
COMMIT;
SELECT 'ack', 32;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (33, 1, X'76616C75652D3030303030303333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (33, 'wal', 'ack-33');
COMMIT;
SELECT 'ack', 33;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (34, 2, X'76616C75652D3030303030303334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (34, 'wal', 'ack-34');
COMMIT;
SELECT 'ack', 34;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (35, 3, X'76616C75652D3030303030303335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (35, 'wal', 'ack-35');
COMMIT;
SELECT 'ack', 35;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (36, 4, X'76616C75652D3030303030303336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (36, 'wal', 'ack-36');
COMMIT;
SELECT 'ack', 36;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (37, 5, X'76616C75652D3030303030303337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (37, 'wal', 'ack-37');
COMMIT;
SELECT 'ack', 37;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (38, 6, X'76616C75652D3030303030303338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (38, 'wal', 'ack-38');
COMMIT;
SELECT 'ack', 38;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (39, 7, X'76616C75652D3030303030303339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (39, 'wal', 'ack-39');
COMMIT;
SELECT 'ack', 39;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (40, 8, X'76616C75652D3030303030303430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (40, 'wal', 'ack-40');
COMMIT;
SELECT 'ack', 40;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (41, 9, X'76616C75652D3030303030303431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (41, 'wal', 'ack-41');
COMMIT;
SELECT 'ack', 41;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (42, 10, X'76616C75652D3030303030303432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (42, 'wal', 'ack-42');
COMMIT;
SELECT 'ack', 42;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (43, 11, X'76616C75652D3030303030303433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (43, 'wal', 'ack-43');
COMMIT;
SELECT 'ack', 43;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (44, 12, X'76616C75652D3030303030303434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (44, 'wal', 'ack-44');
COMMIT;
SELECT 'ack', 44;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (45, 13, X'76616C75652D3030303030303435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (45, 'wal', 'ack-45');
COMMIT;
SELECT 'ack', 45;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (46, 14, X'76616C75652D3030303030303436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (46, 'wal', 'ack-46');
COMMIT;
SELECT 'ack', 46;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (47, 15, X'76616C75652D3030303030303437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (47, 'wal', 'ack-47');
COMMIT;
SELECT 'ack', 47;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (48, 16, X'76616C75652D3030303030303438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (48, 'wal', 'ack-48');
COMMIT;
SELECT 'ack', 48;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (49, 17, X'76616C75652D3030303030303439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (49, 'wal', 'ack-49');
COMMIT;
SELECT 'ack', 49;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (50, 18, X'76616C75652D3030303030303530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (50, 'wal', 'ack-50');
COMMIT;
SELECT 'ack', 50;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (51, 19, X'76616C75652D3030303030303531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (51, 'wal', 'ack-51');
COMMIT;
SELECT 'ack', 51;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (52, 20, X'76616C75652D3030303030303532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (52, 'wal', 'ack-52');
COMMIT;
SELECT 'ack', 52;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (53, 21, X'76616C75652D3030303030303533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (53, 'wal', 'ack-53');
COMMIT;
SELECT 'ack', 53;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (54, 22, X'76616C75652D3030303030303534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (54, 'wal', 'ack-54');
COMMIT;
SELECT 'ack', 54;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (55, 23, X'76616C75652D3030303030303535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (55, 'wal', 'ack-55');
COMMIT;
SELECT 'ack', 55;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (56, 24, X'76616C75652D3030303030303536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (56, 'wal', 'ack-56');
COMMIT;
SELECT 'ack', 56;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (57, 25, X'76616C75652D3030303030303537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (57, 'wal', 'ack-57');
COMMIT;
SELECT 'ack', 57;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (58, 26, X'76616C75652D3030303030303538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (58, 'wal', 'ack-58');
COMMIT;
SELECT 'ack', 58;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (59, 27, X'76616C75652D3030303030303539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (59, 'wal', 'ack-59');
COMMIT;
SELECT 'ack', 59;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (60, 28, X'76616C75652D3030303030303630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (60, 'wal', 'ack-60');
COMMIT;
SELECT 'ack', 60;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (61, 29, X'76616C75652D3030303030303631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (61, 'wal', 'ack-61');
COMMIT;
SELECT 'ack', 61;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (62, 30, X'76616C75652D3030303030303632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (62, 'wal', 'ack-62');
COMMIT;
SELECT 'ack', 62;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (63, 31, X'76616C75652D3030303030303633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (63, 'wal', 'ack-63');
COMMIT;
SELECT 'ack', 63;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (64, 0, X'76616C75652D3030303030303634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (64, 'wal', 'ack-64');
COMMIT;
SELECT 'ack', 64;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (65, 1, X'76616C75652D3030303030303635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (65, 'wal', 'ack-65');
COMMIT;
SELECT 'ack', 65;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (66, 2, X'76616C75652D3030303030303636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (66, 'wal', 'ack-66');
COMMIT;
SELECT 'ack', 66;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (67, 3, X'76616C75652D3030303030303637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (67, 'wal', 'ack-67');
COMMIT;
SELECT 'ack', 67;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (68, 4, X'76616C75652D3030303030303638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (68, 'wal', 'ack-68');
COMMIT;
SELECT 'ack', 68;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (69, 5, X'76616C75652D3030303030303639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (69, 'wal', 'ack-69');
COMMIT;
SELECT 'ack', 69;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (70, 6, X'76616C75652D3030303030303730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (70, 'wal', 'ack-70');
COMMIT;
SELECT 'ack', 70;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (71, 7, X'76616C75652D3030303030303731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (71, 'wal', 'ack-71');
COMMIT;
SELECT 'ack', 71;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (72, 8, X'76616C75652D3030303030303732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (72, 'wal', 'ack-72');
COMMIT;
SELECT 'ack', 72;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (73, 9, X'76616C75652D3030303030303733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (73, 'wal', 'ack-73');
COMMIT;
SELECT 'ack', 73;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (74, 10, X'76616C75652D3030303030303734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (74, 'wal', 'ack-74');
COMMIT;
SELECT 'ack', 74;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (75, 11, X'76616C75652D3030303030303735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (75, 'wal', 'ack-75');
COMMIT;
SELECT 'ack', 75;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (76, 12, X'76616C75652D3030303030303736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (76, 'wal', 'ack-76');
COMMIT;
SELECT 'ack', 76;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (77, 13, X'76616C75652D3030303030303737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (77, 'wal', 'ack-77');
COMMIT;
SELECT 'ack', 77;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (78, 14, X'76616C75652D3030303030303738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (78, 'wal', 'ack-78');
COMMIT;
SELECT 'ack', 78;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (79, 15, X'76616C75652D3030303030303739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (79, 'wal', 'ack-79');
COMMIT;
SELECT 'ack', 79;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (80, 16, X'76616C75652D3030303030303830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (80, 'wal', 'ack-80');
COMMIT;
SELECT 'ack', 80;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (81, 17, X'76616C75652D3030303030303831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (81, 'wal', 'ack-81');
COMMIT;
SELECT 'ack', 81;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (82, 18, X'76616C75652D3030303030303832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (82, 'wal', 'ack-82');
COMMIT;
SELECT 'ack', 82;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (83, 19, X'76616C75652D3030303030303833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (83, 'wal', 'ack-83');
COMMIT;
SELECT 'ack', 83;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (84, 20, X'76616C75652D3030303030303834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (84, 'wal', 'ack-84');
COMMIT;
SELECT 'ack', 84;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (85, 21, X'76616C75652D3030303030303835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (85, 'wal', 'ack-85');
COMMIT;
SELECT 'ack', 85;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (86, 22, X'76616C75652D3030303030303836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (86, 'wal', 'ack-86');
COMMIT;
SELECT 'ack', 86;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (87, 23, X'76616C75652D3030303030303837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (87, 'wal', 'ack-87');
COMMIT;
SELECT 'ack', 87;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (88, 24, X'76616C75652D3030303030303838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (88, 'wal', 'ack-88');
COMMIT;
SELECT 'ack', 88;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (89, 25, X'76616C75652D3030303030303839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (89, 'wal', 'ack-89');
COMMIT;
SELECT 'ack', 89;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (90, 26, X'76616C75652D3030303030303930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (90, 'wal', 'ack-90');
COMMIT;
SELECT 'ack', 90;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (91, 27, X'76616C75652D3030303030303931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (91, 'wal', 'ack-91');
COMMIT;
SELECT 'ack', 91;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (92, 28, X'76616C75652D3030303030303932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (92, 'wal', 'ack-92');
COMMIT;
SELECT 'ack', 92;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (93, 29, X'76616C75652D3030303030303933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (93, 'wal', 'ack-93');
COMMIT;
SELECT 'ack', 93;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (94, 30, X'76616C75652D3030303030303934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (94, 'wal', 'ack-94');
COMMIT;
SELECT 'ack', 94;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (95, 31, X'76616C75652D3030303030303935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (95, 'wal', 'ack-95');
COMMIT;
SELECT 'ack', 95;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (96, 0, X'76616C75652D3030303030303936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (96, 'wal', 'ack-96');
COMMIT;
SELECT 'ack', 96;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (97, 1, X'76616C75652D3030303030303937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (97, 'wal', 'ack-97');
COMMIT;
SELECT 'ack', 97;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (98, 2, X'76616C75652D3030303030303938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (98, 'wal', 'ack-98');
COMMIT;
SELECT 'ack', 98;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (99, 3, X'76616C75652D3030303030303939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (99, 'wal', 'ack-99');
COMMIT;
SELECT 'ack', 99;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (100, 4, X'76616C75652D3030303030313030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (100, 'wal', 'ack-100');
COMMIT;
SELECT 'ack', 100;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (101, 5, X'76616C75652D3030303030313031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (101, 'wal', 'ack-101');
COMMIT;
SELECT 'ack', 101;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (102, 6, X'76616C75652D3030303030313032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (102, 'wal', 'ack-102');
COMMIT;
SELECT 'ack', 102;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (103, 7, X'76616C75652D3030303030313033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (103, 'wal', 'ack-103');
COMMIT;
SELECT 'ack', 103;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (104, 8, X'76616C75652D3030303030313034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (104, 'wal', 'ack-104');
COMMIT;
SELECT 'ack', 104;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (105, 9, X'76616C75652D3030303030313035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (105, 'wal', 'ack-105');
COMMIT;
SELECT 'ack', 105;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (106, 10, X'76616C75652D3030303030313036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (106, 'wal', 'ack-106');
COMMIT;
SELECT 'ack', 106;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (107, 11, X'76616C75652D3030303030313037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (107, 'wal', 'ack-107');
COMMIT;
SELECT 'ack', 107;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (108, 12, X'76616C75652D3030303030313038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (108, 'wal', 'ack-108');
COMMIT;
SELECT 'ack', 108;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (109, 13, X'76616C75652D3030303030313039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (109, 'wal', 'ack-109');
COMMIT;
SELECT 'ack', 109;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (110, 14, X'76616C75652D3030303030313130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (110, 'wal', 'ack-110');
COMMIT;
SELECT 'ack', 110;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (111, 15, X'76616C75652D3030303030313131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (111, 'wal', 'ack-111');
COMMIT;
SELECT 'ack', 111;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (112, 16, X'76616C75652D3030303030313132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (112, 'wal', 'ack-112');
COMMIT;
SELECT 'ack', 112;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (113, 17, X'76616C75652D3030303030313133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (113, 'wal', 'ack-113');
COMMIT;
SELECT 'ack', 113;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (114, 18, X'76616C75652D3030303030313134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (114, 'wal', 'ack-114');
COMMIT;
SELECT 'ack', 114;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (115, 19, X'76616C75652D3030303030313135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (115, 'wal', 'ack-115');
COMMIT;
SELECT 'ack', 115;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (116, 20, X'76616C75652D3030303030313136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (116, 'wal', 'ack-116');
COMMIT;
SELECT 'ack', 116;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (117, 21, X'76616C75652D3030303030313137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (117, 'wal', 'ack-117');
COMMIT;
SELECT 'ack', 117;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (118, 22, X'76616C75652D3030303030313138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (118, 'wal', 'ack-118');
COMMIT;
SELECT 'ack', 118;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (119, 23, X'76616C75652D3030303030313139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (119, 'wal', 'ack-119');
COMMIT;
SELECT 'ack', 119;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (120, 24, X'76616C75652D3030303030313230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (120, 'wal', 'ack-120');
COMMIT;
SELECT 'ack', 120;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (121, 25, X'76616C75652D3030303030313231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (121, 'wal', 'ack-121');
COMMIT;
SELECT 'ack', 121;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (122, 26, X'76616C75652D3030303030313232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (122, 'wal', 'ack-122');
COMMIT;
SELECT 'ack', 122;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (123, 27, X'76616C75652D3030303030313233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (123, 'wal', 'ack-123');
COMMIT;
SELECT 'ack', 123;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (124, 28, X'76616C75652D3030303030313234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (124, 'wal', 'ack-124');
COMMIT;
SELECT 'ack', 124;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (125, 29, X'76616C75652D3030303030313235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (125, 'wal', 'ack-125');
COMMIT;
SELECT 'ack', 125;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (126, 30, X'76616C75652D3030303030313236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (126, 'wal', 'ack-126');
COMMIT;
SELECT 'ack', 126;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (127, 31, X'76616C75652D3030303030313237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (127, 'wal', 'ack-127');
COMMIT;
SELECT 'ack', 127;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (128, 0, X'76616C75652D3030303030313238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (128, 'wal', 'ack-128');
COMMIT;
SELECT 'ack', 128;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (129, 1, X'76616C75652D3030303030313239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (129, 'wal', 'ack-129');
COMMIT;
SELECT 'ack', 129;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (130, 2, X'76616C75652D3030303030313330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (130, 'wal', 'ack-130');
COMMIT;
SELECT 'ack', 130;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (131, 3, X'76616C75652D3030303030313331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (131, 'wal', 'ack-131');
COMMIT;
SELECT 'ack', 131;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (132, 4, X'76616C75652D3030303030313332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (132, 'wal', 'ack-132');
COMMIT;
SELECT 'ack', 132;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (133, 5, X'76616C75652D3030303030313333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (133, 'wal', 'ack-133');
COMMIT;
SELECT 'ack', 133;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (134, 6, X'76616C75652D3030303030313334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (134, 'wal', 'ack-134');
COMMIT;
SELECT 'ack', 134;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (135, 7, X'76616C75652D3030303030313335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (135, 'wal', 'ack-135');
COMMIT;
SELECT 'ack', 135;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (136, 8, X'76616C75652D3030303030313336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (136, 'wal', 'ack-136');
COMMIT;
SELECT 'ack', 136;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (137, 9, X'76616C75652D3030303030313337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (137, 'wal', 'ack-137');
COMMIT;
SELECT 'ack', 137;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (138, 10, X'76616C75652D3030303030313338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (138, 'wal', 'ack-138');
COMMIT;
SELECT 'ack', 138;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (139, 11, X'76616C75652D3030303030313339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (139, 'wal', 'ack-139');
COMMIT;
SELECT 'ack', 139;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (140, 12, X'76616C75652D3030303030313430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (140, 'wal', 'ack-140');
COMMIT;
SELECT 'ack', 140;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (141, 13, X'76616C75652D3030303030313431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (141, 'wal', 'ack-141');
COMMIT;
SELECT 'ack', 141;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (142, 14, X'76616C75652D3030303030313432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (142, 'wal', 'ack-142');
COMMIT;
SELECT 'ack', 142;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (143, 15, X'76616C75652D3030303030313433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (143, 'wal', 'ack-143');
COMMIT;
SELECT 'ack', 143;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (144, 16, X'76616C75652D3030303030313434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (144, 'wal', 'ack-144');
COMMIT;
SELECT 'ack', 144;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (145, 17, X'76616C75652D3030303030313435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (145, 'wal', 'ack-145');
COMMIT;
SELECT 'ack', 145;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (146, 18, X'76616C75652D3030303030313436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (146, 'wal', 'ack-146');
COMMIT;
SELECT 'ack', 146;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (147, 19, X'76616C75652D3030303030313437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (147, 'wal', 'ack-147');
COMMIT;
SELECT 'ack', 147;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (148, 20, X'76616C75652D3030303030313438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (148, 'wal', 'ack-148');
COMMIT;
SELECT 'ack', 148;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (149, 21, X'76616C75652D3030303030313439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (149, 'wal', 'ack-149');
COMMIT;
SELECT 'ack', 149;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (150, 22, X'76616C75652D3030303030313530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (150, 'wal', 'ack-150');
COMMIT;
SELECT 'ack', 150;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (151, 23, X'76616C75652D3030303030313531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (151, 'wal', 'ack-151');
COMMIT;
SELECT 'ack', 151;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (152, 24, X'76616C75652D3030303030313532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (152, 'wal', 'ack-152');
COMMIT;
SELECT 'ack', 152;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (153, 25, X'76616C75652D3030303030313533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (153, 'wal', 'ack-153');
COMMIT;
SELECT 'ack', 153;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (154, 26, X'76616C75652D3030303030313534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (154, 'wal', 'ack-154');
COMMIT;
SELECT 'ack', 154;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (155, 27, X'76616C75652D3030303030313535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (155, 'wal', 'ack-155');
COMMIT;
SELECT 'ack', 155;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (156, 28, X'76616C75652D3030303030313536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (156, 'wal', 'ack-156');
COMMIT;
SELECT 'ack', 156;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (157, 29, X'76616C75652D3030303030313537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (157, 'wal', 'ack-157');
COMMIT;
SELECT 'ack', 157;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (158, 30, X'76616C75652D3030303030313538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (158, 'wal', 'ack-158');
COMMIT;
SELECT 'ack', 158;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (159, 31, X'76616C75652D3030303030313539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (159, 'wal', 'ack-159');
COMMIT;
SELECT 'ack', 159;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (160, 0, X'76616C75652D3030303030313630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (160, 'wal', 'ack-160');
COMMIT;
SELECT 'ack', 160;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (161, 1, X'76616C75652D3030303030313631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (161, 'wal', 'ack-161');
COMMIT;
SELECT 'ack', 161;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (162, 2, X'76616C75652D3030303030313632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (162, 'wal', 'ack-162');
COMMIT;
SELECT 'ack', 162;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (163, 3, X'76616C75652D3030303030313633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (163, 'wal', 'ack-163');
COMMIT;
SELECT 'ack', 163;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (164, 4, X'76616C75652D3030303030313634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (164, 'wal', 'ack-164');
COMMIT;
SELECT 'ack', 164;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (165, 5, X'76616C75652D3030303030313635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (165, 'wal', 'ack-165');
COMMIT;
SELECT 'ack', 165;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (166, 6, X'76616C75652D3030303030313636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (166, 'wal', 'ack-166');
COMMIT;
SELECT 'ack', 166;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (167, 7, X'76616C75652D3030303030313637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (167, 'wal', 'ack-167');
COMMIT;
SELECT 'ack', 167;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (168, 8, X'76616C75652D3030303030313638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (168, 'wal', 'ack-168');
COMMIT;
SELECT 'ack', 168;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (169, 9, X'76616C75652D3030303030313639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (169, 'wal', 'ack-169');
COMMIT;
SELECT 'ack', 169;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (170, 10, X'76616C75652D3030303030313730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (170, 'wal', 'ack-170');
COMMIT;
SELECT 'ack', 170;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (171, 11, X'76616C75652D3030303030313731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (171, 'wal', 'ack-171');
COMMIT;
SELECT 'ack', 171;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (172, 12, X'76616C75652D3030303030313732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (172, 'wal', 'ack-172');
COMMIT;
SELECT 'ack', 172;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (173, 13, X'76616C75652D3030303030313733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (173, 'wal', 'ack-173');
COMMIT;
SELECT 'ack', 173;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (174, 14, X'76616C75652D3030303030313734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (174, 'wal', 'ack-174');
COMMIT;
SELECT 'ack', 174;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (175, 15, X'76616C75652D3030303030313735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (175, 'wal', 'ack-175');
COMMIT;
SELECT 'ack', 175;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (176, 16, X'76616C75652D3030303030313736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (176, 'wal', 'ack-176');
COMMIT;
SELECT 'ack', 176;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (177, 17, X'76616C75652D3030303030313737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (177, 'wal', 'ack-177');
COMMIT;
SELECT 'ack', 177;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (178, 18, X'76616C75652D3030303030313738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (178, 'wal', 'ack-178');
COMMIT;
SELECT 'ack', 178;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (179, 19, X'76616C75652D3030303030313739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (179, 'wal', 'ack-179');
COMMIT;
SELECT 'ack', 179;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (180, 20, X'76616C75652D3030303030313830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (180, 'wal', 'ack-180');
COMMIT;
SELECT 'ack', 180;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (181, 21, X'76616C75652D3030303030313831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (181, 'wal', 'ack-181');
COMMIT;
SELECT 'ack', 181;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (182, 22, X'76616C75652D3030303030313832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (182, 'wal', 'ack-182');
COMMIT;
SELECT 'ack', 182;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (183, 23, X'76616C75652D3030303030313833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (183, 'wal', 'ack-183');
COMMIT;
SELECT 'ack', 183;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (184, 24, X'76616C75652D3030303030313834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (184, 'wal', 'ack-184');
COMMIT;
SELECT 'ack', 184;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (185, 25, X'76616C75652D3030303030313835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (185, 'wal', 'ack-185');
COMMIT;
SELECT 'ack', 185;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (186, 26, X'76616C75652D3030303030313836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (186, 'wal', 'ack-186');
COMMIT;
SELECT 'ack', 186;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (187, 27, X'76616C75652D3030303030313837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (187, 'wal', 'ack-187');
COMMIT;
SELECT 'ack', 187;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (188, 28, X'76616C75652D3030303030313838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (188, 'wal', 'ack-188');
COMMIT;
SELECT 'ack', 188;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (189, 29, X'76616C75652D3030303030313839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (189, 'wal', 'ack-189');
COMMIT;
SELECT 'ack', 189;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (190, 30, X'76616C75652D3030303030313930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (190, 'wal', 'ack-190');
COMMIT;
SELECT 'ack', 190;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (191, 31, X'76616C75652D3030303030313931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (191, 'wal', 'ack-191');
COMMIT;
SELECT 'ack', 191;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (192, 0, X'76616C75652D3030303030313932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (192, 'wal', 'ack-192');
COMMIT;
SELECT 'ack', 192;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (193, 1, X'76616C75652D3030303030313933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (193, 'wal', 'ack-193');
COMMIT;
SELECT 'ack', 193;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (194, 2, X'76616C75652D3030303030313934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (194, 'wal', 'ack-194');
COMMIT;
SELECT 'ack', 194;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (195, 3, X'76616C75652D3030303030313935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (195, 'wal', 'ack-195');
COMMIT;
SELECT 'ack', 195;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (196, 4, X'76616C75652D3030303030313936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (196, 'wal', 'ack-196');
COMMIT;
SELECT 'ack', 196;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (197, 5, X'76616C75652D3030303030313937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (197, 'wal', 'ack-197');
COMMIT;
SELECT 'ack', 197;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (198, 6, X'76616C75652D3030303030313938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (198, 'wal', 'ack-198');
COMMIT;
SELECT 'ack', 198;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (199, 7, X'76616C75652D3030303030313939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (199, 'wal', 'ack-199');
COMMIT;
SELECT 'ack', 199;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (200, 8, X'76616C75652D3030303030323030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (200, 'wal', 'ack-200');
COMMIT;
SELECT 'ack', 200;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (201, 9, X'76616C75652D3030303030323031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (201, 'wal', 'ack-201');
COMMIT;
SELECT 'ack', 201;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (202, 10, X'76616C75652D3030303030323032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (202, 'wal', 'ack-202');
COMMIT;
SELECT 'ack', 202;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (203, 11, X'76616C75652D3030303030323033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (203, 'wal', 'ack-203');
COMMIT;
SELECT 'ack', 203;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (204, 12, X'76616C75652D3030303030323034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (204, 'wal', 'ack-204');
COMMIT;
SELECT 'ack', 204;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (205, 13, X'76616C75652D3030303030323035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (205, 'wal', 'ack-205');
COMMIT;
SELECT 'ack', 205;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (206, 14, X'76616C75652D3030303030323036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (206, 'wal', 'ack-206');
COMMIT;
SELECT 'ack', 206;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (207, 15, X'76616C75652D3030303030323037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (207, 'wal', 'ack-207');
COMMIT;
SELECT 'ack', 207;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (208, 16, X'76616C75652D3030303030323038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (208, 'wal', 'ack-208');
COMMIT;
SELECT 'ack', 208;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (209, 17, X'76616C75652D3030303030323039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (209, 'wal', 'ack-209');
COMMIT;
SELECT 'ack', 209;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (210, 18, X'76616C75652D3030303030323130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (210, 'wal', 'ack-210');
COMMIT;
SELECT 'ack', 210;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (211, 19, X'76616C75652D3030303030323131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (211, 'wal', 'ack-211');
COMMIT;
SELECT 'ack', 211;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (212, 20, X'76616C75652D3030303030323132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (212, 'wal', 'ack-212');
COMMIT;
SELECT 'ack', 212;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (213, 21, X'76616C75652D3030303030323133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (213, 'wal', 'ack-213');
COMMIT;
SELECT 'ack', 213;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (214, 22, X'76616C75652D3030303030323134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (214, 'wal', 'ack-214');
COMMIT;
SELECT 'ack', 214;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (215, 23, X'76616C75652D3030303030323135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (215, 'wal', 'ack-215');
COMMIT;
SELECT 'ack', 215;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (216, 24, X'76616C75652D3030303030323136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (216, 'wal', 'ack-216');
COMMIT;
SELECT 'ack', 216;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (217, 25, X'76616C75652D3030303030323137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (217, 'wal', 'ack-217');
COMMIT;
SELECT 'ack', 217;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (218, 26, X'76616C75652D3030303030323138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (218, 'wal', 'ack-218');
COMMIT;
SELECT 'ack', 218;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (219, 27, X'76616C75652D3030303030323139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (219, 'wal', 'ack-219');
COMMIT;
SELECT 'ack', 219;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (220, 28, X'76616C75652D3030303030323230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (220, 'wal', 'ack-220');
COMMIT;
SELECT 'ack', 220;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (221, 29, X'76616C75652D3030303030323231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (221, 'wal', 'ack-221');
COMMIT;
SELECT 'ack', 221;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (222, 30, X'76616C75652D3030303030323232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (222, 'wal', 'ack-222');
COMMIT;
SELECT 'ack', 222;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (223, 31, X'76616C75652D3030303030323233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (223, 'wal', 'ack-223');
COMMIT;
SELECT 'ack', 223;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (224, 0, X'76616C75652D3030303030323234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (224, 'wal', 'ack-224');
COMMIT;
SELECT 'ack', 224;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (225, 1, X'76616C75652D3030303030323235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (225, 'wal', 'ack-225');
COMMIT;
SELECT 'ack', 225;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (226, 2, X'76616C75652D3030303030323236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (226, 'wal', 'ack-226');
COMMIT;
SELECT 'ack', 226;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (227, 3, X'76616C75652D3030303030323237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (227, 'wal', 'ack-227');
COMMIT;
SELECT 'ack', 227;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (228, 4, X'76616C75652D3030303030323238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (228, 'wal', 'ack-228');
COMMIT;
SELECT 'ack', 228;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (229, 5, X'76616C75652D3030303030323239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (229, 'wal', 'ack-229');
COMMIT;
SELECT 'ack', 229;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (230, 6, X'76616C75652D3030303030323330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (230, 'wal', 'ack-230');
COMMIT;
SELECT 'ack', 230;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (231, 7, X'76616C75652D3030303030323331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (231, 'wal', 'ack-231');
COMMIT;
SELECT 'ack', 231;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (232, 8, X'76616C75652D3030303030323332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (232, 'wal', 'ack-232');
COMMIT;
SELECT 'ack', 232;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (233, 9, X'76616C75652D3030303030323333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (233, 'wal', 'ack-233');
COMMIT;
SELECT 'ack', 233;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (234, 10, X'76616C75652D3030303030323334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (234, 'wal', 'ack-234');
COMMIT;
SELECT 'ack', 234;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (235, 11, X'76616C75652D3030303030323335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (235, 'wal', 'ack-235');
COMMIT;
SELECT 'ack', 235;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (236, 12, X'76616C75652D3030303030323336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (236, 'wal', 'ack-236');
COMMIT;
SELECT 'ack', 236;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (237, 13, X'76616C75652D3030303030323337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (237, 'wal', 'ack-237');
COMMIT;
SELECT 'ack', 237;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (238, 14, X'76616C75652D3030303030323338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (238, 'wal', 'ack-238');
COMMIT;
SELECT 'ack', 238;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (239, 15, X'76616C75652D3030303030323339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (239, 'wal', 'ack-239');
COMMIT;
SELECT 'ack', 239;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (240, 16, X'76616C75652D3030303030323430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (240, 'wal', 'ack-240');
COMMIT;
SELECT 'ack', 240;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (241, 17, X'76616C75652D3030303030323431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (241, 'wal', 'ack-241');
COMMIT;
SELECT 'ack', 241;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (242, 18, X'76616C75652D3030303030323432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (242, 'wal', 'ack-242');
COMMIT;
SELECT 'ack', 242;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (243, 19, X'76616C75652D3030303030323433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (243, 'wal', 'ack-243');
COMMIT;
SELECT 'ack', 243;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (244, 20, X'76616C75652D3030303030323434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (244, 'wal', 'ack-244');
COMMIT;
SELECT 'ack', 244;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (245, 21, X'76616C75652D3030303030323435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (245, 'wal', 'ack-245');
COMMIT;
SELECT 'ack', 245;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (246, 22, X'76616C75652D3030303030323436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (246, 'wal', 'ack-246');
COMMIT;
SELECT 'ack', 246;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (247, 23, X'76616C75652D3030303030323437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (247, 'wal', 'ack-247');
COMMIT;
SELECT 'ack', 247;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (248, 24, X'76616C75652D3030303030323438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (248, 'wal', 'ack-248');
COMMIT;
SELECT 'ack', 248;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (249, 25, X'76616C75652D3030303030323439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (249, 'wal', 'ack-249');
COMMIT;
SELECT 'ack', 249;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (250, 26, X'76616C75652D3030303030323530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (250, 'wal', 'ack-250');
COMMIT;
SELECT 'ack', 250;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (251, 27, X'76616C75652D3030303030323531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (251, 'wal', 'ack-251');
COMMIT;
SELECT 'ack', 251;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (252, 28, X'76616C75652D3030303030323532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (252, 'wal', 'ack-252');
COMMIT;
SELECT 'ack', 252;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (253, 29, X'76616C75652D3030303030323533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (253, 'wal', 'ack-253');
COMMIT;
SELECT 'ack', 253;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (254, 30, X'76616C75652D3030303030323534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (254, 'wal', 'ack-254');
COMMIT;
SELECT 'ack', 254;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (255, 31, X'76616C75652D3030303030323535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (255, 'wal', 'ack-255');
COMMIT;
SELECT 'ack', 255;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (256, 0, X'76616C75652D3030303030323536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (256, 'wal', 'ack-256');
COMMIT;
SELECT 'ack', 256;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (257, 1, X'76616C75652D3030303030323537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (257, 'wal', 'ack-257');
COMMIT;
SELECT 'ack', 257;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (258, 2, X'76616C75652D3030303030323538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (258, 'wal', 'ack-258');
COMMIT;
SELECT 'ack', 258;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (259, 3, X'76616C75652D3030303030323539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (259, 'wal', 'ack-259');
COMMIT;
SELECT 'ack', 259;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (260, 4, X'76616C75652D3030303030323630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (260, 'wal', 'ack-260');
COMMIT;
SELECT 'ack', 260;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (261, 5, X'76616C75652D3030303030323631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (261, 'wal', 'ack-261');
COMMIT;
SELECT 'ack', 261;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (262, 6, X'76616C75652D3030303030323632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (262, 'wal', 'ack-262');
COMMIT;
SELECT 'ack', 262;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (263, 7, X'76616C75652D3030303030323633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (263, 'wal', 'ack-263');
COMMIT;
SELECT 'ack', 263;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (264, 8, X'76616C75652D3030303030323634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (264, 'wal', 'ack-264');
COMMIT;
SELECT 'ack', 264;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (265, 9, X'76616C75652D3030303030323635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (265, 'wal', 'ack-265');
COMMIT;
SELECT 'ack', 265;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (266, 10, X'76616C75652D3030303030323636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (266, 'wal', 'ack-266');
COMMIT;
SELECT 'ack', 266;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (267, 11, X'76616C75652D3030303030323637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (267, 'wal', 'ack-267');
COMMIT;
SELECT 'ack', 267;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (268, 12, X'76616C75652D3030303030323638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (268, 'wal', 'ack-268');
COMMIT;
SELECT 'ack', 268;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (269, 13, X'76616C75652D3030303030323639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (269, 'wal', 'ack-269');
COMMIT;
SELECT 'ack', 269;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (270, 14, X'76616C75652D3030303030323730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (270, 'wal', 'ack-270');
COMMIT;
SELECT 'ack', 270;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (271, 15, X'76616C75652D3030303030323731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (271, 'wal', 'ack-271');
COMMIT;
SELECT 'ack', 271;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (272, 16, X'76616C75652D3030303030323732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (272, 'wal', 'ack-272');
COMMIT;
SELECT 'ack', 272;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (273, 17, X'76616C75652D3030303030323733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (273, 'wal', 'ack-273');
COMMIT;
SELECT 'ack', 273;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (274, 18, X'76616C75652D3030303030323734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (274, 'wal', 'ack-274');
COMMIT;
SELECT 'ack', 274;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (275, 19, X'76616C75652D3030303030323735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (275, 'wal', 'ack-275');
COMMIT;
SELECT 'ack', 275;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (276, 20, X'76616C75652D3030303030323736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (276, 'wal', 'ack-276');
COMMIT;
SELECT 'ack', 276;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (277, 21, X'76616C75652D3030303030323737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (277, 'wal', 'ack-277');
COMMIT;
SELECT 'ack', 277;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (278, 22, X'76616C75652D3030303030323738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (278, 'wal', 'ack-278');
COMMIT;
SELECT 'ack', 278;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (279, 23, X'76616C75652D3030303030323739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (279, 'wal', 'ack-279');
COMMIT;
SELECT 'ack', 279;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (280, 24, X'76616C75652D3030303030323830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (280, 'wal', 'ack-280');
COMMIT;
SELECT 'ack', 280;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (281, 25, X'76616C75652D3030303030323831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (281, 'wal', 'ack-281');
COMMIT;
SELECT 'ack', 281;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (282, 26, X'76616C75652D3030303030323832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (282, 'wal', 'ack-282');
COMMIT;
SELECT 'ack', 282;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (283, 27, X'76616C75652D3030303030323833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (283, 'wal', 'ack-283');
COMMIT;
SELECT 'ack', 283;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (284, 28, X'76616C75652D3030303030323834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (284, 'wal', 'ack-284');
COMMIT;
SELECT 'ack', 284;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (285, 29, X'76616C75652D3030303030323835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (285, 'wal', 'ack-285');
COMMIT;
SELECT 'ack', 285;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (286, 30, X'76616C75652D3030303030323836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (286, 'wal', 'ack-286');
COMMIT;
SELECT 'ack', 286;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (287, 31, X'76616C75652D3030303030323837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (287, 'wal', 'ack-287');
COMMIT;
SELECT 'ack', 287;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (288, 0, X'76616C75652D3030303030323838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (288, 'wal', 'ack-288');
COMMIT;
SELECT 'ack', 288;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (289, 1, X'76616C75652D3030303030323839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (289, 'wal', 'ack-289');
COMMIT;
SELECT 'ack', 289;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (290, 2, X'76616C75652D3030303030323930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (290, 'wal', 'ack-290');
COMMIT;
SELECT 'ack', 290;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (291, 3, X'76616C75652D3030303030323931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (291, 'wal', 'ack-291');
COMMIT;
SELECT 'ack', 291;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (292, 4, X'76616C75652D3030303030323932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (292, 'wal', 'ack-292');
COMMIT;
SELECT 'ack', 292;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (293, 5, X'76616C75652D3030303030323933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (293, 'wal', 'ack-293');
COMMIT;
SELECT 'ack', 293;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (294, 6, X'76616C75652D3030303030323934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (294, 'wal', 'ack-294');
COMMIT;
SELECT 'ack', 294;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (295, 7, X'76616C75652D3030303030323935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (295, 'wal', 'ack-295');
COMMIT;
SELECT 'ack', 295;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (296, 8, X'76616C75652D3030303030323936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (296, 'wal', 'ack-296');
COMMIT;
SELECT 'ack', 296;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (297, 9, X'76616C75652D3030303030323937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (297, 'wal', 'ack-297');
COMMIT;
SELECT 'ack', 297;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (298, 10, X'76616C75652D3030303030323938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (298, 'wal', 'ack-298');
COMMIT;
SELECT 'ack', 298;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (299, 11, X'76616C75652D3030303030323939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (299, 'wal', 'ack-299');
COMMIT;
SELECT 'ack', 299;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (300, 12, X'76616C75652D3030303030333030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (300, 'wal', 'ack-300');
COMMIT;
SELECT 'ack', 300;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (301, 13, X'76616C75652D3030303030333031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (301, 'wal', 'ack-301');
COMMIT;
SELECT 'ack', 301;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (302, 14, X'76616C75652D3030303030333032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (302, 'wal', 'ack-302');
COMMIT;
SELECT 'ack', 302;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (303, 15, X'76616C75652D3030303030333033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (303, 'wal', 'ack-303');
COMMIT;
SELECT 'ack', 303;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (304, 16, X'76616C75652D3030303030333034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (304, 'wal', 'ack-304');
COMMIT;
SELECT 'ack', 304;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (305, 17, X'76616C75652D3030303030333035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (305, 'wal', 'ack-305');
COMMIT;
SELECT 'ack', 305;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (306, 18, X'76616C75652D3030303030333036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (306, 'wal', 'ack-306');
COMMIT;
SELECT 'ack', 306;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (307, 19, X'76616C75652D3030303030333037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (307, 'wal', 'ack-307');
COMMIT;
SELECT 'ack', 307;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (308, 20, X'76616C75652D3030303030333038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (308, 'wal', 'ack-308');
COMMIT;
SELECT 'ack', 308;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (309, 21, X'76616C75652D3030303030333039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (309, 'wal', 'ack-309');
COMMIT;
SELECT 'ack', 309;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (310, 22, X'76616C75652D3030303030333130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (310, 'wal', 'ack-310');
COMMIT;
SELECT 'ack', 310;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (311, 23, X'76616C75652D3030303030333131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (311, 'wal', 'ack-311');
COMMIT;
SELECT 'ack', 311;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (312, 24, X'76616C75652D3030303030333132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (312, 'wal', 'ack-312');
COMMIT;
SELECT 'ack', 312;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (313, 25, X'76616C75652D3030303030333133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (313, 'wal', 'ack-313');
COMMIT;
SELECT 'ack', 313;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (314, 26, X'76616C75652D3030303030333134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (314, 'wal', 'ack-314');
COMMIT;
SELECT 'ack', 314;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (315, 27, X'76616C75652D3030303030333135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (315, 'wal', 'ack-315');
COMMIT;
SELECT 'ack', 315;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (316, 28, X'76616C75652D3030303030333136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (316, 'wal', 'ack-316');
COMMIT;
SELECT 'ack', 316;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (317, 29, X'76616C75652D3030303030333137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (317, 'wal', 'ack-317');
COMMIT;
SELECT 'ack', 317;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (318, 30, X'76616C75652D3030303030333138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (318, 'wal', 'ack-318');
COMMIT;
SELECT 'ack', 318;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (319, 31, X'76616C75652D3030303030333139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (319, 'wal', 'ack-319');
COMMIT;
SELECT 'ack', 319;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (320, 0, X'76616C75652D3030303030333230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (320, 'wal', 'ack-320');
COMMIT;
SELECT 'ack', 320;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (321, 1, X'76616C75652D3030303030333231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (321, 'wal', 'ack-321');
COMMIT;
SELECT 'ack', 321;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (322, 2, X'76616C75652D3030303030333232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (322, 'wal', 'ack-322');
COMMIT;
SELECT 'ack', 322;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (323, 3, X'76616C75652D3030303030333233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (323, 'wal', 'ack-323');
COMMIT;
SELECT 'ack', 323;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (324, 4, X'76616C75652D3030303030333234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (324, 'wal', 'ack-324');
COMMIT;
SELECT 'ack', 324;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (325, 5, X'76616C75652D3030303030333235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (325, 'wal', 'ack-325');
COMMIT;
SELECT 'ack', 325;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (326, 6, X'76616C75652D3030303030333236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (326, 'wal', 'ack-326');
COMMIT;
SELECT 'ack', 326;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (327, 7, X'76616C75652D3030303030333237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (327, 'wal', 'ack-327');
COMMIT;
SELECT 'ack', 327;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (328, 8, X'76616C75652D3030303030333238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (328, 'wal', 'ack-328');
COMMIT;
SELECT 'ack', 328;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (329, 9, X'76616C75652D3030303030333239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (329, 'wal', 'ack-329');
COMMIT;
SELECT 'ack', 329;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (330, 10, X'76616C75652D3030303030333330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (330, 'wal', 'ack-330');
COMMIT;
SELECT 'ack', 330;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (331, 11, X'76616C75652D3030303030333331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (331, 'wal', 'ack-331');
COMMIT;
SELECT 'ack', 331;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (332, 12, X'76616C75652D3030303030333332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (332, 'wal', 'ack-332');
COMMIT;
SELECT 'ack', 332;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (333, 13, X'76616C75652D3030303030333333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (333, 'wal', 'ack-333');
COMMIT;
SELECT 'ack', 333;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (334, 14, X'76616C75652D3030303030333334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (334, 'wal', 'ack-334');
COMMIT;
SELECT 'ack', 334;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (335, 15, X'76616C75652D3030303030333335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (335, 'wal', 'ack-335');
COMMIT;
SELECT 'ack', 335;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (336, 16, X'76616C75652D3030303030333336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (336, 'wal', 'ack-336');
COMMIT;
SELECT 'ack', 336;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (337, 17, X'76616C75652D3030303030333337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (337, 'wal', 'ack-337');
COMMIT;
SELECT 'ack', 337;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (338, 18, X'76616C75652D3030303030333338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (338, 'wal', 'ack-338');
COMMIT;
SELECT 'ack', 338;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (339, 19, X'76616C75652D3030303030333339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (339, 'wal', 'ack-339');
COMMIT;
SELECT 'ack', 339;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (340, 20, X'76616C75652D3030303030333430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (340, 'wal', 'ack-340');
COMMIT;
SELECT 'ack', 340;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (341, 21, X'76616C75652D3030303030333431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (341, 'wal', 'ack-341');
COMMIT;
SELECT 'ack', 341;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (342, 22, X'76616C75652D3030303030333432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (342, 'wal', 'ack-342');
COMMIT;
SELECT 'ack', 342;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (343, 23, X'76616C75652D3030303030333433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (343, 'wal', 'ack-343');
COMMIT;
SELECT 'ack', 343;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (344, 24, X'76616C75652D3030303030333434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (344, 'wal', 'ack-344');
COMMIT;
SELECT 'ack', 344;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (345, 25, X'76616C75652D3030303030333435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (345, 'wal', 'ack-345');
COMMIT;
SELECT 'ack', 345;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (346, 26, X'76616C75652D3030303030333436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (346, 'wal', 'ack-346');
COMMIT;
SELECT 'ack', 346;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (347, 27, X'76616C75652D3030303030333437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (347, 'wal', 'ack-347');
COMMIT;
SELECT 'ack', 347;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (348, 28, X'76616C75652D3030303030333438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (348, 'wal', 'ack-348');
COMMIT;
SELECT 'ack', 348;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (349, 29, X'76616C75652D3030303030333439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (349, 'wal', 'ack-349');
COMMIT;
SELECT 'ack', 349;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (350, 30, X'76616C75652D3030303030333530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (350, 'wal', 'ack-350');
COMMIT;
SELECT 'ack', 350;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (351, 31, X'76616C75652D3030303030333531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (351, 'wal', 'ack-351');
COMMIT;
SELECT 'ack', 351;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (352, 0, X'76616C75652D3030303030333532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (352, 'wal', 'ack-352');
COMMIT;
SELECT 'ack', 352;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (353, 1, X'76616C75652D3030303030333533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (353, 'wal', 'ack-353');
COMMIT;
SELECT 'ack', 353;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (354, 2, X'76616C75652D3030303030333534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (354, 'wal', 'ack-354');
COMMIT;
SELECT 'ack', 354;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (355, 3, X'76616C75652D3030303030333535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (355, 'wal', 'ack-355');
COMMIT;
SELECT 'ack', 355;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (356, 4, X'76616C75652D3030303030333536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (356, 'wal', 'ack-356');
COMMIT;
SELECT 'ack', 356;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (357, 5, X'76616C75652D3030303030333537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (357, 'wal', 'ack-357');
COMMIT;
SELECT 'ack', 357;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (358, 6, X'76616C75652D3030303030333538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (358, 'wal', 'ack-358');
COMMIT;
SELECT 'ack', 358;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (359, 7, X'76616C75652D3030303030333539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (359, 'wal', 'ack-359');
COMMIT;
SELECT 'ack', 359;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (360, 8, X'76616C75652D3030303030333630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (360, 'wal', 'ack-360');
COMMIT;
SELECT 'ack', 360;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (361, 9, X'76616C75652D3030303030333631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (361, 'wal', 'ack-361');
COMMIT;
SELECT 'ack', 361;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (362, 10, X'76616C75652D3030303030333632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (362, 'wal', 'ack-362');
COMMIT;
SELECT 'ack', 362;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (363, 11, X'76616C75652D3030303030333633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (363, 'wal', 'ack-363');
COMMIT;
SELECT 'ack', 363;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (364, 12, X'76616C75652D3030303030333634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (364, 'wal', 'ack-364');
COMMIT;
SELECT 'ack', 364;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (365, 13, X'76616C75652D3030303030333635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (365, 'wal', 'ack-365');
COMMIT;
SELECT 'ack', 365;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (366, 14, X'76616C75652D3030303030333636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (366, 'wal', 'ack-366');
COMMIT;
SELECT 'ack', 366;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (367, 15, X'76616C75652D3030303030333637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (367, 'wal', 'ack-367');
COMMIT;
SELECT 'ack', 367;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (368, 16, X'76616C75652D3030303030333638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (368, 'wal', 'ack-368');
COMMIT;
SELECT 'ack', 368;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (369, 17, X'76616C75652D3030303030333639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (369, 'wal', 'ack-369');
COMMIT;
SELECT 'ack', 369;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (370, 18, X'76616C75652D3030303030333730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (370, 'wal', 'ack-370');
COMMIT;
SELECT 'ack', 370;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (371, 19, X'76616C75652D3030303030333731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (371, 'wal', 'ack-371');
COMMIT;
SELECT 'ack', 371;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (372, 20, X'76616C75652D3030303030333732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (372, 'wal', 'ack-372');
COMMIT;
SELECT 'ack', 372;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (373, 21, X'76616C75652D3030303030333733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (373, 'wal', 'ack-373');
COMMIT;
SELECT 'ack', 373;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (374, 22, X'76616C75652D3030303030333734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (374, 'wal', 'ack-374');
COMMIT;
SELECT 'ack', 374;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (375, 23, X'76616C75652D3030303030333735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (375, 'wal', 'ack-375');
COMMIT;
SELECT 'ack', 375;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (376, 24, X'76616C75652D3030303030333736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (376, 'wal', 'ack-376');
COMMIT;
SELECT 'ack', 376;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (377, 25, X'76616C75652D3030303030333737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (377, 'wal', 'ack-377');
COMMIT;
SELECT 'ack', 377;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (378, 26, X'76616C75652D3030303030333738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (378, 'wal', 'ack-378');
COMMIT;
SELECT 'ack', 378;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (379, 27, X'76616C75652D3030303030333739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (379, 'wal', 'ack-379');
COMMIT;
SELECT 'ack', 379;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (380, 28, X'76616C75652D3030303030333830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (380, 'wal', 'ack-380');
COMMIT;
SELECT 'ack', 380;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (381, 29, X'76616C75652D3030303030333831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (381, 'wal', 'ack-381');
COMMIT;
SELECT 'ack', 381;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (382, 30, X'76616C75652D3030303030333832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (382, 'wal', 'ack-382');
COMMIT;
SELECT 'ack', 382;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (383, 31, X'76616C75652D3030303030333833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (383, 'wal', 'ack-383');
COMMIT;
SELECT 'ack', 383;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (384, 0, X'76616C75652D3030303030333834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (384, 'wal', 'ack-384');
COMMIT;
SELECT 'ack', 384;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (385, 1, X'76616C75652D3030303030333835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (385, 'wal', 'ack-385');
COMMIT;
SELECT 'ack', 385;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (386, 2, X'76616C75652D3030303030333836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (386, 'wal', 'ack-386');
COMMIT;
SELECT 'ack', 386;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (387, 3, X'76616C75652D3030303030333837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (387, 'wal', 'ack-387');
COMMIT;
SELECT 'ack', 387;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (388, 4, X'76616C75652D3030303030333838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (388, 'wal', 'ack-388');
COMMIT;
SELECT 'ack', 388;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (389, 5, X'76616C75652D3030303030333839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (389, 'wal', 'ack-389');
COMMIT;
SELECT 'ack', 389;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (390, 6, X'76616C75652D3030303030333930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (390, 'wal', 'ack-390');
COMMIT;
SELECT 'ack', 390;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (391, 7, X'76616C75652D3030303030333931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (391, 'wal', 'ack-391');
COMMIT;
SELECT 'ack', 391;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (392, 8, X'76616C75652D3030303030333932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (392, 'wal', 'ack-392');
COMMIT;
SELECT 'ack', 392;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (393, 9, X'76616C75652D3030303030333933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (393, 'wal', 'ack-393');
COMMIT;
SELECT 'ack', 393;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (394, 10, X'76616C75652D3030303030333934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (394, 'wal', 'ack-394');
COMMIT;
SELECT 'ack', 394;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (395, 11, X'76616C75652D3030303030333935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (395, 'wal', 'ack-395');
COMMIT;
SELECT 'ack', 395;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (396, 12, X'76616C75652D3030303030333936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (396, 'wal', 'ack-396');
COMMIT;
SELECT 'ack', 396;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (397, 13, X'76616C75652D3030303030333937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (397, 'wal', 'ack-397');
COMMIT;
SELECT 'ack', 397;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (398, 14, X'76616C75652D3030303030333938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (398, 'wal', 'ack-398');
COMMIT;
SELECT 'ack', 398;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (399, 15, X'76616C75652D3030303030333939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (399, 'wal', 'ack-399');
COMMIT;
SELECT 'ack', 399;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (400, 16, X'76616C75652D3030303030343030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (400, 'wal', 'ack-400');
COMMIT;
SELECT 'ack', 400;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (401, 17, X'76616C75652D3030303030343031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (401, 'wal', 'ack-401');
COMMIT;
SELECT 'ack', 401;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (402, 18, X'76616C75652D3030303030343032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (402, 'wal', 'ack-402');
COMMIT;
SELECT 'ack', 402;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (403, 19, X'76616C75652D3030303030343033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (403, 'wal', 'ack-403');
COMMIT;
SELECT 'ack', 403;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (404, 20, X'76616C75652D3030303030343034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (404, 'wal', 'ack-404');
COMMIT;
SELECT 'ack', 404;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (405, 21, X'76616C75652D3030303030343035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (405, 'wal', 'ack-405');
COMMIT;
SELECT 'ack', 405;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (406, 22, X'76616C75652D3030303030343036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (406, 'wal', 'ack-406');
COMMIT;
SELECT 'ack', 406;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (407, 23, X'76616C75652D3030303030343037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (407, 'wal', 'ack-407');
COMMIT;
SELECT 'ack', 407;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (408, 24, X'76616C75652D3030303030343038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (408, 'wal', 'ack-408');
COMMIT;
SELECT 'ack', 408;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (409, 25, X'76616C75652D3030303030343039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (409, 'wal', 'ack-409');
COMMIT;
SELECT 'ack', 409;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (410, 26, X'76616C75652D3030303030343130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (410, 'wal', 'ack-410');
COMMIT;
SELECT 'ack', 410;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (411, 27, X'76616C75652D3030303030343131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (411, 'wal', 'ack-411');
COMMIT;
SELECT 'ack', 411;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (412, 28, X'76616C75652D3030303030343132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (412, 'wal', 'ack-412');
COMMIT;
SELECT 'ack', 412;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (413, 29, X'76616C75652D3030303030343133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (413, 'wal', 'ack-413');
COMMIT;
SELECT 'ack', 413;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (414, 30, X'76616C75652D3030303030343134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (414, 'wal', 'ack-414');
COMMIT;
SELECT 'ack', 414;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (415, 31, X'76616C75652D3030303030343135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (415, 'wal', 'ack-415');
COMMIT;
SELECT 'ack', 415;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (416, 0, X'76616C75652D3030303030343136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (416, 'wal', 'ack-416');
COMMIT;
SELECT 'ack', 416;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (417, 1, X'76616C75652D3030303030343137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (417, 'wal', 'ack-417');
COMMIT;
SELECT 'ack', 417;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (418, 2, X'76616C75652D3030303030343138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (418, 'wal', 'ack-418');
COMMIT;
SELECT 'ack', 418;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (419, 3, X'76616C75652D3030303030343139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (419, 'wal', 'ack-419');
COMMIT;
SELECT 'ack', 419;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (420, 4, X'76616C75652D3030303030343230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (420, 'wal', 'ack-420');
COMMIT;
SELECT 'ack', 420;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (421, 5, X'76616C75652D3030303030343231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (421, 'wal', 'ack-421');
COMMIT;
SELECT 'ack', 421;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (422, 6, X'76616C75652D3030303030343232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (422, 'wal', 'ack-422');
COMMIT;
SELECT 'ack', 422;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (423, 7, X'76616C75652D3030303030343233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (423, 'wal', 'ack-423');
COMMIT;
SELECT 'ack', 423;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (424, 8, X'76616C75652D3030303030343234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (424, 'wal', 'ack-424');
COMMIT;
SELECT 'ack', 424;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (425, 9, X'76616C75652D3030303030343235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (425, 'wal', 'ack-425');
COMMIT;
SELECT 'ack', 425;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (426, 10, X'76616C75652D3030303030343236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (426, 'wal', 'ack-426');
COMMIT;
SELECT 'ack', 426;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (427, 11, X'76616C75652D3030303030343237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (427, 'wal', 'ack-427');
COMMIT;
SELECT 'ack', 427;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (428, 12, X'76616C75652D3030303030343238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (428, 'wal', 'ack-428');
COMMIT;
SELECT 'ack', 428;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (429, 13, X'76616C75652D3030303030343239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (429, 'wal', 'ack-429');
COMMIT;
SELECT 'ack', 429;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (430, 14, X'76616C75652D3030303030343330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (430, 'wal', 'ack-430');
COMMIT;
SELECT 'ack', 430;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (431, 15, X'76616C75652D3030303030343331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (431, 'wal', 'ack-431');
COMMIT;
SELECT 'ack', 431;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (432, 16, X'76616C75652D3030303030343332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (432, 'wal', 'ack-432');
COMMIT;
SELECT 'ack', 432;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (433, 17, X'76616C75652D3030303030343333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (433, 'wal', 'ack-433');
COMMIT;
SELECT 'ack', 433;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (434, 18, X'76616C75652D3030303030343334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (434, 'wal', 'ack-434');
COMMIT;
SELECT 'ack', 434;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (435, 19, X'76616C75652D3030303030343335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (435, 'wal', 'ack-435');
COMMIT;
SELECT 'ack', 435;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (436, 20, X'76616C75652D3030303030343336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (436, 'wal', 'ack-436');
COMMIT;
SELECT 'ack', 436;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (437, 21, X'76616C75652D3030303030343337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (437, 'wal', 'ack-437');
COMMIT;
SELECT 'ack', 437;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (438, 22, X'76616C75652D3030303030343338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (438, 'wal', 'ack-438');
COMMIT;
SELECT 'ack', 438;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (439, 23, X'76616C75652D3030303030343339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (439, 'wal', 'ack-439');
COMMIT;
SELECT 'ack', 439;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (440, 24, X'76616C75652D3030303030343430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (440, 'wal', 'ack-440');
COMMIT;
SELECT 'ack', 440;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (441, 25, X'76616C75652D3030303030343431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (441, 'wal', 'ack-441');
COMMIT;
SELECT 'ack', 441;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (442, 26, X'76616C75652D3030303030343432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (442, 'wal', 'ack-442');
COMMIT;
SELECT 'ack', 442;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (443, 27, X'76616C75652D3030303030343433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (443, 'wal', 'ack-443');
COMMIT;
SELECT 'ack', 443;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (444, 28, X'76616C75652D3030303030343434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (444, 'wal', 'ack-444');
COMMIT;
SELECT 'ack', 444;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (445, 29, X'76616C75652D3030303030343435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (445, 'wal', 'ack-445');
COMMIT;
SELECT 'ack', 445;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (446, 30, X'76616C75652D3030303030343436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (446, 'wal', 'ack-446');
COMMIT;
SELECT 'ack', 446;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (447, 31, X'76616C75652D3030303030343437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (447, 'wal', 'ack-447');
COMMIT;
SELECT 'ack', 447;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (448, 0, X'76616C75652D3030303030343438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (448, 'wal', 'ack-448');
COMMIT;
SELECT 'ack', 448;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (449, 1, X'76616C75652D3030303030343439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (449, 'wal', 'ack-449');
COMMIT;
SELECT 'ack', 449;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (450, 2, X'76616C75652D3030303030343530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (450, 'wal', 'ack-450');
COMMIT;
SELECT 'ack', 450;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (451, 3, X'76616C75652D3030303030343531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (451, 'wal', 'ack-451');
COMMIT;
SELECT 'ack', 451;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (452, 4, X'76616C75652D3030303030343532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (452, 'wal', 'ack-452');
COMMIT;
SELECT 'ack', 452;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (453, 5, X'76616C75652D3030303030343533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (453, 'wal', 'ack-453');
COMMIT;
SELECT 'ack', 453;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (454, 6, X'76616C75652D3030303030343534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (454, 'wal', 'ack-454');
COMMIT;
SELECT 'ack', 454;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (455, 7, X'76616C75652D3030303030343535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (455, 'wal', 'ack-455');
COMMIT;
SELECT 'ack', 455;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (456, 8, X'76616C75652D3030303030343536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (456, 'wal', 'ack-456');
COMMIT;
SELECT 'ack', 456;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (457, 9, X'76616C75652D3030303030343537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (457, 'wal', 'ack-457');
COMMIT;
SELECT 'ack', 457;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (458, 10, X'76616C75652D3030303030343538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (458, 'wal', 'ack-458');
COMMIT;
SELECT 'ack', 458;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (459, 11, X'76616C75652D3030303030343539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (459, 'wal', 'ack-459');
COMMIT;
SELECT 'ack', 459;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (460, 12, X'76616C75652D3030303030343630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (460, 'wal', 'ack-460');
COMMIT;
SELECT 'ack', 460;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (461, 13, X'76616C75652D3030303030343631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (461, 'wal', 'ack-461');
COMMIT;
SELECT 'ack', 461;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (462, 14, X'76616C75652D3030303030343632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (462, 'wal', 'ack-462');
COMMIT;
SELECT 'ack', 462;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (463, 15, X'76616C75652D3030303030343633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (463, 'wal', 'ack-463');
COMMIT;
SELECT 'ack', 463;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (464, 16, X'76616C75652D3030303030343634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (464, 'wal', 'ack-464');
COMMIT;
SELECT 'ack', 464;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (465, 17, X'76616C75652D3030303030343635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (465, 'wal', 'ack-465');
COMMIT;
SELECT 'ack', 465;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (466, 18, X'76616C75652D3030303030343636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (466, 'wal', 'ack-466');
COMMIT;
SELECT 'ack', 466;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (467, 19, X'76616C75652D3030303030343637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (467, 'wal', 'ack-467');
COMMIT;
SELECT 'ack', 467;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (468, 20, X'76616C75652D3030303030343638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (468, 'wal', 'ack-468');
COMMIT;
SELECT 'ack', 468;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (469, 21, X'76616C75652D3030303030343639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (469, 'wal', 'ack-469');
COMMIT;
SELECT 'ack', 469;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (470, 22, X'76616C75652D3030303030343730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (470, 'wal', 'ack-470');
COMMIT;
SELECT 'ack', 470;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (471, 23, X'76616C75652D3030303030343731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (471, 'wal', 'ack-471');
COMMIT;
SELECT 'ack', 471;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (472, 24, X'76616C75652D3030303030343732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (472, 'wal', 'ack-472');
COMMIT;
SELECT 'ack', 472;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (473, 25, X'76616C75652D3030303030343733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (473, 'wal', 'ack-473');
COMMIT;
SELECT 'ack', 473;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (474, 26, X'76616C75652D3030303030343734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (474, 'wal', 'ack-474');
COMMIT;
SELECT 'ack', 474;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (475, 27, X'76616C75652D3030303030343735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (475, 'wal', 'ack-475');
COMMIT;
SELECT 'ack', 475;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (476, 28, X'76616C75652D3030303030343736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (476, 'wal', 'ack-476');
COMMIT;
SELECT 'ack', 476;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (477, 29, X'76616C75652D3030303030343737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (477, 'wal', 'ack-477');
COMMIT;
SELECT 'ack', 477;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (478, 30, X'76616C75652D3030303030343738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (478, 'wal', 'ack-478');
COMMIT;
SELECT 'ack', 478;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (479, 31, X'76616C75652D3030303030343739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (479, 'wal', 'ack-479');
COMMIT;
SELECT 'ack', 479;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (480, 0, X'76616C75652D3030303030343830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (480, 'wal', 'ack-480');
COMMIT;
SELECT 'ack', 480;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (481, 1, X'76616C75652D3030303030343831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (481, 'wal', 'ack-481');
COMMIT;
SELECT 'ack', 481;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (482, 2, X'76616C75652D3030303030343832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (482, 'wal', 'ack-482');
COMMIT;
SELECT 'ack', 482;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (483, 3, X'76616C75652D3030303030343833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (483, 'wal', 'ack-483');
COMMIT;
SELECT 'ack', 483;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (484, 4, X'76616C75652D3030303030343834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (484, 'wal', 'ack-484');
COMMIT;
SELECT 'ack', 484;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (485, 5, X'76616C75652D3030303030343835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (485, 'wal', 'ack-485');
COMMIT;
SELECT 'ack', 485;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (486, 6, X'76616C75652D3030303030343836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (486, 'wal', 'ack-486');
COMMIT;
SELECT 'ack', 486;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (487, 7, X'76616C75652D3030303030343837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (487, 'wal', 'ack-487');
COMMIT;
SELECT 'ack', 487;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (488, 8, X'76616C75652D3030303030343838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (488, 'wal', 'ack-488');
COMMIT;
SELECT 'ack', 488;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (489, 9, X'76616C75652D3030303030343839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (489, 'wal', 'ack-489');
COMMIT;
SELECT 'ack', 489;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (490, 10, X'76616C75652D3030303030343930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (490, 'wal', 'ack-490');
COMMIT;
SELECT 'ack', 490;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (491, 11, X'76616C75652D3030303030343931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (491, 'wal', 'ack-491');
COMMIT;
SELECT 'ack', 491;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (492, 12, X'76616C75652D3030303030343932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (492, 'wal', 'ack-492');
COMMIT;
SELECT 'ack', 492;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (493, 13, X'76616C75652D3030303030343933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (493, 'wal', 'ack-493');
COMMIT;
SELECT 'ack', 493;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (494, 14, X'76616C75652D3030303030343934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (494, 'wal', 'ack-494');
COMMIT;
SELECT 'ack', 494;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (495, 15, X'76616C75652D3030303030343935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (495, 'wal', 'ack-495');
COMMIT;
SELECT 'ack', 495;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (496, 16, X'76616C75652D3030303030343936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (496, 'wal', 'ack-496');
COMMIT;
SELECT 'ack', 496;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (497, 17, X'76616C75652D3030303030343937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (497, 'wal', 'ack-497');
COMMIT;
SELECT 'ack', 497;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (498, 18, X'76616C75652D3030303030343938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (498, 'wal', 'ack-498');
COMMIT;
SELECT 'ack', 498;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (499, 19, X'76616C75652D3030303030343939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (499, 'wal', 'ack-499');
COMMIT;
SELECT 'ack', 499;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (500, 20, X'76616C75652D3030303030353030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (500, 'wal', 'ack-500');
COMMIT;
SELECT 'ack', 500;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (501, 21, X'76616C75652D3030303030353031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (501, 'wal', 'ack-501');
COMMIT;
SELECT 'ack', 501;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (502, 22, X'76616C75652D3030303030353032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (502, 'wal', 'ack-502');
COMMIT;
SELECT 'ack', 502;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (503, 23, X'76616C75652D3030303030353033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (503, 'wal', 'ack-503');
COMMIT;
SELECT 'ack', 503;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (504, 24, X'76616C75652D3030303030353034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (504, 'wal', 'ack-504');
COMMIT;
SELECT 'ack', 504;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (505, 25, X'76616C75652D3030303030353035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (505, 'wal', 'ack-505');
COMMIT;
SELECT 'ack', 505;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (506, 26, X'76616C75652D3030303030353036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (506, 'wal', 'ack-506');
COMMIT;
SELECT 'ack', 506;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (507, 27, X'76616C75652D3030303030353037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (507, 'wal', 'ack-507');
COMMIT;
SELECT 'ack', 507;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (508, 28, X'76616C75652D3030303030353038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (508, 'wal', 'ack-508');
COMMIT;
SELECT 'ack', 508;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (509, 29, X'76616C75652D3030303030353039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (509, 'wal', 'ack-509');
COMMIT;
SELECT 'ack', 509;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (510, 30, X'76616C75652D3030303030353130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (510, 'wal', 'ack-510');
COMMIT;
SELECT 'ack', 510;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (511, 31, X'76616C75652D3030303030353131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (511, 'wal', 'ack-511');
COMMIT;
SELECT 'ack', 511;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (512, 0, X'76616C75652D3030303030353132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (512, 'wal', 'ack-512');
COMMIT;
SELECT 'ack', 512;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (513, 1, X'76616C75652D3030303030353133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (513, 'wal', 'ack-513');
COMMIT;
SELECT 'ack', 513;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (514, 2, X'76616C75652D3030303030353134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (514, 'wal', 'ack-514');
COMMIT;
SELECT 'ack', 514;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (515, 3, X'76616C75652D3030303030353135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (515, 'wal', 'ack-515');
COMMIT;
SELECT 'ack', 515;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (516, 4, X'76616C75652D3030303030353136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (516, 'wal', 'ack-516');
COMMIT;
SELECT 'ack', 516;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (517, 5, X'76616C75652D3030303030353137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (517, 'wal', 'ack-517');
COMMIT;
SELECT 'ack', 517;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (518, 6, X'76616C75652D3030303030353138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (518, 'wal', 'ack-518');
COMMIT;
SELECT 'ack', 518;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (519, 7, X'76616C75652D3030303030353139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (519, 'wal', 'ack-519');
COMMIT;
SELECT 'ack', 519;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (520, 8, X'76616C75652D3030303030353230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (520, 'wal', 'ack-520');
COMMIT;
SELECT 'ack', 520;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (521, 9, X'76616C75652D3030303030353231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (521, 'wal', 'ack-521');
COMMIT;
SELECT 'ack', 521;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (522, 10, X'76616C75652D3030303030353232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (522, 'wal', 'ack-522');
COMMIT;
SELECT 'ack', 522;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (523, 11, X'76616C75652D3030303030353233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (523, 'wal', 'ack-523');
COMMIT;
SELECT 'ack', 523;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (524, 12, X'76616C75652D3030303030353234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (524, 'wal', 'ack-524');
COMMIT;
SELECT 'ack', 524;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (525, 13, X'76616C75652D3030303030353235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (525, 'wal', 'ack-525');
COMMIT;
SELECT 'ack', 525;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (526, 14, X'76616C75652D3030303030353236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (526, 'wal', 'ack-526');
COMMIT;
SELECT 'ack', 526;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (527, 15, X'76616C75652D3030303030353237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (527, 'wal', 'ack-527');
COMMIT;
SELECT 'ack', 527;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (528, 16, X'76616C75652D3030303030353238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (528, 'wal', 'ack-528');
COMMIT;
SELECT 'ack', 528;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (529, 17, X'76616C75652D3030303030353239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (529, 'wal', 'ack-529');
COMMIT;
SELECT 'ack', 529;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (530, 18, X'76616C75652D3030303030353330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (530, 'wal', 'ack-530');
COMMIT;
SELECT 'ack', 530;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (531, 19, X'76616C75652D3030303030353331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (531, 'wal', 'ack-531');
COMMIT;
SELECT 'ack', 531;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (532, 20, X'76616C75652D3030303030353332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (532, 'wal', 'ack-532');
COMMIT;
SELECT 'ack', 532;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (533, 21, X'76616C75652D3030303030353333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (533, 'wal', 'ack-533');
COMMIT;
SELECT 'ack', 533;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (534, 22, X'76616C75652D3030303030353334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (534, 'wal', 'ack-534');
COMMIT;
SELECT 'ack', 534;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (535, 23, X'76616C75652D3030303030353335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (535, 'wal', 'ack-535');
COMMIT;
SELECT 'ack', 535;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (536, 24, X'76616C75652D3030303030353336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (536, 'wal', 'ack-536');
COMMIT;
SELECT 'ack', 536;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (537, 25, X'76616C75652D3030303030353337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (537, 'wal', 'ack-537');
COMMIT;
SELECT 'ack', 537;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (538, 26, X'76616C75652D3030303030353338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (538, 'wal', 'ack-538');
COMMIT;
SELECT 'ack', 538;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (539, 27, X'76616C75652D3030303030353339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (539, 'wal', 'ack-539');
COMMIT;
SELECT 'ack', 539;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (540, 28, X'76616C75652D3030303030353430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (540, 'wal', 'ack-540');
COMMIT;
SELECT 'ack', 540;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (541, 29, X'76616C75652D3030303030353431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (541, 'wal', 'ack-541');
COMMIT;
SELECT 'ack', 541;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (542, 30, X'76616C75652D3030303030353432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (542, 'wal', 'ack-542');
COMMIT;
SELECT 'ack', 542;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (543, 31, X'76616C75652D3030303030353433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (543, 'wal', 'ack-543');
COMMIT;
SELECT 'ack', 543;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (544, 0, X'76616C75652D3030303030353434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (544, 'wal', 'ack-544');
COMMIT;
SELECT 'ack', 544;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (545, 1, X'76616C75652D3030303030353435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (545, 'wal', 'ack-545');
COMMIT;
SELECT 'ack', 545;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (546, 2, X'76616C75652D3030303030353436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (546, 'wal', 'ack-546');
COMMIT;
SELECT 'ack', 546;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (547, 3, X'76616C75652D3030303030353437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (547, 'wal', 'ack-547');
COMMIT;
SELECT 'ack', 547;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (548, 4, X'76616C75652D3030303030353438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (548, 'wal', 'ack-548');
COMMIT;
SELECT 'ack', 548;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (549, 5, X'76616C75652D3030303030353439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (549, 'wal', 'ack-549');
COMMIT;
SELECT 'ack', 549;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (550, 6, X'76616C75652D3030303030353530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (550, 'wal', 'ack-550');
COMMIT;
SELECT 'ack', 550;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (551, 7, X'76616C75652D3030303030353531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (551, 'wal', 'ack-551');
COMMIT;
SELECT 'ack', 551;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (552, 8, X'76616C75652D3030303030353532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (552, 'wal', 'ack-552');
COMMIT;
SELECT 'ack', 552;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (553, 9, X'76616C75652D3030303030353533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (553, 'wal', 'ack-553');
COMMIT;
SELECT 'ack', 553;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (554, 10, X'76616C75652D3030303030353534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (554, 'wal', 'ack-554');
COMMIT;
SELECT 'ack', 554;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (555, 11, X'76616C75652D3030303030353535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (555, 'wal', 'ack-555');
COMMIT;
SELECT 'ack', 555;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (556, 12, X'76616C75652D3030303030353536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (556, 'wal', 'ack-556');
COMMIT;
SELECT 'ack', 556;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (557, 13, X'76616C75652D3030303030353537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (557, 'wal', 'ack-557');
COMMIT;
SELECT 'ack', 557;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (558, 14, X'76616C75652D3030303030353538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (558, 'wal', 'ack-558');
COMMIT;
SELECT 'ack', 558;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (559, 15, X'76616C75652D3030303030353539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (559, 'wal', 'ack-559');
COMMIT;
SELECT 'ack', 559;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (560, 16, X'76616C75652D3030303030353630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (560, 'wal', 'ack-560');
COMMIT;
SELECT 'ack', 560;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (561, 17, X'76616C75652D3030303030353631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (561, 'wal', 'ack-561');
COMMIT;
SELECT 'ack', 561;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (562, 18, X'76616C75652D3030303030353632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (562, 'wal', 'ack-562');
COMMIT;
SELECT 'ack', 562;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (563, 19, X'76616C75652D3030303030353633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (563, 'wal', 'ack-563');
COMMIT;
SELECT 'ack', 563;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (564, 20, X'76616C75652D3030303030353634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (564, 'wal', 'ack-564');
COMMIT;
SELECT 'ack', 564;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (565, 21, X'76616C75652D3030303030353635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (565, 'wal', 'ack-565');
COMMIT;
SELECT 'ack', 565;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (566, 22, X'76616C75652D3030303030353636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (566, 'wal', 'ack-566');
COMMIT;
SELECT 'ack', 566;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (567, 23, X'76616C75652D3030303030353637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (567, 'wal', 'ack-567');
COMMIT;
SELECT 'ack', 567;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (568, 24, X'76616C75652D3030303030353638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (568, 'wal', 'ack-568');
COMMIT;
SELECT 'ack', 568;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (569, 25, X'76616C75652D3030303030353639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (569, 'wal', 'ack-569');
COMMIT;
SELECT 'ack', 569;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (570, 26, X'76616C75652D3030303030353730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (570, 'wal', 'ack-570');
COMMIT;
SELECT 'ack', 570;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (571, 27, X'76616C75652D3030303030353731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (571, 'wal', 'ack-571');
COMMIT;
SELECT 'ack', 571;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (572, 28, X'76616C75652D3030303030353732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (572, 'wal', 'ack-572');
COMMIT;
SELECT 'ack', 572;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (573, 29, X'76616C75652D3030303030353733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (573, 'wal', 'ack-573');
COMMIT;
SELECT 'ack', 573;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (574, 30, X'76616C75652D3030303030353734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (574, 'wal', 'ack-574');
COMMIT;
SELECT 'ack', 574;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (575, 31, X'76616C75652D3030303030353735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (575, 'wal', 'ack-575');
COMMIT;
SELECT 'ack', 575;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (576, 0, X'76616C75652D3030303030353736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (576, 'wal', 'ack-576');
COMMIT;
SELECT 'ack', 576;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (577, 1, X'76616C75652D3030303030353737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (577, 'wal', 'ack-577');
COMMIT;
SELECT 'ack', 577;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (578, 2, X'76616C75652D3030303030353738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (578, 'wal', 'ack-578');
COMMIT;
SELECT 'ack', 578;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (579, 3, X'76616C75652D3030303030353739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (579, 'wal', 'ack-579');
COMMIT;
SELECT 'ack', 579;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (580, 4, X'76616C75652D3030303030353830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (580, 'wal', 'ack-580');
COMMIT;
SELECT 'ack', 580;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (581, 5, X'76616C75652D3030303030353831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (581, 'wal', 'ack-581');
COMMIT;
SELECT 'ack', 581;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (582, 6, X'76616C75652D3030303030353832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (582, 'wal', 'ack-582');
COMMIT;
SELECT 'ack', 582;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (583, 7, X'76616C75652D3030303030353833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (583, 'wal', 'ack-583');
COMMIT;
SELECT 'ack', 583;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (584, 8, X'76616C75652D3030303030353834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (584, 'wal', 'ack-584');
COMMIT;
SELECT 'ack', 584;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (585, 9, X'76616C75652D3030303030353835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (585, 'wal', 'ack-585');
COMMIT;
SELECT 'ack', 585;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (586, 10, X'76616C75652D3030303030353836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (586, 'wal', 'ack-586');
COMMIT;
SELECT 'ack', 586;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (587, 11, X'76616C75652D3030303030353837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (587, 'wal', 'ack-587');
COMMIT;
SELECT 'ack', 587;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (588, 12, X'76616C75652D3030303030353838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (588, 'wal', 'ack-588');
COMMIT;
SELECT 'ack', 588;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (589, 13, X'76616C75652D3030303030353839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (589, 'wal', 'ack-589');
COMMIT;
SELECT 'ack', 589;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (590, 14, X'76616C75652D3030303030353930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (590, 'wal', 'ack-590');
COMMIT;
SELECT 'ack', 590;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (591, 15, X'76616C75652D3030303030353931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (591, 'wal', 'ack-591');
COMMIT;
SELECT 'ack', 591;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (592, 16, X'76616C75652D3030303030353932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (592, 'wal', 'ack-592');
COMMIT;
SELECT 'ack', 592;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (593, 17, X'76616C75652D3030303030353933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (593, 'wal', 'ack-593');
COMMIT;
SELECT 'ack', 593;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (594, 18, X'76616C75652D3030303030353934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (594, 'wal', 'ack-594');
COMMIT;
SELECT 'ack', 594;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (595, 19, X'76616C75652D3030303030353935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (595, 'wal', 'ack-595');
COMMIT;
SELECT 'ack', 595;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (596, 20, X'76616C75652D3030303030353936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (596, 'wal', 'ack-596');
COMMIT;
SELECT 'ack', 596;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (597, 21, X'76616C75652D3030303030353937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (597, 'wal', 'ack-597');
COMMIT;
SELECT 'ack', 597;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (598, 22, X'76616C75652D3030303030353938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (598, 'wal', 'ack-598');
COMMIT;
SELECT 'ack', 598;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (599, 23, X'76616C75652D3030303030353939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (599, 'wal', 'ack-599');
COMMIT;
SELECT 'ack', 599;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (600, 24, X'76616C75652D3030303030363030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (600, 'wal', 'ack-600');
COMMIT;
SELECT 'ack', 600;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (601, 25, X'76616C75652D3030303030363031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (601, 'wal', 'ack-601');
COMMIT;
SELECT 'ack', 601;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (602, 26, X'76616C75652D3030303030363032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (602, 'wal', 'ack-602');
COMMIT;
SELECT 'ack', 602;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (603, 27, X'76616C75652D3030303030363033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (603, 'wal', 'ack-603');
COMMIT;
SELECT 'ack', 603;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (604, 28, X'76616C75652D3030303030363034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (604, 'wal', 'ack-604');
COMMIT;
SELECT 'ack', 604;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (605, 29, X'76616C75652D3030303030363035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (605, 'wal', 'ack-605');
COMMIT;
SELECT 'ack', 605;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (606, 30, X'76616C75652D3030303030363036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (606, 'wal', 'ack-606');
COMMIT;
SELECT 'ack', 606;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (607, 31, X'76616C75652D3030303030363037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (607, 'wal', 'ack-607');
COMMIT;
SELECT 'ack', 607;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (608, 0, X'76616C75652D3030303030363038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (608, 'wal', 'ack-608');
COMMIT;
SELECT 'ack', 608;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (609, 1, X'76616C75652D3030303030363039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (609, 'wal', 'ack-609');
COMMIT;
SELECT 'ack', 609;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (610, 2, X'76616C75652D3030303030363130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (610, 'wal', 'ack-610');
COMMIT;
SELECT 'ack', 610;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (611, 3, X'76616C75652D3030303030363131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (611, 'wal', 'ack-611');
COMMIT;
SELECT 'ack', 611;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (612, 4, X'76616C75652D3030303030363132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (612, 'wal', 'ack-612');
COMMIT;
SELECT 'ack', 612;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (613, 5, X'76616C75652D3030303030363133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (613, 'wal', 'ack-613');
COMMIT;
SELECT 'ack', 613;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (614, 6, X'76616C75652D3030303030363134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (614, 'wal', 'ack-614');
COMMIT;
SELECT 'ack', 614;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (615, 7, X'76616C75652D3030303030363135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (615, 'wal', 'ack-615');
COMMIT;
SELECT 'ack', 615;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (616, 8, X'76616C75652D3030303030363136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (616, 'wal', 'ack-616');
COMMIT;
SELECT 'ack', 616;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (617, 9, X'76616C75652D3030303030363137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (617, 'wal', 'ack-617');
COMMIT;
SELECT 'ack', 617;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (618, 10, X'76616C75652D3030303030363138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (618, 'wal', 'ack-618');
COMMIT;
SELECT 'ack', 618;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (619, 11, X'76616C75652D3030303030363139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (619, 'wal', 'ack-619');
COMMIT;
SELECT 'ack', 619;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (620, 12, X'76616C75652D3030303030363230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (620, 'wal', 'ack-620');
COMMIT;
SELECT 'ack', 620;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (621, 13, X'76616C75652D3030303030363231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (621, 'wal', 'ack-621');
COMMIT;
SELECT 'ack', 621;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (622, 14, X'76616C75652D3030303030363232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (622, 'wal', 'ack-622');
COMMIT;
SELECT 'ack', 622;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (623, 15, X'76616C75652D3030303030363233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (623, 'wal', 'ack-623');
COMMIT;
SELECT 'ack', 623;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (624, 16, X'76616C75652D3030303030363234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (624, 'wal', 'ack-624');
COMMIT;
SELECT 'ack', 624;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (625, 17, X'76616C75652D3030303030363235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (625, 'wal', 'ack-625');
COMMIT;
SELECT 'ack', 625;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (626, 18, X'76616C75652D3030303030363236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (626, 'wal', 'ack-626');
COMMIT;
SELECT 'ack', 626;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (627, 19, X'76616C75652D3030303030363237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (627, 'wal', 'ack-627');
COMMIT;
SELECT 'ack', 627;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (628, 20, X'76616C75652D3030303030363238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (628, 'wal', 'ack-628');
COMMIT;
SELECT 'ack', 628;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (629, 21, X'76616C75652D3030303030363239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (629, 'wal', 'ack-629');
COMMIT;
SELECT 'ack', 629;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (630, 22, X'76616C75652D3030303030363330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (630, 'wal', 'ack-630');
COMMIT;
SELECT 'ack', 630;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (631, 23, X'76616C75652D3030303030363331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (631, 'wal', 'ack-631');
COMMIT;
SELECT 'ack', 631;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (632, 24, X'76616C75652D3030303030363332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (632, 'wal', 'ack-632');
COMMIT;
SELECT 'ack', 632;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (633, 25, X'76616C75652D3030303030363333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (633, 'wal', 'ack-633');
COMMIT;
SELECT 'ack', 633;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (634, 26, X'76616C75652D3030303030363334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (634, 'wal', 'ack-634');
COMMIT;
SELECT 'ack', 634;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (635, 27, X'76616C75652D3030303030363335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (635, 'wal', 'ack-635');
COMMIT;
SELECT 'ack', 635;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (636, 28, X'76616C75652D3030303030363336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (636, 'wal', 'ack-636');
COMMIT;
SELECT 'ack', 636;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (637, 29, X'76616C75652D3030303030363337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (637, 'wal', 'ack-637');
COMMIT;
SELECT 'ack', 637;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (638, 30, X'76616C75652D3030303030363338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (638, 'wal', 'ack-638');
COMMIT;
SELECT 'ack', 638;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (639, 31, X'76616C75652D3030303030363339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (639, 'wal', 'ack-639');
COMMIT;
SELECT 'ack', 639;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (640, 0, X'76616C75652D3030303030363430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (640, 'wal', 'ack-640');
COMMIT;
SELECT 'ack', 640;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (641, 1, X'76616C75652D3030303030363431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (641, 'wal', 'ack-641');
COMMIT;
SELECT 'ack', 641;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (642, 2, X'76616C75652D3030303030363432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (642, 'wal', 'ack-642');
COMMIT;
SELECT 'ack', 642;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (643, 3, X'76616C75652D3030303030363433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (643, 'wal', 'ack-643');
COMMIT;
SELECT 'ack', 643;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (644, 4, X'76616C75652D3030303030363434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (644, 'wal', 'ack-644');
COMMIT;
SELECT 'ack', 644;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (645, 5, X'76616C75652D3030303030363435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (645, 'wal', 'ack-645');
COMMIT;
SELECT 'ack', 645;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (646, 6, X'76616C75652D3030303030363436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (646, 'wal', 'ack-646');
COMMIT;
SELECT 'ack', 646;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (647, 7, X'76616C75652D3030303030363437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (647, 'wal', 'ack-647');
COMMIT;
SELECT 'ack', 647;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (648, 8, X'76616C75652D3030303030363438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (648, 'wal', 'ack-648');
COMMIT;
SELECT 'ack', 648;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (649, 9, X'76616C75652D3030303030363439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (649, 'wal', 'ack-649');
COMMIT;
SELECT 'ack', 649;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (650, 10, X'76616C75652D3030303030363530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (650, 'wal', 'ack-650');
COMMIT;
SELECT 'ack', 650;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (651, 11, X'76616C75652D3030303030363531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (651, 'wal', 'ack-651');
COMMIT;
SELECT 'ack', 651;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (652, 12, X'76616C75652D3030303030363532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (652, 'wal', 'ack-652');
COMMIT;
SELECT 'ack', 652;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (653, 13, X'76616C75652D3030303030363533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (653, 'wal', 'ack-653');
COMMIT;
SELECT 'ack', 653;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (654, 14, X'76616C75652D3030303030363534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (654, 'wal', 'ack-654');
COMMIT;
SELECT 'ack', 654;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (655, 15, X'76616C75652D3030303030363535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (655, 'wal', 'ack-655');
COMMIT;
SELECT 'ack', 655;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (656, 16, X'76616C75652D3030303030363536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (656, 'wal', 'ack-656');
COMMIT;
SELECT 'ack', 656;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (657, 17, X'76616C75652D3030303030363537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (657, 'wal', 'ack-657');
COMMIT;
SELECT 'ack', 657;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (658, 18, X'76616C75652D3030303030363538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (658, 'wal', 'ack-658');
COMMIT;
SELECT 'ack', 658;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (659, 19, X'76616C75652D3030303030363539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (659, 'wal', 'ack-659');
COMMIT;
SELECT 'ack', 659;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (660, 20, X'76616C75652D3030303030363630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (660, 'wal', 'ack-660');
COMMIT;
SELECT 'ack', 660;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (661, 21, X'76616C75652D3030303030363631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (661, 'wal', 'ack-661');
COMMIT;
SELECT 'ack', 661;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (662, 22, X'76616C75652D3030303030363632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (662, 'wal', 'ack-662');
COMMIT;
SELECT 'ack', 662;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (663, 23, X'76616C75652D3030303030363633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (663, 'wal', 'ack-663');
COMMIT;
SELECT 'ack', 663;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (664, 24, X'76616C75652D3030303030363634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (664, 'wal', 'ack-664');
COMMIT;
SELECT 'ack', 664;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (665, 25, X'76616C75652D3030303030363635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (665, 'wal', 'ack-665');
COMMIT;
SELECT 'ack', 665;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (666, 26, X'76616C75652D3030303030363636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (666, 'wal', 'ack-666');
COMMIT;
SELECT 'ack', 666;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (667, 27, X'76616C75652D3030303030363637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (667, 'wal', 'ack-667');
COMMIT;
SELECT 'ack', 667;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (668, 28, X'76616C75652D3030303030363638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (668, 'wal', 'ack-668');
COMMIT;
SELECT 'ack', 668;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (669, 29, X'76616C75652D3030303030363639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (669, 'wal', 'ack-669');
COMMIT;
SELECT 'ack', 669;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (670, 30, X'76616C75652D3030303030363730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (670, 'wal', 'ack-670');
COMMIT;
SELECT 'ack', 670;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (671, 31, X'76616C75652D3030303030363731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (671, 'wal', 'ack-671');
COMMIT;
SELECT 'ack', 671;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (672, 0, X'76616C75652D3030303030363732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (672, 'wal', 'ack-672');
COMMIT;
SELECT 'ack', 672;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (673, 1, X'76616C75652D3030303030363733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (673, 'wal', 'ack-673');
COMMIT;
SELECT 'ack', 673;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (674, 2, X'76616C75652D3030303030363734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (674, 'wal', 'ack-674');
COMMIT;
SELECT 'ack', 674;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (675, 3, X'76616C75652D3030303030363735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (675, 'wal', 'ack-675');
COMMIT;
SELECT 'ack', 675;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (676, 4, X'76616C75652D3030303030363736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (676, 'wal', 'ack-676');
COMMIT;
SELECT 'ack', 676;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (677, 5, X'76616C75652D3030303030363737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (677, 'wal', 'ack-677');
COMMIT;
SELECT 'ack', 677;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (678, 6, X'76616C75652D3030303030363738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (678, 'wal', 'ack-678');
COMMIT;
SELECT 'ack', 678;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (679, 7, X'76616C75652D3030303030363739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (679, 'wal', 'ack-679');
COMMIT;
SELECT 'ack', 679;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (680, 8, X'76616C75652D3030303030363830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (680, 'wal', 'ack-680');
COMMIT;
SELECT 'ack', 680;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (681, 9, X'76616C75652D3030303030363831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (681, 'wal', 'ack-681');
COMMIT;
SELECT 'ack', 681;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (682, 10, X'76616C75652D3030303030363832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (682, 'wal', 'ack-682');
COMMIT;
SELECT 'ack', 682;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (683, 11, X'76616C75652D3030303030363833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (683, 'wal', 'ack-683');
COMMIT;
SELECT 'ack', 683;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (684, 12, X'76616C75652D3030303030363834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (684, 'wal', 'ack-684');
COMMIT;
SELECT 'ack', 684;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (685, 13, X'76616C75652D3030303030363835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (685, 'wal', 'ack-685');
COMMIT;
SELECT 'ack', 685;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (686, 14, X'76616C75652D3030303030363836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (686, 'wal', 'ack-686');
COMMIT;
SELECT 'ack', 686;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (687, 15, X'76616C75652D3030303030363837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (687, 'wal', 'ack-687');
COMMIT;
SELECT 'ack', 687;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (688, 16, X'76616C75652D3030303030363838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (688, 'wal', 'ack-688');
COMMIT;
SELECT 'ack', 688;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (689, 17, X'76616C75652D3030303030363839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (689, 'wal', 'ack-689');
COMMIT;
SELECT 'ack', 689;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (690, 18, X'76616C75652D3030303030363930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (690, 'wal', 'ack-690');
COMMIT;
SELECT 'ack', 690;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (691, 19, X'76616C75652D3030303030363931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (691, 'wal', 'ack-691');
COMMIT;
SELECT 'ack', 691;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (692, 20, X'76616C75652D3030303030363932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (692, 'wal', 'ack-692');
COMMIT;
SELECT 'ack', 692;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (693, 21, X'76616C75652D3030303030363933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (693, 'wal', 'ack-693');
COMMIT;
SELECT 'ack', 693;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (694, 22, X'76616C75652D3030303030363934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (694, 'wal', 'ack-694');
COMMIT;
SELECT 'ack', 694;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (695, 23, X'76616C75652D3030303030363935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (695, 'wal', 'ack-695');
COMMIT;
SELECT 'ack', 695;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (696, 24, X'76616C75652D3030303030363936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (696, 'wal', 'ack-696');
COMMIT;
SELECT 'ack', 696;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (697, 25, X'76616C75652D3030303030363937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (697, 'wal', 'ack-697');
COMMIT;
SELECT 'ack', 697;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (698, 26, X'76616C75652D3030303030363938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (698, 'wal', 'ack-698');
COMMIT;
SELECT 'ack', 698;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (699, 27, X'76616C75652D3030303030363939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (699, 'wal', 'ack-699');
COMMIT;
SELECT 'ack', 699;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (700, 28, X'76616C75652D3030303030373030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (700, 'wal', 'ack-700');
COMMIT;
SELECT 'ack', 700;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (701, 29, X'76616C75652D3030303030373031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (701, 'wal', 'ack-701');
COMMIT;
SELECT 'ack', 701;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (702, 30, X'76616C75652D3030303030373032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (702, 'wal', 'ack-702');
COMMIT;
SELECT 'ack', 702;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (703, 31, X'76616C75652D3030303030373033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (703, 'wal', 'ack-703');
COMMIT;
SELECT 'ack', 703;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (704, 0, X'76616C75652D3030303030373034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (704, 'wal', 'ack-704');
COMMIT;
SELECT 'ack', 704;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (705, 1, X'76616C75652D3030303030373035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (705, 'wal', 'ack-705');
COMMIT;
SELECT 'ack', 705;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (706, 2, X'76616C75652D3030303030373036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (706, 'wal', 'ack-706');
COMMIT;
SELECT 'ack', 706;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (707, 3, X'76616C75652D3030303030373037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (707, 'wal', 'ack-707');
COMMIT;
SELECT 'ack', 707;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (708, 4, X'76616C75652D3030303030373038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (708, 'wal', 'ack-708');
COMMIT;
SELECT 'ack', 708;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (709, 5, X'76616C75652D3030303030373039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (709, 'wal', 'ack-709');
COMMIT;
SELECT 'ack', 709;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (710, 6, X'76616C75652D3030303030373130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (710, 'wal', 'ack-710');
COMMIT;
SELECT 'ack', 710;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (711, 7, X'76616C75652D3030303030373131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (711, 'wal', 'ack-711');
COMMIT;
SELECT 'ack', 711;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (712, 8, X'76616C75652D3030303030373132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (712, 'wal', 'ack-712');
COMMIT;
SELECT 'ack', 712;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (713, 9, X'76616C75652D3030303030373133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (713, 'wal', 'ack-713');
COMMIT;
SELECT 'ack', 713;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (714, 10, X'76616C75652D3030303030373134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (714, 'wal', 'ack-714');
COMMIT;
SELECT 'ack', 714;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (715, 11, X'76616C75652D3030303030373135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (715, 'wal', 'ack-715');
COMMIT;
SELECT 'ack', 715;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (716, 12, X'76616C75652D3030303030373136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (716, 'wal', 'ack-716');
COMMIT;
SELECT 'ack', 716;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (717, 13, X'76616C75652D3030303030373137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (717, 'wal', 'ack-717');
COMMIT;
SELECT 'ack', 717;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (718, 14, X'76616C75652D3030303030373138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (718, 'wal', 'ack-718');
COMMIT;
SELECT 'ack', 718;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (719, 15, X'76616C75652D3030303030373139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (719, 'wal', 'ack-719');
COMMIT;
SELECT 'ack', 719;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (720, 16, X'76616C75652D3030303030373230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (720, 'wal', 'ack-720');
COMMIT;
SELECT 'ack', 720;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (721, 17, X'76616C75652D3030303030373231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (721, 'wal', 'ack-721');
COMMIT;
SELECT 'ack', 721;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (722, 18, X'76616C75652D3030303030373232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (722, 'wal', 'ack-722');
COMMIT;
SELECT 'ack', 722;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (723, 19, X'76616C75652D3030303030373233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (723, 'wal', 'ack-723');
COMMIT;
SELECT 'ack', 723;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (724, 20, X'76616C75652D3030303030373234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (724, 'wal', 'ack-724');
COMMIT;
SELECT 'ack', 724;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (725, 21, X'76616C75652D3030303030373235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (725, 'wal', 'ack-725');
COMMIT;
SELECT 'ack', 725;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (726, 22, X'76616C75652D3030303030373236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (726, 'wal', 'ack-726');
COMMIT;
SELECT 'ack', 726;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (727, 23, X'76616C75652D3030303030373237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (727, 'wal', 'ack-727');
COMMIT;
SELECT 'ack', 727;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (728, 24, X'76616C75652D3030303030373238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (728, 'wal', 'ack-728');
COMMIT;
SELECT 'ack', 728;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (729, 25, X'76616C75652D3030303030373239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (729, 'wal', 'ack-729');
COMMIT;
SELECT 'ack', 729;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (730, 26, X'76616C75652D3030303030373330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (730, 'wal', 'ack-730');
COMMIT;
SELECT 'ack', 730;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (731, 27, X'76616C75652D3030303030373331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (731, 'wal', 'ack-731');
COMMIT;
SELECT 'ack', 731;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (732, 28, X'76616C75652D3030303030373332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (732, 'wal', 'ack-732');
COMMIT;
SELECT 'ack', 732;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (733, 29, X'76616C75652D3030303030373333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (733, 'wal', 'ack-733');
COMMIT;
SELECT 'ack', 733;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (734, 30, X'76616C75652D3030303030373334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (734, 'wal', 'ack-734');
COMMIT;
SELECT 'ack', 734;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (735, 31, X'76616C75652D3030303030373335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (735, 'wal', 'ack-735');
COMMIT;
SELECT 'ack', 735;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (736, 0, X'76616C75652D3030303030373336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (736, 'wal', 'ack-736');
COMMIT;
SELECT 'ack', 736;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (737, 1, X'76616C75652D3030303030373337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (737, 'wal', 'ack-737');
COMMIT;
SELECT 'ack', 737;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (738, 2, X'76616C75652D3030303030373338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (738, 'wal', 'ack-738');
COMMIT;
SELECT 'ack', 738;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (739, 3, X'76616C75652D3030303030373339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (739, 'wal', 'ack-739');
COMMIT;
SELECT 'ack', 739;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (740, 4, X'76616C75652D3030303030373430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (740, 'wal', 'ack-740');
COMMIT;
SELECT 'ack', 740;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (741, 5, X'76616C75652D3030303030373431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (741, 'wal', 'ack-741');
COMMIT;
SELECT 'ack', 741;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (742, 6, X'76616C75652D3030303030373432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (742, 'wal', 'ack-742');
COMMIT;
SELECT 'ack', 742;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (743, 7, X'76616C75652D3030303030373433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (743, 'wal', 'ack-743');
COMMIT;
SELECT 'ack', 743;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (744, 8, X'76616C75652D3030303030373434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (744, 'wal', 'ack-744');
COMMIT;
SELECT 'ack', 744;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (745, 9, X'76616C75652D3030303030373435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (745, 'wal', 'ack-745');
COMMIT;
SELECT 'ack', 745;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (746, 10, X'76616C75652D3030303030373436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (746, 'wal', 'ack-746');
COMMIT;
SELECT 'ack', 746;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (747, 11, X'76616C75652D3030303030373437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (747, 'wal', 'ack-747');
COMMIT;
SELECT 'ack', 747;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (748, 12, X'76616C75652D3030303030373438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (748, 'wal', 'ack-748');
COMMIT;
SELECT 'ack', 748;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (749, 13, X'76616C75652D3030303030373439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (749, 'wal', 'ack-749');
COMMIT;
SELECT 'ack', 749;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (750, 14, X'76616C75652D3030303030373530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (750, 'wal', 'ack-750');
COMMIT;
SELECT 'ack', 750;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (751, 15, X'76616C75652D3030303030373531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (751, 'wal', 'ack-751');
COMMIT;
SELECT 'ack', 751;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (752, 16, X'76616C75652D3030303030373532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (752, 'wal', 'ack-752');
COMMIT;
SELECT 'ack', 752;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (753, 17, X'76616C75652D3030303030373533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (753, 'wal', 'ack-753');
COMMIT;
SELECT 'ack', 753;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (754, 18, X'76616C75652D3030303030373534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (754, 'wal', 'ack-754');
COMMIT;
SELECT 'ack', 754;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (755, 19, X'76616C75652D3030303030373535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (755, 'wal', 'ack-755');
COMMIT;
SELECT 'ack', 755;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (756, 20, X'76616C75652D3030303030373536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (756, 'wal', 'ack-756');
COMMIT;
SELECT 'ack', 756;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (757, 21, X'76616C75652D3030303030373537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (757, 'wal', 'ack-757');
COMMIT;
SELECT 'ack', 757;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (758, 22, X'76616C75652D3030303030373538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (758, 'wal', 'ack-758');
COMMIT;
SELECT 'ack', 758;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (759, 23, X'76616C75652D3030303030373539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (759, 'wal', 'ack-759');
COMMIT;
SELECT 'ack', 759;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (760, 24, X'76616C75652D3030303030373630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (760, 'wal', 'ack-760');
COMMIT;
SELECT 'ack', 760;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (761, 25, X'76616C75652D3030303030373631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (761, 'wal', 'ack-761');
COMMIT;
SELECT 'ack', 761;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (762, 26, X'76616C75652D3030303030373632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (762, 'wal', 'ack-762');
COMMIT;
SELECT 'ack', 762;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (763, 27, X'76616C75652D3030303030373633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (763, 'wal', 'ack-763');
COMMIT;
SELECT 'ack', 763;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (764, 28, X'76616C75652D3030303030373634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (764, 'wal', 'ack-764');
COMMIT;
SELECT 'ack', 764;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (765, 29, X'76616C75652D3030303030373635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (765, 'wal', 'ack-765');
COMMIT;
SELECT 'ack', 765;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (766, 30, X'76616C75652D3030303030373636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (766, 'wal', 'ack-766');
COMMIT;
SELECT 'ack', 766;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (767, 31, X'76616C75652D3030303030373637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (767, 'wal', 'ack-767');
COMMIT;
SELECT 'ack', 767;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (768, 0, X'76616C75652D3030303030373638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (768, 'wal', 'ack-768');
COMMIT;
SELECT 'ack', 768;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (769, 1, X'76616C75652D3030303030373639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (769, 'wal', 'ack-769');
COMMIT;
SELECT 'ack', 769;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (770, 2, X'76616C75652D3030303030373730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (770, 'wal', 'ack-770');
COMMIT;
SELECT 'ack', 770;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (771, 3, X'76616C75652D3030303030373731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (771, 'wal', 'ack-771');
COMMIT;
SELECT 'ack', 771;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (772, 4, X'76616C75652D3030303030373732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (772, 'wal', 'ack-772');
COMMIT;
SELECT 'ack', 772;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (773, 5, X'76616C75652D3030303030373733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (773, 'wal', 'ack-773');
COMMIT;
SELECT 'ack', 773;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (774, 6, X'76616C75652D3030303030373734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (774, 'wal', 'ack-774');
COMMIT;
SELECT 'ack', 774;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (775, 7, X'76616C75652D3030303030373735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (775, 'wal', 'ack-775');
COMMIT;
SELECT 'ack', 775;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (776, 8, X'76616C75652D3030303030373736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (776, 'wal', 'ack-776');
COMMIT;
SELECT 'ack', 776;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (777, 9, X'76616C75652D3030303030373737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (777, 'wal', 'ack-777');
COMMIT;
SELECT 'ack', 777;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (778, 10, X'76616C75652D3030303030373738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (778, 'wal', 'ack-778');
COMMIT;
SELECT 'ack', 778;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (779, 11, X'76616C75652D3030303030373739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (779, 'wal', 'ack-779');
COMMIT;
SELECT 'ack', 779;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (780, 12, X'76616C75652D3030303030373830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (780, 'wal', 'ack-780');
COMMIT;
SELECT 'ack', 780;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (781, 13, X'76616C75652D3030303030373831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (781, 'wal', 'ack-781');
COMMIT;
SELECT 'ack', 781;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (782, 14, X'76616C75652D3030303030373832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (782, 'wal', 'ack-782');
COMMIT;
SELECT 'ack', 782;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (783, 15, X'76616C75652D3030303030373833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (783, 'wal', 'ack-783');
COMMIT;
SELECT 'ack', 783;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (784, 16, X'76616C75652D3030303030373834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (784, 'wal', 'ack-784');
COMMIT;
SELECT 'ack', 784;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (785, 17, X'76616C75652D3030303030373835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (785, 'wal', 'ack-785');
COMMIT;
SELECT 'ack', 785;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (786, 18, X'76616C75652D3030303030373836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (786, 'wal', 'ack-786');
COMMIT;
SELECT 'ack', 786;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (787, 19, X'76616C75652D3030303030373837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (787, 'wal', 'ack-787');
COMMIT;
SELECT 'ack', 787;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (788, 20, X'76616C75652D3030303030373838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (788, 'wal', 'ack-788');
COMMIT;
SELECT 'ack', 788;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (789, 21, X'76616C75652D3030303030373839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (789, 'wal', 'ack-789');
COMMIT;
SELECT 'ack', 789;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (790, 22, X'76616C75652D3030303030373930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (790, 'wal', 'ack-790');
COMMIT;
SELECT 'ack', 790;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (791, 23, X'76616C75652D3030303030373931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (791, 'wal', 'ack-791');
COMMIT;
SELECT 'ack', 791;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (792, 24, X'76616C75652D3030303030373932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (792, 'wal', 'ack-792');
COMMIT;
SELECT 'ack', 792;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (793, 25, X'76616C75652D3030303030373933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (793, 'wal', 'ack-793');
COMMIT;
SELECT 'ack', 793;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (794, 26, X'76616C75652D3030303030373934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (794, 'wal', 'ack-794');
COMMIT;
SELECT 'ack', 794;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (795, 27, X'76616C75652D3030303030373935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (795, 'wal', 'ack-795');
COMMIT;
SELECT 'ack', 795;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (796, 28, X'76616C75652D3030303030373936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (796, 'wal', 'ack-796');
COMMIT;
SELECT 'ack', 796;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (797, 29, X'76616C75652D3030303030373937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (797, 'wal', 'ack-797');
COMMIT;
SELECT 'ack', 797;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (798, 30, X'76616C75652D3030303030373938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (798, 'wal', 'ack-798');
COMMIT;
SELECT 'ack', 798;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (799, 31, X'76616C75652D3030303030373939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (799, 'wal', 'ack-799');
COMMIT;
SELECT 'ack', 799;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (800, 0, X'76616C75652D3030303030383030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (800, 'wal', 'ack-800');
COMMIT;
SELECT 'ack', 800;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (801, 1, X'76616C75652D3030303030383031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (801, 'wal', 'ack-801');
COMMIT;
SELECT 'ack', 801;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (802, 2, X'76616C75652D3030303030383032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (802, 'wal', 'ack-802');
COMMIT;
SELECT 'ack', 802;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (803, 3, X'76616C75652D3030303030383033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (803, 'wal', 'ack-803');
COMMIT;
SELECT 'ack', 803;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (804, 4, X'76616C75652D3030303030383034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (804, 'wal', 'ack-804');
COMMIT;
SELECT 'ack', 804;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (805, 5, X'76616C75652D3030303030383035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (805, 'wal', 'ack-805');
COMMIT;
SELECT 'ack', 805;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (806, 6, X'76616C75652D3030303030383036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (806, 'wal', 'ack-806');
COMMIT;
SELECT 'ack', 806;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (807, 7, X'76616C75652D3030303030383037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (807, 'wal', 'ack-807');
COMMIT;
SELECT 'ack', 807;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (808, 8, X'76616C75652D3030303030383038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (808, 'wal', 'ack-808');
COMMIT;
SELECT 'ack', 808;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (809, 9, X'76616C75652D3030303030383039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (809, 'wal', 'ack-809');
COMMIT;
SELECT 'ack', 809;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (810, 10, X'76616C75652D3030303030383130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (810, 'wal', 'ack-810');
COMMIT;
SELECT 'ack', 810;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (811, 11, X'76616C75652D3030303030383131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (811, 'wal', 'ack-811');
COMMIT;
SELECT 'ack', 811;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (812, 12, X'76616C75652D3030303030383132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (812, 'wal', 'ack-812');
COMMIT;
SELECT 'ack', 812;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (813, 13, X'76616C75652D3030303030383133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (813, 'wal', 'ack-813');
COMMIT;
SELECT 'ack', 813;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (814, 14, X'76616C75652D3030303030383134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (814, 'wal', 'ack-814');
COMMIT;
SELECT 'ack', 814;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (815, 15, X'76616C75652D3030303030383135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (815, 'wal', 'ack-815');
COMMIT;
SELECT 'ack', 815;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (816, 16, X'76616C75652D3030303030383136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (816, 'wal', 'ack-816');
COMMIT;
SELECT 'ack', 816;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (817, 17, X'76616C75652D3030303030383137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (817, 'wal', 'ack-817');
COMMIT;
SELECT 'ack', 817;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (818, 18, X'76616C75652D3030303030383138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (818, 'wal', 'ack-818');
COMMIT;
SELECT 'ack', 818;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (819, 19, X'76616C75652D3030303030383139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (819, 'wal', 'ack-819');
COMMIT;
SELECT 'ack', 819;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (820, 20, X'76616C75652D3030303030383230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (820, 'wal', 'ack-820');
COMMIT;
SELECT 'ack', 820;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (821, 21, X'76616C75652D3030303030383231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (821, 'wal', 'ack-821');
COMMIT;
SELECT 'ack', 821;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (822, 22, X'76616C75652D3030303030383232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (822, 'wal', 'ack-822');
COMMIT;
SELECT 'ack', 822;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (823, 23, X'76616C75652D3030303030383233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (823, 'wal', 'ack-823');
COMMIT;
SELECT 'ack', 823;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (824, 24, X'76616C75652D3030303030383234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (824, 'wal', 'ack-824');
COMMIT;
SELECT 'ack', 824;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (825, 25, X'76616C75652D3030303030383235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (825, 'wal', 'ack-825');
COMMIT;
SELECT 'ack', 825;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (826, 26, X'76616C75652D3030303030383236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (826, 'wal', 'ack-826');
COMMIT;
SELECT 'ack', 826;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (827, 27, X'76616C75652D3030303030383237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (827, 'wal', 'ack-827');
COMMIT;
SELECT 'ack', 827;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (828, 28, X'76616C75652D3030303030383238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (828, 'wal', 'ack-828');
COMMIT;
SELECT 'ack', 828;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (829, 29, X'76616C75652D3030303030383239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (829, 'wal', 'ack-829');
COMMIT;
SELECT 'ack', 829;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (830, 30, X'76616C75652D3030303030383330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (830, 'wal', 'ack-830');
COMMIT;
SELECT 'ack', 830;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (831, 31, X'76616C75652D3030303030383331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (831, 'wal', 'ack-831');
COMMIT;
SELECT 'ack', 831;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (832, 0, X'76616C75652D3030303030383332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (832, 'wal', 'ack-832');
COMMIT;
SELECT 'ack', 832;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (833, 1, X'76616C75652D3030303030383333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (833, 'wal', 'ack-833');
COMMIT;
SELECT 'ack', 833;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (834, 2, X'76616C75652D3030303030383334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (834, 'wal', 'ack-834');
COMMIT;
SELECT 'ack', 834;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (835, 3, X'76616C75652D3030303030383335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (835, 'wal', 'ack-835');
COMMIT;
SELECT 'ack', 835;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (836, 4, X'76616C75652D3030303030383336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (836, 'wal', 'ack-836');
COMMIT;
SELECT 'ack', 836;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (837, 5, X'76616C75652D3030303030383337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (837, 'wal', 'ack-837');
COMMIT;
SELECT 'ack', 837;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (838, 6, X'76616C75652D3030303030383338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (838, 'wal', 'ack-838');
COMMIT;
SELECT 'ack', 838;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (839, 7, X'76616C75652D3030303030383339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (839, 'wal', 'ack-839');
COMMIT;
SELECT 'ack', 839;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (840, 8, X'76616C75652D3030303030383430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (840, 'wal', 'ack-840');
COMMIT;
SELECT 'ack', 840;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (841, 9, X'76616C75652D3030303030383431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (841, 'wal', 'ack-841');
COMMIT;
SELECT 'ack', 841;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (842, 10, X'76616C75652D3030303030383432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (842, 'wal', 'ack-842');
COMMIT;
SELECT 'ack', 842;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (843, 11, X'76616C75652D3030303030383433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (843, 'wal', 'ack-843');
COMMIT;
SELECT 'ack', 843;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (844, 12, X'76616C75652D3030303030383434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (844, 'wal', 'ack-844');
COMMIT;
SELECT 'ack', 844;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (845, 13, X'76616C75652D3030303030383435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (845, 'wal', 'ack-845');
COMMIT;
SELECT 'ack', 845;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (846, 14, X'76616C75652D3030303030383436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (846, 'wal', 'ack-846');
COMMIT;
SELECT 'ack', 846;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (847, 15, X'76616C75652D3030303030383437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (847, 'wal', 'ack-847');
COMMIT;
SELECT 'ack', 847;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (848, 16, X'76616C75652D3030303030383438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (848, 'wal', 'ack-848');
COMMIT;
SELECT 'ack', 848;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (849, 17, X'76616C75652D3030303030383439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (849, 'wal', 'ack-849');
COMMIT;
SELECT 'ack', 849;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (850, 18, X'76616C75652D3030303030383530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (850, 'wal', 'ack-850');
COMMIT;
SELECT 'ack', 850;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (851, 19, X'76616C75652D3030303030383531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (851, 'wal', 'ack-851');
COMMIT;
SELECT 'ack', 851;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (852, 20, X'76616C75652D3030303030383532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (852, 'wal', 'ack-852');
COMMIT;
SELECT 'ack', 852;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (853, 21, X'76616C75652D3030303030383533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (853, 'wal', 'ack-853');
COMMIT;
SELECT 'ack', 853;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (854, 22, X'76616C75652D3030303030383534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (854, 'wal', 'ack-854');
COMMIT;
SELECT 'ack', 854;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (855, 23, X'76616C75652D3030303030383535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (855, 'wal', 'ack-855');
COMMIT;
SELECT 'ack', 855;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (856, 24, X'76616C75652D3030303030383536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (856, 'wal', 'ack-856');
COMMIT;
SELECT 'ack', 856;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (857, 25, X'76616C75652D3030303030383537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (857, 'wal', 'ack-857');
COMMIT;
SELECT 'ack', 857;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (858, 26, X'76616C75652D3030303030383538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (858, 'wal', 'ack-858');
COMMIT;
SELECT 'ack', 858;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (859, 27, X'76616C75652D3030303030383539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (859, 'wal', 'ack-859');
COMMIT;
SELECT 'ack', 859;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (860, 28, X'76616C75652D3030303030383630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (860, 'wal', 'ack-860');
COMMIT;
SELECT 'ack', 860;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (861, 29, X'76616C75652D3030303030383631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (861, 'wal', 'ack-861');
COMMIT;
SELECT 'ack', 861;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (862, 30, X'76616C75652D3030303030383632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (862, 'wal', 'ack-862');
COMMIT;
SELECT 'ack', 862;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (863, 31, X'76616C75652D3030303030383633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (863, 'wal', 'ack-863');
COMMIT;
SELECT 'ack', 863;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (864, 0, X'76616C75652D3030303030383634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (864, 'wal', 'ack-864');
COMMIT;
SELECT 'ack', 864;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (865, 1, X'76616C75652D3030303030383635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (865, 'wal', 'ack-865');
COMMIT;
SELECT 'ack', 865;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (866, 2, X'76616C75652D3030303030383636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (866, 'wal', 'ack-866');
COMMIT;
SELECT 'ack', 866;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (867, 3, X'76616C75652D3030303030383637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (867, 'wal', 'ack-867');
COMMIT;
SELECT 'ack', 867;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (868, 4, X'76616C75652D3030303030383638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (868, 'wal', 'ack-868');
COMMIT;
SELECT 'ack', 868;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (869, 5, X'76616C75652D3030303030383639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (869, 'wal', 'ack-869');
COMMIT;
SELECT 'ack', 869;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (870, 6, X'76616C75652D3030303030383730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (870, 'wal', 'ack-870');
COMMIT;
SELECT 'ack', 870;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (871, 7, X'76616C75652D3030303030383731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (871, 'wal', 'ack-871');
COMMIT;
SELECT 'ack', 871;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (872, 8, X'76616C75652D3030303030383732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (872, 'wal', 'ack-872');
COMMIT;
SELECT 'ack', 872;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (873, 9, X'76616C75652D3030303030383733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (873, 'wal', 'ack-873');
COMMIT;
SELECT 'ack', 873;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (874, 10, X'76616C75652D3030303030383734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (874, 'wal', 'ack-874');
COMMIT;
SELECT 'ack', 874;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (875, 11, X'76616C75652D3030303030383735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (875, 'wal', 'ack-875');
COMMIT;
SELECT 'ack', 875;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (876, 12, X'76616C75652D3030303030383736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (876, 'wal', 'ack-876');
COMMIT;
SELECT 'ack', 876;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (877, 13, X'76616C75652D3030303030383737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (877, 'wal', 'ack-877');
COMMIT;
SELECT 'ack', 877;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (878, 14, X'76616C75652D3030303030383738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (878, 'wal', 'ack-878');
COMMIT;
SELECT 'ack', 878;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (879, 15, X'76616C75652D3030303030383739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (879, 'wal', 'ack-879');
COMMIT;
SELECT 'ack', 879;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (880, 16, X'76616C75652D3030303030383830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (880, 'wal', 'ack-880');
COMMIT;
SELECT 'ack', 880;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (881, 17, X'76616C75652D3030303030383831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (881, 'wal', 'ack-881');
COMMIT;
SELECT 'ack', 881;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (882, 18, X'76616C75652D3030303030383832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (882, 'wal', 'ack-882');
COMMIT;
SELECT 'ack', 882;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (883, 19, X'76616C75652D3030303030383833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (883, 'wal', 'ack-883');
COMMIT;
SELECT 'ack', 883;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (884, 20, X'76616C75652D3030303030383834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (884, 'wal', 'ack-884');
COMMIT;
SELECT 'ack', 884;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (885, 21, X'76616C75652D3030303030383835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (885, 'wal', 'ack-885');
COMMIT;
SELECT 'ack', 885;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (886, 22, X'76616C75652D3030303030383836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (886, 'wal', 'ack-886');
COMMIT;
SELECT 'ack', 886;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (887, 23, X'76616C75652D3030303030383837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (887, 'wal', 'ack-887');
COMMIT;
SELECT 'ack', 887;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (888, 24, X'76616C75652D3030303030383838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (888, 'wal', 'ack-888');
COMMIT;
SELECT 'ack', 888;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (889, 25, X'76616C75652D3030303030383839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (889, 'wal', 'ack-889');
COMMIT;
SELECT 'ack', 889;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (890, 26, X'76616C75652D3030303030383930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (890, 'wal', 'ack-890');
COMMIT;
SELECT 'ack', 890;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (891, 27, X'76616C75652D3030303030383931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (891, 'wal', 'ack-891');
COMMIT;
SELECT 'ack', 891;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (892, 28, X'76616C75652D3030303030383932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (892, 'wal', 'ack-892');
COMMIT;
SELECT 'ack', 892;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (893, 29, X'76616C75652D3030303030383933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (893, 'wal', 'ack-893');
COMMIT;
SELECT 'ack', 893;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (894, 30, X'76616C75652D3030303030383934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (894, 'wal', 'ack-894');
COMMIT;
SELECT 'ack', 894;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (895, 31, X'76616C75652D3030303030383935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (895, 'wal', 'ack-895');
COMMIT;
SELECT 'ack', 895;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (896, 0, X'76616C75652D3030303030383936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (896, 'wal', 'ack-896');
COMMIT;
SELECT 'ack', 896;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (897, 1, X'76616C75652D3030303030383937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (897, 'wal', 'ack-897');
COMMIT;
SELECT 'ack', 897;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (898, 2, X'76616C75652D3030303030383938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (898, 'wal', 'ack-898');
COMMIT;
SELECT 'ack', 898;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (899, 3, X'76616C75652D3030303030383939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (899, 'wal', 'ack-899');
COMMIT;
SELECT 'ack', 899;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (900, 4, X'76616C75652D3030303030393030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (900, 'wal', 'ack-900');
COMMIT;
SELECT 'ack', 900;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (901, 5, X'76616C75652D3030303030393031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (901, 'wal', 'ack-901');
COMMIT;
SELECT 'ack', 901;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (902, 6, X'76616C75652D3030303030393032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (902, 'wal', 'ack-902');
COMMIT;
SELECT 'ack', 902;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (903, 7, X'76616C75652D3030303030393033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (903, 'wal', 'ack-903');
COMMIT;
SELECT 'ack', 903;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (904, 8, X'76616C75652D3030303030393034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (904, 'wal', 'ack-904');
COMMIT;
SELECT 'ack', 904;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (905, 9, X'76616C75652D3030303030393035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (905, 'wal', 'ack-905');
COMMIT;
SELECT 'ack', 905;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (906, 10, X'76616C75652D3030303030393036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (906, 'wal', 'ack-906');
COMMIT;
SELECT 'ack', 906;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (907, 11, X'76616C75652D3030303030393037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (907, 'wal', 'ack-907');
COMMIT;
SELECT 'ack', 907;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (908, 12, X'76616C75652D3030303030393038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (908, 'wal', 'ack-908');
COMMIT;
SELECT 'ack', 908;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (909, 13, X'76616C75652D3030303030393039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (909, 'wal', 'ack-909');
COMMIT;
SELECT 'ack', 909;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (910, 14, X'76616C75652D3030303030393130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (910, 'wal', 'ack-910');
COMMIT;
SELECT 'ack', 910;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (911, 15, X'76616C75652D3030303030393131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (911, 'wal', 'ack-911');
COMMIT;
SELECT 'ack', 911;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (912, 16, X'76616C75652D3030303030393132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (912, 'wal', 'ack-912');
COMMIT;
SELECT 'ack', 912;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (913, 17, X'76616C75652D3030303030393133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (913, 'wal', 'ack-913');
COMMIT;
SELECT 'ack', 913;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (914, 18, X'76616C75652D3030303030393134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (914, 'wal', 'ack-914');
COMMIT;
SELECT 'ack', 914;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (915, 19, X'76616C75652D3030303030393135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (915, 'wal', 'ack-915');
COMMIT;
SELECT 'ack', 915;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (916, 20, X'76616C75652D3030303030393136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (916, 'wal', 'ack-916');
COMMIT;
SELECT 'ack', 916;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (917, 21, X'76616C75652D3030303030393137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (917, 'wal', 'ack-917');
COMMIT;
SELECT 'ack', 917;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (918, 22, X'76616C75652D3030303030393138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (918, 'wal', 'ack-918');
COMMIT;
SELECT 'ack', 918;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (919, 23, X'76616C75652D3030303030393139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (919, 'wal', 'ack-919');
COMMIT;
SELECT 'ack', 919;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (920, 24, X'76616C75652D3030303030393230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (920, 'wal', 'ack-920');
COMMIT;
SELECT 'ack', 920;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (921, 25, X'76616C75652D3030303030393231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (921, 'wal', 'ack-921');
COMMIT;
SELECT 'ack', 921;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (922, 26, X'76616C75652D3030303030393232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (922, 'wal', 'ack-922');
COMMIT;
SELECT 'ack', 922;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (923, 27, X'76616C75652D3030303030393233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (923, 'wal', 'ack-923');
COMMIT;
SELECT 'ack', 923;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (924, 28, X'76616C75652D3030303030393234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (924, 'wal', 'ack-924');
COMMIT;
SELECT 'ack', 924;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (925, 29, X'76616C75652D3030303030393235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (925, 'wal', 'ack-925');
COMMIT;
SELECT 'ack', 925;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (926, 30, X'76616C75652D3030303030393236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (926, 'wal', 'ack-926');
COMMIT;
SELECT 'ack', 926;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (927, 31, X'76616C75652D3030303030393237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (927, 'wal', 'ack-927');
COMMIT;
SELECT 'ack', 927;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (928, 0, X'76616C75652D3030303030393238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (928, 'wal', 'ack-928');
COMMIT;
SELECT 'ack', 928;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (929, 1, X'76616C75652D3030303030393239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (929, 'wal', 'ack-929');
COMMIT;
SELECT 'ack', 929;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (930, 2, X'76616C75652D3030303030393330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (930, 'wal', 'ack-930');
COMMIT;
SELECT 'ack', 930;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (931, 3, X'76616C75652D3030303030393331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (931, 'wal', 'ack-931');
COMMIT;
SELECT 'ack', 931;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (932, 4, X'76616C75652D3030303030393332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (932, 'wal', 'ack-932');
COMMIT;
SELECT 'ack', 932;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (933, 5, X'76616C75652D3030303030393333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (933, 'wal', 'ack-933');
COMMIT;
SELECT 'ack', 933;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (934, 6, X'76616C75652D3030303030393334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (934, 'wal', 'ack-934');
COMMIT;
SELECT 'ack', 934;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (935, 7, X'76616C75652D3030303030393335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (935, 'wal', 'ack-935');
COMMIT;
SELECT 'ack', 935;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (936, 8, X'76616C75652D3030303030393336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (936, 'wal', 'ack-936');
COMMIT;
SELECT 'ack', 936;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (937, 9, X'76616C75652D3030303030393337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (937, 'wal', 'ack-937');
COMMIT;
SELECT 'ack', 937;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (938, 10, X'76616C75652D3030303030393338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (938, 'wal', 'ack-938');
COMMIT;
SELECT 'ack', 938;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (939, 11, X'76616C75652D3030303030393339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (939, 'wal', 'ack-939');
COMMIT;
SELECT 'ack', 939;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (940, 12, X'76616C75652D3030303030393430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (940, 'wal', 'ack-940');
COMMIT;
SELECT 'ack', 940;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (941, 13, X'76616C75652D3030303030393431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (941, 'wal', 'ack-941');
COMMIT;
SELECT 'ack', 941;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (942, 14, X'76616C75652D3030303030393432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (942, 'wal', 'ack-942');
COMMIT;
SELECT 'ack', 942;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (943, 15, X'76616C75652D3030303030393433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (943, 'wal', 'ack-943');
COMMIT;
SELECT 'ack', 943;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (944, 16, X'76616C75652D3030303030393434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (944, 'wal', 'ack-944');
COMMIT;
SELECT 'ack', 944;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (945, 17, X'76616C75652D3030303030393435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (945, 'wal', 'ack-945');
COMMIT;
SELECT 'ack', 945;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (946, 18, X'76616C75652D3030303030393436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (946, 'wal', 'ack-946');
COMMIT;
SELECT 'ack', 946;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (947, 19, X'76616C75652D3030303030393437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (947, 'wal', 'ack-947');
COMMIT;
SELECT 'ack', 947;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (948, 20, X'76616C75652D3030303030393438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (948, 'wal', 'ack-948');
COMMIT;
SELECT 'ack', 948;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (949, 21, X'76616C75652D3030303030393439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (949, 'wal', 'ack-949');
COMMIT;
SELECT 'ack', 949;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (950, 22, X'76616C75652D3030303030393530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (950, 'wal', 'ack-950');
COMMIT;
SELECT 'ack', 950;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (951, 23, X'76616C75652D3030303030393531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (951, 'wal', 'ack-951');
COMMIT;
SELECT 'ack', 951;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (952, 24, X'76616C75652D3030303030393532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (952, 'wal', 'ack-952');
COMMIT;
SELECT 'ack', 952;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (953, 25, X'76616C75652D3030303030393533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (953, 'wal', 'ack-953');
COMMIT;
SELECT 'ack', 953;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (954, 26, X'76616C75652D3030303030393534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (954, 'wal', 'ack-954');
COMMIT;
SELECT 'ack', 954;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (955, 27, X'76616C75652D3030303030393535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (955, 'wal', 'ack-955');
COMMIT;
SELECT 'ack', 955;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (956, 28, X'76616C75652D3030303030393536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (956, 'wal', 'ack-956');
COMMIT;
SELECT 'ack', 956;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (957, 29, X'76616C75652D3030303030393537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (957, 'wal', 'ack-957');
COMMIT;
SELECT 'ack', 957;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (958, 30, X'76616C75652D3030303030393538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (958, 'wal', 'ack-958');
COMMIT;
SELECT 'ack', 958;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (959, 31, X'76616C75652D3030303030393539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (959, 'wal', 'ack-959');
COMMIT;
SELECT 'ack', 959;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (960, 0, X'76616C75652D3030303030393630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (960, 'wal', 'ack-960');
COMMIT;
SELECT 'ack', 960;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (961, 1, X'76616C75652D3030303030393631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (961, 'wal', 'ack-961');
COMMIT;
SELECT 'ack', 961;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (962, 2, X'76616C75652D3030303030393632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (962, 'wal', 'ack-962');
COMMIT;
SELECT 'ack', 962;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (963, 3, X'76616C75652D3030303030393633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (963, 'wal', 'ack-963');
COMMIT;
SELECT 'ack', 963;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (964, 4, X'76616C75652D3030303030393634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (964, 'wal', 'ack-964');
COMMIT;
SELECT 'ack', 964;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (965, 5, X'76616C75652D3030303030393635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (965, 'wal', 'ack-965');
COMMIT;
SELECT 'ack', 965;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (966, 6, X'76616C75652D3030303030393636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (966, 'wal', 'ack-966');
COMMIT;
SELECT 'ack', 966;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (967, 7, X'76616C75652D3030303030393637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (967, 'wal', 'ack-967');
COMMIT;
SELECT 'ack', 967;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (968, 8, X'76616C75652D3030303030393638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (968, 'wal', 'ack-968');
COMMIT;
SELECT 'ack', 968;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (969, 9, X'76616C75652D3030303030393639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (969, 'wal', 'ack-969');
COMMIT;
SELECT 'ack', 969;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (970, 10, X'76616C75652D3030303030393730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (970, 'wal', 'ack-970');
COMMIT;
SELECT 'ack', 970;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (971, 11, X'76616C75652D3030303030393731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (971, 'wal', 'ack-971');
COMMIT;
SELECT 'ack', 971;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (972, 12, X'76616C75652D3030303030393732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (972, 'wal', 'ack-972');
COMMIT;
SELECT 'ack', 972;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (973, 13, X'76616C75652D3030303030393733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (973, 'wal', 'ack-973');
COMMIT;
SELECT 'ack', 973;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (974, 14, X'76616C75652D3030303030393734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (974, 'wal', 'ack-974');
COMMIT;
SELECT 'ack', 974;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (975, 15, X'76616C75652D3030303030393735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (975, 'wal', 'ack-975');
COMMIT;
SELECT 'ack', 975;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (976, 16, X'76616C75652D3030303030393736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (976, 'wal', 'ack-976');
COMMIT;
SELECT 'ack', 976;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (977, 17, X'76616C75652D3030303030393737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (977, 'wal', 'ack-977');
COMMIT;
SELECT 'ack', 977;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (978, 18, X'76616C75652D3030303030393738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (978, 'wal', 'ack-978');
COMMIT;
SELECT 'ack', 978;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (979, 19, X'76616C75652D3030303030393739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (979, 'wal', 'ack-979');
COMMIT;
SELECT 'ack', 979;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (980, 20, X'76616C75652D3030303030393830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (980, 'wal', 'ack-980');
COMMIT;
SELECT 'ack', 980;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (981, 21, X'76616C75652D3030303030393831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (981, 'wal', 'ack-981');
COMMIT;
SELECT 'ack', 981;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (982, 22, X'76616C75652D3030303030393832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (982, 'wal', 'ack-982');
COMMIT;
SELECT 'ack', 982;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (983, 23, X'76616C75652D3030303030393833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (983, 'wal', 'ack-983');
COMMIT;
SELECT 'ack', 983;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (984, 24, X'76616C75652D3030303030393834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (984, 'wal', 'ack-984');
COMMIT;
SELECT 'ack', 984;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (985, 25, X'76616C75652D3030303030393835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (985, 'wal', 'ack-985');
COMMIT;
SELECT 'ack', 985;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (986, 26, X'76616C75652D3030303030393836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (986, 'wal', 'ack-986');
COMMIT;
SELECT 'ack', 986;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (987, 27, X'76616C75652D3030303030393837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (987, 'wal', 'ack-987');
COMMIT;
SELECT 'ack', 987;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (988, 28, X'76616C75652D3030303030393838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (988, 'wal', 'ack-988');
COMMIT;
SELECT 'ack', 988;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (989, 29, X'76616C75652D3030303030393839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (989, 'wal', 'ack-989');
COMMIT;
SELECT 'ack', 989;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (990, 30, X'76616C75652D3030303030393930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (990, 'wal', 'ack-990');
COMMIT;
SELECT 'ack', 990;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (991, 31, X'76616C75652D3030303030393931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (991, 'wal', 'ack-991');
COMMIT;
SELECT 'ack', 991;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (992, 0, X'76616C75652D3030303030393932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (992, 'wal', 'ack-992');
COMMIT;
SELECT 'ack', 992;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (993, 1, X'76616C75652D3030303030393933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (993, 'wal', 'ack-993');
COMMIT;
SELECT 'ack', 993;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (994, 2, X'76616C75652D3030303030393934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (994, 'wal', 'ack-994');
COMMIT;
SELECT 'ack', 994;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (995, 3, X'76616C75652D3030303030393935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (995, 'wal', 'ack-995');
COMMIT;
SELECT 'ack', 995;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (996, 4, X'76616C75652D3030303030393936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (996, 'wal', 'ack-996');
COMMIT;
SELECT 'ack', 996;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (997, 5, X'76616C75652D3030303030393937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (997, 'wal', 'ack-997');
COMMIT;
SELECT 'ack', 997;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (998, 6, X'76616C75652D3030303030393938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (998, 'wal', 'ack-998');
COMMIT;
SELECT 'ack', 998;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (999, 7, X'76616C75652D3030303030393939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (999, 'wal', 'ack-999');
COMMIT;
SELECT 'ack', 999;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1000, 8, X'76616C75652D3030303031303030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1000, 'wal', 'ack-1000');
COMMIT;
SELECT 'ack', 1000;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1001, 9, X'76616C75652D3030303031303031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1001, 'wal', 'ack-1001');
COMMIT;
SELECT 'ack', 1001;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1002, 10, X'76616C75652D3030303031303032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1002, 'wal', 'ack-1002');
COMMIT;
SELECT 'ack', 1002;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1003, 11, X'76616C75652D3030303031303033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1003, 'wal', 'ack-1003');
COMMIT;
SELECT 'ack', 1003;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1004, 12, X'76616C75652D3030303031303034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1004, 'wal', 'ack-1004');
COMMIT;
SELECT 'ack', 1004;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1005, 13, X'76616C75652D3030303031303035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1005, 'wal', 'ack-1005');
COMMIT;
SELECT 'ack', 1005;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1006, 14, X'76616C75652D3030303031303036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1006, 'wal', 'ack-1006');
COMMIT;
SELECT 'ack', 1006;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1007, 15, X'76616C75652D3030303031303037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1007, 'wal', 'ack-1007');
COMMIT;
SELECT 'ack', 1007;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1008, 16, X'76616C75652D3030303031303038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1008, 'wal', 'ack-1008');
COMMIT;
SELECT 'ack', 1008;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1009, 17, X'76616C75652D3030303031303039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1009, 'wal', 'ack-1009');
COMMIT;
SELECT 'ack', 1009;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1010, 18, X'76616C75652D3030303031303130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1010, 'wal', 'ack-1010');
COMMIT;
SELECT 'ack', 1010;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1011, 19, X'76616C75652D3030303031303131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1011, 'wal', 'ack-1011');
COMMIT;
SELECT 'ack', 1011;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1012, 20, X'76616C75652D3030303031303132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1012, 'wal', 'ack-1012');
COMMIT;
SELECT 'ack', 1012;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1013, 21, X'76616C75652D3030303031303133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1013, 'wal', 'ack-1013');
COMMIT;
SELECT 'ack', 1013;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1014, 22, X'76616C75652D3030303031303134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1014, 'wal', 'ack-1014');
COMMIT;
SELECT 'ack', 1014;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1015, 23, X'76616C75652D3030303031303135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1015, 'wal', 'ack-1015');
COMMIT;
SELECT 'ack', 1015;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1016, 24, X'76616C75652D3030303031303136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1016, 'wal', 'ack-1016');
COMMIT;
SELECT 'ack', 1016;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1017, 25, X'76616C75652D3030303031303137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1017, 'wal', 'ack-1017');
COMMIT;
SELECT 'ack', 1017;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1018, 26, X'76616C75652D3030303031303138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1018, 'wal', 'ack-1018');
COMMIT;
SELECT 'ack', 1018;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1019, 27, X'76616C75652D3030303031303139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1019, 'wal', 'ack-1019');
COMMIT;
SELECT 'ack', 1019;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1020, 28, X'76616C75652D3030303031303230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1020, 'wal', 'ack-1020');
COMMIT;
SELECT 'ack', 1020;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1021, 29, X'76616C75652D3030303031303231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1021, 'wal', 'ack-1021');
COMMIT;
SELECT 'ack', 1021;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1022, 30, X'76616C75652D3030303031303232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1022, 'wal', 'ack-1022');
COMMIT;
SELECT 'ack', 1022;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1023, 31, X'76616C75652D3030303031303233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1023, 'wal', 'ack-1023');
COMMIT;
SELECT 'ack', 1023;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1024, 0, X'76616C75652D3030303031303234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1024, 'wal', 'ack-1024');
COMMIT;
SELECT 'ack', 1024;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1025, 1, X'76616C75652D3030303031303235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1025, 'wal', 'ack-1025');
COMMIT;
SELECT 'ack', 1025;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1026, 2, X'76616C75652D3030303031303236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1026, 'wal', 'ack-1026');
COMMIT;
SELECT 'ack', 1026;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1027, 3, X'76616C75652D3030303031303237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1027, 'wal', 'ack-1027');
COMMIT;
SELECT 'ack', 1027;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1028, 4, X'76616C75652D3030303031303238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1028, 'wal', 'ack-1028');
COMMIT;
SELECT 'ack', 1028;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1029, 5, X'76616C75652D3030303031303239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1029, 'wal', 'ack-1029');
COMMIT;
SELECT 'ack', 1029;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1030, 6, X'76616C75652D3030303031303330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1030, 'wal', 'ack-1030');
COMMIT;
SELECT 'ack', 1030;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1031, 7, X'76616C75652D3030303031303331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1031, 'wal', 'ack-1031');
COMMIT;
SELECT 'ack', 1031;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1032, 8, X'76616C75652D3030303031303332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1032, 'wal', 'ack-1032');
COMMIT;
SELECT 'ack', 1032;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1033, 9, X'76616C75652D3030303031303333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1033, 'wal', 'ack-1033');
COMMIT;
SELECT 'ack', 1033;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1034, 10, X'76616C75652D3030303031303334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1034, 'wal', 'ack-1034');
COMMIT;
SELECT 'ack', 1034;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1035, 11, X'76616C75652D3030303031303335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1035, 'wal', 'ack-1035');
COMMIT;
SELECT 'ack', 1035;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1036, 12, X'76616C75652D3030303031303336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1036, 'wal', 'ack-1036');
COMMIT;
SELECT 'ack', 1036;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1037, 13, X'76616C75652D3030303031303337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1037, 'wal', 'ack-1037');
COMMIT;
SELECT 'ack', 1037;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1038, 14, X'76616C75652D3030303031303338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1038, 'wal', 'ack-1038');
COMMIT;
SELECT 'ack', 1038;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1039, 15, X'76616C75652D3030303031303339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1039, 'wal', 'ack-1039');
COMMIT;
SELECT 'ack', 1039;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1040, 16, X'76616C75652D3030303031303430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1040, 'wal', 'ack-1040');
COMMIT;
SELECT 'ack', 1040;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1041, 17, X'76616C75652D3030303031303431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1041, 'wal', 'ack-1041');
COMMIT;
SELECT 'ack', 1041;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1042, 18, X'76616C75652D3030303031303432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1042, 'wal', 'ack-1042');
COMMIT;
SELECT 'ack', 1042;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1043, 19, X'76616C75652D3030303031303433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1043, 'wal', 'ack-1043');
COMMIT;
SELECT 'ack', 1043;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1044, 20, X'76616C75652D3030303031303434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1044, 'wal', 'ack-1044');
COMMIT;
SELECT 'ack', 1044;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1045, 21, X'76616C75652D3030303031303435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1045, 'wal', 'ack-1045');
COMMIT;
SELECT 'ack', 1045;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1046, 22, X'76616C75652D3030303031303436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1046, 'wal', 'ack-1046');
COMMIT;
SELECT 'ack', 1046;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1047, 23, X'76616C75652D3030303031303437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1047, 'wal', 'ack-1047');
COMMIT;
SELECT 'ack', 1047;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1048, 24, X'76616C75652D3030303031303438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1048, 'wal', 'ack-1048');
COMMIT;
SELECT 'ack', 1048;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1049, 25, X'76616C75652D3030303031303439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1049, 'wal', 'ack-1049');
COMMIT;
SELECT 'ack', 1049;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1050, 26, X'76616C75652D3030303031303530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1050, 'wal', 'ack-1050');
COMMIT;
SELECT 'ack', 1050;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1051, 27, X'76616C75652D3030303031303531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1051, 'wal', 'ack-1051');
COMMIT;
SELECT 'ack', 1051;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1052, 28, X'76616C75652D3030303031303532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1052, 'wal', 'ack-1052');
COMMIT;
SELECT 'ack', 1052;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1053, 29, X'76616C75652D3030303031303533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1053, 'wal', 'ack-1053');
COMMIT;
SELECT 'ack', 1053;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1054, 30, X'76616C75652D3030303031303534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1054, 'wal', 'ack-1054');
COMMIT;
SELECT 'ack', 1054;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1055, 31, X'76616C75652D3030303031303535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1055, 'wal', 'ack-1055');
COMMIT;
SELECT 'ack', 1055;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1056, 0, X'76616C75652D3030303031303536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1056, 'wal', 'ack-1056');
COMMIT;
SELECT 'ack', 1056;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1057, 1, X'76616C75652D3030303031303537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1057, 'wal', 'ack-1057');
COMMIT;
SELECT 'ack', 1057;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1058, 2, X'76616C75652D3030303031303538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1058, 'wal', 'ack-1058');
COMMIT;
SELECT 'ack', 1058;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1059, 3, X'76616C75652D3030303031303539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1059, 'wal', 'ack-1059');
COMMIT;
SELECT 'ack', 1059;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1060, 4, X'76616C75652D3030303031303630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1060, 'wal', 'ack-1060');
COMMIT;
SELECT 'ack', 1060;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1061, 5, X'76616C75652D3030303031303631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1061, 'wal', 'ack-1061');
COMMIT;
SELECT 'ack', 1061;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1062, 6, X'76616C75652D3030303031303632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1062, 'wal', 'ack-1062');
COMMIT;
SELECT 'ack', 1062;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1063, 7, X'76616C75652D3030303031303633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1063, 'wal', 'ack-1063');
COMMIT;
SELECT 'ack', 1063;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1064, 8, X'76616C75652D3030303031303634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1064, 'wal', 'ack-1064');
COMMIT;
SELECT 'ack', 1064;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1065, 9, X'76616C75652D3030303031303635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1065, 'wal', 'ack-1065');
COMMIT;
SELECT 'ack', 1065;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1066, 10, X'76616C75652D3030303031303636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1066, 'wal', 'ack-1066');
COMMIT;
SELECT 'ack', 1066;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1067, 11, X'76616C75652D3030303031303637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1067, 'wal', 'ack-1067');
COMMIT;
SELECT 'ack', 1067;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1068, 12, X'76616C75652D3030303031303638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1068, 'wal', 'ack-1068');
COMMIT;
SELECT 'ack', 1068;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1069, 13, X'76616C75652D3030303031303639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1069, 'wal', 'ack-1069');
COMMIT;
SELECT 'ack', 1069;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1070, 14, X'76616C75652D3030303031303730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1070, 'wal', 'ack-1070');
COMMIT;
SELECT 'ack', 1070;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1071, 15, X'76616C75652D3030303031303731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1071, 'wal', 'ack-1071');
COMMIT;
SELECT 'ack', 1071;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1072, 16, X'76616C75652D3030303031303732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1072, 'wal', 'ack-1072');
COMMIT;
SELECT 'ack', 1072;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1073, 17, X'76616C75652D3030303031303733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1073, 'wal', 'ack-1073');
COMMIT;
SELECT 'ack', 1073;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1074, 18, X'76616C75652D3030303031303734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1074, 'wal', 'ack-1074');
COMMIT;
SELECT 'ack', 1074;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1075, 19, X'76616C75652D3030303031303735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1075, 'wal', 'ack-1075');
COMMIT;
SELECT 'ack', 1075;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1076, 20, X'76616C75652D3030303031303736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1076, 'wal', 'ack-1076');
COMMIT;
SELECT 'ack', 1076;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1077, 21, X'76616C75652D3030303031303737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1077, 'wal', 'ack-1077');
COMMIT;
SELECT 'ack', 1077;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1078, 22, X'76616C75652D3030303031303738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1078, 'wal', 'ack-1078');
COMMIT;
SELECT 'ack', 1078;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1079, 23, X'76616C75652D3030303031303739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1079, 'wal', 'ack-1079');
COMMIT;
SELECT 'ack', 1079;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1080, 24, X'76616C75652D3030303031303830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1080, 'wal', 'ack-1080');
COMMIT;
SELECT 'ack', 1080;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1081, 25, X'76616C75652D3030303031303831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1081, 'wal', 'ack-1081');
COMMIT;
SELECT 'ack', 1081;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1082, 26, X'76616C75652D3030303031303832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1082, 'wal', 'ack-1082');
COMMIT;
SELECT 'ack', 1082;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1083, 27, X'76616C75652D3030303031303833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1083, 'wal', 'ack-1083');
COMMIT;
SELECT 'ack', 1083;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1084, 28, X'76616C75652D3030303031303834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1084, 'wal', 'ack-1084');
COMMIT;
SELECT 'ack', 1084;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1085, 29, X'76616C75652D3030303031303835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1085, 'wal', 'ack-1085');
COMMIT;
SELECT 'ack', 1085;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1086, 30, X'76616C75652D3030303031303836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1086, 'wal', 'ack-1086');
COMMIT;
SELECT 'ack', 1086;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1087, 31, X'76616C75652D3030303031303837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1087, 'wal', 'ack-1087');
COMMIT;
SELECT 'ack', 1087;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1088, 0, X'76616C75652D3030303031303838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1088, 'wal', 'ack-1088');
COMMIT;
SELECT 'ack', 1088;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1089, 1, X'76616C75652D3030303031303839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1089, 'wal', 'ack-1089');
COMMIT;
SELECT 'ack', 1089;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1090, 2, X'76616C75652D3030303031303930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1090, 'wal', 'ack-1090');
COMMIT;
SELECT 'ack', 1090;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1091, 3, X'76616C75652D3030303031303931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1091, 'wal', 'ack-1091');
COMMIT;
SELECT 'ack', 1091;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1092, 4, X'76616C75652D3030303031303932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1092, 'wal', 'ack-1092');
COMMIT;
SELECT 'ack', 1092;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1093, 5, X'76616C75652D3030303031303933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1093, 'wal', 'ack-1093');
COMMIT;
SELECT 'ack', 1093;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1094, 6, X'76616C75652D3030303031303934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1094, 'wal', 'ack-1094');
COMMIT;
SELECT 'ack', 1094;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1095, 7, X'76616C75652D3030303031303935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1095, 'wal', 'ack-1095');
COMMIT;
SELECT 'ack', 1095;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1096, 8, X'76616C75652D3030303031303936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1096, 'wal', 'ack-1096');
COMMIT;
SELECT 'ack', 1096;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1097, 9, X'76616C75652D3030303031303937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1097, 'wal', 'ack-1097');
COMMIT;
SELECT 'ack', 1097;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1098, 10, X'76616C75652D3030303031303938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1098, 'wal', 'ack-1098');
COMMIT;
SELECT 'ack', 1098;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1099, 11, X'76616C75652D3030303031303939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1099, 'wal', 'ack-1099');
COMMIT;
SELECT 'ack', 1099;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1100, 12, X'76616C75652D3030303031313030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1100, 'wal', 'ack-1100');
COMMIT;
SELECT 'ack', 1100;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1101, 13, X'76616C75652D3030303031313031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1101, 'wal', 'ack-1101');
COMMIT;
SELECT 'ack', 1101;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1102, 14, X'76616C75652D3030303031313032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1102, 'wal', 'ack-1102');
COMMIT;
SELECT 'ack', 1102;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1103, 15, X'76616C75652D3030303031313033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1103, 'wal', 'ack-1103');
COMMIT;
SELECT 'ack', 1103;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1104, 16, X'76616C75652D3030303031313034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1104, 'wal', 'ack-1104');
COMMIT;
SELECT 'ack', 1104;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1105, 17, X'76616C75652D3030303031313035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1105, 'wal', 'ack-1105');
COMMIT;
SELECT 'ack', 1105;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1106, 18, X'76616C75652D3030303031313036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1106, 'wal', 'ack-1106');
COMMIT;
SELECT 'ack', 1106;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1107, 19, X'76616C75652D3030303031313037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1107, 'wal', 'ack-1107');
COMMIT;
SELECT 'ack', 1107;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1108, 20, X'76616C75652D3030303031313038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1108, 'wal', 'ack-1108');
COMMIT;
SELECT 'ack', 1108;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1109, 21, X'76616C75652D3030303031313039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1109, 'wal', 'ack-1109');
COMMIT;
SELECT 'ack', 1109;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1110, 22, X'76616C75652D3030303031313130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1110, 'wal', 'ack-1110');
COMMIT;
SELECT 'ack', 1110;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1111, 23, X'76616C75652D3030303031313131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1111, 'wal', 'ack-1111');
COMMIT;
SELECT 'ack', 1111;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1112, 24, X'76616C75652D3030303031313132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1112, 'wal', 'ack-1112');
COMMIT;
SELECT 'ack', 1112;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1113, 25, X'76616C75652D3030303031313133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1113, 'wal', 'ack-1113');
COMMIT;
SELECT 'ack', 1113;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1114, 26, X'76616C75652D3030303031313134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1114, 'wal', 'ack-1114');
COMMIT;
SELECT 'ack', 1114;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1115, 27, X'76616C75652D3030303031313135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1115, 'wal', 'ack-1115');
COMMIT;
SELECT 'ack', 1115;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1116, 28, X'76616C75652D3030303031313136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1116, 'wal', 'ack-1116');
COMMIT;
SELECT 'ack', 1116;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1117, 29, X'76616C75652D3030303031313137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1117, 'wal', 'ack-1117');
COMMIT;
SELECT 'ack', 1117;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1118, 30, X'76616C75652D3030303031313138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1118, 'wal', 'ack-1118');
COMMIT;
SELECT 'ack', 1118;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1119, 31, X'76616C75652D3030303031313139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1119, 'wal', 'ack-1119');
COMMIT;
SELECT 'ack', 1119;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1120, 0, X'76616C75652D3030303031313230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1120, 'wal', 'ack-1120');
COMMIT;
SELECT 'ack', 1120;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1121, 1, X'76616C75652D3030303031313231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1121, 'wal', 'ack-1121');
COMMIT;
SELECT 'ack', 1121;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1122, 2, X'76616C75652D3030303031313232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1122, 'wal', 'ack-1122');
COMMIT;
SELECT 'ack', 1122;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1123, 3, X'76616C75652D3030303031313233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1123, 'wal', 'ack-1123');
COMMIT;
SELECT 'ack', 1123;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1124, 4, X'76616C75652D3030303031313234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1124, 'wal', 'ack-1124');
COMMIT;
SELECT 'ack', 1124;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1125, 5, X'76616C75652D3030303031313235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1125, 'wal', 'ack-1125');
COMMIT;
SELECT 'ack', 1125;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1126, 6, X'76616C75652D3030303031313236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1126, 'wal', 'ack-1126');
COMMIT;
SELECT 'ack', 1126;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1127, 7, X'76616C75652D3030303031313237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1127, 'wal', 'ack-1127');
COMMIT;
SELECT 'ack', 1127;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1128, 8, X'76616C75652D3030303031313238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1128, 'wal', 'ack-1128');
COMMIT;
SELECT 'ack', 1128;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1129, 9, X'76616C75652D3030303031313239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1129, 'wal', 'ack-1129');
COMMIT;
SELECT 'ack', 1129;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1130, 10, X'76616C75652D3030303031313330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1130, 'wal', 'ack-1130');
COMMIT;
SELECT 'ack', 1130;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1131, 11, X'76616C75652D3030303031313331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1131, 'wal', 'ack-1131');
COMMIT;
SELECT 'ack', 1131;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1132, 12, X'76616C75652D3030303031313332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1132, 'wal', 'ack-1132');
COMMIT;
SELECT 'ack', 1132;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1133, 13, X'76616C75652D3030303031313333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1133, 'wal', 'ack-1133');
COMMIT;
SELECT 'ack', 1133;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1134, 14, X'76616C75652D3030303031313334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1134, 'wal', 'ack-1134');
COMMIT;
SELECT 'ack', 1134;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1135, 15, X'76616C75652D3030303031313335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1135, 'wal', 'ack-1135');
COMMIT;
SELECT 'ack', 1135;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1136, 16, X'76616C75652D3030303031313336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1136, 'wal', 'ack-1136');
COMMIT;
SELECT 'ack', 1136;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1137, 17, X'76616C75652D3030303031313337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1137, 'wal', 'ack-1137');
COMMIT;
SELECT 'ack', 1137;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1138, 18, X'76616C75652D3030303031313338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1138, 'wal', 'ack-1138');
COMMIT;
SELECT 'ack', 1138;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1139, 19, X'76616C75652D3030303031313339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1139, 'wal', 'ack-1139');
COMMIT;
SELECT 'ack', 1139;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1140, 20, X'76616C75652D3030303031313430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1140, 'wal', 'ack-1140');
COMMIT;
SELECT 'ack', 1140;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1141, 21, X'76616C75652D3030303031313431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1141, 'wal', 'ack-1141');
COMMIT;
SELECT 'ack', 1141;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1142, 22, X'76616C75652D3030303031313432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1142, 'wal', 'ack-1142');
COMMIT;
SELECT 'ack', 1142;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1143, 23, X'76616C75652D3030303031313433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1143, 'wal', 'ack-1143');
COMMIT;
SELECT 'ack', 1143;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1144, 24, X'76616C75652D3030303031313434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1144, 'wal', 'ack-1144');
COMMIT;
SELECT 'ack', 1144;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1145, 25, X'76616C75652D3030303031313435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1145, 'wal', 'ack-1145');
COMMIT;
SELECT 'ack', 1145;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1146, 26, X'76616C75652D3030303031313436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1146, 'wal', 'ack-1146');
COMMIT;
SELECT 'ack', 1146;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1147, 27, X'76616C75652D3030303031313437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1147, 'wal', 'ack-1147');
COMMIT;
SELECT 'ack', 1147;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1148, 28, X'76616C75652D3030303031313438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1148, 'wal', 'ack-1148');
COMMIT;
SELECT 'ack', 1148;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1149, 29, X'76616C75652D3030303031313439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1149, 'wal', 'ack-1149');
COMMIT;
SELECT 'ack', 1149;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1150, 30, X'76616C75652D3030303031313530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1150, 'wal', 'ack-1150');
COMMIT;
SELECT 'ack', 1150;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1151, 31, X'76616C75652D3030303031313531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1151, 'wal', 'ack-1151');
COMMIT;
SELECT 'ack', 1151;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1152, 0, X'76616C75652D3030303031313532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1152, 'wal', 'ack-1152');
COMMIT;
SELECT 'ack', 1152;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1153, 1, X'76616C75652D3030303031313533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1153, 'wal', 'ack-1153');
COMMIT;
SELECT 'ack', 1153;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1154, 2, X'76616C75652D3030303031313534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1154, 'wal', 'ack-1154');
COMMIT;
SELECT 'ack', 1154;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1155, 3, X'76616C75652D3030303031313535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1155, 'wal', 'ack-1155');
COMMIT;
SELECT 'ack', 1155;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1156, 4, X'76616C75652D3030303031313536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1156, 'wal', 'ack-1156');
COMMIT;
SELECT 'ack', 1156;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1157, 5, X'76616C75652D3030303031313537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1157, 'wal', 'ack-1157');
COMMIT;
SELECT 'ack', 1157;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1158, 6, X'76616C75652D3030303031313538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1158, 'wal', 'ack-1158');
COMMIT;
SELECT 'ack', 1158;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1159, 7, X'76616C75652D3030303031313539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1159, 'wal', 'ack-1159');
COMMIT;
SELECT 'ack', 1159;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1160, 8, X'76616C75652D3030303031313630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1160, 'wal', 'ack-1160');
COMMIT;
SELECT 'ack', 1160;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1161, 9, X'76616C75652D3030303031313631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1161, 'wal', 'ack-1161');
COMMIT;
SELECT 'ack', 1161;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1162, 10, X'76616C75652D3030303031313632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1162, 'wal', 'ack-1162');
COMMIT;
SELECT 'ack', 1162;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1163, 11, X'76616C75652D3030303031313633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1163, 'wal', 'ack-1163');
COMMIT;
SELECT 'ack', 1163;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1164, 12, X'76616C75652D3030303031313634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1164, 'wal', 'ack-1164');
COMMIT;
SELECT 'ack', 1164;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1165, 13, X'76616C75652D3030303031313635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1165, 'wal', 'ack-1165');
COMMIT;
SELECT 'ack', 1165;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1166, 14, X'76616C75652D3030303031313636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1166, 'wal', 'ack-1166');
COMMIT;
SELECT 'ack', 1166;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1167, 15, X'76616C75652D3030303031313637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1167, 'wal', 'ack-1167');
COMMIT;
SELECT 'ack', 1167;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1168, 16, X'76616C75652D3030303031313638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1168, 'wal', 'ack-1168');
COMMIT;
SELECT 'ack', 1168;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1169, 17, X'76616C75652D3030303031313639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1169, 'wal', 'ack-1169');
COMMIT;
SELECT 'ack', 1169;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1170, 18, X'76616C75652D3030303031313730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1170, 'wal', 'ack-1170');
COMMIT;
SELECT 'ack', 1170;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1171, 19, X'76616C75652D3030303031313731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1171, 'wal', 'ack-1171');
COMMIT;
SELECT 'ack', 1171;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1172, 20, X'76616C75652D3030303031313732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1172, 'wal', 'ack-1172');
COMMIT;
SELECT 'ack', 1172;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1173, 21, X'76616C75652D3030303031313733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1173, 'wal', 'ack-1173');
COMMIT;
SELECT 'ack', 1173;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1174, 22, X'76616C75652D3030303031313734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1174, 'wal', 'ack-1174');
COMMIT;
SELECT 'ack', 1174;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1175, 23, X'76616C75652D3030303031313735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1175, 'wal', 'ack-1175');
COMMIT;
SELECT 'ack', 1175;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1176, 24, X'76616C75652D3030303031313736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1176, 'wal', 'ack-1176');
COMMIT;
SELECT 'ack', 1176;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1177, 25, X'76616C75652D3030303031313737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1177, 'wal', 'ack-1177');
COMMIT;
SELECT 'ack', 1177;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1178, 26, X'76616C75652D3030303031313738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1178, 'wal', 'ack-1178');
COMMIT;
SELECT 'ack', 1178;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1179, 27, X'76616C75652D3030303031313739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1179, 'wal', 'ack-1179');
COMMIT;
SELECT 'ack', 1179;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1180, 28, X'76616C75652D3030303031313830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1180, 'wal', 'ack-1180');
COMMIT;
SELECT 'ack', 1180;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1181, 29, X'76616C75652D3030303031313831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1181, 'wal', 'ack-1181');
COMMIT;
SELECT 'ack', 1181;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1182, 30, X'76616C75652D3030303031313832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1182, 'wal', 'ack-1182');
COMMIT;
SELECT 'ack', 1182;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1183, 31, X'76616C75652D3030303031313833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1183, 'wal', 'ack-1183');
COMMIT;
SELECT 'ack', 1183;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1184, 0, X'76616C75652D3030303031313834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1184, 'wal', 'ack-1184');
COMMIT;
SELECT 'ack', 1184;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1185, 1, X'76616C75652D3030303031313835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1185, 'wal', 'ack-1185');
COMMIT;
SELECT 'ack', 1185;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1186, 2, X'76616C75652D3030303031313836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1186, 'wal', 'ack-1186');
COMMIT;
SELECT 'ack', 1186;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1187, 3, X'76616C75652D3030303031313837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1187, 'wal', 'ack-1187');
COMMIT;
SELECT 'ack', 1187;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1188, 4, X'76616C75652D3030303031313838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1188, 'wal', 'ack-1188');
COMMIT;
SELECT 'ack', 1188;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1189, 5, X'76616C75652D3030303031313839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1189, 'wal', 'ack-1189');
COMMIT;
SELECT 'ack', 1189;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1190, 6, X'76616C75652D3030303031313930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1190, 'wal', 'ack-1190');
COMMIT;
SELECT 'ack', 1190;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1191, 7, X'76616C75652D3030303031313931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1191, 'wal', 'ack-1191');
COMMIT;
SELECT 'ack', 1191;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1192, 8, X'76616C75652D3030303031313932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1192, 'wal', 'ack-1192');
COMMIT;
SELECT 'ack', 1192;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1193, 9, X'76616C75652D3030303031313933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1193, 'wal', 'ack-1193');
COMMIT;
SELECT 'ack', 1193;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1194, 10, X'76616C75652D3030303031313934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1194, 'wal', 'ack-1194');
COMMIT;
SELECT 'ack', 1194;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1195, 11, X'76616C75652D3030303031313935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1195, 'wal', 'ack-1195');
COMMIT;
SELECT 'ack', 1195;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1196, 12, X'76616C75652D3030303031313936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1196, 'wal', 'ack-1196');
COMMIT;
SELECT 'ack', 1196;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1197, 13, X'76616C75652D3030303031313937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1197, 'wal', 'ack-1197');
COMMIT;
SELECT 'ack', 1197;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1198, 14, X'76616C75652D3030303031313938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1198, 'wal', 'ack-1198');
COMMIT;
SELECT 'ack', 1198;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1199, 15, X'76616C75652D3030303031313939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1199, 'wal', 'ack-1199');
COMMIT;
SELECT 'ack', 1199;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1200, 16, X'76616C75652D3030303031323030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1200, 'wal', 'ack-1200');
COMMIT;
SELECT 'ack', 1200;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1201, 17, X'76616C75652D3030303031323031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1201, 'wal', 'ack-1201');
COMMIT;
SELECT 'ack', 1201;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1202, 18, X'76616C75652D3030303031323032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1202, 'wal', 'ack-1202');
COMMIT;
SELECT 'ack', 1202;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1203, 19, X'76616C75652D3030303031323033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1203, 'wal', 'ack-1203');
COMMIT;
SELECT 'ack', 1203;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1204, 20, X'76616C75652D3030303031323034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1204, 'wal', 'ack-1204');
COMMIT;
SELECT 'ack', 1204;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1205, 21, X'76616C75652D3030303031323035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1205, 'wal', 'ack-1205');
COMMIT;
SELECT 'ack', 1205;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1206, 22, X'76616C75652D3030303031323036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1206, 'wal', 'ack-1206');
COMMIT;
SELECT 'ack', 1206;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1207, 23, X'76616C75652D3030303031323037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1207, 'wal', 'ack-1207');
COMMIT;
SELECT 'ack', 1207;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1208, 24, X'76616C75652D3030303031323038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1208, 'wal', 'ack-1208');
COMMIT;
SELECT 'ack', 1208;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1209, 25, X'76616C75652D3030303031323039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1209, 'wal', 'ack-1209');
COMMIT;
SELECT 'ack', 1209;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1210, 26, X'76616C75652D3030303031323130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1210, 'wal', 'ack-1210');
COMMIT;
SELECT 'ack', 1210;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1211, 27, X'76616C75652D3030303031323131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1211, 'wal', 'ack-1211');
COMMIT;
SELECT 'ack', 1211;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1212, 28, X'76616C75652D3030303031323132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1212, 'wal', 'ack-1212');
COMMIT;
SELECT 'ack', 1212;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1213, 29, X'76616C75652D3030303031323133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1213, 'wal', 'ack-1213');
COMMIT;
SELECT 'ack', 1213;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1214, 30, X'76616C75652D3030303031323134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1214, 'wal', 'ack-1214');
COMMIT;
SELECT 'ack', 1214;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1215, 31, X'76616C75652D3030303031323135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1215, 'wal', 'ack-1215');
COMMIT;
SELECT 'ack', 1215;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1216, 0, X'76616C75652D3030303031323136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1216, 'wal', 'ack-1216');
COMMIT;
SELECT 'ack', 1216;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1217, 1, X'76616C75652D3030303031323137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1217, 'wal', 'ack-1217');
COMMIT;
SELECT 'ack', 1217;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1218, 2, X'76616C75652D3030303031323138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1218, 'wal', 'ack-1218');
COMMIT;
SELECT 'ack', 1218;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1219, 3, X'76616C75652D3030303031323139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1219, 'wal', 'ack-1219');
COMMIT;
SELECT 'ack', 1219;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1220, 4, X'76616C75652D3030303031323230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1220, 'wal', 'ack-1220');
COMMIT;
SELECT 'ack', 1220;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1221, 5, X'76616C75652D3030303031323231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1221, 'wal', 'ack-1221');
COMMIT;
SELECT 'ack', 1221;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1222, 6, X'76616C75652D3030303031323232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1222, 'wal', 'ack-1222');
COMMIT;
SELECT 'ack', 1222;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1223, 7, X'76616C75652D3030303031323233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1223, 'wal', 'ack-1223');
COMMIT;
SELECT 'ack', 1223;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1224, 8, X'76616C75652D3030303031323234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1224, 'wal', 'ack-1224');
COMMIT;
SELECT 'ack', 1224;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1225, 9, X'76616C75652D3030303031323235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1225, 'wal', 'ack-1225');
COMMIT;
SELECT 'ack', 1225;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1226, 10, X'76616C75652D3030303031323236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1226, 'wal', 'ack-1226');
COMMIT;
SELECT 'ack', 1226;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1227, 11, X'76616C75652D3030303031323237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1227, 'wal', 'ack-1227');
COMMIT;
SELECT 'ack', 1227;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1228, 12, X'76616C75652D3030303031323238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1228, 'wal', 'ack-1228');
COMMIT;
SELECT 'ack', 1228;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1229, 13, X'76616C75652D3030303031323239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1229, 'wal', 'ack-1229');
COMMIT;
SELECT 'ack', 1229;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1230, 14, X'76616C75652D3030303031323330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1230, 'wal', 'ack-1230');
COMMIT;
SELECT 'ack', 1230;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1231, 15, X'76616C75652D3030303031323331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1231, 'wal', 'ack-1231');
COMMIT;
SELECT 'ack', 1231;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1232, 16, X'76616C75652D3030303031323332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1232, 'wal', 'ack-1232');
COMMIT;
SELECT 'ack', 1232;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1233, 17, X'76616C75652D3030303031323333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1233, 'wal', 'ack-1233');
COMMIT;
SELECT 'ack', 1233;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1234, 18, X'76616C75652D3030303031323334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1234, 'wal', 'ack-1234');
COMMIT;
SELECT 'ack', 1234;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1235, 19, X'76616C75652D3030303031323335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1235, 'wal', 'ack-1235');
COMMIT;
SELECT 'ack', 1235;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1236, 20, X'76616C75652D3030303031323336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1236, 'wal', 'ack-1236');
COMMIT;
SELECT 'ack', 1236;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1237, 21, X'76616C75652D3030303031323337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1237, 'wal', 'ack-1237');
COMMIT;
SELECT 'ack', 1237;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1238, 22, X'76616C75652D3030303031323338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1238, 'wal', 'ack-1238');
COMMIT;
SELECT 'ack', 1238;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1239, 23, X'76616C75652D3030303031323339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1239, 'wal', 'ack-1239');
COMMIT;
SELECT 'ack', 1239;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1240, 24, X'76616C75652D3030303031323430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1240, 'wal', 'ack-1240');
COMMIT;
SELECT 'ack', 1240;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1241, 25, X'76616C75652D3030303031323431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1241, 'wal', 'ack-1241');
COMMIT;
SELECT 'ack', 1241;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1242, 26, X'76616C75652D3030303031323432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1242, 'wal', 'ack-1242');
COMMIT;
SELECT 'ack', 1242;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1243, 27, X'76616C75652D3030303031323433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1243, 'wal', 'ack-1243');
COMMIT;
SELECT 'ack', 1243;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1244, 28, X'76616C75652D3030303031323434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1244, 'wal', 'ack-1244');
COMMIT;
SELECT 'ack', 1244;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1245, 29, X'76616C75652D3030303031323435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1245, 'wal', 'ack-1245');
COMMIT;
SELECT 'ack', 1245;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1246, 30, X'76616C75652D3030303031323436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1246, 'wal', 'ack-1246');
COMMIT;
SELECT 'ack', 1246;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1247, 31, X'76616C75652D3030303031323437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1247, 'wal', 'ack-1247');
COMMIT;
SELECT 'ack', 1247;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1248, 0, X'76616C75652D3030303031323438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1248, 'wal', 'ack-1248');
COMMIT;
SELECT 'ack', 1248;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1249, 1, X'76616C75652D3030303031323439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1249, 'wal', 'ack-1249');
COMMIT;
SELECT 'ack', 1249;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1250, 2, X'76616C75652D3030303031323530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1250, 'wal', 'ack-1250');
COMMIT;
SELECT 'ack', 1250;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1251, 3, X'76616C75652D3030303031323531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1251, 'wal', 'ack-1251');
COMMIT;
SELECT 'ack', 1251;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1252, 4, X'76616C75652D3030303031323532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1252, 'wal', 'ack-1252');
COMMIT;
SELECT 'ack', 1252;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1253, 5, X'76616C75652D3030303031323533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1253, 'wal', 'ack-1253');
COMMIT;
SELECT 'ack', 1253;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1254, 6, X'76616C75652D3030303031323534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1254, 'wal', 'ack-1254');
COMMIT;
SELECT 'ack', 1254;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1255, 7, X'76616C75652D3030303031323535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1255, 'wal', 'ack-1255');
COMMIT;
SELECT 'ack', 1255;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1256, 8, X'76616C75652D3030303031323536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1256, 'wal', 'ack-1256');
COMMIT;
SELECT 'ack', 1256;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1257, 9, X'76616C75652D3030303031323537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1257, 'wal', 'ack-1257');
COMMIT;
SELECT 'ack', 1257;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1258, 10, X'76616C75652D3030303031323538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1258, 'wal', 'ack-1258');
COMMIT;
SELECT 'ack', 1258;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1259, 11, X'76616C75652D3030303031323539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1259, 'wal', 'ack-1259');
COMMIT;
SELECT 'ack', 1259;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1260, 12, X'76616C75652D3030303031323630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1260, 'wal', 'ack-1260');
COMMIT;
SELECT 'ack', 1260;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1261, 13, X'76616C75652D3030303031323631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1261, 'wal', 'ack-1261');
COMMIT;
SELECT 'ack', 1261;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1262, 14, X'76616C75652D3030303031323632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1262, 'wal', 'ack-1262');
COMMIT;
SELECT 'ack', 1262;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1263, 15, X'76616C75652D3030303031323633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1263, 'wal', 'ack-1263');
COMMIT;
SELECT 'ack', 1263;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1264, 16, X'76616C75652D3030303031323634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1264, 'wal', 'ack-1264');
COMMIT;
SELECT 'ack', 1264;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1265, 17, X'76616C75652D3030303031323635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1265, 'wal', 'ack-1265');
COMMIT;
SELECT 'ack', 1265;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1266, 18, X'76616C75652D3030303031323636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1266, 'wal', 'ack-1266');
COMMIT;
SELECT 'ack', 1266;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1267, 19, X'76616C75652D3030303031323637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1267, 'wal', 'ack-1267');
COMMIT;
SELECT 'ack', 1267;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1268, 20, X'76616C75652D3030303031323638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1268, 'wal', 'ack-1268');
COMMIT;
SELECT 'ack', 1268;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1269, 21, X'76616C75652D3030303031323639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1269, 'wal', 'ack-1269');
COMMIT;
SELECT 'ack', 1269;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1270, 22, X'76616C75652D3030303031323730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1270, 'wal', 'ack-1270');
COMMIT;
SELECT 'ack', 1270;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1271, 23, X'76616C75652D3030303031323731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1271, 'wal', 'ack-1271');
COMMIT;
SELECT 'ack', 1271;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1272, 24, X'76616C75652D3030303031323732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1272, 'wal', 'ack-1272');
COMMIT;
SELECT 'ack', 1272;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1273, 25, X'76616C75652D3030303031323733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1273, 'wal', 'ack-1273');
COMMIT;
SELECT 'ack', 1273;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1274, 26, X'76616C75652D3030303031323734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1274, 'wal', 'ack-1274');
COMMIT;
SELECT 'ack', 1274;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1275, 27, X'76616C75652D3030303031323735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1275, 'wal', 'ack-1275');
COMMIT;
SELECT 'ack', 1275;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1276, 28, X'76616C75652D3030303031323736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1276, 'wal', 'ack-1276');
COMMIT;
SELECT 'ack', 1276;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1277, 29, X'76616C75652D3030303031323737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1277, 'wal', 'ack-1277');
COMMIT;
SELECT 'ack', 1277;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1278, 30, X'76616C75652D3030303031323738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1278, 'wal', 'ack-1278');
COMMIT;
SELECT 'ack', 1278;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1279, 31, X'76616C75652D3030303031323739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1279, 'wal', 'ack-1279');
COMMIT;
SELECT 'ack', 1279;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1280, 0, X'76616C75652D3030303031323830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1280, 'wal', 'ack-1280');
COMMIT;
SELECT 'ack', 1280;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1281, 1, X'76616C75652D3030303031323831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1281, 'wal', 'ack-1281');
COMMIT;
SELECT 'ack', 1281;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1282, 2, X'76616C75652D3030303031323832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1282, 'wal', 'ack-1282');
COMMIT;
SELECT 'ack', 1282;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1283, 3, X'76616C75652D3030303031323833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1283, 'wal', 'ack-1283');
COMMIT;
SELECT 'ack', 1283;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1284, 4, X'76616C75652D3030303031323834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1284, 'wal', 'ack-1284');
COMMIT;
SELECT 'ack', 1284;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1285, 5, X'76616C75652D3030303031323835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1285, 'wal', 'ack-1285');
COMMIT;
SELECT 'ack', 1285;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1286, 6, X'76616C75652D3030303031323836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1286, 'wal', 'ack-1286');
COMMIT;
SELECT 'ack', 1286;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1287, 7, X'76616C75652D3030303031323837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1287, 'wal', 'ack-1287');
COMMIT;
SELECT 'ack', 1287;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1288, 8, X'76616C75652D3030303031323838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1288, 'wal', 'ack-1288');
COMMIT;
SELECT 'ack', 1288;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1289, 9, X'76616C75652D3030303031323839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1289, 'wal', 'ack-1289');
COMMIT;
SELECT 'ack', 1289;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1290, 10, X'76616C75652D3030303031323930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1290, 'wal', 'ack-1290');
COMMIT;
SELECT 'ack', 1290;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1291, 11, X'76616C75652D3030303031323931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1291, 'wal', 'ack-1291');
COMMIT;
SELECT 'ack', 1291;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1292, 12, X'76616C75652D3030303031323932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1292, 'wal', 'ack-1292');
COMMIT;
SELECT 'ack', 1292;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1293, 13, X'76616C75652D3030303031323933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1293, 'wal', 'ack-1293');
COMMIT;
SELECT 'ack', 1293;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1294, 14, X'76616C75652D3030303031323934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1294, 'wal', 'ack-1294');
COMMIT;
SELECT 'ack', 1294;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1295, 15, X'76616C75652D3030303031323935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1295, 'wal', 'ack-1295');
COMMIT;
SELECT 'ack', 1295;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1296, 16, X'76616C75652D3030303031323936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1296, 'wal', 'ack-1296');
COMMIT;
SELECT 'ack', 1296;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1297, 17, X'76616C75652D3030303031323937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1297, 'wal', 'ack-1297');
COMMIT;
SELECT 'ack', 1297;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1298, 18, X'76616C75652D3030303031323938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1298, 'wal', 'ack-1298');
COMMIT;
SELECT 'ack', 1298;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1299, 19, X'76616C75652D3030303031323939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1299, 'wal', 'ack-1299');
COMMIT;
SELECT 'ack', 1299;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1300, 20, X'76616C75652D3030303031333030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1300, 'wal', 'ack-1300');
COMMIT;
SELECT 'ack', 1300;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1301, 21, X'76616C75652D3030303031333031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1301, 'wal', 'ack-1301');
COMMIT;
SELECT 'ack', 1301;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1302, 22, X'76616C75652D3030303031333032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1302, 'wal', 'ack-1302');
COMMIT;
SELECT 'ack', 1302;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1303, 23, X'76616C75652D3030303031333033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1303, 'wal', 'ack-1303');
COMMIT;
SELECT 'ack', 1303;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1304, 24, X'76616C75652D3030303031333034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1304, 'wal', 'ack-1304');
COMMIT;
SELECT 'ack', 1304;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1305, 25, X'76616C75652D3030303031333035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1305, 'wal', 'ack-1305');
COMMIT;
SELECT 'ack', 1305;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1306, 26, X'76616C75652D3030303031333036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1306, 'wal', 'ack-1306');
COMMIT;
SELECT 'ack', 1306;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1307, 27, X'76616C75652D3030303031333037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1307, 'wal', 'ack-1307');
COMMIT;
SELECT 'ack', 1307;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1308, 28, X'76616C75652D3030303031333038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1308, 'wal', 'ack-1308');
COMMIT;
SELECT 'ack', 1308;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1309, 29, X'76616C75652D3030303031333039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1309, 'wal', 'ack-1309');
COMMIT;
SELECT 'ack', 1309;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1310, 30, X'76616C75652D3030303031333130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1310, 'wal', 'ack-1310');
COMMIT;
SELECT 'ack', 1310;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1311, 31, X'76616C75652D3030303031333131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1311, 'wal', 'ack-1311');
COMMIT;
SELECT 'ack', 1311;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1312, 0, X'76616C75652D3030303031333132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1312, 'wal', 'ack-1312');
COMMIT;
SELECT 'ack', 1312;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1313, 1, X'76616C75652D3030303031333133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1313, 'wal', 'ack-1313');
COMMIT;
SELECT 'ack', 1313;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1314, 2, X'76616C75652D3030303031333134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1314, 'wal', 'ack-1314');
COMMIT;
SELECT 'ack', 1314;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1315, 3, X'76616C75652D3030303031333135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1315, 'wal', 'ack-1315');
COMMIT;
SELECT 'ack', 1315;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1316, 4, X'76616C75652D3030303031333136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1316, 'wal', 'ack-1316');
COMMIT;
SELECT 'ack', 1316;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1317, 5, X'76616C75652D3030303031333137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1317, 'wal', 'ack-1317');
COMMIT;
SELECT 'ack', 1317;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1318, 6, X'76616C75652D3030303031333138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1318, 'wal', 'ack-1318');
COMMIT;
SELECT 'ack', 1318;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1319, 7, X'76616C75652D3030303031333139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1319, 'wal', 'ack-1319');
COMMIT;
SELECT 'ack', 1319;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1320, 8, X'76616C75652D3030303031333230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1320, 'wal', 'ack-1320');
COMMIT;
SELECT 'ack', 1320;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1321, 9, X'76616C75652D3030303031333231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1321, 'wal', 'ack-1321');
COMMIT;
SELECT 'ack', 1321;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1322, 10, X'76616C75652D3030303031333232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1322, 'wal', 'ack-1322');
COMMIT;
SELECT 'ack', 1322;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1323, 11, X'76616C75652D3030303031333233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1323, 'wal', 'ack-1323');
COMMIT;
SELECT 'ack', 1323;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1324, 12, X'76616C75652D3030303031333234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1324, 'wal', 'ack-1324');
COMMIT;
SELECT 'ack', 1324;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1325, 13, X'76616C75652D3030303031333235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1325, 'wal', 'ack-1325');
COMMIT;
SELECT 'ack', 1325;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1326, 14, X'76616C75652D3030303031333236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1326, 'wal', 'ack-1326');
COMMIT;
SELECT 'ack', 1326;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1327, 15, X'76616C75652D3030303031333237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1327, 'wal', 'ack-1327');
COMMIT;
SELECT 'ack', 1327;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1328, 16, X'76616C75652D3030303031333238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1328, 'wal', 'ack-1328');
COMMIT;
SELECT 'ack', 1328;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1329, 17, X'76616C75652D3030303031333239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1329, 'wal', 'ack-1329');
COMMIT;
SELECT 'ack', 1329;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1330, 18, X'76616C75652D3030303031333330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1330, 'wal', 'ack-1330');
COMMIT;
SELECT 'ack', 1330;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1331, 19, X'76616C75652D3030303031333331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1331, 'wal', 'ack-1331');
COMMIT;
SELECT 'ack', 1331;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1332, 20, X'76616C75652D3030303031333332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1332, 'wal', 'ack-1332');
COMMIT;
SELECT 'ack', 1332;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1333, 21, X'76616C75652D3030303031333333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1333, 'wal', 'ack-1333');
COMMIT;
SELECT 'ack', 1333;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1334, 22, X'76616C75652D3030303031333334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1334, 'wal', 'ack-1334');
COMMIT;
SELECT 'ack', 1334;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1335, 23, X'76616C75652D3030303031333335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1335, 'wal', 'ack-1335');
COMMIT;
SELECT 'ack', 1335;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1336, 24, X'76616C75652D3030303031333336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1336, 'wal', 'ack-1336');
COMMIT;
SELECT 'ack', 1336;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1337, 25, X'76616C75652D3030303031333337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1337, 'wal', 'ack-1337');
COMMIT;
SELECT 'ack', 1337;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1338, 26, X'76616C75652D3030303031333338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1338, 'wal', 'ack-1338');
COMMIT;
SELECT 'ack', 1338;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1339, 27, X'76616C75652D3030303031333339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1339, 'wal', 'ack-1339');
COMMIT;
SELECT 'ack', 1339;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1340, 28, X'76616C75652D3030303031333430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1340, 'wal', 'ack-1340');
COMMIT;
SELECT 'ack', 1340;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1341, 29, X'76616C75652D3030303031333431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1341, 'wal', 'ack-1341');
COMMIT;
SELECT 'ack', 1341;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1342, 30, X'76616C75652D3030303031333432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1342, 'wal', 'ack-1342');
COMMIT;
SELECT 'ack', 1342;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1343, 31, X'76616C75652D3030303031333433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1343, 'wal', 'ack-1343');
COMMIT;
SELECT 'ack', 1343;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1344, 0, X'76616C75652D3030303031333434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1344, 'wal', 'ack-1344');
COMMIT;
SELECT 'ack', 1344;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1345, 1, X'76616C75652D3030303031333435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1345, 'wal', 'ack-1345');
COMMIT;
SELECT 'ack', 1345;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1346, 2, X'76616C75652D3030303031333436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1346, 'wal', 'ack-1346');
COMMIT;
SELECT 'ack', 1346;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1347, 3, X'76616C75652D3030303031333437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1347, 'wal', 'ack-1347');
COMMIT;
SELECT 'ack', 1347;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1348, 4, X'76616C75652D3030303031333438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1348, 'wal', 'ack-1348');
COMMIT;
SELECT 'ack', 1348;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1349, 5, X'76616C75652D3030303031333439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1349, 'wal', 'ack-1349');
COMMIT;
SELECT 'ack', 1349;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1350, 6, X'76616C75652D3030303031333530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1350, 'wal', 'ack-1350');
COMMIT;
SELECT 'ack', 1350;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1351, 7, X'76616C75652D3030303031333531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1351, 'wal', 'ack-1351');
COMMIT;
SELECT 'ack', 1351;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1352, 8, X'76616C75652D3030303031333532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1352, 'wal', 'ack-1352');
COMMIT;
SELECT 'ack', 1352;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1353, 9, X'76616C75652D3030303031333533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1353, 'wal', 'ack-1353');
COMMIT;
SELECT 'ack', 1353;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1354, 10, X'76616C75652D3030303031333534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1354, 'wal', 'ack-1354');
COMMIT;
SELECT 'ack', 1354;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1355, 11, X'76616C75652D3030303031333535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1355, 'wal', 'ack-1355');
COMMIT;
SELECT 'ack', 1355;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1356, 12, X'76616C75652D3030303031333536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1356, 'wal', 'ack-1356');
COMMIT;
SELECT 'ack', 1356;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1357, 13, X'76616C75652D3030303031333537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1357, 'wal', 'ack-1357');
COMMIT;
SELECT 'ack', 1357;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1358, 14, X'76616C75652D3030303031333538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1358, 'wal', 'ack-1358');
COMMIT;
SELECT 'ack', 1358;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1359, 15, X'76616C75652D3030303031333539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1359, 'wal', 'ack-1359');
COMMIT;
SELECT 'ack', 1359;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1360, 16, X'76616C75652D3030303031333630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1360, 'wal', 'ack-1360');
COMMIT;
SELECT 'ack', 1360;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1361, 17, X'76616C75652D3030303031333631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1361, 'wal', 'ack-1361');
COMMIT;
SELECT 'ack', 1361;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1362, 18, X'76616C75652D3030303031333632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1362, 'wal', 'ack-1362');
COMMIT;
SELECT 'ack', 1362;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1363, 19, X'76616C75652D3030303031333633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1363, 'wal', 'ack-1363');
COMMIT;
SELECT 'ack', 1363;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1364, 20, X'76616C75652D3030303031333634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1364, 'wal', 'ack-1364');
COMMIT;
SELECT 'ack', 1364;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1365, 21, X'76616C75652D3030303031333635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1365, 'wal', 'ack-1365');
COMMIT;
SELECT 'ack', 1365;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1366, 22, X'76616C75652D3030303031333636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1366, 'wal', 'ack-1366');
COMMIT;
SELECT 'ack', 1366;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1367, 23, X'76616C75652D3030303031333637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1367, 'wal', 'ack-1367');
COMMIT;
SELECT 'ack', 1367;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1368, 24, X'76616C75652D3030303031333638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1368, 'wal', 'ack-1368');
COMMIT;
SELECT 'ack', 1368;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1369, 25, X'76616C75652D3030303031333639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1369, 'wal', 'ack-1369');
COMMIT;
SELECT 'ack', 1369;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1370, 26, X'76616C75652D3030303031333730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1370, 'wal', 'ack-1370');
COMMIT;
SELECT 'ack', 1370;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1371, 27, X'76616C75652D3030303031333731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1371, 'wal', 'ack-1371');
COMMIT;
SELECT 'ack', 1371;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1372, 28, X'76616C75652D3030303031333732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1372, 'wal', 'ack-1372');
COMMIT;
SELECT 'ack', 1372;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1373, 29, X'76616C75652D3030303031333733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1373, 'wal', 'ack-1373');
COMMIT;
SELECT 'ack', 1373;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1374, 30, X'76616C75652D3030303031333734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1374, 'wal', 'ack-1374');
COMMIT;
SELECT 'ack', 1374;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1375, 31, X'76616C75652D3030303031333735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1375, 'wal', 'ack-1375');
COMMIT;
SELECT 'ack', 1375;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1376, 0, X'76616C75652D3030303031333736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1376, 'wal', 'ack-1376');
COMMIT;
SELECT 'ack', 1376;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1377, 1, X'76616C75652D3030303031333737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1377, 'wal', 'ack-1377');
COMMIT;
SELECT 'ack', 1377;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1378, 2, X'76616C75652D3030303031333738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1378, 'wal', 'ack-1378');
COMMIT;
SELECT 'ack', 1378;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1379, 3, X'76616C75652D3030303031333739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1379, 'wal', 'ack-1379');
COMMIT;
SELECT 'ack', 1379;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1380, 4, X'76616C75652D3030303031333830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1380, 'wal', 'ack-1380');
COMMIT;
SELECT 'ack', 1380;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1381, 5, X'76616C75652D3030303031333831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1381, 'wal', 'ack-1381');
COMMIT;
SELECT 'ack', 1381;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1382, 6, X'76616C75652D3030303031333832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1382, 'wal', 'ack-1382');
COMMIT;
SELECT 'ack', 1382;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1383, 7, X'76616C75652D3030303031333833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1383, 'wal', 'ack-1383');
COMMIT;
SELECT 'ack', 1383;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1384, 8, X'76616C75652D3030303031333834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1384, 'wal', 'ack-1384');
COMMIT;
SELECT 'ack', 1384;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1385, 9, X'76616C75652D3030303031333835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1385, 'wal', 'ack-1385');
COMMIT;
SELECT 'ack', 1385;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1386, 10, X'76616C75652D3030303031333836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1386, 'wal', 'ack-1386');
COMMIT;
SELECT 'ack', 1386;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1387, 11, X'76616C75652D3030303031333837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1387, 'wal', 'ack-1387');
COMMIT;
SELECT 'ack', 1387;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1388, 12, X'76616C75652D3030303031333838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1388, 'wal', 'ack-1388');
COMMIT;
SELECT 'ack', 1388;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1389, 13, X'76616C75652D3030303031333839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1389, 'wal', 'ack-1389');
COMMIT;
SELECT 'ack', 1389;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1390, 14, X'76616C75652D3030303031333930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1390, 'wal', 'ack-1390');
COMMIT;
SELECT 'ack', 1390;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1391, 15, X'76616C75652D3030303031333931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1391, 'wal', 'ack-1391');
COMMIT;
SELECT 'ack', 1391;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1392, 16, X'76616C75652D3030303031333932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1392, 'wal', 'ack-1392');
COMMIT;
SELECT 'ack', 1392;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1393, 17, X'76616C75652D3030303031333933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1393, 'wal', 'ack-1393');
COMMIT;
SELECT 'ack', 1393;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1394, 18, X'76616C75652D3030303031333934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1394, 'wal', 'ack-1394');
COMMIT;
SELECT 'ack', 1394;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1395, 19, X'76616C75652D3030303031333935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1395, 'wal', 'ack-1395');
COMMIT;
SELECT 'ack', 1395;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1396, 20, X'76616C75652D3030303031333936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1396, 'wal', 'ack-1396');
COMMIT;
SELECT 'ack', 1396;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1397, 21, X'76616C75652D3030303031333937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1397, 'wal', 'ack-1397');
COMMIT;
SELECT 'ack', 1397;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1398, 22, X'76616C75652D3030303031333938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1398, 'wal', 'ack-1398');
COMMIT;
SELECT 'ack', 1398;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1399, 23, X'76616C75652D3030303031333939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1399, 'wal', 'ack-1399');
COMMIT;
SELECT 'ack', 1399;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1400, 24, X'76616C75652D3030303031343030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1400, 'wal', 'ack-1400');
COMMIT;
SELECT 'ack', 1400;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1401, 25, X'76616C75652D3030303031343031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1401, 'wal', 'ack-1401');
COMMIT;
SELECT 'ack', 1401;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1402, 26, X'76616C75652D3030303031343032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1402, 'wal', 'ack-1402');
COMMIT;
SELECT 'ack', 1402;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1403, 27, X'76616C75652D3030303031343033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1403, 'wal', 'ack-1403');
COMMIT;
SELECT 'ack', 1403;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1404, 28, X'76616C75652D3030303031343034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1404, 'wal', 'ack-1404');
COMMIT;
SELECT 'ack', 1404;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1405, 29, X'76616C75652D3030303031343035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1405, 'wal', 'ack-1405');
COMMIT;
SELECT 'ack', 1405;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1406, 30, X'76616C75652D3030303031343036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1406, 'wal', 'ack-1406');
COMMIT;
SELECT 'ack', 1406;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1407, 31, X'76616C75652D3030303031343037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1407, 'wal', 'ack-1407');
COMMIT;
SELECT 'ack', 1407;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1408, 0, X'76616C75652D3030303031343038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1408, 'wal', 'ack-1408');
COMMIT;
SELECT 'ack', 1408;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1409, 1, X'76616C75652D3030303031343039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1409, 'wal', 'ack-1409');
COMMIT;
SELECT 'ack', 1409;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1410, 2, X'76616C75652D3030303031343130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1410, 'wal', 'ack-1410');
COMMIT;
SELECT 'ack', 1410;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1411, 3, X'76616C75652D3030303031343131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1411, 'wal', 'ack-1411');
COMMIT;
SELECT 'ack', 1411;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1412, 4, X'76616C75652D3030303031343132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1412, 'wal', 'ack-1412');
COMMIT;
SELECT 'ack', 1412;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1413, 5, X'76616C75652D3030303031343133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1413, 'wal', 'ack-1413');
COMMIT;
SELECT 'ack', 1413;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1414, 6, X'76616C75652D3030303031343134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1414, 'wal', 'ack-1414');
COMMIT;
SELECT 'ack', 1414;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1415, 7, X'76616C75652D3030303031343135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1415, 'wal', 'ack-1415');
COMMIT;
SELECT 'ack', 1415;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1416, 8, X'76616C75652D3030303031343136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1416, 'wal', 'ack-1416');
COMMIT;
SELECT 'ack', 1416;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1417, 9, X'76616C75652D3030303031343137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1417, 'wal', 'ack-1417');
COMMIT;
SELECT 'ack', 1417;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1418, 10, X'76616C75652D3030303031343138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1418, 'wal', 'ack-1418');
COMMIT;
SELECT 'ack', 1418;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1419, 11, X'76616C75652D3030303031343139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1419, 'wal', 'ack-1419');
COMMIT;
SELECT 'ack', 1419;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1420, 12, X'76616C75652D3030303031343230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1420, 'wal', 'ack-1420');
COMMIT;
SELECT 'ack', 1420;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1421, 13, X'76616C75652D3030303031343231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1421, 'wal', 'ack-1421');
COMMIT;
SELECT 'ack', 1421;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1422, 14, X'76616C75652D3030303031343232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1422, 'wal', 'ack-1422');
COMMIT;
SELECT 'ack', 1422;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1423, 15, X'76616C75652D3030303031343233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1423, 'wal', 'ack-1423');
COMMIT;
SELECT 'ack', 1423;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1424, 16, X'76616C75652D3030303031343234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1424, 'wal', 'ack-1424');
COMMIT;
SELECT 'ack', 1424;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1425, 17, X'76616C75652D3030303031343235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1425, 'wal', 'ack-1425');
COMMIT;
SELECT 'ack', 1425;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1426, 18, X'76616C75652D3030303031343236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1426, 'wal', 'ack-1426');
COMMIT;
SELECT 'ack', 1426;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1427, 19, X'76616C75652D3030303031343237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1427, 'wal', 'ack-1427');
COMMIT;
SELECT 'ack', 1427;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1428, 20, X'76616C75652D3030303031343238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1428, 'wal', 'ack-1428');
COMMIT;
SELECT 'ack', 1428;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1429, 21, X'76616C75652D3030303031343239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1429, 'wal', 'ack-1429');
COMMIT;
SELECT 'ack', 1429;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1430, 22, X'76616C75652D3030303031343330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1430, 'wal', 'ack-1430');
COMMIT;
SELECT 'ack', 1430;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1431, 23, X'76616C75652D3030303031343331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1431, 'wal', 'ack-1431');
COMMIT;
SELECT 'ack', 1431;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1432, 24, X'76616C75652D3030303031343332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1432, 'wal', 'ack-1432');
COMMIT;
SELECT 'ack', 1432;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1433, 25, X'76616C75652D3030303031343333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1433, 'wal', 'ack-1433');
COMMIT;
SELECT 'ack', 1433;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1434, 26, X'76616C75652D3030303031343334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1434, 'wal', 'ack-1434');
COMMIT;
SELECT 'ack', 1434;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1435, 27, X'76616C75652D3030303031343335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1435, 'wal', 'ack-1435');
COMMIT;
SELECT 'ack', 1435;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1436, 28, X'76616C75652D3030303031343336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1436, 'wal', 'ack-1436');
COMMIT;
SELECT 'ack', 1436;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1437, 29, X'76616C75652D3030303031343337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1437, 'wal', 'ack-1437');
COMMIT;
SELECT 'ack', 1437;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1438, 30, X'76616C75652D3030303031343338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1438, 'wal', 'ack-1438');
COMMIT;
SELECT 'ack', 1438;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1439, 31, X'76616C75652D3030303031343339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1439, 'wal', 'ack-1439');
COMMIT;
SELECT 'ack', 1439;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1440, 0, X'76616C75652D3030303031343430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1440, 'wal', 'ack-1440');
COMMIT;
SELECT 'ack', 1440;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1441, 1, X'76616C75652D3030303031343431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1441, 'wal', 'ack-1441');
COMMIT;
SELECT 'ack', 1441;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1442, 2, X'76616C75652D3030303031343432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1442, 'wal', 'ack-1442');
COMMIT;
SELECT 'ack', 1442;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1443, 3, X'76616C75652D3030303031343433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1443, 'wal', 'ack-1443');
COMMIT;
SELECT 'ack', 1443;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1444, 4, X'76616C75652D3030303031343434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1444, 'wal', 'ack-1444');
COMMIT;
SELECT 'ack', 1444;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1445, 5, X'76616C75652D3030303031343435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1445, 'wal', 'ack-1445');
COMMIT;
SELECT 'ack', 1445;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1446, 6, X'76616C75652D3030303031343436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1446, 'wal', 'ack-1446');
COMMIT;
SELECT 'ack', 1446;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1447, 7, X'76616C75652D3030303031343437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1447, 'wal', 'ack-1447');
COMMIT;
SELECT 'ack', 1447;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1448, 8, X'76616C75652D3030303031343438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1448, 'wal', 'ack-1448');
COMMIT;
SELECT 'ack', 1448;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1449, 9, X'76616C75652D3030303031343439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1449, 'wal', 'ack-1449');
COMMIT;
SELECT 'ack', 1449;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1450, 10, X'76616C75652D3030303031343530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1450, 'wal', 'ack-1450');
COMMIT;
SELECT 'ack', 1450;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1451, 11, X'76616C75652D3030303031343531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1451, 'wal', 'ack-1451');
COMMIT;
SELECT 'ack', 1451;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1452, 12, X'76616C75652D3030303031343532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1452, 'wal', 'ack-1452');
COMMIT;
SELECT 'ack', 1452;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1453, 13, X'76616C75652D3030303031343533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1453, 'wal', 'ack-1453');
COMMIT;
SELECT 'ack', 1453;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1454, 14, X'76616C75652D3030303031343534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1454, 'wal', 'ack-1454');
COMMIT;
SELECT 'ack', 1454;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1455, 15, X'76616C75652D3030303031343535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1455, 'wal', 'ack-1455');
COMMIT;
SELECT 'ack', 1455;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1456, 16, X'76616C75652D3030303031343536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1456, 'wal', 'ack-1456');
COMMIT;
SELECT 'ack', 1456;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1457, 17, X'76616C75652D3030303031343537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1457, 'wal', 'ack-1457');
COMMIT;
SELECT 'ack', 1457;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1458, 18, X'76616C75652D3030303031343538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1458, 'wal', 'ack-1458');
COMMIT;
SELECT 'ack', 1458;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1459, 19, X'76616C75652D3030303031343539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1459, 'wal', 'ack-1459');
COMMIT;
SELECT 'ack', 1459;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1460, 20, X'76616C75652D3030303031343630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1460, 'wal', 'ack-1460');
COMMIT;
SELECT 'ack', 1460;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1461, 21, X'76616C75652D3030303031343631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1461, 'wal', 'ack-1461');
COMMIT;
SELECT 'ack', 1461;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1462, 22, X'76616C75652D3030303031343632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1462, 'wal', 'ack-1462');
COMMIT;
SELECT 'ack', 1462;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1463, 23, X'76616C75652D3030303031343633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1463, 'wal', 'ack-1463');
COMMIT;
SELECT 'ack', 1463;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1464, 24, X'76616C75652D3030303031343634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1464, 'wal', 'ack-1464');
COMMIT;
SELECT 'ack', 1464;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1465, 25, X'76616C75652D3030303031343635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1465, 'wal', 'ack-1465');
COMMIT;
SELECT 'ack', 1465;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1466, 26, X'76616C75652D3030303031343636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1466, 'wal', 'ack-1466');
COMMIT;
SELECT 'ack', 1466;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1467, 27, X'76616C75652D3030303031343637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1467, 'wal', 'ack-1467');
COMMIT;
SELECT 'ack', 1467;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1468, 28, X'76616C75652D3030303031343638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1468, 'wal', 'ack-1468');
COMMIT;
SELECT 'ack', 1468;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1469, 29, X'76616C75652D3030303031343639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1469, 'wal', 'ack-1469');
COMMIT;
SELECT 'ack', 1469;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1470, 30, X'76616C75652D3030303031343730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1470, 'wal', 'ack-1470');
COMMIT;
SELECT 'ack', 1470;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1471, 31, X'76616C75652D3030303031343731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1471, 'wal', 'ack-1471');
COMMIT;
SELECT 'ack', 1471;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1472, 0, X'76616C75652D3030303031343732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1472, 'wal', 'ack-1472');
COMMIT;
SELECT 'ack', 1472;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1473, 1, X'76616C75652D3030303031343733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1473, 'wal', 'ack-1473');
COMMIT;
SELECT 'ack', 1473;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1474, 2, X'76616C75652D3030303031343734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1474, 'wal', 'ack-1474');
COMMIT;
SELECT 'ack', 1474;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1475, 3, X'76616C75652D3030303031343735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1475, 'wal', 'ack-1475');
COMMIT;
SELECT 'ack', 1475;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1476, 4, X'76616C75652D3030303031343736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1476, 'wal', 'ack-1476');
COMMIT;
SELECT 'ack', 1476;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1477, 5, X'76616C75652D3030303031343737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1477, 'wal', 'ack-1477');
COMMIT;
SELECT 'ack', 1477;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1478, 6, X'76616C75652D3030303031343738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1478, 'wal', 'ack-1478');
COMMIT;
SELECT 'ack', 1478;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1479, 7, X'76616C75652D3030303031343739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1479, 'wal', 'ack-1479');
COMMIT;
SELECT 'ack', 1479;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1480, 8, X'76616C75652D3030303031343830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1480, 'wal', 'ack-1480');
COMMIT;
SELECT 'ack', 1480;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1481, 9, X'76616C75652D3030303031343831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1481, 'wal', 'ack-1481');
COMMIT;
SELECT 'ack', 1481;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1482, 10, X'76616C75652D3030303031343832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1482, 'wal', 'ack-1482');
COMMIT;
SELECT 'ack', 1482;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1483, 11, X'76616C75652D3030303031343833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1483, 'wal', 'ack-1483');
COMMIT;
SELECT 'ack', 1483;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1484, 12, X'76616C75652D3030303031343834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1484, 'wal', 'ack-1484');
COMMIT;
SELECT 'ack', 1484;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1485, 13, X'76616C75652D3030303031343835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1485, 'wal', 'ack-1485');
COMMIT;
SELECT 'ack', 1485;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1486, 14, X'76616C75652D3030303031343836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1486, 'wal', 'ack-1486');
COMMIT;
SELECT 'ack', 1486;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1487, 15, X'76616C75652D3030303031343837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1487, 'wal', 'ack-1487');
COMMIT;
SELECT 'ack', 1487;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1488, 16, X'76616C75652D3030303031343838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1488, 'wal', 'ack-1488');
COMMIT;
SELECT 'ack', 1488;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1489, 17, X'76616C75652D3030303031343839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1489, 'wal', 'ack-1489');
COMMIT;
SELECT 'ack', 1489;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1490, 18, X'76616C75652D3030303031343930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1490, 'wal', 'ack-1490');
COMMIT;
SELECT 'ack', 1490;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1491, 19, X'76616C75652D3030303031343931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1491, 'wal', 'ack-1491');
COMMIT;
SELECT 'ack', 1491;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1492, 20, X'76616C75652D3030303031343932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1492, 'wal', 'ack-1492');
COMMIT;
SELECT 'ack', 1492;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1493, 21, X'76616C75652D3030303031343933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1493, 'wal', 'ack-1493');
COMMIT;
SELECT 'ack', 1493;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1494, 22, X'76616C75652D3030303031343934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1494, 'wal', 'ack-1494');
COMMIT;
SELECT 'ack', 1494;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1495, 23, X'76616C75652D3030303031343935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1495, 'wal', 'ack-1495');
COMMIT;
SELECT 'ack', 1495;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1496, 24, X'76616C75652D3030303031343936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1496, 'wal', 'ack-1496');
COMMIT;
SELECT 'ack', 1496;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1497, 25, X'76616C75652D3030303031343937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1497, 'wal', 'ack-1497');
COMMIT;
SELECT 'ack', 1497;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1498, 26, X'76616C75652D3030303031343938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1498, 'wal', 'ack-1498');
COMMIT;
SELECT 'ack', 1498;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1499, 27, X'76616C75652D3030303031343939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1499, 'wal', 'ack-1499');
COMMIT;
SELECT 'ack', 1499;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1500, 28, X'76616C75652D3030303031353030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1500, 'wal', 'ack-1500');
COMMIT;
SELECT 'ack', 1500;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1501, 29, X'76616C75652D3030303031353031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1501, 'wal', 'ack-1501');
COMMIT;
SELECT 'ack', 1501;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1502, 30, X'76616C75652D3030303031353032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1502, 'wal', 'ack-1502');
COMMIT;
SELECT 'ack', 1502;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1503, 31, X'76616C75652D3030303031353033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1503, 'wal', 'ack-1503');
COMMIT;
SELECT 'ack', 1503;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1504, 0, X'76616C75652D3030303031353034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1504, 'wal', 'ack-1504');
COMMIT;
SELECT 'ack', 1504;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1505, 1, X'76616C75652D3030303031353035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1505, 'wal', 'ack-1505');
COMMIT;
SELECT 'ack', 1505;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1506, 2, X'76616C75652D3030303031353036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1506, 'wal', 'ack-1506');
COMMIT;
SELECT 'ack', 1506;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1507, 3, X'76616C75652D3030303031353037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1507, 'wal', 'ack-1507');
COMMIT;
SELECT 'ack', 1507;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1508, 4, X'76616C75652D3030303031353038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1508, 'wal', 'ack-1508');
COMMIT;
SELECT 'ack', 1508;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1509, 5, X'76616C75652D3030303031353039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1509, 'wal', 'ack-1509');
COMMIT;
SELECT 'ack', 1509;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1510, 6, X'76616C75652D3030303031353130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1510, 'wal', 'ack-1510');
COMMIT;
SELECT 'ack', 1510;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1511, 7, X'76616C75652D3030303031353131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1511, 'wal', 'ack-1511');
COMMIT;
SELECT 'ack', 1511;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1512, 8, X'76616C75652D3030303031353132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1512, 'wal', 'ack-1512');
COMMIT;
SELECT 'ack', 1512;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1513, 9, X'76616C75652D3030303031353133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1513, 'wal', 'ack-1513');
COMMIT;
SELECT 'ack', 1513;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1514, 10, X'76616C75652D3030303031353134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1514, 'wal', 'ack-1514');
COMMIT;
SELECT 'ack', 1514;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1515, 11, X'76616C75652D3030303031353135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1515, 'wal', 'ack-1515');
COMMIT;
SELECT 'ack', 1515;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1516, 12, X'76616C75652D3030303031353136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1516, 'wal', 'ack-1516');
COMMIT;
SELECT 'ack', 1516;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1517, 13, X'76616C75652D3030303031353137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1517, 'wal', 'ack-1517');
COMMIT;
SELECT 'ack', 1517;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1518, 14, X'76616C75652D3030303031353138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1518, 'wal', 'ack-1518');
COMMIT;
SELECT 'ack', 1518;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1519, 15, X'76616C75652D3030303031353139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1519, 'wal', 'ack-1519');
COMMIT;
SELECT 'ack', 1519;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1520, 16, X'76616C75652D3030303031353230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1520, 'wal', 'ack-1520');
COMMIT;
SELECT 'ack', 1520;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1521, 17, X'76616C75652D3030303031353231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1521, 'wal', 'ack-1521');
COMMIT;
SELECT 'ack', 1521;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1522, 18, X'76616C75652D3030303031353232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1522, 'wal', 'ack-1522');
COMMIT;
SELECT 'ack', 1522;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1523, 19, X'76616C75652D3030303031353233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1523, 'wal', 'ack-1523');
COMMIT;
SELECT 'ack', 1523;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1524, 20, X'76616C75652D3030303031353234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1524, 'wal', 'ack-1524');
COMMIT;
SELECT 'ack', 1524;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1525, 21, X'76616C75652D3030303031353235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1525, 'wal', 'ack-1525');
COMMIT;
SELECT 'ack', 1525;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1526, 22, X'76616C75652D3030303031353236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1526, 'wal', 'ack-1526');
COMMIT;
SELECT 'ack', 1526;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1527, 23, X'76616C75652D3030303031353237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1527, 'wal', 'ack-1527');
COMMIT;
SELECT 'ack', 1527;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1528, 24, X'76616C75652D3030303031353238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1528, 'wal', 'ack-1528');
COMMIT;
SELECT 'ack', 1528;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1529, 25, X'76616C75652D3030303031353239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1529, 'wal', 'ack-1529');
COMMIT;
SELECT 'ack', 1529;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1530, 26, X'76616C75652D3030303031353330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1530, 'wal', 'ack-1530');
COMMIT;
SELECT 'ack', 1530;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1531, 27, X'76616C75652D3030303031353331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1531, 'wal', 'ack-1531');
COMMIT;
SELECT 'ack', 1531;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1532, 28, X'76616C75652D3030303031353332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1532, 'wal', 'ack-1532');
COMMIT;
SELECT 'ack', 1532;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1533, 29, X'76616C75652D3030303031353333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1533, 'wal', 'ack-1533');
COMMIT;
SELECT 'ack', 1533;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1534, 30, X'76616C75652D3030303031353334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1534, 'wal', 'ack-1534');
COMMIT;
SELECT 'ack', 1534;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1535, 31, X'76616C75652D3030303031353335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1535, 'wal', 'ack-1535');
COMMIT;
SELECT 'ack', 1535;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1536, 0, X'76616C75652D3030303031353336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1536, 'wal', 'ack-1536');
COMMIT;
SELECT 'ack', 1536;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1537, 1, X'76616C75652D3030303031353337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1537, 'wal', 'ack-1537');
COMMIT;
SELECT 'ack', 1537;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1538, 2, X'76616C75652D3030303031353338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1538, 'wal', 'ack-1538');
COMMIT;
SELECT 'ack', 1538;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1539, 3, X'76616C75652D3030303031353339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1539, 'wal', 'ack-1539');
COMMIT;
SELECT 'ack', 1539;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1540, 4, X'76616C75652D3030303031353430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1540, 'wal', 'ack-1540');
COMMIT;
SELECT 'ack', 1540;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1541, 5, X'76616C75652D3030303031353431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1541, 'wal', 'ack-1541');
COMMIT;
SELECT 'ack', 1541;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1542, 6, X'76616C75652D3030303031353432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1542, 'wal', 'ack-1542');
COMMIT;
SELECT 'ack', 1542;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1543, 7, X'76616C75652D3030303031353433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1543, 'wal', 'ack-1543');
COMMIT;
SELECT 'ack', 1543;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1544, 8, X'76616C75652D3030303031353434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1544, 'wal', 'ack-1544');
COMMIT;
SELECT 'ack', 1544;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1545, 9, X'76616C75652D3030303031353435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1545, 'wal', 'ack-1545');
COMMIT;
SELECT 'ack', 1545;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1546, 10, X'76616C75652D3030303031353436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1546, 'wal', 'ack-1546');
COMMIT;
SELECT 'ack', 1546;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1547, 11, X'76616C75652D3030303031353437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1547, 'wal', 'ack-1547');
COMMIT;
SELECT 'ack', 1547;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1548, 12, X'76616C75652D3030303031353438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1548, 'wal', 'ack-1548');
COMMIT;
SELECT 'ack', 1548;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1549, 13, X'76616C75652D3030303031353439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1549, 'wal', 'ack-1549');
COMMIT;
SELECT 'ack', 1549;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1550, 14, X'76616C75652D3030303031353530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1550, 'wal', 'ack-1550');
COMMIT;
SELECT 'ack', 1550;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1551, 15, X'76616C75652D3030303031353531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1551, 'wal', 'ack-1551');
COMMIT;
SELECT 'ack', 1551;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1552, 16, X'76616C75652D3030303031353532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1552, 'wal', 'ack-1552');
COMMIT;
SELECT 'ack', 1552;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1553, 17, X'76616C75652D3030303031353533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1553, 'wal', 'ack-1553');
COMMIT;
SELECT 'ack', 1553;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1554, 18, X'76616C75652D3030303031353534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1554, 'wal', 'ack-1554');
COMMIT;
SELECT 'ack', 1554;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1555, 19, X'76616C75652D3030303031353535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1555, 'wal', 'ack-1555');
COMMIT;
SELECT 'ack', 1555;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1556, 20, X'76616C75652D3030303031353536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1556, 'wal', 'ack-1556');
COMMIT;
SELECT 'ack', 1556;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1557, 21, X'76616C75652D3030303031353537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1557, 'wal', 'ack-1557');
COMMIT;
SELECT 'ack', 1557;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1558, 22, X'76616C75652D3030303031353538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1558, 'wal', 'ack-1558');
COMMIT;
SELECT 'ack', 1558;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1559, 23, X'76616C75652D3030303031353539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1559, 'wal', 'ack-1559');
COMMIT;
SELECT 'ack', 1559;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1560, 24, X'76616C75652D3030303031353630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1560, 'wal', 'ack-1560');
COMMIT;
SELECT 'ack', 1560;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1561, 25, X'76616C75652D3030303031353631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1561, 'wal', 'ack-1561');
COMMIT;
SELECT 'ack', 1561;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1562, 26, X'76616C75652D3030303031353632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1562, 'wal', 'ack-1562');
COMMIT;
SELECT 'ack', 1562;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1563, 27, X'76616C75652D3030303031353633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1563, 'wal', 'ack-1563');
COMMIT;
SELECT 'ack', 1563;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1564, 28, X'76616C75652D3030303031353634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1564, 'wal', 'ack-1564');
COMMIT;
SELECT 'ack', 1564;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1565, 29, X'76616C75652D3030303031353635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1565, 'wal', 'ack-1565');
COMMIT;
SELECT 'ack', 1565;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1566, 30, X'76616C75652D3030303031353636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1566, 'wal', 'ack-1566');
COMMIT;
SELECT 'ack', 1566;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1567, 31, X'76616C75652D3030303031353637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1567, 'wal', 'ack-1567');
COMMIT;
SELECT 'ack', 1567;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1568, 0, X'76616C75652D3030303031353638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1568, 'wal', 'ack-1568');
COMMIT;
SELECT 'ack', 1568;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1569, 1, X'76616C75652D3030303031353639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1569, 'wal', 'ack-1569');
COMMIT;
SELECT 'ack', 1569;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1570, 2, X'76616C75652D3030303031353730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1570, 'wal', 'ack-1570');
COMMIT;
SELECT 'ack', 1570;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1571, 3, X'76616C75652D3030303031353731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1571, 'wal', 'ack-1571');
COMMIT;
SELECT 'ack', 1571;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1572, 4, X'76616C75652D3030303031353732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1572, 'wal', 'ack-1572');
COMMIT;
SELECT 'ack', 1572;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1573, 5, X'76616C75652D3030303031353733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1573, 'wal', 'ack-1573');
COMMIT;
SELECT 'ack', 1573;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1574, 6, X'76616C75652D3030303031353734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1574, 'wal', 'ack-1574');
COMMIT;
SELECT 'ack', 1574;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1575, 7, X'76616C75652D3030303031353735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1575, 'wal', 'ack-1575');
COMMIT;
SELECT 'ack', 1575;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1576, 8, X'76616C75652D3030303031353736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1576, 'wal', 'ack-1576');
COMMIT;
SELECT 'ack', 1576;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1577, 9, X'76616C75652D3030303031353737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1577, 'wal', 'ack-1577');
COMMIT;
SELECT 'ack', 1577;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1578, 10, X'76616C75652D3030303031353738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1578, 'wal', 'ack-1578');
COMMIT;
SELECT 'ack', 1578;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1579, 11, X'76616C75652D3030303031353739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1579, 'wal', 'ack-1579');
COMMIT;
SELECT 'ack', 1579;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1580, 12, X'76616C75652D3030303031353830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1580, 'wal', 'ack-1580');
COMMIT;
SELECT 'ack', 1580;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1581, 13, X'76616C75652D3030303031353831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1581, 'wal', 'ack-1581');
COMMIT;
SELECT 'ack', 1581;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1582, 14, X'76616C75652D3030303031353832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1582, 'wal', 'ack-1582');
COMMIT;
SELECT 'ack', 1582;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1583, 15, X'76616C75652D3030303031353833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1583, 'wal', 'ack-1583');
COMMIT;
SELECT 'ack', 1583;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1584, 16, X'76616C75652D3030303031353834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1584, 'wal', 'ack-1584');
COMMIT;
SELECT 'ack', 1584;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1585, 17, X'76616C75652D3030303031353835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1585, 'wal', 'ack-1585');
COMMIT;
SELECT 'ack', 1585;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1586, 18, X'76616C75652D3030303031353836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1586, 'wal', 'ack-1586');
COMMIT;
SELECT 'ack', 1586;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1587, 19, X'76616C75652D3030303031353837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1587, 'wal', 'ack-1587');
COMMIT;
SELECT 'ack', 1587;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1588, 20, X'76616C75652D3030303031353838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1588, 'wal', 'ack-1588');
COMMIT;
SELECT 'ack', 1588;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1589, 21, X'76616C75652D3030303031353839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1589, 'wal', 'ack-1589');
COMMIT;
SELECT 'ack', 1589;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1590, 22, X'76616C75652D3030303031353930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1590, 'wal', 'ack-1590');
COMMIT;
SELECT 'ack', 1590;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1591, 23, X'76616C75652D3030303031353931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1591, 'wal', 'ack-1591');
COMMIT;
SELECT 'ack', 1591;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1592, 24, X'76616C75652D3030303031353932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1592, 'wal', 'ack-1592');
COMMIT;
SELECT 'ack', 1592;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1593, 25, X'76616C75652D3030303031353933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1593, 'wal', 'ack-1593');
COMMIT;
SELECT 'ack', 1593;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1594, 26, X'76616C75652D3030303031353934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1594, 'wal', 'ack-1594');
COMMIT;
SELECT 'ack', 1594;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1595, 27, X'76616C75652D3030303031353935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1595, 'wal', 'ack-1595');
COMMIT;
SELECT 'ack', 1595;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1596, 28, X'76616C75652D3030303031353936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1596, 'wal', 'ack-1596');
COMMIT;
SELECT 'ack', 1596;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1597, 29, X'76616C75652D3030303031353937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1597, 'wal', 'ack-1597');
COMMIT;
SELECT 'ack', 1597;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1598, 30, X'76616C75652D3030303031353938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1598, 'wal', 'ack-1598');
COMMIT;
SELECT 'ack', 1598;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1599, 31, X'76616C75652D3030303031353939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1599, 'wal', 'ack-1599');
COMMIT;
SELECT 'ack', 1599;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1600, 0, X'76616C75652D3030303031363030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1600, 'wal', 'ack-1600');
COMMIT;
SELECT 'ack', 1600;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1601, 1, X'76616C75652D3030303031363031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1601, 'wal', 'ack-1601');
COMMIT;
SELECT 'ack', 1601;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1602, 2, X'76616C75652D3030303031363032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1602, 'wal', 'ack-1602');
COMMIT;
SELECT 'ack', 1602;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1603, 3, X'76616C75652D3030303031363033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1603, 'wal', 'ack-1603');
COMMIT;
SELECT 'ack', 1603;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1604, 4, X'76616C75652D3030303031363034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1604, 'wal', 'ack-1604');
COMMIT;
SELECT 'ack', 1604;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1605, 5, X'76616C75652D3030303031363035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1605, 'wal', 'ack-1605');
COMMIT;
SELECT 'ack', 1605;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1606, 6, X'76616C75652D3030303031363036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1606, 'wal', 'ack-1606');
COMMIT;
SELECT 'ack', 1606;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1607, 7, X'76616C75652D3030303031363037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1607, 'wal', 'ack-1607');
COMMIT;
SELECT 'ack', 1607;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1608, 8, X'76616C75652D3030303031363038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1608, 'wal', 'ack-1608');
COMMIT;
SELECT 'ack', 1608;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1609, 9, X'76616C75652D3030303031363039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1609, 'wal', 'ack-1609');
COMMIT;
SELECT 'ack', 1609;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1610, 10, X'76616C75652D3030303031363130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1610, 'wal', 'ack-1610');
COMMIT;
SELECT 'ack', 1610;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1611, 11, X'76616C75652D3030303031363131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1611, 'wal', 'ack-1611');
COMMIT;
SELECT 'ack', 1611;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1612, 12, X'76616C75652D3030303031363132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1612, 'wal', 'ack-1612');
COMMIT;
SELECT 'ack', 1612;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1613, 13, X'76616C75652D3030303031363133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1613, 'wal', 'ack-1613');
COMMIT;
SELECT 'ack', 1613;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1614, 14, X'76616C75652D3030303031363134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1614, 'wal', 'ack-1614');
COMMIT;
SELECT 'ack', 1614;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1615, 15, X'76616C75652D3030303031363135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1615, 'wal', 'ack-1615');
COMMIT;
SELECT 'ack', 1615;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1616, 16, X'76616C75652D3030303031363136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1616, 'wal', 'ack-1616');
COMMIT;
SELECT 'ack', 1616;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1617, 17, X'76616C75652D3030303031363137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1617, 'wal', 'ack-1617');
COMMIT;
SELECT 'ack', 1617;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1618, 18, X'76616C75652D3030303031363138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1618, 'wal', 'ack-1618');
COMMIT;
SELECT 'ack', 1618;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1619, 19, X'76616C75652D3030303031363139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1619, 'wal', 'ack-1619');
COMMIT;
SELECT 'ack', 1619;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1620, 20, X'76616C75652D3030303031363230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1620, 'wal', 'ack-1620');
COMMIT;
SELECT 'ack', 1620;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1621, 21, X'76616C75652D3030303031363231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1621, 'wal', 'ack-1621');
COMMIT;
SELECT 'ack', 1621;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1622, 22, X'76616C75652D3030303031363232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1622, 'wal', 'ack-1622');
COMMIT;
SELECT 'ack', 1622;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1623, 23, X'76616C75652D3030303031363233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1623, 'wal', 'ack-1623');
COMMIT;
SELECT 'ack', 1623;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1624, 24, X'76616C75652D3030303031363234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1624, 'wal', 'ack-1624');
COMMIT;
SELECT 'ack', 1624;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1625, 25, X'76616C75652D3030303031363235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1625, 'wal', 'ack-1625');
COMMIT;
SELECT 'ack', 1625;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1626, 26, X'76616C75652D3030303031363236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1626, 'wal', 'ack-1626');
COMMIT;
SELECT 'ack', 1626;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1627, 27, X'76616C75652D3030303031363237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1627, 'wal', 'ack-1627');
COMMIT;
SELECT 'ack', 1627;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1628, 28, X'76616C75652D3030303031363238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1628, 'wal', 'ack-1628');
COMMIT;
SELECT 'ack', 1628;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1629, 29, X'76616C75652D3030303031363239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1629, 'wal', 'ack-1629');
COMMIT;
SELECT 'ack', 1629;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1630, 30, X'76616C75652D3030303031363330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1630, 'wal', 'ack-1630');
COMMIT;
SELECT 'ack', 1630;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1631, 31, X'76616C75652D3030303031363331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1631, 'wal', 'ack-1631');
COMMIT;
SELECT 'ack', 1631;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1632, 0, X'76616C75652D3030303031363332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1632, 'wal', 'ack-1632');
COMMIT;
SELECT 'ack', 1632;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1633, 1, X'76616C75652D3030303031363333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1633, 'wal', 'ack-1633');
COMMIT;
SELECT 'ack', 1633;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1634, 2, X'76616C75652D3030303031363334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1634, 'wal', 'ack-1634');
COMMIT;
SELECT 'ack', 1634;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1635, 3, X'76616C75652D3030303031363335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1635, 'wal', 'ack-1635');
COMMIT;
SELECT 'ack', 1635;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1636, 4, X'76616C75652D3030303031363336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1636, 'wal', 'ack-1636');
COMMIT;
SELECT 'ack', 1636;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1637, 5, X'76616C75652D3030303031363337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1637, 'wal', 'ack-1637');
COMMIT;
SELECT 'ack', 1637;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1638, 6, X'76616C75652D3030303031363338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1638, 'wal', 'ack-1638');
COMMIT;
SELECT 'ack', 1638;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1639, 7, X'76616C75652D3030303031363339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1639, 'wal', 'ack-1639');
COMMIT;
SELECT 'ack', 1639;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1640, 8, X'76616C75652D3030303031363430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1640, 'wal', 'ack-1640');
COMMIT;
SELECT 'ack', 1640;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1641, 9, X'76616C75652D3030303031363431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1641, 'wal', 'ack-1641');
COMMIT;
SELECT 'ack', 1641;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1642, 10, X'76616C75652D3030303031363432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1642, 'wal', 'ack-1642');
COMMIT;
SELECT 'ack', 1642;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1643, 11, X'76616C75652D3030303031363433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1643, 'wal', 'ack-1643');
COMMIT;
SELECT 'ack', 1643;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1644, 12, X'76616C75652D3030303031363434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1644, 'wal', 'ack-1644');
COMMIT;
SELECT 'ack', 1644;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1645, 13, X'76616C75652D3030303031363435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1645, 'wal', 'ack-1645');
COMMIT;
SELECT 'ack', 1645;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1646, 14, X'76616C75652D3030303031363436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1646, 'wal', 'ack-1646');
COMMIT;
SELECT 'ack', 1646;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1647, 15, X'76616C75652D3030303031363437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1647, 'wal', 'ack-1647');
COMMIT;
SELECT 'ack', 1647;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1648, 16, X'76616C75652D3030303031363438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1648, 'wal', 'ack-1648');
COMMIT;
SELECT 'ack', 1648;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1649, 17, X'76616C75652D3030303031363439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1649, 'wal', 'ack-1649');
COMMIT;
SELECT 'ack', 1649;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1650, 18, X'76616C75652D3030303031363530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1650, 'wal', 'ack-1650');
COMMIT;
SELECT 'ack', 1650;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1651, 19, X'76616C75652D3030303031363531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1651, 'wal', 'ack-1651');
COMMIT;
SELECT 'ack', 1651;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1652, 20, X'76616C75652D3030303031363532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1652, 'wal', 'ack-1652');
COMMIT;
SELECT 'ack', 1652;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1653, 21, X'76616C75652D3030303031363533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1653, 'wal', 'ack-1653');
COMMIT;
SELECT 'ack', 1653;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1654, 22, X'76616C75652D3030303031363534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1654, 'wal', 'ack-1654');
COMMIT;
SELECT 'ack', 1654;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1655, 23, X'76616C75652D3030303031363535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1655, 'wal', 'ack-1655');
COMMIT;
SELECT 'ack', 1655;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1656, 24, X'76616C75652D3030303031363536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1656, 'wal', 'ack-1656');
COMMIT;
SELECT 'ack', 1656;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1657, 25, X'76616C75652D3030303031363537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1657, 'wal', 'ack-1657');
COMMIT;
SELECT 'ack', 1657;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1658, 26, X'76616C75652D3030303031363538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1658, 'wal', 'ack-1658');
COMMIT;
SELECT 'ack', 1658;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1659, 27, X'76616C75652D3030303031363539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1659, 'wal', 'ack-1659');
COMMIT;
SELECT 'ack', 1659;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1660, 28, X'76616C75652D3030303031363630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1660, 'wal', 'ack-1660');
COMMIT;
SELECT 'ack', 1660;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1661, 29, X'76616C75652D3030303031363631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1661, 'wal', 'ack-1661');
COMMIT;
SELECT 'ack', 1661;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1662, 30, X'76616C75652D3030303031363632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1662, 'wal', 'ack-1662');
COMMIT;
SELECT 'ack', 1662;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1663, 31, X'76616C75652D3030303031363633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1663, 'wal', 'ack-1663');
COMMIT;
SELECT 'ack', 1663;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1664, 0, X'76616C75652D3030303031363634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1664, 'wal', 'ack-1664');
COMMIT;
SELECT 'ack', 1664;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1665, 1, X'76616C75652D3030303031363635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1665, 'wal', 'ack-1665');
COMMIT;
SELECT 'ack', 1665;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1666, 2, X'76616C75652D3030303031363636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1666, 'wal', 'ack-1666');
COMMIT;
SELECT 'ack', 1666;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1667, 3, X'76616C75652D3030303031363637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1667, 'wal', 'ack-1667');
COMMIT;
SELECT 'ack', 1667;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1668, 4, X'76616C75652D3030303031363638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1668, 'wal', 'ack-1668');
COMMIT;
SELECT 'ack', 1668;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1669, 5, X'76616C75652D3030303031363639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1669, 'wal', 'ack-1669');
COMMIT;
SELECT 'ack', 1669;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1670, 6, X'76616C75652D3030303031363730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1670, 'wal', 'ack-1670');
COMMIT;
SELECT 'ack', 1670;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1671, 7, X'76616C75652D3030303031363731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1671, 'wal', 'ack-1671');
COMMIT;
SELECT 'ack', 1671;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1672, 8, X'76616C75652D3030303031363732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1672, 'wal', 'ack-1672');
COMMIT;
SELECT 'ack', 1672;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1673, 9, X'76616C75652D3030303031363733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1673, 'wal', 'ack-1673');
COMMIT;
SELECT 'ack', 1673;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1674, 10, X'76616C75652D3030303031363734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1674, 'wal', 'ack-1674');
COMMIT;
SELECT 'ack', 1674;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1675, 11, X'76616C75652D3030303031363735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1675, 'wal', 'ack-1675');
COMMIT;
SELECT 'ack', 1675;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1676, 12, X'76616C75652D3030303031363736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1676, 'wal', 'ack-1676');
COMMIT;
SELECT 'ack', 1676;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1677, 13, X'76616C75652D3030303031363737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1677, 'wal', 'ack-1677');
COMMIT;
SELECT 'ack', 1677;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1678, 14, X'76616C75652D3030303031363738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1678, 'wal', 'ack-1678');
COMMIT;
SELECT 'ack', 1678;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1679, 15, X'76616C75652D3030303031363739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1679, 'wal', 'ack-1679');
COMMIT;
SELECT 'ack', 1679;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1680, 16, X'76616C75652D3030303031363830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1680, 'wal', 'ack-1680');
COMMIT;
SELECT 'ack', 1680;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1681, 17, X'76616C75652D3030303031363831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1681, 'wal', 'ack-1681');
COMMIT;
SELECT 'ack', 1681;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1682, 18, X'76616C75652D3030303031363832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1682, 'wal', 'ack-1682');
COMMIT;
SELECT 'ack', 1682;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1683, 19, X'76616C75652D3030303031363833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1683, 'wal', 'ack-1683');
COMMIT;
SELECT 'ack', 1683;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1684, 20, X'76616C75652D3030303031363834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1684, 'wal', 'ack-1684');
COMMIT;
SELECT 'ack', 1684;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1685, 21, X'76616C75652D3030303031363835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1685, 'wal', 'ack-1685');
COMMIT;
SELECT 'ack', 1685;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1686, 22, X'76616C75652D3030303031363836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1686, 'wal', 'ack-1686');
COMMIT;
SELECT 'ack', 1686;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1687, 23, X'76616C75652D3030303031363837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1687, 'wal', 'ack-1687');
COMMIT;
SELECT 'ack', 1687;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1688, 24, X'76616C75652D3030303031363838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1688, 'wal', 'ack-1688');
COMMIT;
SELECT 'ack', 1688;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1689, 25, X'76616C75652D3030303031363839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1689, 'wal', 'ack-1689');
COMMIT;
SELECT 'ack', 1689;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1690, 26, X'76616C75652D3030303031363930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1690, 'wal', 'ack-1690');
COMMIT;
SELECT 'ack', 1690;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1691, 27, X'76616C75652D3030303031363931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1691, 'wal', 'ack-1691');
COMMIT;
SELECT 'ack', 1691;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1692, 28, X'76616C75652D3030303031363932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1692, 'wal', 'ack-1692');
COMMIT;
SELECT 'ack', 1692;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1693, 29, X'76616C75652D3030303031363933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1693, 'wal', 'ack-1693');
COMMIT;
SELECT 'ack', 1693;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1694, 30, X'76616C75652D3030303031363934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1694, 'wal', 'ack-1694');
COMMIT;
SELECT 'ack', 1694;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1695, 31, X'76616C75652D3030303031363935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1695, 'wal', 'ack-1695');
COMMIT;
SELECT 'ack', 1695;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1696, 0, X'76616C75652D3030303031363936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1696, 'wal', 'ack-1696');
COMMIT;
SELECT 'ack', 1696;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1697, 1, X'76616C75652D3030303031363937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1697, 'wal', 'ack-1697');
COMMIT;
SELECT 'ack', 1697;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1698, 2, X'76616C75652D3030303031363938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1698, 'wal', 'ack-1698');
COMMIT;
SELECT 'ack', 1698;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1699, 3, X'76616C75652D3030303031363939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1699, 'wal', 'ack-1699');
COMMIT;
SELECT 'ack', 1699;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1700, 4, X'76616C75652D3030303031373030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1700, 'wal', 'ack-1700');
COMMIT;
SELECT 'ack', 1700;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1701, 5, X'76616C75652D3030303031373031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1701, 'wal', 'ack-1701');
COMMIT;
SELECT 'ack', 1701;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1702, 6, X'76616C75652D3030303031373032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1702, 'wal', 'ack-1702');
COMMIT;
SELECT 'ack', 1702;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1703, 7, X'76616C75652D3030303031373033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1703, 'wal', 'ack-1703');
COMMIT;
SELECT 'ack', 1703;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1704, 8, X'76616C75652D3030303031373034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1704, 'wal', 'ack-1704');
COMMIT;
SELECT 'ack', 1704;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1705, 9, X'76616C75652D3030303031373035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1705, 'wal', 'ack-1705');
COMMIT;
SELECT 'ack', 1705;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1706, 10, X'76616C75652D3030303031373036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1706, 'wal', 'ack-1706');
COMMIT;
SELECT 'ack', 1706;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1707, 11, X'76616C75652D3030303031373037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1707, 'wal', 'ack-1707');
COMMIT;
SELECT 'ack', 1707;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1708, 12, X'76616C75652D3030303031373038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1708, 'wal', 'ack-1708');
COMMIT;
SELECT 'ack', 1708;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1709, 13, X'76616C75652D3030303031373039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1709, 'wal', 'ack-1709');
COMMIT;
SELECT 'ack', 1709;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1710, 14, X'76616C75652D3030303031373130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1710, 'wal', 'ack-1710');
COMMIT;
SELECT 'ack', 1710;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1711, 15, X'76616C75652D3030303031373131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1711, 'wal', 'ack-1711');
COMMIT;
SELECT 'ack', 1711;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1712, 16, X'76616C75652D3030303031373132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1712, 'wal', 'ack-1712');
COMMIT;
SELECT 'ack', 1712;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1713, 17, X'76616C75652D3030303031373133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1713, 'wal', 'ack-1713');
COMMIT;
SELECT 'ack', 1713;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1714, 18, X'76616C75652D3030303031373134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1714, 'wal', 'ack-1714');
COMMIT;
SELECT 'ack', 1714;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1715, 19, X'76616C75652D3030303031373135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1715, 'wal', 'ack-1715');
COMMIT;
SELECT 'ack', 1715;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1716, 20, X'76616C75652D3030303031373136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1716, 'wal', 'ack-1716');
COMMIT;
SELECT 'ack', 1716;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1717, 21, X'76616C75652D3030303031373137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1717, 'wal', 'ack-1717');
COMMIT;
SELECT 'ack', 1717;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1718, 22, X'76616C75652D3030303031373138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1718, 'wal', 'ack-1718');
COMMIT;
SELECT 'ack', 1718;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1719, 23, X'76616C75652D3030303031373139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1719, 'wal', 'ack-1719');
COMMIT;
SELECT 'ack', 1719;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1720, 24, X'76616C75652D3030303031373230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1720, 'wal', 'ack-1720');
COMMIT;
SELECT 'ack', 1720;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1721, 25, X'76616C75652D3030303031373231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1721, 'wal', 'ack-1721');
COMMIT;
SELECT 'ack', 1721;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1722, 26, X'76616C75652D3030303031373232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1722, 'wal', 'ack-1722');
COMMIT;
SELECT 'ack', 1722;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1723, 27, X'76616C75652D3030303031373233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1723, 'wal', 'ack-1723');
COMMIT;
SELECT 'ack', 1723;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1724, 28, X'76616C75652D3030303031373234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1724, 'wal', 'ack-1724');
COMMIT;
SELECT 'ack', 1724;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1725, 29, X'76616C75652D3030303031373235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1725, 'wal', 'ack-1725');
COMMIT;
SELECT 'ack', 1725;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1726, 30, X'76616C75652D3030303031373236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1726, 'wal', 'ack-1726');
COMMIT;
SELECT 'ack', 1726;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1727, 31, X'76616C75652D3030303031373237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1727, 'wal', 'ack-1727');
COMMIT;
SELECT 'ack', 1727;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1728, 0, X'76616C75652D3030303031373238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1728, 'wal', 'ack-1728');
COMMIT;
SELECT 'ack', 1728;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1729, 1, X'76616C75652D3030303031373239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1729, 'wal', 'ack-1729');
COMMIT;
SELECT 'ack', 1729;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1730, 2, X'76616C75652D3030303031373330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1730, 'wal', 'ack-1730');
COMMIT;
SELECT 'ack', 1730;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1731, 3, X'76616C75652D3030303031373331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1731, 'wal', 'ack-1731');
COMMIT;
SELECT 'ack', 1731;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1732, 4, X'76616C75652D3030303031373332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1732, 'wal', 'ack-1732');
COMMIT;
SELECT 'ack', 1732;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1733, 5, X'76616C75652D3030303031373333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1733, 'wal', 'ack-1733');
COMMIT;
SELECT 'ack', 1733;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1734, 6, X'76616C75652D3030303031373334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1734, 'wal', 'ack-1734');
COMMIT;
SELECT 'ack', 1734;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1735, 7, X'76616C75652D3030303031373335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1735, 'wal', 'ack-1735');
COMMIT;
SELECT 'ack', 1735;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1736, 8, X'76616C75652D3030303031373336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1736, 'wal', 'ack-1736');
COMMIT;
SELECT 'ack', 1736;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1737, 9, X'76616C75652D3030303031373337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1737, 'wal', 'ack-1737');
COMMIT;
SELECT 'ack', 1737;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1738, 10, X'76616C75652D3030303031373338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1738, 'wal', 'ack-1738');
COMMIT;
SELECT 'ack', 1738;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1739, 11, X'76616C75652D3030303031373339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1739, 'wal', 'ack-1739');
COMMIT;
SELECT 'ack', 1739;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1740, 12, X'76616C75652D3030303031373430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1740, 'wal', 'ack-1740');
COMMIT;
SELECT 'ack', 1740;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1741, 13, X'76616C75652D3030303031373431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1741, 'wal', 'ack-1741');
COMMIT;
SELECT 'ack', 1741;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1742, 14, X'76616C75652D3030303031373432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1742, 'wal', 'ack-1742');
COMMIT;
SELECT 'ack', 1742;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1743, 15, X'76616C75652D3030303031373433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1743, 'wal', 'ack-1743');
COMMIT;
SELECT 'ack', 1743;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1744, 16, X'76616C75652D3030303031373434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1744, 'wal', 'ack-1744');
COMMIT;
SELECT 'ack', 1744;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1745, 17, X'76616C75652D3030303031373435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1745, 'wal', 'ack-1745');
COMMIT;
SELECT 'ack', 1745;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1746, 18, X'76616C75652D3030303031373436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1746, 'wal', 'ack-1746');
COMMIT;
SELECT 'ack', 1746;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1747, 19, X'76616C75652D3030303031373437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1747, 'wal', 'ack-1747');
COMMIT;
SELECT 'ack', 1747;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1748, 20, X'76616C75652D3030303031373438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1748, 'wal', 'ack-1748');
COMMIT;
SELECT 'ack', 1748;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1749, 21, X'76616C75652D3030303031373439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1749, 'wal', 'ack-1749');
COMMIT;
SELECT 'ack', 1749;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1750, 22, X'76616C75652D3030303031373530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1750, 'wal', 'ack-1750');
COMMIT;
SELECT 'ack', 1750;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1751, 23, X'76616C75652D3030303031373531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1751, 'wal', 'ack-1751');
COMMIT;
SELECT 'ack', 1751;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1752, 24, X'76616C75652D3030303031373532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1752, 'wal', 'ack-1752');
COMMIT;
SELECT 'ack', 1752;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1753, 25, X'76616C75652D3030303031373533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1753, 'wal', 'ack-1753');
COMMIT;
SELECT 'ack', 1753;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1754, 26, X'76616C75652D3030303031373534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1754, 'wal', 'ack-1754');
COMMIT;
SELECT 'ack', 1754;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1755, 27, X'76616C75652D3030303031373535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1755, 'wal', 'ack-1755');
COMMIT;
SELECT 'ack', 1755;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1756, 28, X'76616C75652D3030303031373536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1756, 'wal', 'ack-1756');
COMMIT;
SELECT 'ack', 1756;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1757, 29, X'76616C75652D3030303031373537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1757, 'wal', 'ack-1757');
COMMIT;
SELECT 'ack', 1757;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1758, 30, X'76616C75652D3030303031373538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1758, 'wal', 'ack-1758');
COMMIT;
SELECT 'ack', 1758;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1759, 31, X'76616C75652D3030303031373539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1759, 'wal', 'ack-1759');
COMMIT;
SELECT 'ack', 1759;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1760, 0, X'76616C75652D3030303031373630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1760, 'wal', 'ack-1760');
COMMIT;
SELECT 'ack', 1760;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1761, 1, X'76616C75652D3030303031373631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1761, 'wal', 'ack-1761');
COMMIT;
SELECT 'ack', 1761;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1762, 2, X'76616C75652D3030303031373632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1762, 'wal', 'ack-1762');
COMMIT;
SELECT 'ack', 1762;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1763, 3, X'76616C75652D3030303031373633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1763, 'wal', 'ack-1763');
COMMIT;
SELECT 'ack', 1763;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1764, 4, X'76616C75652D3030303031373634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1764, 'wal', 'ack-1764');
COMMIT;
SELECT 'ack', 1764;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1765, 5, X'76616C75652D3030303031373635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1765, 'wal', 'ack-1765');
COMMIT;
SELECT 'ack', 1765;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1766, 6, X'76616C75652D3030303031373636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1766, 'wal', 'ack-1766');
COMMIT;
SELECT 'ack', 1766;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1767, 7, X'76616C75652D3030303031373637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1767, 'wal', 'ack-1767');
COMMIT;
SELECT 'ack', 1767;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1768, 8, X'76616C75652D3030303031373638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1768, 'wal', 'ack-1768');
COMMIT;
SELECT 'ack', 1768;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1769, 9, X'76616C75652D3030303031373639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1769, 'wal', 'ack-1769');
COMMIT;
SELECT 'ack', 1769;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1770, 10, X'76616C75652D3030303031373730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1770, 'wal', 'ack-1770');
COMMIT;
SELECT 'ack', 1770;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1771, 11, X'76616C75652D3030303031373731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1771, 'wal', 'ack-1771');
COMMIT;
SELECT 'ack', 1771;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1772, 12, X'76616C75652D3030303031373732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1772, 'wal', 'ack-1772');
COMMIT;
SELECT 'ack', 1772;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1773, 13, X'76616C75652D3030303031373733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1773, 'wal', 'ack-1773');
COMMIT;
SELECT 'ack', 1773;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1774, 14, X'76616C75652D3030303031373734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1774, 'wal', 'ack-1774');
COMMIT;
SELECT 'ack', 1774;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1775, 15, X'76616C75652D3030303031373735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1775, 'wal', 'ack-1775');
COMMIT;
SELECT 'ack', 1775;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1776, 16, X'76616C75652D3030303031373736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1776, 'wal', 'ack-1776');
COMMIT;
SELECT 'ack', 1776;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1777, 17, X'76616C75652D3030303031373737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1777, 'wal', 'ack-1777');
COMMIT;
SELECT 'ack', 1777;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1778, 18, X'76616C75652D3030303031373738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1778, 'wal', 'ack-1778');
COMMIT;
SELECT 'ack', 1778;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1779, 19, X'76616C75652D3030303031373739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1779, 'wal', 'ack-1779');
COMMIT;
SELECT 'ack', 1779;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1780, 20, X'76616C75652D3030303031373830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1780, 'wal', 'ack-1780');
COMMIT;
SELECT 'ack', 1780;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1781, 21, X'76616C75652D3030303031373831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1781, 'wal', 'ack-1781');
COMMIT;
SELECT 'ack', 1781;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1782, 22, X'76616C75652D3030303031373832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1782, 'wal', 'ack-1782');
COMMIT;
SELECT 'ack', 1782;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1783, 23, X'76616C75652D3030303031373833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1783, 'wal', 'ack-1783');
COMMIT;
SELECT 'ack', 1783;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1784, 24, X'76616C75652D3030303031373834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1784, 'wal', 'ack-1784');
COMMIT;
SELECT 'ack', 1784;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1785, 25, X'76616C75652D3030303031373835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1785, 'wal', 'ack-1785');
COMMIT;
SELECT 'ack', 1785;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1786, 26, X'76616C75652D3030303031373836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1786, 'wal', 'ack-1786');
COMMIT;
SELECT 'ack', 1786;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1787, 27, X'76616C75652D3030303031373837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1787, 'wal', 'ack-1787');
COMMIT;
SELECT 'ack', 1787;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1788, 28, X'76616C75652D3030303031373838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1788, 'wal', 'ack-1788');
COMMIT;
SELECT 'ack', 1788;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1789, 29, X'76616C75652D3030303031373839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1789, 'wal', 'ack-1789');
COMMIT;
SELECT 'ack', 1789;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1790, 30, X'76616C75652D3030303031373930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1790, 'wal', 'ack-1790');
COMMIT;
SELECT 'ack', 1790;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1791, 31, X'76616C75652D3030303031373931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1791, 'wal', 'ack-1791');
COMMIT;
SELECT 'ack', 1791;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1792, 0, X'76616C75652D3030303031373932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1792, 'wal', 'ack-1792');
COMMIT;
SELECT 'ack', 1792;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1793, 1, X'76616C75652D3030303031373933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1793, 'wal', 'ack-1793');
COMMIT;
SELECT 'ack', 1793;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1794, 2, X'76616C75652D3030303031373934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1794, 'wal', 'ack-1794');
COMMIT;
SELECT 'ack', 1794;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1795, 3, X'76616C75652D3030303031373935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1795, 'wal', 'ack-1795');
COMMIT;
SELECT 'ack', 1795;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1796, 4, X'76616C75652D3030303031373936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1796, 'wal', 'ack-1796');
COMMIT;
SELECT 'ack', 1796;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1797, 5, X'76616C75652D3030303031373937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1797, 'wal', 'ack-1797');
COMMIT;
SELECT 'ack', 1797;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1798, 6, X'76616C75652D3030303031373938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1798, 'wal', 'ack-1798');
COMMIT;
SELECT 'ack', 1798;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1799, 7, X'76616C75652D3030303031373939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1799, 'wal', 'ack-1799');
COMMIT;
SELECT 'ack', 1799;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1800, 8, X'76616C75652D3030303031383030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1800, 'wal', 'ack-1800');
COMMIT;
SELECT 'ack', 1800;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1801, 9, X'76616C75652D3030303031383031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1801, 'wal', 'ack-1801');
COMMIT;
SELECT 'ack', 1801;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1802, 10, X'76616C75652D3030303031383032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1802, 'wal', 'ack-1802');
COMMIT;
SELECT 'ack', 1802;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1803, 11, X'76616C75652D3030303031383033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1803, 'wal', 'ack-1803');
COMMIT;
SELECT 'ack', 1803;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1804, 12, X'76616C75652D3030303031383034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1804, 'wal', 'ack-1804');
COMMIT;
SELECT 'ack', 1804;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1805, 13, X'76616C75652D3030303031383035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1805, 'wal', 'ack-1805');
COMMIT;
SELECT 'ack', 1805;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1806, 14, X'76616C75652D3030303031383036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1806, 'wal', 'ack-1806');
COMMIT;
SELECT 'ack', 1806;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1807, 15, X'76616C75652D3030303031383037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1807, 'wal', 'ack-1807');
COMMIT;
SELECT 'ack', 1807;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1808, 16, X'76616C75652D3030303031383038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1808, 'wal', 'ack-1808');
COMMIT;
SELECT 'ack', 1808;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1809, 17, X'76616C75652D3030303031383039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1809, 'wal', 'ack-1809');
COMMIT;
SELECT 'ack', 1809;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1810, 18, X'76616C75652D3030303031383130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1810, 'wal', 'ack-1810');
COMMIT;
SELECT 'ack', 1810;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1811, 19, X'76616C75652D3030303031383131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1811, 'wal', 'ack-1811');
COMMIT;
SELECT 'ack', 1811;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1812, 20, X'76616C75652D3030303031383132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1812, 'wal', 'ack-1812');
COMMIT;
SELECT 'ack', 1812;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1813, 21, X'76616C75652D3030303031383133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1813, 'wal', 'ack-1813');
COMMIT;
SELECT 'ack', 1813;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1814, 22, X'76616C75652D3030303031383134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1814, 'wal', 'ack-1814');
COMMIT;
SELECT 'ack', 1814;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1815, 23, X'76616C75652D3030303031383135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1815, 'wal', 'ack-1815');
COMMIT;
SELECT 'ack', 1815;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1816, 24, X'76616C75652D3030303031383136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1816, 'wal', 'ack-1816');
COMMIT;
SELECT 'ack', 1816;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1817, 25, X'76616C75652D3030303031383137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1817, 'wal', 'ack-1817');
COMMIT;
SELECT 'ack', 1817;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1818, 26, X'76616C75652D3030303031383138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1818, 'wal', 'ack-1818');
COMMIT;
SELECT 'ack', 1818;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1819, 27, X'76616C75652D3030303031383139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1819, 'wal', 'ack-1819');
COMMIT;
SELECT 'ack', 1819;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1820, 28, X'76616C75652D3030303031383230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1820, 'wal', 'ack-1820');
COMMIT;
SELECT 'ack', 1820;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1821, 29, X'76616C75652D3030303031383231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1821, 'wal', 'ack-1821');
COMMIT;
SELECT 'ack', 1821;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1822, 30, X'76616C75652D3030303031383232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1822, 'wal', 'ack-1822');
COMMIT;
SELECT 'ack', 1822;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1823, 31, X'76616C75652D3030303031383233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1823, 'wal', 'ack-1823');
COMMIT;
SELECT 'ack', 1823;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1824, 0, X'76616C75652D3030303031383234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1824, 'wal', 'ack-1824');
COMMIT;
SELECT 'ack', 1824;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1825, 1, X'76616C75652D3030303031383235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1825, 'wal', 'ack-1825');
COMMIT;
SELECT 'ack', 1825;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1826, 2, X'76616C75652D3030303031383236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1826, 'wal', 'ack-1826');
COMMIT;
SELECT 'ack', 1826;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1827, 3, X'76616C75652D3030303031383237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1827, 'wal', 'ack-1827');
COMMIT;
SELECT 'ack', 1827;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1828, 4, X'76616C75652D3030303031383238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1828, 'wal', 'ack-1828');
COMMIT;
SELECT 'ack', 1828;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1829, 5, X'76616C75652D3030303031383239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1829, 'wal', 'ack-1829');
COMMIT;
SELECT 'ack', 1829;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1830, 6, X'76616C75652D3030303031383330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1830, 'wal', 'ack-1830');
COMMIT;
SELECT 'ack', 1830;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1831, 7, X'76616C75652D3030303031383331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1831, 'wal', 'ack-1831');
COMMIT;
SELECT 'ack', 1831;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1832, 8, X'76616C75652D3030303031383332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1832, 'wal', 'ack-1832');
COMMIT;
SELECT 'ack', 1832;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1833, 9, X'76616C75652D3030303031383333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1833, 'wal', 'ack-1833');
COMMIT;
SELECT 'ack', 1833;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1834, 10, X'76616C75652D3030303031383334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1834, 'wal', 'ack-1834');
COMMIT;
SELECT 'ack', 1834;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1835, 11, X'76616C75652D3030303031383335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1835, 'wal', 'ack-1835');
COMMIT;
SELECT 'ack', 1835;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1836, 12, X'76616C75652D3030303031383336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1836, 'wal', 'ack-1836');
COMMIT;
SELECT 'ack', 1836;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1837, 13, X'76616C75652D3030303031383337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1837, 'wal', 'ack-1837');
COMMIT;
SELECT 'ack', 1837;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1838, 14, X'76616C75652D3030303031383338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1838, 'wal', 'ack-1838');
COMMIT;
SELECT 'ack', 1838;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1839, 15, X'76616C75652D3030303031383339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1839, 'wal', 'ack-1839');
COMMIT;
SELECT 'ack', 1839;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1840, 16, X'76616C75652D3030303031383430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1840, 'wal', 'ack-1840');
COMMIT;
SELECT 'ack', 1840;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1841, 17, X'76616C75652D3030303031383431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1841, 'wal', 'ack-1841');
COMMIT;
SELECT 'ack', 1841;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1842, 18, X'76616C75652D3030303031383432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1842, 'wal', 'ack-1842');
COMMIT;
SELECT 'ack', 1842;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1843, 19, X'76616C75652D3030303031383433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1843, 'wal', 'ack-1843');
COMMIT;
SELECT 'ack', 1843;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1844, 20, X'76616C75652D3030303031383434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1844, 'wal', 'ack-1844');
COMMIT;
SELECT 'ack', 1844;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1845, 21, X'76616C75652D3030303031383435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1845, 'wal', 'ack-1845');
COMMIT;
SELECT 'ack', 1845;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1846, 22, X'76616C75652D3030303031383436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1846, 'wal', 'ack-1846');
COMMIT;
SELECT 'ack', 1846;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1847, 23, X'76616C75652D3030303031383437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1847, 'wal', 'ack-1847');
COMMIT;
SELECT 'ack', 1847;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1848, 24, X'76616C75652D3030303031383438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1848, 'wal', 'ack-1848');
COMMIT;
SELECT 'ack', 1848;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1849, 25, X'76616C75652D3030303031383439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1849, 'wal', 'ack-1849');
COMMIT;
SELECT 'ack', 1849;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1850, 26, X'76616C75652D3030303031383530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1850, 'wal', 'ack-1850');
COMMIT;
SELECT 'ack', 1850;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1851, 27, X'76616C75652D3030303031383531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1851, 'wal', 'ack-1851');
COMMIT;
SELECT 'ack', 1851;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1852, 28, X'76616C75652D3030303031383532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1852, 'wal', 'ack-1852');
COMMIT;
SELECT 'ack', 1852;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1853, 29, X'76616C75652D3030303031383533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1853, 'wal', 'ack-1853');
COMMIT;
SELECT 'ack', 1853;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1854, 30, X'76616C75652D3030303031383534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1854, 'wal', 'ack-1854');
COMMIT;
SELECT 'ack', 1854;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1855, 31, X'76616C75652D3030303031383535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1855, 'wal', 'ack-1855');
COMMIT;
SELECT 'ack', 1855;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1856, 0, X'76616C75652D3030303031383536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1856, 'wal', 'ack-1856');
COMMIT;
SELECT 'ack', 1856;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1857, 1, X'76616C75652D3030303031383537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1857, 'wal', 'ack-1857');
COMMIT;
SELECT 'ack', 1857;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1858, 2, X'76616C75652D3030303031383538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1858, 'wal', 'ack-1858');
COMMIT;
SELECT 'ack', 1858;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1859, 3, X'76616C75652D3030303031383539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1859, 'wal', 'ack-1859');
COMMIT;
SELECT 'ack', 1859;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1860, 4, X'76616C75652D3030303031383630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1860, 'wal', 'ack-1860');
COMMIT;
SELECT 'ack', 1860;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1861, 5, X'76616C75652D3030303031383631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1861, 'wal', 'ack-1861');
COMMIT;
SELECT 'ack', 1861;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1862, 6, X'76616C75652D3030303031383632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1862, 'wal', 'ack-1862');
COMMIT;
SELECT 'ack', 1862;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1863, 7, X'76616C75652D3030303031383633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1863, 'wal', 'ack-1863');
COMMIT;
SELECT 'ack', 1863;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1864, 8, X'76616C75652D3030303031383634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1864, 'wal', 'ack-1864');
COMMIT;
SELECT 'ack', 1864;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1865, 9, X'76616C75652D3030303031383635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1865, 'wal', 'ack-1865');
COMMIT;
SELECT 'ack', 1865;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1866, 10, X'76616C75652D3030303031383636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1866, 'wal', 'ack-1866');
COMMIT;
SELECT 'ack', 1866;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1867, 11, X'76616C75652D3030303031383637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1867, 'wal', 'ack-1867');
COMMIT;
SELECT 'ack', 1867;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1868, 12, X'76616C75652D3030303031383638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1868, 'wal', 'ack-1868');
COMMIT;
SELECT 'ack', 1868;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1869, 13, X'76616C75652D3030303031383639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1869, 'wal', 'ack-1869');
COMMIT;
SELECT 'ack', 1869;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1870, 14, X'76616C75652D3030303031383730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1870, 'wal', 'ack-1870');
COMMIT;
SELECT 'ack', 1870;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1871, 15, X'76616C75652D3030303031383731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1871, 'wal', 'ack-1871');
COMMIT;
SELECT 'ack', 1871;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1872, 16, X'76616C75652D3030303031383732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1872, 'wal', 'ack-1872');
COMMIT;
SELECT 'ack', 1872;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1873, 17, X'76616C75652D3030303031383733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1873, 'wal', 'ack-1873');
COMMIT;
SELECT 'ack', 1873;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1874, 18, X'76616C75652D3030303031383734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1874, 'wal', 'ack-1874');
COMMIT;
SELECT 'ack', 1874;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1875, 19, X'76616C75652D3030303031383735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1875, 'wal', 'ack-1875');
COMMIT;
SELECT 'ack', 1875;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1876, 20, X'76616C75652D3030303031383736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1876, 'wal', 'ack-1876');
COMMIT;
SELECT 'ack', 1876;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1877, 21, X'76616C75652D3030303031383737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1877, 'wal', 'ack-1877');
COMMIT;
SELECT 'ack', 1877;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1878, 22, X'76616C75652D3030303031383738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1878, 'wal', 'ack-1878');
COMMIT;
SELECT 'ack', 1878;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1879, 23, X'76616C75652D3030303031383739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1879, 'wal', 'ack-1879');
COMMIT;
SELECT 'ack', 1879;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1880, 24, X'76616C75652D3030303031383830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1880, 'wal', 'ack-1880');
COMMIT;
SELECT 'ack', 1880;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1881, 25, X'76616C75652D3030303031383831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1881, 'wal', 'ack-1881');
COMMIT;
SELECT 'ack', 1881;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1882, 26, X'76616C75652D3030303031383832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1882, 'wal', 'ack-1882');
COMMIT;
SELECT 'ack', 1882;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1883, 27, X'76616C75652D3030303031383833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1883, 'wal', 'ack-1883');
COMMIT;
SELECT 'ack', 1883;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1884, 28, X'76616C75652D3030303031383834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1884, 'wal', 'ack-1884');
COMMIT;
SELECT 'ack', 1884;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1885, 29, X'76616C75652D3030303031383835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1885, 'wal', 'ack-1885');
COMMIT;
SELECT 'ack', 1885;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1886, 30, X'76616C75652D3030303031383836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1886, 'wal', 'ack-1886');
COMMIT;
SELECT 'ack', 1886;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1887, 31, X'76616C75652D3030303031383837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1887, 'wal', 'ack-1887');
COMMIT;
SELECT 'ack', 1887;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1888, 0, X'76616C75652D3030303031383838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1888, 'wal', 'ack-1888');
COMMIT;
SELECT 'ack', 1888;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1889, 1, X'76616C75652D3030303031383839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1889, 'wal', 'ack-1889');
COMMIT;
SELECT 'ack', 1889;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1890, 2, X'76616C75652D3030303031383930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1890, 'wal', 'ack-1890');
COMMIT;
SELECT 'ack', 1890;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1891, 3, X'76616C75652D3030303031383931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1891, 'wal', 'ack-1891');
COMMIT;
SELECT 'ack', 1891;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1892, 4, X'76616C75652D3030303031383932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1892, 'wal', 'ack-1892');
COMMIT;
SELECT 'ack', 1892;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1893, 5, X'76616C75652D3030303031383933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1893, 'wal', 'ack-1893');
COMMIT;
SELECT 'ack', 1893;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1894, 6, X'76616C75652D3030303031383934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1894, 'wal', 'ack-1894');
COMMIT;
SELECT 'ack', 1894;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1895, 7, X'76616C75652D3030303031383935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1895, 'wal', 'ack-1895');
COMMIT;
SELECT 'ack', 1895;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1896, 8, X'76616C75652D3030303031383936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1896, 'wal', 'ack-1896');
COMMIT;
SELECT 'ack', 1896;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1897, 9, X'76616C75652D3030303031383937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1897, 'wal', 'ack-1897');
COMMIT;
SELECT 'ack', 1897;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1898, 10, X'76616C75652D3030303031383938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1898, 'wal', 'ack-1898');
COMMIT;
SELECT 'ack', 1898;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1899, 11, X'76616C75652D3030303031383939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1899, 'wal', 'ack-1899');
COMMIT;
SELECT 'ack', 1899;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1900, 12, X'76616C75652D3030303031393030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1900, 'wal', 'ack-1900');
COMMIT;
SELECT 'ack', 1900;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1901, 13, X'76616C75652D3030303031393031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1901, 'wal', 'ack-1901');
COMMIT;
SELECT 'ack', 1901;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1902, 14, X'76616C75652D3030303031393032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1902, 'wal', 'ack-1902');
COMMIT;
SELECT 'ack', 1902;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1903, 15, X'76616C75652D3030303031393033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1903, 'wal', 'ack-1903');
COMMIT;
SELECT 'ack', 1903;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1904, 16, X'76616C75652D3030303031393034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1904, 'wal', 'ack-1904');
COMMIT;
SELECT 'ack', 1904;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1905, 17, X'76616C75652D3030303031393035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1905, 'wal', 'ack-1905');
COMMIT;
SELECT 'ack', 1905;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1906, 18, X'76616C75652D3030303031393036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1906, 'wal', 'ack-1906');
COMMIT;
SELECT 'ack', 1906;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1907, 19, X'76616C75652D3030303031393037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1907, 'wal', 'ack-1907');
COMMIT;
SELECT 'ack', 1907;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1908, 20, X'76616C75652D3030303031393038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1908, 'wal', 'ack-1908');
COMMIT;
SELECT 'ack', 1908;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1909, 21, X'76616C75652D3030303031393039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1909, 'wal', 'ack-1909');
COMMIT;
SELECT 'ack', 1909;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1910, 22, X'76616C75652D3030303031393130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1910, 'wal', 'ack-1910');
COMMIT;
SELECT 'ack', 1910;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1911, 23, X'76616C75652D3030303031393131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1911, 'wal', 'ack-1911');
COMMIT;
SELECT 'ack', 1911;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1912, 24, X'76616C75652D3030303031393132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1912, 'wal', 'ack-1912');
COMMIT;
SELECT 'ack', 1912;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1913, 25, X'76616C75652D3030303031393133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1913, 'wal', 'ack-1913');
COMMIT;
SELECT 'ack', 1913;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1914, 26, X'76616C75652D3030303031393134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1914, 'wal', 'ack-1914');
COMMIT;
SELECT 'ack', 1914;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1915, 27, X'76616C75652D3030303031393135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1915, 'wal', 'ack-1915');
COMMIT;
SELECT 'ack', 1915;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1916, 28, X'76616C75652D3030303031393136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1916, 'wal', 'ack-1916');
COMMIT;
SELECT 'ack', 1916;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1917, 29, X'76616C75652D3030303031393137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1917, 'wal', 'ack-1917');
COMMIT;
SELECT 'ack', 1917;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1918, 30, X'76616C75652D3030303031393138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1918, 'wal', 'ack-1918');
COMMIT;
SELECT 'ack', 1918;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1919, 31, X'76616C75652D3030303031393139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1919, 'wal', 'ack-1919');
COMMIT;
SELECT 'ack', 1919;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1920, 0, X'76616C75652D3030303031393230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1920, 'wal', 'ack-1920');
COMMIT;
SELECT 'ack', 1920;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1921, 1, X'76616C75652D3030303031393231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1921, 'wal', 'ack-1921');
COMMIT;
SELECT 'ack', 1921;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1922, 2, X'76616C75652D3030303031393232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1922, 'wal', 'ack-1922');
COMMIT;
SELECT 'ack', 1922;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1923, 3, X'76616C75652D3030303031393233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1923, 'wal', 'ack-1923');
COMMIT;
SELECT 'ack', 1923;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1924, 4, X'76616C75652D3030303031393234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1924, 'wal', 'ack-1924');
COMMIT;
SELECT 'ack', 1924;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1925, 5, X'76616C75652D3030303031393235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1925, 'wal', 'ack-1925');
COMMIT;
SELECT 'ack', 1925;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1926, 6, X'76616C75652D3030303031393236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1926, 'wal', 'ack-1926');
COMMIT;
SELECT 'ack', 1926;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1927, 7, X'76616C75652D3030303031393237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1927, 'wal', 'ack-1927');
COMMIT;
SELECT 'ack', 1927;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1928, 8, X'76616C75652D3030303031393238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1928, 'wal', 'ack-1928');
COMMIT;
SELECT 'ack', 1928;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1929, 9, X'76616C75652D3030303031393239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1929, 'wal', 'ack-1929');
COMMIT;
SELECT 'ack', 1929;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1930, 10, X'76616C75652D3030303031393330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1930, 'wal', 'ack-1930');
COMMIT;
SELECT 'ack', 1930;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1931, 11, X'76616C75652D3030303031393331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1931, 'wal', 'ack-1931');
COMMIT;
SELECT 'ack', 1931;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1932, 12, X'76616C75652D3030303031393332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1932, 'wal', 'ack-1932');
COMMIT;
SELECT 'ack', 1932;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1933, 13, X'76616C75652D3030303031393333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1933, 'wal', 'ack-1933');
COMMIT;
SELECT 'ack', 1933;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1934, 14, X'76616C75652D3030303031393334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1934, 'wal', 'ack-1934');
COMMIT;
SELECT 'ack', 1934;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1935, 15, X'76616C75652D3030303031393335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1935, 'wal', 'ack-1935');
COMMIT;
SELECT 'ack', 1935;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1936, 16, X'76616C75652D3030303031393336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1936, 'wal', 'ack-1936');
COMMIT;
SELECT 'ack', 1936;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1937, 17, X'76616C75652D3030303031393337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1937, 'wal', 'ack-1937');
COMMIT;
SELECT 'ack', 1937;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1938, 18, X'76616C75652D3030303031393338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1938, 'wal', 'ack-1938');
COMMIT;
SELECT 'ack', 1938;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1939, 19, X'76616C75652D3030303031393339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1939, 'wal', 'ack-1939');
COMMIT;
SELECT 'ack', 1939;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1940, 20, X'76616C75652D3030303031393430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1940, 'wal', 'ack-1940');
COMMIT;
SELECT 'ack', 1940;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1941, 21, X'76616C75652D3030303031393431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1941, 'wal', 'ack-1941');
COMMIT;
SELECT 'ack', 1941;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1942, 22, X'76616C75652D3030303031393432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1942, 'wal', 'ack-1942');
COMMIT;
SELECT 'ack', 1942;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1943, 23, X'76616C75652D3030303031393433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1943, 'wal', 'ack-1943');
COMMIT;
SELECT 'ack', 1943;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1944, 24, X'76616C75652D3030303031393434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1944, 'wal', 'ack-1944');
COMMIT;
SELECT 'ack', 1944;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1945, 25, X'76616C75652D3030303031393435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1945, 'wal', 'ack-1945');
COMMIT;
SELECT 'ack', 1945;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1946, 26, X'76616C75652D3030303031393436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1946, 'wal', 'ack-1946');
COMMIT;
SELECT 'ack', 1946;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1947, 27, X'76616C75652D3030303031393437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1947, 'wal', 'ack-1947');
COMMIT;
SELECT 'ack', 1947;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1948, 28, X'76616C75652D3030303031393438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1948, 'wal', 'ack-1948');
COMMIT;
SELECT 'ack', 1948;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1949, 29, X'76616C75652D3030303031393439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1949, 'wal', 'ack-1949');
COMMIT;
SELECT 'ack', 1949;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1950, 30, X'76616C75652D3030303031393530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1950, 'wal', 'ack-1950');
COMMIT;
SELECT 'ack', 1950;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1951, 31, X'76616C75652D3030303031393531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1951, 'wal', 'ack-1951');
COMMIT;
SELECT 'ack', 1951;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1952, 0, X'76616C75652D3030303031393532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1952, 'wal', 'ack-1952');
COMMIT;
SELECT 'ack', 1952;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1953, 1, X'76616C75652D3030303031393533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1953, 'wal', 'ack-1953');
COMMIT;
SELECT 'ack', 1953;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1954, 2, X'76616C75652D3030303031393534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1954, 'wal', 'ack-1954');
COMMIT;
SELECT 'ack', 1954;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1955, 3, X'76616C75652D3030303031393535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1955, 'wal', 'ack-1955');
COMMIT;
SELECT 'ack', 1955;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1956, 4, X'76616C75652D3030303031393536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1956, 'wal', 'ack-1956');
COMMIT;
SELECT 'ack', 1956;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1957, 5, X'76616C75652D3030303031393537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1957, 'wal', 'ack-1957');
COMMIT;
SELECT 'ack', 1957;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1958, 6, X'76616C75652D3030303031393538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1958, 'wal', 'ack-1958');
COMMIT;
SELECT 'ack', 1958;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1959, 7, X'76616C75652D3030303031393539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1959, 'wal', 'ack-1959');
COMMIT;
SELECT 'ack', 1959;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1960, 8, X'76616C75652D3030303031393630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1960, 'wal', 'ack-1960');
COMMIT;
SELECT 'ack', 1960;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1961, 9, X'76616C75652D3030303031393631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1961, 'wal', 'ack-1961');
COMMIT;
SELECT 'ack', 1961;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1962, 10, X'76616C75652D3030303031393632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1962, 'wal', 'ack-1962');
COMMIT;
SELECT 'ack', 1962;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1963, 11, X'76616C75652D3030303031393633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1963, 'wal', 'ack-1963');
COMMIT;
SELECT 'ack', 1963;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1964, 12, X'76616C75652D3030303031393634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1964, 'wal', 'ack-1964');
COMMIT;
SELECT 'ack', 1964;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1965, 13, X'76616C75652D3030303031393635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1965, 'wal', 'ack-1965');
COMMIT;
SELECT 'ack', 1965;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1966, 14, X'76616C75652D3030303031393636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1966, 'wal', 'ack-1966');
COMMIT;
SELECT 'ack', 1966;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1967, 15, X'76616C75652D3030303031393637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1967, 'wal', 'ack-1967');
COMMIT;
SELECT 'ack', 1967;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1968, 16, X'76616C75652D3030303031393638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1968, 'wal', 'ack-1968');
COMMIT;
SELECT 'ack', 1968;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1969, 17, X'76616C75652D3030303031393639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1969, 'wal', 'ack-1969');
COMMIT;
SELECT 'ack', 1969;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1970, 18, X'76616C75652D3030303031393730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1970, 'wal', 'ack-1970');
COMMIT;
SELECT 'ack', 1970;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1971, 19, X'76616C75652D3030303031393731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1971, 'wal', 'ack-1971');
COMMIT;
SELECT 'ack', 1971;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1972, 20, X'76616C75652D3030303031393732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1972, 'wal', 'ack-1972');
COMMIT;
SELECT 'ack', 1972;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1973, 21, X'76616C75652D3030303031393733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1973, 'wal', 'ack-1973');
COMMIT;
SELECT 'ack', 1973;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1974, 22, X'76616C75652D3030303031393734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1974, 'wal', 'ack-1974');
COMMIT;
SELECT 'ack', 1974;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1975, 23, X'76616C75652D3030303031393735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1975, 'wal', 'ack-1975');
COMMIT;
SELECT 'ack', 1975;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1976, 24, X'76616C75652D3030303031393736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1976, 'wal', 'ack-1976');
COMMIT;
SELECT 'ack', 1976;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1977, 25, X'76616C75652D3030303031393737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1977, 'wal', 'ack-1977');
COMMIT;
SELECT 'ack', 1977;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1978, 26, X'76616C75652D3030303031393738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1978, 'wal', 'ack-1978');
COMMIT;
SELECT 'ack', 1978;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1979, 27, X'76616C75652D3030303031393739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1979, 'wal', 'ack-1979');
COMMIT;
SELECT 'ack', 1979;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1980, 28, X'76616C75652D3030303031393830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1980, 'wal', 'ack-1980');
COMMIT;
SELECT 'ack', 1980;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1981, 29, X'76616C75652D3030303031393831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1981, 'wal', 'ack-1981');
COMMIT;
SELECT 'ack', 1981;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1982, 30, X'76616C75652D3030303031393832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1982, 'wal', 'ack-1982');
COMMIT;
SELECT 'ack', 1982;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1983, 31, X'76616C75652D3030303031393833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1983, 'wal', 'ack-1983');
COMMIT;
SELECT 'ack', 1983;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1984, 0, X'76616C75652D3030303031393834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1984, 'wal', 'ack-1984');
COMMIT;
SELECT 'ack', 1984;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1985, 1, X'76616C75652D3030303031393835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1985, 'wal', 'ack-1985');
COMMIT;
SELECT 'ack', 1985;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1986, 2, X'76616C75652D3030303031393836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1986, 'wal', 'ack-1986');
COMMIT;
SELECT 'ack', 1986;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1987, 3, X'76616C75652D3030303031393837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1987, 'wal', 'ack-1987');
COMMIT;
SELECT 'ack', 1987;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1988, 4, X'76616C75652D3030303031393838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1988, 'wal', 'ack-1988');
COMMIT;
SELECT 'ack', 1988;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1989, 5, X'76616C75652D3030303031393839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1989, 'wal', 'ack-1989');
COMMIT;
SELECT 'ack', 1989;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1990, 6, X'76616C75652D3030303031393930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1990, 'wal', 'ack-1990');
COMMIT;
SELECT 'ack', 1990;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1991, 7, X'76616C75652D3030303031393931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1991, 'wal', 'ack-1991');
COMMIT;
SELECT 'ack', 1991;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1992, 8, X'76616C75652D3030303031393932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1992, 'wal', 'ack-1992');
COMMIT;
SELECT 'ack', 1992;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1993, 9, X'76616C75652D3030303031393933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1993, 'wal', 'ack-1993');
COMMIT;
SELECT 'ack', 1993;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1994, 10, X'76616C75652D3030303031393934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1994, 'wal', 'ack-1994');
COMMIT;
SELECT 'ack', 1994;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1995, 11, X'76616C75652D3030303031393935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1995, 'wal', 'ack-1995');
COMMIT;
SELECT 'ack', 1995;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1996, 12, X'76616C75652D3030303031393936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1996, 'wal', 'ack-1996');
COMMIT;
SELECT 'ack', 1996;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1997, 13, X'76616C75652D3030303031393937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1997, 'wal', 'ack-1997');
COMMIT;
SELECT 'ack', 1997;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1998, 14, X'76616C75652D3030303031393938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1998, 'wal', 'ack-1998');
COMMIT;
SELECT 'ack', 1998;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (1999, 15, X'76616C75652D3030303031393939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (1999, 'wal', 'ack-1999');
COMMIT;
SELECT 'ack', 1999;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2000, 16, X'76616C75652D3030303032303030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2000, 'wal', 'ack-2000');
COMMIT;
SELECT 'ack', 2000;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2001, 17, X'76616C75652D3030303032303031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2001, 'wal', 'ack-2001');
COMMIT;
SELECT 'ack', 2001;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2002, 18, X'76616C75652D3030303032303032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2002, 'wal', 'ack-2002');
COMMIT;
SELECT 'ack', 2002;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2003, 19, X'76616C75652D3030303032303033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2003, 'wal', 'ack-2003');
COMMIT;
SELECT 'ack', 2003;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2004, 20, X'76616C75652D3030303032303034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2004, 'wal', 'ack-2004');
COMMIT;
SELECT 'ack', 2004;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2005, 21, X'76616C75652D3030303032303035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2005, 'wal', 'ack-2005');
COMMIT;
SELECT 'ack', 2005;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2006, 22, X'76616C75652D3030303032303036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2006, 'wal', 'ack-2006');
COMMIT;
SELECT 'ack', 2006;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2007, 23, X'76616C75652D3030303032303037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2007, 'wal', 'ack-2007');
COMMIT;
SELECT 'ack', 2007;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2008, 24, X'76616C75652D3030303032303038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2008, 'wal', 'ack-2008');
COMMIT;
SELECT 'ack', 2008;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2009, 25, X'76616C75652D3030303032303039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2009, 'wal', 'ack-2009');
COMMIT;
SELECT 'ack', 2009;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2010, 26, X'76616C75652D3030303032303130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2010, 'wal', 'ack-2010');
COMMIT;
SELECT 'ack', 2010;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2011, 27, X'76616C75652D3030303032303131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2011, 'wal', 'ack-2011');
COMMIT;
SELECT 'ack', 2011;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2012, 28, X'76616C75652D3030303032303132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2012, 'wal', 'ack-2012');
COMMIT;
SELECT 'ack', 2012;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2013, 29, X'76616C75652D3030303032303133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2013, 'wal', 'ack-2013');
COMMIT;
SELECT 'ack', 2013;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2014, 30, X'76616C75652D3030303032303134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2014, 'wal', 'ack-2014');
COMMIT;
SELECT 'ack', 2014;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2015, 31, X'76616C75652D3030303032303135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2015, 'wal', 'ack-2015');
COMMIT;
SELECT 'ack', 2015;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2016, 0, X'76616C75652D3030303032303136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2016, 'wal', 'ack-2016');
COMMIT;
SELECT 'ack', 2016;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2017, 1, X'76616C75652D3030303032303137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2017, 'wal', 'ack-2017');
COMMIT;
SELECT 'ack', 2017;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2018, 2, X'76616C75652D3030303032303138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2018, 'wal', 'ack-2018');
COMMIT;
SELECT 'ack', 2018;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2019, 3, X'76616C75652D3030303032303139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2019, 'wal', 'ack-2019');
COMMIT;
SELECT 'ack', 2019;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2020, 4, X'76616C75652D3030303032303230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2020, 'wal', 'ack-2020');
COMMIT;
SELECT 'ack', 2020;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2021, 5, X'76616C75652D3030303032303231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2021, 'wal', 'ack-2021');
COMMIT;
SELECT 'ack', 2021;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2022, 6, X'76616C75652D3030303032303232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2022, 'wal', 'ack-2022');
COMMIT;
SELECT 'ack', 2022;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2023, 7, X'76616C75652D3030303032303233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2023, 'wal', 'ack-2023');
COMMIT;
SELECT 'ack', 2023;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2024, 8, X'76616C75652D3030303032303234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2024, 'wal', 'ack-2024');
COMMIT;
SELECT 'ack', 2024;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2025, 9, X'76616C75652D3030303032303235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2025, 'wal', 'ack-2025');
COMMIT;
SELECT 'ack', 2025;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2026, 10, X'76616C75652D3030303032303236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2026, 'wal', 'ack-2026');
COMMIT;
SELECT 'ack', 2026;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2027, 11, X'76616C75652D3030303032303237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2027, 'wal', 'ack-2027');
COMMIT;
SELECT 'ack', 2027;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2028, 12, X'76616C75652D3030303032303238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2028, 'wal', 'ack-2028');
COMMIT;
SELECT 'ack', 2028;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2029, 13, X'76616C75652D3030303032303239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2029, 'wal', 'ack-2029');
COMMIT;
SELECT 'ack', 2029;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2030, 14, X'76616C75652D3030303032303330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2030, 'wal', 'ack-2030');
COMMIT;
SELECT 'ack', 2030;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2031, 15, X'76616C75652D3030303032303331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2031, 'wal', 'ack-2031');
COMMIT;
SELECT 'ack', 2031;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2032, 16, X'76616C75652D3030303032303332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2032, 'wal', 'ack-2032');
COMMIT;
SELECT 'ack', 2032;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2033, 17, X'76616C75652D3030303032303333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2033, 'wal', 'ack-2033');
COMMIT;
SELECT 'ack', 2033;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2034, 18, X'76616C75652D3030303032303334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2034, 'wal', 'ack-2034');
COMMIT;
SELECT 'ack', 2034;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2035, 19, X'76616C75652D3030303032303335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2035, 'wal', 'ack-2035');
COMMIT;
SELECT 'ack', 2035;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2036, 20, X'76616C75652D3030303032303336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2036, 'wal', 'ack-2036');
COMMIT;
SELECT 'ack', 2036;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2037, 21, X'76616C75652D3030303032303337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2037, 'wal', 'ack-2037');
COMMIT;
SELECT 'ack', 2037;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2038, 22, X'76616C75652D3030303032303338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2038, 'wal', 'ack-2038');
COMMIT;
SELECT 'ack', 2038;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2039, 23, X'76616C75652D3030303032303339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2039, 'wal', 'ack-2039');
COMMIT;
SELECT 'ack', 2039;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2040, 24, X'76616C75652D3030303032303430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2040, 'wal', 'ack-2040');
COMMIT;
SELECT 'ack', 2040;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2041, 25, X'76616C75652D3030303032303431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2041, 'wal', 'ack-2041');
COMMIT;
SELECT 'ack', 2041;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2042, 26, X'76616C75652D3030303032303432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2042, 'wal', 'ack-2042');
COMMIT;
SELECT 'ack', 2042;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2043, 27, X'76616C75652D3030303032303433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2043, 'wal', 'ack-2043');
COMMIT;
SELECT 'ack', 2043;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2044, 28, X'76616C75652D3030303032303434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2044, 'wal', 'ack-2044');
COMMIT;
SELECT 'ack', 2044;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2045, 29, X'76616C75652D3030303032303435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2045, 'wal', 'ack-2045');
COMMIT;
SELECT 'ack', 2045;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2046, 30, X'76616C75652D3030303032303436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2046, 'wal', 'ack-2046');
COMMIT;
SELECT 'ack', 2046;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2047, 31, X'76616C75652D3030303032303437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2047, 'wal', 'ack-2047');
COMMIT;
SELECT 'ack', 2047;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2048, 0, X'76616C75652D3030303032303438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2048, 'wal', 'ack-2048');
COMMIT;
SELECT 'ack', 2048;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2049, 1, X'76616C75652D3030303032303439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2049, 'wal', 'ack-2049');
COMMIT;
SELECT 'ack', 2049;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2050, 2, X'76616C75652D3030303032303530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2050, 'wal', 'ack-2050');
COMMIT;
SELECT 'ack', 2050;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2051, 3, X'76616C75652D3030303032303531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2051, 'wal', 'ack-2051');
COMMIT;
SELECT 'ack', 2051;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2052, 4, X'76616C75652D3030303032303532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2052, 'wal', 'ack-2052');
COMMIT;
SELECT 'ack', 2052;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2053, 5, X'76616C75652D3030303032303533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2053, 'wal', 'ack-2053');
COMMIT;
SELECT 'ack', 2053;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2054, 6, X'76616C75652D3030303032303534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2054, 'wal', 'ack-2054');
COMMIT;
SELECT 'ack', 2054;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2055, 7, X'76616C75652D3030303032303535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2055, 'wal', 'ack-2055');
COMMIT;
SELECT 'ack', 2055;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2056, 8, X'76616C75652D3030303032303536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2056, 'wal', 'ack-2056');
COMMIT;
SELECT 'ack', 2056;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2057, 9, X'76616C75652D3030303032303537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2057, 'wal', 'ack-2057');
COMMIT;
SELECT 'ack', 2057;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2058, 10, X'76616C75652D3030303032303538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2058, 'wal', 'ack-2058');
COMMIT;
SELECT 'ack', 2058;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2059, 11, X'76616C75652D3030303032303539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2059, 'wal', 'ack-2059');
COMMIT;
SELECT 'ack', 2059;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2060, 12, X'76616C75652D3030303032303630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2060, 'wal', 'ack-2060');
COMMIT;
SELECT 'ack', 2060;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2061, 13, X'76616C75652D3030303032303631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2061, 'wal', 'ack-2061');
COMMIT;
SELECT 'ack', 2061;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2062, 14, X'76616C75652D3030303032303632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2062, 'wal', 'ack-2062');
COMMIT;
SELECT 'ack', 2062;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2063, 15, X'76616C75652D3030303032303633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2063, 'wal', 'ack-2063');
COMMIT;
SELECT 'ack', 2063;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2064, 16, X'76616C75652D3030303032303634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2064, 'wal', 'ack-2064');
COMMIT;
SELECT 'ack', 2064;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2065, 17, X'76616C75652D3030303032303635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2065, 'wal', 'ack-2065');
COMMIT;
SELECT 'ack', 2065;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2066, 18, X'76616C75652D3030303032303636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2066, 'wal', 'ack-2066');
COMMIT;
SELECT 'ack', 2066;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2067, 19, X'76616C75652D3030303032303637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2067, 'wal', 'ack-2067');
COMMIT;
SELECT 'ack', 2067;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2068, 20, X'76616C75652D3030303032303638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2068, 'wal', 'ack-2068');
COMMIT;
SELECT 'ack', 2068;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2069, 21, X'76616C75652D3030303032303639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2069, 'wal', 'ack-2069');
COMMIT;
SELECT 'ack', 2069;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2070, 22, X'76616C75652D3030303032303730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2070, 'wal', 'ack-2070');
COMMIT;
SELECT 'ack', 2070;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2071, 23, X'76616C75652D3030303032303731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2071, 'wal', 'ack-2071');
COMMIT;
SELECT 'ack', 2071;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2072, 24, X'76616C75652D3030303032303732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2072, 'wal', 'ack-2072');
COMMIT;
SELECT 'ack', 2072;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2073, 25, X'76616C75652D3030303032303733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2073, 'wal', 'ack-2073');
COMMIT;
SELECT 'ack', 2073;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2074, 26, X'76616C75652D3030303032303734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2074, 'wal', 'ack-2074');
COMMIT;
SELECT 'ack', 2074;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2075, 27, X'76616C75652D3030303032303735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2075, 'wal', 'ack-2075');
COMMIT;
SELECT 'ack', 2075;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2076, 28, X'76616C75652D3030303032303736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2076, 'wal', 'ack-2076');
COMMIT;
SELECT 'ack', 2076;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2077, 29, X'76616C75652D3030303032303737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2077, 'wal', 'ack-2077');
COMMIT;
SELECT 'ack', 2077;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2078, 30, X'76616C75652D3030303032303738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2078, 'wal', 'ack-2078');
COMMIT;
SELECT 'ack', 2078;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2079, 31, X'76616C75652D3030303032303739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2079, 'wal', 'ack-2079');
COMMIT;
SELECT 'ack', 2079;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2080, 0, X'76616C75652D3030303032303830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2080, 'wal', 'ack-2080');
COMMIT;
SELECT 'ack', 2080;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2081, 1, X'76616C75652D3030303032303831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2081, 'wal', 'ack-2081');
COMMIT;
SELECT 'ack', 2081;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2082, 2, X'76616C75652D3030303032303832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2082, 'wal', 'ack-2082');
COMMIT;
SELECT 'ack', 2082;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2083, 3, X'76616C75652D3030303032303833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2083, 'wal', 'ack-2083');
COMMIT;
SELECT 'ack', 2083;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2084, 4, X'76616C75652D3030303032303834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2084, 'wal', 'ack-2084');
COMMIT;
SELECT 'ack', 2084;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2085, 5, X'76616C75652D3030303032303835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2085, 'wal', 'ack-2085');
COMMIT;
SELECT 'ack', 2085;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2086, 6, X'76616C75652D3030303032303836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2086, 'wal', 'ack-2086');
COMMIT;
SELECT 'ack', 2086;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2087, 7, X'76616C75652D3030303032303837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2087, 'wal', 'ack-2087');
COMMIT;
SELECT 'ack', 2087;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2088, 8, X'76616C75652D3030303032303838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2088, 'wal', 'ack-2088');
COMMIT;
SELECT 'ack', 2088;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2089, 9, X'76616C75652D3030303032303839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2089, 'wal', 'ack-2089');
COMMIT;
SELECT 'ack', 2089;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2090, 10, X'76616C75652D3030303032303930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2090, 'wal', 'ack-2090');
COMMIT;
SELECT 'ack', 2090;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2091, 11, X'76616C75652D3030303032303931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2091, 'wal', 'ack-2091');
COMMIT;
SELECT 'ack', 2091;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2092, 12, X'76616C75652D3030303032303932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2092, 'wal', 'ack-2092');
COMMIT;
SELECT 'ack', 2092;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2093, 13, X'76616C75652D3030303032303933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2093, 'wal', 'ack-2093');
COMMIT;
SELECT 'ack', 2093;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2094, 14, X'76616C75652D3030303032303934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2094, 'wal', 'ack-2094');
COMMIT;
SELECT 'ack', 2094;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2095, 15, X'76616C75652D3030303032303935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2095, 'wal', 'ack-2095');
COMMIT;
SELECT 'ack', 2095;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2096, 16, X'76616C75652D3030303032303936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2096, 'wal', 'ack-2096');
COMMIT;
SELECT 'ack', 2096;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2097, 17, X'76616C75652D3030303032303937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2097, 'wal', 'ack-2097');
COMMIT;
SELECT 'ack', 2097;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2098, 18, X'76616C75652D3030303032303938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2098, 'wal', 'ack-2098');
COMMIT;
SELECT 'ack', 2098;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2099, 19, X'76616C75652D3030303032303939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2099, 'wal', 'ack-2099');
COMMIT;
SELECT 'ack', 2099;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2100, 20, X'76616C75652D3030303032313030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2100, 'wal', 'ack-2100');
COMMIT;
SELECT 'ack', 2100;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2101, 21, X'76616C75652D3030303032313031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2101, 'wal', 'ack-2101');
COMMIT;
SELECT 'ack', 2101;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2102, 22, X'76616C75652D3030303032313032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2102, 'wal', 'ack-2102');
COMMIT;
SELECT 'ack', 2102;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2103, 23, X'76616C75652D3030303032313033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2103, 'wal', 'ack-2103');
COMMIT;
SELECT 'ack', 2103;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2104, 24, X'76616C75652D3030303032313034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2104, 'wal', 'ack-2104');
COMMIT;
SELECT 'ack', 2104;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2105, 25, X'76616C75652D3030303032313035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2105, 'wal', 'ack-2105');
COMMIT;
SELECT 'ack', 2105;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2106, 26, X'76616C75652D3030303032313036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2106, 'wal', 'ack-2106');
COMMIT;
SELECT 'ack', 2106;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2107, 27, X'76616C75652D3030303032313037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2107, 'wal', 'ack-2107');
COMMIT;
SELECT 'ack', 2107;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2108, 28, X'76616C75652D3030303032313038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2108, 'wal', 'ack-2108');
COMMIT;
SELECT 'ack', 2108;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2109, 29, X'76616C75652D3030303032313039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2109, 'wal', 'ack-2109');
COMMIT;
SELECT 'ack', 2109;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2110, 30, X'76616C75652D3030303032313130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2110, 'wal', 'ack-2110');
COMMIT;
SELECT 'ack', 2110;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2111, 31, X'76616C75652D3030303032313131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2111, 'wal', 'ack-2111');
COMMIT;
SELECT 'ack', 2111;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2112, 0, X'76616C75652D3030303032313132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2112, 'wal', 'ack-2112');
COMMIT;
SELECT 'ack', 2112;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2113, 1, X'76616C75652D3030303032313133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2113, 'wal', 'ack-2113');
COMMIT;
SELECT 'ack', 2113;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2114, 2, X'76616C75652D3030303032313134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2114, 'wal', 'ack-2114');
COMMIT;
SELECT 'ack', 2114;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2115, 3, X'76616C75652D3030303032313135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2115, 'wal', 'ack-2115');
COMMIT;
SELECT 'ack', 2115;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2116, 4, X'76616C75652D3030303032313136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2116, 'wal', 'ack-2116');
COMMIT;
SELECT 'ack', 2116;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2117, 5, X'76616C75652D3030303032313137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2117, 'wal', 'ack-2117');
COMMIT;
SELECT 'ack', 2117;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2118, 6, X'76616C75652D3030303032313138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2118, 'wal', 'ack-2118');
COMMIT;
SELECT 'ack', 2118;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2119, 7, X'76616C75652D3030303032313139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2119, 'wal', 'ack-2119');
COMMIT;
SELECT 'ack', 2119;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2120, 8, X'76616C75652D3030303032313230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2120, 'wal', 'ack-2120');
COMMIT;
SELECT 'ack', 2120;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2121, 9, X'76616C75652D3030303032313231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2121, 'wal', 'ack-2121');
COMMIT;
SELECT 'ack', 2121;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2122, 10, X'76616C75652D3030303032313232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2122, 'wal', 'ack-2122');
COMMIT;
SELECT 'ack', 2122;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2123, 11, X'76616C75652D3030303032313233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2123, 'wal', 'ack-2123');
COMMIT;
SELECT 'ack', 2123;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2124, 12, X'76616C75652D3030303032313234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2124, 'wal', 'ack-2124');
COMMIT;
SELECT 'ack', 2124;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2125, 13, X'76616C75652D3030303032313235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2125, 'wal', 'ack-2125');
COMMIT;
SELECT 'ack', 2125;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2126, 14, X'76616C75652D3030303032313236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2126, 'wal', 'ack-2126');
COMMIT;
SELECT 'ack', 2126;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2127, 15, X'76616C75652D3030303032313237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2127, 'wal', 'ack-2127');
COMMIT;
SELECT 'ack', 2127;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2128, 16, X'76616C75652D3030303032313238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2128, 'wal', 'ack-2128');
COMMIT;
SELECT 'ack', 2128;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2129, 17, X'76616C75652D3030303032313239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2129, 'wal', 'ack-2129');
COMMIT;
SELECT 'ack', 2129;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2130, 18, X'76616C75652D3030303032313330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2130, 'wal', 'ack-2130');
COMMIT;
SELECT 'ack', 2130;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2131, 19, X'76616C75652D3030303032313331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2131, 'wal', 'ack-2131');
COMMIT;
SELECT 'ack', 2131;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2132, 20, X'76616C75652D3030303032313332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2132, 'wal', 'ack-2132');
COMMIT;
SELECT 'ack', 2132;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2133, 21, X'76616C75652D3030303032313333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2133, 'wal', 'ack-2133');
COMMIT;
SELECT 'ack', 2133;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2134, 22, X'76616C75652D3030303032313334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2134, 'wal', 'ack-2134');
COMMIT;
SELECT 'ack', 2134;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2135, 23, X'76616C75652D3030303032313335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2135, 'wal', 'ack-2135');
COMMIT;
SELECT 'ack', 2135;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2136, 24, X'76616C75652D3030303032313336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2136, 'wal', 'ack-2136');
COMMIT;
SELECT 'ack', 2136;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2137, 25, X'76616C75652D3030303032313337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2137, 'wal', 'ack-2137');
COMMIT;
SELECT 'ack', 2137;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2138, 26, X'76616C75652D3030303032313338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2138, 'wal', 'ack-2138');
COMMIT;
SELECT 'ack', 2138;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2139, 27, X'76616C75652D3030303032313339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2139, 'wal', 'ack-2139');
COMMIT;
SELECT 'ack', 2139;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2140, 28, X'76616C75652D3030303032313430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2140, 'wal', 'ack-2140');
COMMIT;
SELECT 'ack', 2140;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2141, 29, X'76616C75652D3030303032313431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2141, 'wal', 'ack-2141');
COMMIT;
SELECT 'ack', 2141;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2142, 30, X'76616C75652D3030303032313432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2142, 'wal', 'ack-2142');
COMMIT;
SELECT 'ack', 2142;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2143, 31, X'76616C75652D3030303032313433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2143, 'wal', 'ack-2143');
COMMIT;
SELECT 'ack', 2143;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2144, 0, X'76616C75652D3030303032313434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2144, 'wal', 'ack-2144');
COMMIT;
SELECT 'ack', 2144;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2145, 1, X'76616C75652D3030303032313435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2145, 'wal', 'ack-2145');
COMMIT;
SELECT 'ack', 2145;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2146, 2, X'76616C75652D3030303032313436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2146, 'wal', 'ack-2146');
COMMIT;
SELECT 'ack', 2146;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2147, 3, X'76616C75652D3030303032313437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2147, 'wal', 'ack-2147');
COMMIT;
SELECT 'ack', 2147;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2148, 4, X'76616C75652D3030303032313438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2148, 'wal', 'ack-2148');
COMMIT;
SELECT 'ack', 2148;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2149, 5, X'76616C75652D3030303032313439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2149, 'wal', 'ack-2149');
COMMIT;
SELECT 'ack', 2149;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2150, 6, X'76616C75652D3030303032313530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2150, 'wal', 'ack-2150');
COMMIT;
SELECT 'ack', 2150;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2151, 7, X'76616C75652D3030303032313531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2151, 'wal', 'ack-2151');
COMMIT;
SELECT 'ack', 2151;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2152, 8, X'76616C75652D3030303032313532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2152, 'wal', 'ack-2152');
COMMIT;
SELECT 'ack', 2152;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2153, 9, X'76616C75652D3030303032313533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2153, 'wal', 'ack-2153');
COMMIT;
SELECT 'ack', 2153;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2154, 10, X'76616C75652D3030303032313534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2154, 'wal', 'ack-2154');
COMMIT;
SELECT 'ack', 2154;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2155, 11, X'76616C75652D3030303032313535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2155, 'wal', 'ack-2155');
COMMIT;
SELECT 'ack', 2155;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2156, 12, X'76616C75652D3030303032313536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2156, 'wal', 'ack-2156');
COMMIT;
SELECT 'ack', 2156;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2157, 13, X'76616C75652D3030303032313537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2157, 'wal', 'ack-2157');
COMMIT;
SELECT 'ack', 2157;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2158, 14, X'76616C75652D3030303032313538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2158, 'wal', 'ack-2158');
COMMIT;
SELECT 'ack', 2158;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2159, 15, X'76616C75652D3030303032313539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2159, 'wal', 'ack-2159');
COMMIT;
SELECT 'ack', 2159;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2160, 16, X'76616C75652D3030303032313630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2160, 'wal', 'ack-2160');
COMMIT;
SELECT 'ack', 2160;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2161, 17, X'76616C75652D3030303032313631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2161, 'wal', 'ack-2161');
COMMIT;
SELECT 'ack', 2161;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2162, 18, X'76616C75652D3030303032313632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2162, 'wal', 'ack-2162');
COMMIT;
SELECT 'ack', 2162;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2163, 19, X'76616C75652D3030303032313633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2163, 'wal', 'ack-2163');
COMMIT;
SELECT 'ack', 2163;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2164, 20, X'76616C75652D3030303032313634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2164, 'wal', 'ack-2164');
COMMIT;
SELECT 'ack', 2164;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2165, 21, X'76616C75652D3030303032313635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2165, 'wal', 'ack-2165');
COMMIT;
SELECT 'ack', 2165;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2166, 22, X'76616C75652D3030303032313636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2166, 'wal', 'ack-2166');
COMMIT;
SELECT 'ack', 2166;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2167, 23, X'76616C75652D3030303032313637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2167, 'wal', 'ack-2167');
COMMIT;
SELECT 'ack', 2167;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2168, 24, X'76616C75652D3030303032313638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2168, 'wal', 'ack-2168');
COMMIT;
SELECT 'ack', 2168;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2169, 25, X'76616C75652D3030303032313639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2169, 'wal', 'ack-2169');
COMMIT;
SELECT 'ack', 2169;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2170, 26, X'76616C75652D3030303032313730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2170, 'wal', 'ack-2170');
COMMIT;
SELECT 'ack', 2170;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2171, 27, X'76616C75652D3030303032313731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2171, 'wal', 'ack-2171');
COMMIT;
SELECT 'ack', 2171;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2172, 28, X'76616C75652D3030303032313732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2172, 'wal', 'ack-2172');
COMMIT;
SELECT 'ack', 2172;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2173, 29, X'76616C75652D3030303032313733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2173, 'wal', 'ack-2173');
COMMIT;
SELECT 'ack', 2173;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2174, 30, X'76616C75652D3030303032313734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2174, 'wal', 'ack-2174');
COMMIT;
SELECT 'ack', 2174;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2175, 31, X'76616C75652D3030303032313735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2175, 'wal', 'ack-2175');
COMMIT;
SELECT 'ack', 2175;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2176, 0, X'76616C75652D3030303032313736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2176, 'wal', 'ack-2176');
COMMIT;
SELECT 'ack', 2176;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2177, 1, X'76616C75652D3030303032313737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2177, 'wal', 'ack-2177');
COMMIT;
SELECT 'ack', 2177;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2178, 2, X'76616C75652D3030303032313738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2178, 'wal', 'ack-2178');
COMMIT;
SELECT 'ack', 2178;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2179, 3, X'76616C75652D3030303032313739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2179, 'wal', 'ack-2179');
COMMIT;
SELECT 'ack', 2179;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2180, 4, X'76616C75652D3030303032313830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2180, 'wal', 'ack-2180');
COMMIT;
SELECT 'ack', 2180;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2181, 5, X'76616C75652D3030303032313831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2181, 'wal', 'ack-2181');
COMMIT;
SELECT 'ack', 2181;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2182, 6, X'76616C75652D3030303032313832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2182, 'wal', 'ack-2182');
COMMIT;
SELECT 'ack', 2182;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2183, 7, X'76616C75652D3030303032313833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2183, 'wal', 'ack-2183');
COMMIT;
SELECT 'ack', 2183;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2184, 8, X'76616C75652D3030303032313834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2184, 'wal', 'ack-2184');
COMMIT;
SELECT 'ack', 2184;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2185, 9, X'76616C75652D3030303032313835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2185, 'wal', 'ack-2185');
COMMIT;
SELECT 'ack', 2185;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2186, 10, X'76616C75652D3030303032313836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2186, 'wal', 'ack-2186');
COMMIT;
SELECT 'ack', 2186;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2187, 11, X'76616C75652D3030303032313837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2187, 'wal', 'ack-2187');
COMMIT;
SELECT 'ack', 2187;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2188, 12, X'76616C75652D3030303032313838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2188, 'wal', 'ack-2188');
COMMIT;
SELECT 'ack', 2188;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2189, 13, X'76616C75652D3030303032313839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2189, 'wal', 'ack-2189');
COMMIT;
SELECT 'ack', 2189;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2190, 14, X'76616C75652D3030303032313930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2190, 'wal', 'ack-2190');
COMMIT;
SELECT 'ack', 2190;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2191, 15, X'76616C75652D3030303032313931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2191, 'wal', 'ack-2191');
COMMIT;
SELECT 'ack', 2191;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2192, 16, X'76616C75652D3030303032313932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2192, 'wal', 'ack-2192');
COMMIT;
SELECT 'ack', 2192;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2193, 17, X'76616C75652D3030303032313933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2193, 'wal', 'ack-2193');
COMMIT;
SELECT 'ack', 2193;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2194, 18, X'76616C75652D3030303032313934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2194, 'wal', 'ack-2194');
COMMIT;
SELECT 'ack', 2194;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2195, 19, X'76616C75652D3030303032313935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2195, 'wal', 'ack-2195');
COMMIT;
SELECT 'ack', 2195;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2196, 20, X'76616C75652D3030303032313936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2196, 'wal', 'ack-2196');
COMMIT;
SELECT 'ack', 2196;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2197, 21, X'76616C75652D3030303032313937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2197, 'wal', 'ack-2197');
COMMIT;
SELECT 'ack', 2197;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2198, 22, X'76616C75652D3030303032313938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2198, 'wal', 'ack-2198');
COMMIT;
SELECT 'ack', 2198;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2199, 23, X'76616C75652D3030303032313939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2199, 'wal', 'ack-2199');
COMMIT;
SELECT 'ack', 2199;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2200, 24, X'76616C75652D3030303032323030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2200, 'wal', 'ack-2200');
COMMIT;
SELECT 'ack', 2200;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2201, 25, X'76616C75652D3030303032323031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2201, 'wal', 'ack-2201');
COMMIT;
SELECT 'ack', 2201;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2202, 26, X'76616C75652D3030303032323032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2202, 'wal', 'ack-2202');
COMMIT;
SELECT 'ack', 2202;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2203, 27, X'76616C75652D3030303032323033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2203, 'wal', 'ack-2203');
COMMIT;
SELECT 'ack', 2203;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2204, 28, X'76616C75652D3030303032323034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2204, 'wal', 'ack-2204');
COMMIT;
SELECT 'ack', 2204;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2205, 29, X'76616C75652D3030303032323035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2205, 'wal', 'ack-2205');
COMMIT;
SELECT 'ack', 2205;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2206, 30, X'76616C75652D3030303032323036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2206, 'wal', 'ack-2206');
COMMIT;
SELECT 'ack', 2206;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2207, 31, X'76616C75652D3030303032323037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2207, 'wal', 'ack-2207');
COMMIT;
SELECT 'ack', 2207;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2208, 0, X'76616C75652D3030303032323038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2208, 'wal', 'ack-2208');
COMMIT;
SELECT 'ack', 2208;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2209, 1, X'76616C75652D3030303032323039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2209, 'wal', 'ack-2209');
COMMIT;
SELECT 'ack', 2209;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2210, 2, X'76616C75652D3030303032323130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2210, 'wal', 'ack-2210');
COMMIT;
SELECT 'ack', 2210;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2211, 3, X'76616C75652D3030303032323131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2211, 'wal', 'ack-2211');
COMMIT;
SELECT 'ack', 2211;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2212, 4, X'76616C75652D3030303032323132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2212, 'wal', 'ack-2212');
COMMIT;
SELECT 'ack', 2212;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2213, 5, X'76616C75652D3030303032323133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2213, 'wal', 'ack-2213');
COMMIT;
SELECT 'ack', 2213;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2214, 6, X'76616C75652D3030303032323134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2214, 'wal', 'ack-2214');
COMMIT;
SELECT 'ack', 2214;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2215, 7, X'76616C75652D3030303032323135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2215, 'wal', 'ack-2215');
COMMIT;
SELECT 'ack', 2215;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2216, 8, X'76616C75652D3030303032323136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2216, 'wal', 'ack-2216');
COMMIT;
SELECT 'ack', 2216;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2217, 9, X'76616C75652D3030303032323137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2217, 'wal', 'ack-2217');
COMMIT;
SELECT 'ack', 2217;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2218, 10, X'76616C75652D3030303032323138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2218, 'wal', 'ack-2218');
COMMIT;
SELECT 'ack', 2218;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2219, 11, X'76616C75652D3030303032323139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2219, 'wal', 'ack-2219');
COMMIT;
SELECT 'ack', 2219;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2220, 12, X'76616C75652D3030303032323230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2220, 'wal', 'ack-2220');
COMMIT;
SELECT 'ack', 2220;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2221, 13, X'76616C75652D3030303032323231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2221, 'wal', 'ack-2221');
COMMIT;
SELECT 'ack', 2221;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2222, 14, X'76616C75652D3030303032323232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2222, 'wal', 'ack-2222');
COMMIT;
SELECT 'ack', 2222;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2223, 15, X'76616C75652D3030303032323233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2223, 'wal', 'ack-2223');
COMMIT;
SELECT 'ack', 2223;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2224, 16, X'76616C75652D3030303032323234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2224, 'wal', 'ack-2224');
COMMIT;
SELECT 'ack', 2224;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2225, 17, X'76616C75652D3030303032323235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2225, 'wal', 'ack-2225');
COMMIT;
SELECT 'ack', 2225;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2226, 18, X'76616C75652D3030303032323236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2226, 'wal', 'ack-2226');
COMMIT;
SELECT 'ack', 2226;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2227, 19, X'76616C75652D3030303032323237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2227, 'wal', 'ack-2227');
COMMIT;
SELECT 'ack', 2227;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2228, 20, X'76616C75652D3030303032323238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2228, 'wal', 'ack-2228');
COMMIT;
SELECT 'ack', 2228;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2229, 21, X'76616C75652D3030303032323239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2229, 'wal', 'ack-2229');
COMMIT;
SELECT 'ack', 2229;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2230, 22, X'76616C75652D3030303032323330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2230, 'wal', 'ack-2230');
COMMIT;
SELECT 'ack', 2230;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2231, 23, X'76616C75652D3030303032323331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2231, 'wal', 'ack-2231');
COMMIT;
SELECT 'ack', 2231;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2232, 24, X'76616C75652D3030303032323332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2232, 'wal', 'ack-2232');
COMMIT;
SELECT 'ack', 2232;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2233, 25, X'76616C75652D3030303032323333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2233, 'wal', 'ack-2233');
COMMIT;
SELECT 'ack', 2233;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2234, 26, X'76616C75652D3030303032323334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2234, 'wal', 'ack-2234');
COMMIT;
SELECT 'ack', 2234;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2235, 27, X'76616C75652D3030303032323335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2235, 'wal', 'ack-2235');
COMMIT;
SELECT 'ack', 2235;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2236, 28, X'76616C75652D3030303032323336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2236, 'wal', 'ack-2236');
COMMIT;
SELECT 'ack', 2236;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2237, 29, X'76616C75652D3030303032323337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2237, 'wal', 'ack-2237');
COMMIT;
SELECT 'ack', 2237;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2238, 30, X'76616C75652D3030303032323338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2238, 'wal', 'ack-2238');
COMMIT;
SELECT 'ack', 2238;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2239, 31, X'76616C75652D3030303032323339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2239, 'wal', 'ack-2239');
COMMIT;
SELECT 'ack', 2239;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2240, 0, X'76616C75652D3030303032323430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2240, 'wal', 'ack-2240');
COMMIT;
SELECT 'ack', 2240;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2241, 1, X'76616C75652D3030303032323431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2241, 'wal', 'ack-2241');
COMMIT;
SELECT 'ack', 2241;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2242, 2, X'76616C75652D3030303032323432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2242, 'wal', 'ack-2242');
COMMIT;
SELECT 'ack', 2242;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2243, 3, X'76616C75652D3030303032323433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2243, 'wal', 'ack-2243');
COMMIT;
SELECT 'ack', 2243;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2244, 4, X'76616C75652D3030303032323434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2244, 'wal', 'ack-2244');
COMMIT;
SELECT 'ack', 2244;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2245, 5, X'76616C75652D3030303032323435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2245, 'wal', 'ack-2245');
COMMIT;
SELECT 'ack', 2245;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2246, 6, X'76616C75652D3030303032323436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2246, 'wal', 'ack-2246');
COMMIT;
SELECT 'ack', 2246;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2247, 7, X'76616C75652D3030303032323437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2247, 'wal', 'ack-2247');
COMMIT;
SELECT 'ack', 2247;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2248, 8, X'76616C75652D3030303032323438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2248, 'wal', 'ack-2248');
COMMIT;
SELECT 'ack', 2248;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2249, 9, X'76616C75652D3030303032323439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2249, 'wal', 'ack-2249');
COMMIT;
SELECT 'ack', 2249;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2250, 10, X'76616C75652D3030303032323530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2250, 'wal', 'ack-2250');
COMMIT;
SELECT 'ack', 2250;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2251, 11, X'76616C75652D3030303032323531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2251, 'wal', 'ack-2251');
COMMIT;
SELECT 'ack', 2251;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2252, 12, X'76616C75652D3030303032323532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2252, 'wal', 'ack-2252');
COMMIT;
SELECT 'ack', 2252;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2253, 13, X'76616C75652D3030303032323533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2253, 'wal', 'ack-2253');
COMMIT;
SELECT 'ack', 2253;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2254, 14, X'76616C75652D3030303032323534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2254, 'wal', 'ack-2254');
COMMIT;
SELECT 'ack', 2254;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2255, 15, X'76616C75652D3030303032323535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2255, 'wal', 'ack-2255');
COMMIT;
SELECT 'ack', 2255;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2256, 16, X'76616C75652D3030303032323536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2256, 'wal', 'ack-2256');
COMMIT;
SELECT 'ack', 2256;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2257, 17, X'76616C75652D3030303032323537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2257, 'wal', 'ack-2257');
COMMIT;
SELECT 'ack', 2257;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2258, 18, X'76616C75652D3030303032323538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2258, 'wal', 'ack-2258');
COMMIT;
SELECT 'ack', 2258;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2259, 19, X'76616C75652D3030303032323539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2259, 'wal', 'ack-2259');
COMMIT;
SELECT 'ack', 2259;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2260, 20, X'76616C75652D3030303032323630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2260, 'wal', 'ack-2260');
COMMIT;
SELECT 'ack', 2260;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2261, 21, X'76616C75652D3030303032323631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2261, 'wal', 'ack-2261');
COMMIT;
SELECT 'ack', 2261;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2262, 22, X'76616C75652D3030303032323632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2262, 'wal', 'ack-2262');
COMMIT;
SELECT 'ack', 2262;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2263, 23, X'76616C75652D3030303032323633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2263, 'wal', 'ack-2263');
COMMIT;
SELECT 'ack', 2263;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2264, 24, X'76616C75652D3030303032323634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2264, 'wal', 'ack-2264');
COMMIT;
SELECT 'ack', 2264;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2265, 25, X'76616C75652D3030303032323635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2265, 'wal', 'ack-2265');
COMMIT;
SELECT 'ack', 2265;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2266, 26, X'76616C75652D3030303032323636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2266, 'wal', 'ack-2266');
COMMIT;
SELECT 'ack', 2266;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2267, 27, X'76616C75652D3030303032323637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2267, 'wal', 'ack-2267');
COMMIT;
SELECT 'ack', 2267;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2268, 28, X'76616C75652D3030303032323638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2268, 'wal', 'ack-2268');
COMMIT;
SELECT 'ack', 2268;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2269, 29, X'76616C75652D3030303032323639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2269, 'wal', 'ack-2269');
COMMIT;
SELECT 'ack', 2269;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2270, 30, X'76616C75652D3030303032323730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2270, 'wal', 'ack-2270');
COMMIT;
SELECT 'ack', 2270;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2271, 31, X'76616C75652D3030303032323731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2271, 'wal', 'ack-2271');
COMMIT;
SELECT 'ack', 2271;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2272, 0, X'76616C75652D3030303032323732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2272, 'wal', 'ack-2272');
COMMIT;
SELECT 'ack', 2272;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2273, 1, X'76616C75652D3030303032323733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2273, 'wal', 'ack-2273');
COMMIT;
SELECT 'ack', 2273;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2274, 2, X'76616C75652D3030303032323734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2274, 'wal', 'ack-2274');
COMMIT;
SELECT 'ack', 2274;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2275, 3, X'76616C75652D3030303032323735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2275, 'wal', 'ack-2275');
COMMIT;
SELECT 'ack', 2275;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2276, 4, X'76616C75652D3030303032323736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2276, 'wal', 'ack-2276');
COMMIT;
SELECT 'ack', 2276;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2277, 5, X'76616C75652D3030303032323737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2277, 'wal', 'ack-2277');
COMMIT;
SELECT 'ack', 2277;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2278, 6, X'76616C75652D3030303032323738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2278, 'wal', 'ack-2278');
COMMIT;
SELECT 'ack', 2278;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2279, 7, X'76616C75652D3030303032323739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2279, 'wal', 'ack-2279');
COMMIT;
SELECT 'ack', 2279;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2280, 8, X'76616C75652D3030303032323830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2280, 'wal', 'ack-2280');
COMMIT;
SELECT 'ack', 2280;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2281, 9, X'76616C75652D3030303032323831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2281, 'wal', 'ack-2281');
COMMIT;
SELECT 'ack', 2281;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2282, 10, X'76616C75652D3030303032323832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2282, 'wal', 'ack-2282');
COMMIT;
SELECT 'ack', 2282;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2283, 11, X'76616C75652D3030303032323833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2283, 'wal', 'ack-2283');
COMMIT;
SELECT 'ack', 2283;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2284, 12, X'76616C75652D3030303032323834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2284, 'wal', 'ack-2284');
COMMIT;
SELECT 'ack', 2284;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2285, 13, X'76616C75652D3030303032323835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2285, 'wal', 'ack-2285');
COMMIT;
SELECT 'ack', 2285;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2286, 14, X'76616C75652D3030303032323836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2286, 'wal', 'ack-2286');
COMMIT;
SELECT 'ack', 2286;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2287, 15, X'76616C75652D3030303032323837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2287, 'wal', 'ack-2287');
COMMIT;
SELECT 'ack', 2287;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2288, 16, X'76616C75652D3030303032323838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2288, 'wal', 'ack-2288');
COMMIT;
SELECT 'ack', 2288;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2289, 17, X'76616C75652D3030303032323839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2289, 'wal', 'ack-2289');
COMMIT;
SELECT 'ack', 2289;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2290, 18, X'76616C75652D3030303032323930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2290, 'wal', 'ack-2290');
COMMIT;
SELECT 'ack', 2290;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2291, 19, X'76616C75652D3030303032323931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2291, 'wal', 'ack-2291');
COMMIT;
SELECT 'ack', 2291;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2292, 20, X'76616C75652D3030303032323932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2292, 'wal', 'ack-2292');
COMMIT;
SELECT 'ack', 2292;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2293, 21, X'76616C75652D3030303032323933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2293, 'wal', 'ack-2293');
COMMIT;
SELECT 'ack', 2293;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2294, 22, X'76616C75652D3030303032323934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2294, 'wal', 'ack-2294');
COMMIT;
SELECT 'ack', 2294;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2295, 23, X'76616C75652D3030303032323935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2295, 'wal', 'ack-2295');
COMMIT;
SELECT 'ack', 2295;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2296, 24, X'76616C75652D3030303032323936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2296, 'wal', 'ack-2296');
COMMIT;
SELECT 'ack', 2296;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2297, 25, X'76616C75652D3030303032323937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2297, 'wal', 'ack-2297');
COMMIT;
SELECT 'ack', 2297;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2298, 26, X'76616C75652D3030303032323938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2298, 'wal', 'ack-2298');
COMMIT;
SELECT 'ack', 2298;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2299, 27, X'76616C75652D3030303032323939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2299, 'wal', 'ack-2299');
COMMIT;
SELECT 'ack', 2299;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2300, 28, X'76616C75652D3030303032333030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2300, 'wal', 'ack-2300');
COMMIT;
SELECT 'ack', 2300;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2301, 29, X'76616C75652D3030303032333031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2301, 'wal', 'ack-2301');
COMMIT;
SELECT 'ack', 2301;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2302, 30, X'76616C75652D3030303032333032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2302, 'wal', 'ack-2302');
COMMIT;
SELECT 'ack', 2302;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2303, 31, X'76616C75652D3030303032333033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2303, 'wal', 'ack-2303');
COMMIT;
SELECT 'ack', 2303;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2304, 0, X'76616C75652D3030303032333034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2304, 'wal', 'ack-2304');
COMMIT;
SELECT 'ack', 2304;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2305, 1, X'76616C75652D3030303032333035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2305, 'wal', 'ack-2305');
COMMIT;
SELECT 'ack', 2305;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2306, 2, X'76616C75652D3030303032333036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2306, 'wal', 'ack-2306');
COMMIT;
SELECT 'ack', 2306;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2307, 3, X'76616C75652D3030303032333037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2307, 'wal', 'ack-2307');
COMMIT;
SELECT 'ack', 2307;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2308, 4, X'76616C75652D3030303032333038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2308, 'wal', 'ack-2308');
COMMIT;
SELECT 'ack', 2308;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2309, 5, X'76616C75652D3030303032333039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2309, 'wal', 'ack-2309');
COMMIT;
SELECT 'ack', 2309;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2310, 6, X'76616C75652D3030303032333130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2310, 'wal', 'ack-2310');
COMMIT;
SELECT 'ack', 2310;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2311, 7, X'76616C75652D3030303032333131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2311, 'wal', 'ack-2311');
COMMIT;
SELECT 'ack', 2311;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2312, 8, X'76616C75652D3030303032333132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2312, 'wal', 'ack-2312');
COMMIT;
SELECT 'ack', 2312;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2313, 9, X'76616C75652D3030303032333133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2313, 'wal', 'ack-2313');
COMMIT;
SELECT 'ack', 2313;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2314, 10, X'76616C75652D3030303032333134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2314, 'wal', 'ack-2314');
COMMIT;
SELECT 'ack', 2314;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2315, 11, X'76616C75652D3030303032333135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2315, 'wal', 'ack-2315');
COMMIT;
SELECT 'ack', 2315;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2316, 12, X'76616C75652D3030303032333136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2316, 'wal', 'ack-2316');
COMMIT;
SELECT 'ack', 2316;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2317, 13, X'76616C75652D3030303032333137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2317, 'wal', 'ack-2317');
COMMIT;
SELECT 'ack', 2317;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2318, 14, X'76616C75652D3030303032333138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2318, 'wal', 'ack-2318');
COMMIT;
SELECT 'ack', 2318;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2319, 15, X'76616C75652D3030303032333139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2319, 'wal', 'ack-2319');
COMMIT;
SELECT 'ack', 2319;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2320, 16, X'76616C75652D3030303032333230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2320, 'wal', 'ack-2320');
COMMIT;
SELECT 'ack', 2320;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2321, 17, X'76616C75652D3030303032333231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2321, 'wal', 'ack-2321');
COMMIT;
SELECT 'ack', 2321;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2322, 18, X'76616C75652D3030303032333232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2322, 'wal', 'ack-2322');
COMMIT;
SELECT 'ack', 2322;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2323, 19, X'76616C75652D3030303032333233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2323, 'wal', 'ack-2323');
COMMIT;
SELECT 'ack', 2323;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2324, 20, X'76616C75652D3030303032333234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2324, 'wal', 'ack-2324');
COMMIT;
SELECT 'ack', 2324;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2325, 21, X'76616C75652D3030303032333235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2325, 'wal', 'ack-2325');
COMMIT;
SELECT 'ack', 2325;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2326, 22, X'76616C75652D3030303032333236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2326, 'wal', 'ack-2326');
COMMIT;
SELECT 'ack', 2326;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2327, 23, X'76616C75652D3030303032333237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2327, 'wal', 'ack-2327');
COMMIT;
SELECT 'ack', 2327;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2328, 24, X'76616C75652D3030303032333238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2328, 'wal', 'ack-2328');
COMMIT;
SELECT 'ack', 2328;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2329, 25, X'76616C75652D3030303032333239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2329, 'wal', 'ack-2329');
COMMIT;
SELECT 'ack', 2329;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2330, 26, X'76616C75652D3030303032333330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2330, 'wal', 'ack-2330');
COMMIT;
SELECT 'ack', 2330;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2331, 27, X'76616C75652D3030303032333331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2331, 'wal', 'ack-2331');
COMMIT;
SELECT 'ack', 2331;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2332, 28, X'76616C75652D3030303032333332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2332, 'wal', 'ack-2332');
COMMIT;
SELECT 'ack', 2332;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2333, 29, X'76616C75652D3030303032333333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2333, 'wal', 'ack-2333');
COMMIT;
SELECT 'ack', 2333;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2334, 30, X'76616C75652D3030303032333334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2334, 'wal', 'ack-2334');
COMMIT;
SELECT 'ack', 2334;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2335, 31, X'76616C75652D3030303032333335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2335, 'wal', 'ack-2335');
COMMIT;
SELECT 'ack', 2335;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2336, 0, X'76616C75652D3030303032333336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2336, 'wal', 'ack-2336');
COMMIT;
SELECT 'ack', 2336;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2337, 1, X'76616C75652D3030303032333337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2337, 'wal', 'ack-2337');
COMMIT;
SELECT 'ack', 2337;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2338, 2, X'76616C75652D3030303032333338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2338, 'wal', 'ack-2338');
COMMIT;
SELECT 'ack', 2338;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2339, 3, X'76616C75652D3030303032333339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2339, 'wal', 'ack-2339');
COMMIT;
SELECT 'ack', 2339;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2340, 4, X'76616C75652D3030303032333430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2340, 'wal', 'ack-2340');
COMMIT;
SELECT 'ack', 2340;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2341, 5, X'76616C75652D3030303032333431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2341, 'wal', 'ack-2341');
COMMIT;
SELECT 'ack', 2341;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2342, 6, X'76616C75652D3030303032333432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2342, 'wal', 'ack-2342');
COMMIT;
SELECT 'ack', 2342;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2343, 7, X'76616C75652D3030303032333433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2343, 'wal', 'ack-2343');
COMMIT;
SELECT 'ack', 2343;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2344, 8, X'76616C75652D3030303032333434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2344, 'wal', 'ack-2344');
COMMIT;
SELECT 'ack', 2344;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2345, 9, X'76616C75652D3030303032333435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2345, 'wal', 'ack-2345');
COMMIT;
SELECT 'ack', 2345;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2346, 10, X'76616C75652D3030303032333436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2346, 'wal', 'ack-2346');
COMMIT;
SELECT 'ack', 2346;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2347, 11, X'76616C75652D3030303032333437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2347, 'wal', 'ack-2347');
COMMIT;
SELECT 'ack', 2347;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2348, 12, X'76616C75652D3030303032333438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2348, 'wal', 'ack-2348');
COMMIT;
SELECT 'ack', 2348;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2349, 13, X'76616C75652D3030303032333439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2349, 'wal', 'ack-2349');
COMMIT;
SELECT 'ack', 2349;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2350, 14, X'76616C75652D3030303032333530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2350, 'wal', 'ack-2350');
COMMIT;
SELECT 'ack', 2350;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2351, 15, X'76616C75652D3030303032333531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2351, 'wal', 'ack-2351');
COMMIT;
SELECT 'ack', 2351;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2352, 16, X'76616C75652D3030303032333532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2352, 'wal', 'ack-2352');
COMMIT;
SELECT 'ack', 2352;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2353, 17, X'76616C75652D3030303032333533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2353, 'wal', 'ack-2353');
COMMIT;
SELECT 'ack', 2353;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2354, 18, X'76616C75652D3030303032333534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2354, 'wal', 'ack-2354');
COMMIT;
SELECT 'ack', 2354;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2355, 19, X'76616C75652D3030303032333535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2355, 'wal', 'ack-2355');
COMMIT;
SELECT 'ack', 2355;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2356, 20, X'76616C75652D3030303032333536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2356, 'wal', 'ack-2356');
COMMIT;
SELECT 'ack', 2356;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2357, 21, X'76616C75652D3030303032333537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2357, 'wal', 'ack-2357');
COMMIT;
SELECT 'ack', 2357;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2358, 22, X'76616C75652D3030303032333538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2358, 'wal', 'ack-2358');
COMMIT;
SELECT 'ack', 2358;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2359, 23, X'76616C75652D3030303032333539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2359, 'wal', 'ack-2359');
COMMIT;
SELECT 'ack', 2359;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2360, 24, X'76616C75652D3030303032333630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2360, 'wal', 'ack-2360');
COMMIT;
SELECT 'ack', 2360;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2361, 25, X'76616C75652D3030303032333631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2361, 'wal', 'ack-2361');
COMMIT;
SELECT 'ack', 2361;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2362, 26, X'76616C75652D3030303032333632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2362, 'wal', 'ack-2362');
COMMIT;
SELECT 'ack', 2362;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2363, 27, X'76616C75652D3030303032333633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2363, 'wal', 'ack-2363');
COMMIT;
SELECT 'ack', 2363;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2364, 28, X'76616C75652D3030303032333634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2364, 'wal', 'ack-2364');
COMMIT;
SELECT 'ack', 2364;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2365, 29, X'76616C75652D3030303032333635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2365, 'wal', 'ack-2365');
COMMIT;
SELECT 'ack', 2365;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2366, 30, X'76616C75652D3030303032333636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2366, 'wal', 'ack-2366');
COMMIT;
SELECT 'ack', 2366;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2367, 31, X'76616C75652D3030303032333637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2367, 'wal', 'ack-2367');
COMMIT;
SELECT 'ack', 2367;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2368, 0, X'76616C75652D3030303032333638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2368, 'wal', 'ack-2368');
COMMIT;
SELECT 'ack', 2368;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2369, 1, X'76616C75652D3030303032333639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2369, 'wal', 'ack-2369');
COMMIT;
SELECT 'ack', 2369;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2370, 2, X'76616C75652D3030303032333730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2370, 'wal', 'ack-2370');
COMMIT;
SELECT 'ack', 2370;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2371, 3, X'76616C75652D3030303032333731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2371, 'wal', 'ack-2371');
COMMIT;
SELECT 'ack', 2371;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2372, 4, X'76616C75652D3030303032333732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2372, 'wal', 'ack-2372');
COMMIT;
SELECT 'ack', 2372;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2373, 5, X'76616C75652D3030303032333733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2373, 'wal', 'ack-2373');
COMMIT;
SELECT 'ack', 2373;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2374, 6, X'76616C75652D3030303032333734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2374, 'wal', 'ack-2374');
COMMIT;
SELECT 'ack', 2374;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2375, 7, X'76616C75652D3030303032333735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2375, 'wal', 'ack-2375');
COMMIT;
SELECT 'ack', 2375;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2376, 8, X'76616C75652D3030303032333736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2376, 'wal', 'ack-2376');
COMMIT;
SELECT 'ack', 2376;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2377, 9, X'76616C75652D3030303032333737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2377, 'wal', 'ack-2377');
COMMIT;
SELECT 'ack', 2377;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2378, 10, X'76616C75652D3030303032333738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2378, 'wal', 'ack-2378');
COMMIT;
SELECT 'ack', 2378;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2379, 11, X'76616C75652D3030303032333739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2379, 'wal', 'ack-2379');
COMMIT;
SELECT 'ack', 2379;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2380, 12, X'76616C75652D3030303032333830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2380, 'wal', 'ack-2380');
COMMIT;
SELECT 'ack', 2380;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2381, 13, X'76616C75652D3030303032333831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2381, 'wal', 'ack-2381');
COMMIT;
SELECT 'ack', 2381;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2382, 14, X'76616C75652D3030303032333832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2382, 'wal', 'ack-2382');
COMMIT;
SELECT 'ack', 2382;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2383, 15, X'76616C75652D3030303032333833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2383, 'wal', 'ack-2383');
COMMIT;
SELECT 'ack', 2383;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2384, 16, X'76616C75652D3030303032333834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2384, 'wal', 'ack-2384');
COMMIT;
SELECT 'ack', 2384;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2385, 17, X'76616C75652D3030303032333835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2385, 'wal', 'ack-2385');
COMMIT;
SELECT 'ack', 2385;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2386, 18, X'76616C75652D3030303032333836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2386, 'wal', 'ack-2386');
COMMIT;
SELECT 'ack', 2386;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2387, 19, X'76616C75652D3030303032333837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2387, 'wal', 'ack-2387');
COMMIT;
SELECT 'ack', 2387;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2388, 20, X'76616C75652D3030303032333838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2388, 'wal', 'ack-2388');
COMMIT;
SELECT 'ack', 2388;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2389, 21, X'76616C75652D3030303032333839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2389, 'wal', 'ack-2389');
COMMIT;
SELECT 'ack', 2389;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2390, 22, X'76616C75652D3030303032333930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2390, 'wal', 'ack-2390');
COMMIT;
SELECT 'ack', 2390;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2391, 23, X'76616C75652D3030303032333931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2391, 'wal', 'ack-2391');
COMMIT;
SELECT 'ack', 2391;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2392, 24, X'76616C75652D3030303032333932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2392, 'wal', 'ack-2392');
COMMIT;
SELECT 'ack', 2392;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2393, 25, X'76616C75652D3030303032333933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2393, 'wal', 'ack-2393');
COMMIT;
SELECT 'ack', 2393;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2394, 26, X'76616C75652D3030303032333934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2394, 'wal', 'ack-2394');
COMMIT;
SELECT 'ack', 2394;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2395, 27, X'76616C75652D3030303032333935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2395, 'wal', 'ack-2395');
COMMIT;
SELECT 'ack', 2395;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2396, 28, X'76616C75652D3030303032333936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2396, 'wal', 'ack-2396');
COMMIT;
SELECT 'ack', 2396;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2397, 29, X'76616C75652D3030303032333937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2397, 'wal', 'ack-2397');
COMMIT;
SELECT 'ack', 2397;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2398, 30, X'76616C75652D3030303032333938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2398, 'wal', 'ack-2398');
COMMIT;
SELECT 'ack', 2398;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2399, 31, X'76616C75652D3030303032333939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2399, 'wal', 'ack-2399');
COMMIT;
SELECT 'ack', 2399;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2400, 0, X'76616C75652D3030303032343030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2400, 'wal', 'ack-2400');
COMMIT;
SELECT 'ack', 2400;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2401, 1, X'76616C75652D3030303032343031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2401, 'wal', 'ack-2401');
COMMIT;
SELECT 'ack', 2401;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2402, 2, X'76616C75652D3030303032343032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2402, 'wal', 'ack-2402');
COMMIT;
SELECT 'ack', 2402;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2403, 3, X'76616C75652D3030303032343033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2403, 'wal', 'ack-2403');
COMMIT;
SELECT 'ack', 2403;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2404, 4, X'76616C75652D3030303032343034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2404, 'wal', 'ack-2404');
COMMIT;
SELECT 'ack', 2404;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2405, 5, X'76616C75652D3030303032343035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2405, 'wal', 'ack-2405');
COMMIT;
SELECT 'ack', 2405;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2406, 6, X'76616C75652D3030303032343036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2406, 'wal', 'ack-2406');
COMMIT;
SELECT 'ack', 2406;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2407, 7, X'76616C75652D3030303032343037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2407, 'wal', 'ack-2407');
COMMIT;
SELECT 'ack', 2407;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2408, 8, X'76616C75652D3030303032343038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2408, 'wal', 'ack-2408');
COMMIT;
SELECT 'ack', 2408;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2409, 9, X'76616C75652D3030303032343039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2409, 'wal', 'ack-2409');
COMMIT;
SELECT 'ack', 2409;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2410, 10, X'76616C75652D3030303032343130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2410, 'wal', 'ack-2410');
COMMIT;
SELECT 'ack', 2410;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2411, 11, X'76616C75652D3030303032343131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2411, 'wal', 'ack-2411');
COMMIT;
SELECT 'ack', 2411;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2412, 12, X'76616C75652D3030303032343132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2412, 'wal', 'ack-2412');
COMMIT;
SELECT 'ack', 2412;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2413, 13, X'76616C75652D3030303032343133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2413, 'wal', 'ack-2413');
COMMIT;
SELECT 'ack', 2413;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2414, 14, X'76616C75652D3030303032343134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2414, 'wal', 'ack-2414');
COMMIT;
SELECT 'ack', 2414;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2415, 15, X'76616C75652D3030303032343135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2415, 'wal', 'ack-2415');
COMMIT;
SELECT 'ack', 2415;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2416, 16, X'76616C75652D3030303032343136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2416, 'wal', 'ack-2416');
COMMIT;
SELECT 'ack', 2416;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2417, 17, X'76616C75652D3030303032343137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2417, 'wal', 'ack-2417');
COMMIT;
SELECT 'ack', 2417;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2418, 18, X'76616C75652D3030303032343138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2418, 'wal', 'ack-2418');
COMMIT;
SELECT 'ack', 2418;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2419, 19, X'76616C75652D3030303032343139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2419, 'wal', 'ack-2419');
COMMIT;
SELECT 'ack', 2419;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2420, 20, X'76616C75652D3030303032343230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2420, 'wal', 'ack-2420');
COMMIT;
SELECT 'ack', 2420;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2421, 21, X'76616C75652D3030303032343231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2421, 'wal', 'ack-2421');
COMMIT;
SELECT 'ack', 2421;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2422, 22, X'76616C75652D3030303032343232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2422, 'wal', 'ack-2422');
COMMIT;
SELECT 'ack', 2422;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2423, 23, X'76616C75652D3030303032343233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2423, 'wal', 'ack-2423');
COMMIT;
SELECT 'ack', 2423;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2424, 24, X'76616C75652D3030303032343234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2424, 'wal', 'ack-2424');
COMMIT;
SELECT 'ack', 2424;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2425, 25, X'76616C75652D3030303032343235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2425, 'wal', 'ack-2425');
COMMIT;
SELECT 'ack', 2425;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2426, 26, X'76616C75652D3030303032343236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2426, 'wal', 'ack-2426');
COMMIT;
SELECT 'ack', 2426;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2427, 27, X'76616C75652D3030303032343237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2427, 'wal', 'ack-2427');
COMMIT;
SELECT 'ack', 2427;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2428, 28, X'76616C75652D3030303032343238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2428, 'wal', 'ack-2428');
COMMIT;
SELECT 'ack', 2428;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2429, 29, X'76616C75652D3030303032343239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2429, 'wal', 'ack-2429');
COMMIT;
SELECT 'ack', 2429;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2430, 30, X'76616C75652D3030303032343330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2430, 'wal', 'ack-2430');
COMMIT;
SELECT 'ack', 2430;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2431, 31, X'76616C75652D3030303032343331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2431, 'wal', 'ack-2431');
COMMIT;
SELECT 'ack', 2431;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2432, 0, X'76616C75652D3030303032343332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2432, 'wal', 'ack-2432');
COMMIT;
SELECT 'ack', 2432;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2433, 1, X'76616C75652D3030303032343333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2433, 'wal', 'ack-2433');
COMMIT;
SELECT 'ack', 2433;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2434, 2, X'76616C75652D3030303032343334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2434, 'wal', 'ack-2434');
COMMIT;
SELECT 'ack', 2434;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2435, 3, X'76616C75652D3030303032343335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2435, 'wal', 'ack-2435');
COMMIT;
SELECT 'ack', 2435;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2436, 4, X'76616C75652D3030303032343336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2436, 'wal', 'ack-2436');
COMMIT;
SELECT 'ack', 2436;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2437, 5, X'76616C75652D3030303032343337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2437, 'wal', 'ack-2437');
COMMIT;
SELECT 'ack', 2437;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2438, 6, X'76616C75652D3030303032343338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2438, 'wal', 'ack-2438');
COMMIT;
SELECT 'ack', 2438;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2439, 7, X'76616C75652D3030303032343339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2439, 'wal', 'ack-2439');
COMMIT;
SELECT 'ack', 2439;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2440, 8, X'76616C75652D3030303032343430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2440, 'wal', 'ack-2440');
COMMIT;
SELECT 'ack', 2440;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2441, 9, X'76616C75652D3030303032343431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2441, 'wal', 'ack-2441');
COMMIT;
SELECT 'ack', 2441;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2442, 10, X'76616C75652D3030303032343432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2442, 'wal', 'ack-2442');
COMMIT;
SELECT 'ack', 2442;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2443, 11, X'76616C75652D3030303032343433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2443, 'wal', 'ack-2443');
COMMIT;
SELECT 'ack', 2443;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2444, 12, X'76616C75652D3030303032343434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2444, 'wal', 'ack-2444');
COMMIT;
SELECT 'ack', 2444;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2445, 13, X'76616C75652D3030303032343435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2445, 'wal', 'ack-2445');
COMMIT;
SELECT 'ack', 2445;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2446, 14, X'76616C75652D3030303032343436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2446, 'wal', 'ack-2446');
COMMIT;
SELECT 'ack', 2446;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2447, 15, X'76616C75652D3030303032343437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2447, 'wal', 'ack-2447');
COMMIT;
SELECT 'ack', 2447;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2448, 16, X'76616C75652D3030303032343438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2448, 'wal', 'ack-2448');
COMMIT;
SELECT 'ack', 2448;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2449, 17, X'76616C75652D3030303032343439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2449, 'wal', 'ack-2449');
COMMIT;
SELECT 'ack', 2449;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2450, 18, X'76616C75652D3030303032343530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2450, 'wal', 'ack-2450');
COMMIT;
SELECT 'ack', 2450;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2451, 19, X'76616C75652D3030303032343531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2451, 'wal', 'ack-2451');
COMMIT;
SELECT 'ack', 2451;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2452, 20, X'76616C75652D3030303032343532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2452, 'wal', 'ack-2452');
COMMIT;
SELECT 'ack', 2452;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2453, 21, X'76616C75652D3030303032343533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2453, 'wal', 'ack-2453');
COMMIT;
SELECT 'ack', 2453;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2454, 22, X'76616C75652D3030303032343534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2454, 'wal', 'ack-2454');
COMMIT;
SELECT 'ack', 2454;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2455, 23, X'76616C75652D3030303032343535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2455, 'wal', 'ack-2455');
COMMIT;
SELECT 'ack', 2455;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2456, 24, X'76616C75652D3030303032343536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2456, 'wal', 'ack-2456');
COMMIT;
SELECT 'ack', 2456;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2457, 25, X'76616C75652D3030303032343537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2457, 'wal', 'ack-2457');
COMMIT;
SELECT 'ack', 2457;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2458, 26, X'76616C75652D3030303032343538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2458, 'wal', 'ack-2458');
COMMIT;
SELECT 'ack', 2458;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2459, 27, X'76616C75652D3030303032343539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2459, 'wal', 'ack-2459');
COMMIT;
SELECT 'ack', 2459;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2460, 28, X'76616C75652D3030303032343630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2460, 'wal', 'ack-2460');
COMMIT;
SELECT 'ack', 2460;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2461, 29, X'76616C75652D3030303032343631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2461, 'wal', 'ack-2461');
COMMIT;
SELECT 'ack', 2461;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2462, 30, X'76616C75652D3030303032343632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2462, 'wal', 'ack-2462');
COMMIT;
SELECT 'ack', 2462;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2463, 31, X'76616C75652D3030303032343633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2463, 'wal', 'ack-2463');
COMMIT;
SELECT 'ack', 2463;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2464, 0, X'76616C75652D3030303032343634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2464, 'wal', 'ack-2464');
COMMIT;
SELECT 'ack', 2464;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2465, 1, X'76616C75652D3030303032343635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2465, 'wal', 'ack-2465');
COMMIT;
SELECT 'ack', 2465;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2466, 2, X'76616C75652D3030303032343636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2466, 'wal', 'ack-2466');
COMMIT;
SELECT 'ack', 2466;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2467, 3, X'76616C75652D3030303032343637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2467, 'wal', 'ack-2467');
COMMIT;
SELECT 'ack', 2467;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2468, 4, X'76616C75652D3030303032343638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2468, 'wal', 'ack-2468');
COMMIT;
SELECT 'ack', 2468;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2469, 5, X'76616C75652D3030303032343639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2469, 'wal', 'ack-2469');
COMMIT;
SELECT 'ack', 2469;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2470, 6, X'76616C75652D3030303032343730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2470, 'wal', 'ack-2470');
COMMIT;
SELECT 'ack', 2470;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2471, 7, X'76616C75652D3030303032343731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2471, 'wal', 'ack-2471');
COMMIT;
SELECT 'ack', 2471;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2472, 8, X'76616C75652D3030303032343732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2472, 'wal', 'ack-2472');
COMMIT;
SELECT 'ack', 2472;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2473, 9, X'76616C75652D3030303032343733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2473, 'wal', 'ack-2473');
COMMIT;
SELECT 'ack', 2473;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2474, 10, X'76616C75652D3030303032343734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2474, 'wal', 'ack-2474');
COMMIT;
SELECT 'ack', 2474;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2475, 11, X'76616C75652D3030303032343735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2475, 'wal', 'ack-2475');
COMMIT;
SELECT 'ack', 2475;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2476, 12, X'76616C75652D3030303032343736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2476, 'wal', 'ack-2476');
COMMIT;
SELECT 'ack', 2476;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2477, 13, X'76616C75652D3030303032343737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2477, 'wal', 'ack-2477');
COMMIT;
SELECT 'ack', 2477;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2478, 14, X'76616C75652D3030303032343738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2478, 'wal', 'ack-2478');
COMMIT;
SELECT 'ack', 2478;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2479, 15, X'76616C75652D3030303032343739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2479, 'wal', 'ack-2479');
COMMIT;
SELECT 'ack', 2479;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2480, 16, X'76616C75652D3030303032343830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2480, 'wal', 'ack-2480');
COMMIT;
SELECT 'ack', 2480;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2481, 17, X'76616C75652D3030303032343831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2481, 'wal', 'ack-2481');
COMMIT;
SELECT 'ack', 2481;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2482, 18, X'76616C75652D3030303032343832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2482, 'wal', 'ack-2482');
COMMIT;
SELECT 'ack', 2482;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2483, 19, X'76616C75652D3030303032343833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2483, 'wal', 'ack-2483');
COMMIT;
SELECT 'ack', 2483;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2484, 20, X'76616C75652D3030303032343834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2484, 'wal', 'ack-2484');
COMMIT;
SELECT 'ack', 2484;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2485, 21, X'76616C75652D3030303032343835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2485, 'wal', 'ack-2485');
COMMIT;
SELECT 'ack', 2485;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2486, 22, X'76616C75652D3030303032343836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2486, 'wal', 'ack-2486');
COMMIT;
SELECT 'ack', 2486;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2487, 23, X'76616C75652D3030303032343837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2487, 'wal', 'ack-2487');
COMMIT;
SELECT 'ack', 2487;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2488, 24, X'76616C75652D3030303032343838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2488, 'wal', 'ack-2488');
COMMIT;
SELECT 'ack', 2488;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2489, 25, X'76616C75652D3030303032343839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2489, 'wal', 'ack-2489');
COMMIT;
SELECT 'ack', 2489;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2490, 26, X'76616C75652D3030303032343930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2490, 'wal', 'ack-2490');
COMMIT;
SELECT 'ack', 2490;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2491, 27, X'76616C75652D3030303032343931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2491, 'wal', 'ack-2491');
COMMIT;
SELECT 'ack', 2491;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2492, 28, X'76616C75652D3030303032343932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2492, 'wal', 'ack-2492');
COMMIT;
SELECT 'ack', 2492;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2493, 29, X'76616C75652D3030303032343933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2493, 'wal', 'ack-2493');
COMMIT;
SELECT 'ack', 2493;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2494, 30, X'76616C75652D3030303032343934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2494, 'wal', 'ack-2494');
COMMIT;
SELECT 'ack', 2494;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2495, 31, X'76616C75652D3030303032343935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2495, 'wal', 'ack-2495');
COMMIT;
SELECT 'ack', 2495;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2496, 0, X'76616C75652D3030303032343936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2496, 'wal', 'ack-2496');
COMMIT;
SELECT 'ack', 2496;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2497, 1, X'76616C75652D3030303032343937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2497, 'wal', 'ack-2497');
COMMIT;
SELECT 'ack', 2497;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2498, 2, X'76616C75652D3030303032343938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2498, 'wal', 'ack-2498');
COMMIT;
SELECT 'ack', 2498;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2499, 3, X'76616C75652D3030303032343939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2499, 'wal', 'ack-2499');
COMMIT;
SELECT 'ack', 2499;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2500, 4, X'76616C75652D3030303032353030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2500, 'wal', 'ack-2500');
COMMIT;
SELECT 'ack', 2500;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2501, 5, X'76616C75652D3030303032353031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2501, 'wal', 'ack-2501');
COMMIT;
SELECT 'ack', 2501;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2502, 6, X'76616C75652D3030303032353032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2502, 'wal', 'ack-2502');
COMMIT;
SELECT 'ack', 2502;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2503, 7, X'76616C75652D3030303032353033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2503, 'wal', 'ack-2503');
COMMIT;
SELECT 'ack', 2503;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2504, 8, X'76616C75652D3030303032353034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2504, 'wal', 'ack-2504');
COMMIT;
SELECT 'ack', 2504;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2505, 9, X'76616C75652D3030303032353035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2505, 'wal', 'ack-2505');
COMMIT;
SELECT 'ack', 2505;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2506, 10, X'76616C75652D3030303032353036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2506, 'wal', 'ack-2506');
COMMIT;
SELECT 'ack', 2506;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2507, 11, X'76616C75652D3030303032353037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2507, 'wal', 'ack-2507');
COMMIT;
SELECT 'ack', 2507;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2508, 12, X'76616C75652D3030303032353038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2508, 'wal', 'ack-2508');
COMMIT;
SELECT 'ack', 2508;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2509, 13, X'76616C75652D3030303032353039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2509, 'wal', 'ack-2509');
COMMIT;
SELECT 'ack', 2509;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2510, 14, X'76616C75652D3030303032353130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2510, 'wal', 'ack-2510');
COMMIT;
SELECT 'ack', 2510;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2511, 15, X'76616C75652D3030303032353131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2511, 'wal', 'ack-2511');
COMMIT;
SELECT 'ack', 2511;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2512, 16, X'76616C75652D3030303032353132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2512, 'wal', 'ack-2512');
COMMIT;
SELECT 'ack', 2512;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2513, 17, X'76616C75652D3030303032353133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2513, 'wal', 'ack-2513');
COMMIT;
SELECT 'ack', 2513;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2514, 18, X'76616C75652D3030303032353134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2514, 'wal', 'ack-2514');
COMMIT;
SELECT 'ack', 2514;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2515, 19, X'76616C75652D3030303032353135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2515, 'wal', 'ack-2515');
COMMIT;
SELECT 'ack', 2515;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2516, 20, X'76616C75652D3030303032353136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2516, 'wal', 'ack-2516');
COMMIT;
SELECT 'ack', 2516;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2517, 21, X'76616C75652D3030303032353137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2517, 'wal', 'ack-2517');
COMMIT;
SELECT 'ack', 2517;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2518, 22, X'76616C75652D3030303032353138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2518, 'wal', 'ack-2518');
COMMIT;
SELECT 'ack', 2518;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2519, 23, X'76616C75652D3030303032353139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2519, 'wal', 'ack-2519');
COMMIT;
SELECT 'ack', 2519;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2520, 24, X'76616C75652D3030303032353230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2520, 'wal', 'ack-2520');
COMMIT;
SELECT 'ack', 2520;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2521, 25, X'76616C75652D3030303032353231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2521, 'wal', 'ack-2521');
COMMIT;
SELECT 'ack', 2521;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2522, 26, X'76616C75652D3030303032353232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2522, 'wal', 'ack-2522');
COMMIT;
SELECT 'ack', 2522;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2523, 27, X'76616C75652D3030303032353233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2523, 'wal', 'ack-2523');
COMMIT;
SELECT 'ack', 2523;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2524, 28, X'76616C75652D3030303032353234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2524, 'wal', 'ack-2524');
COMMIT;
SELECT 'ack', 2524;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2525, 29, X'76616C75652D3030303032353235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2525, 'wal', 'ack-2525');
COMMIT;
SELECT 'ack', 2525;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2526, 30, X'76616C75652D3030303032353236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2526, 'wal', 'ack-2526');
COMMIT;
SELECT 'ack', 2526;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2527, 31, X'76616C75652D3030303032353237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2527, 'wal', 'ack-2527');
COMMIT;
SELECT 'ack', 2527;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2528, 0, X'76616C75652D3030303032353238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2528, 'wal', 'ack-2528');
COMMIT;
SELECT 'ack', 2528;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2529, 1, X'76616C75652D3030303032353239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2529, 'wal', 'ack-2529');
COMMIT;
SELECT 'ack', 2529;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2530, 2, X'76616C75652D3030303032353330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2530, 'wal', 'ack-2530');
COMMIT;
SELECT 'ack', 2530;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2531, 3, X'76616C75652D3030303032353331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2531, 'wal', 'ack-2531');
COMMIT;
SELECT 'ack', 2531;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2532, 4, X'76616C75652D3030303032353332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2532, 'wal', 'ack-2532');
COMMIT;
SELECT 'ack', 2532;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2533, 5, X'76616C75652D3030303032353333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2533, 'wal', 'ack-2533');
COMMIT;
SELECT 'ack', 2533;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2534, 6, X'76616C75652D3030303032353334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2534, 'wal', 'ack-2534');
COMMIT;
SELECT 'ack', 2534;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2535, 7, X'76616C75652D3030303032353335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2535, 'wal', 'ack-2535');
COMMIT;
SELECT 'ack', 2535;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2536, 8, X'76616C75652D3030303032353336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2536, 'wal', 'ack-2536');
COMMIT;
SELECT 'ack', 2536;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2537, 9, X'76616C75652D3030303032353337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2537, 'wal', 'ack-2537');
COMMIT;
SELECT 'ack', 2537;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2538, 10, X'76616C75652D3030303032353338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2538, 'wal', 'ack-2538');
COMMIT;
SELECT 'ack', 2538;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2539, 11, X'76616C75652D3030303032353339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2539, 'wal', 'ack-2539');
COMMIT;
SELECT 'ack', 2539;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2540, 12, X'76616C75652D3030303032353430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2540, 'wal', 'ack-2540');
COMMIT;
SELECT 'ack', 2540;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2541, 13, X'76616C75652D3030303032353431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2541, 'wal', 'ack-2541');
COMMIT;
SELECT 'ack', 2541;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2542, 14, X'76616C75652D3030303032353432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2542, 'wal', 'ack-2542');
COMMIT;
SELECT 'ack', 2542;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2543, 15, X'76616C75652D3030303032353433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2543, 'wal', 'ack-2543');
COMMIT;
SELECT 'ack', 2543;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2544, 16, X'76616C75652D3030303032353434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2544, 'wal', 'ack-2544');
COMMIT;
SELECT 'ack', 2544;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2545, 17, X'76616C75652D3030303032353435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2545, 'wal', 'ack-2545');
COMMIT;
SELECT 'ack', 2545;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2546, 18, X'76616C75652D3030303032353436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2546, 'wal', 'ack-2546');
COMMIT;
SELECT 'ack', 2546;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2547, 19, X'76616C75652D3030303032353437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2547, 'wal', 'ack-2547');
COMMIT;
SELECT 'ack', 2547;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2548, 20, X'76616C75652D3030303032353438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2548, 'wal', 'ack-2548');
COMMIT;
SELECT 'ack', 2548;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2549, 21, X'76616C75652D3030303032353439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2549, 'wal', 'ack-2549');
COMMIT;
SELECT 'ack', 2549;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2550, 22, X'76616C75652D3030303032353530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2550, 'wal', 'ack-2550');
COMMIT;
SELECT 'ack', 2550;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2551, 23, X'76616C75652D3030303032353531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2551, 'wal', 'ack-2551');
COMMIT;
SELECT 'ack', 2551;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2552, 24, X'76616C75652D3030303032353532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2552, 'wal', 'ack-2552');
COMMIT;
SELECT 'ack', 2552;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2553, 25, X'76616C75652D3030303032353533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2553, 'wal', 'ack-2553');
COMMIT;
SELECT 'ack', 2553;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2554, 26, X'76616C75652D3030303032353534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2554, 'wal', 'ack-2554');
COMMIT;
SELECT 'ack', 2554;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2555, 27, X'76616C75652D3030303032353535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2555, 'wal', 'ack-2555');
COMMIT;
SELECT 'ack', 2555;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2556, 28, X'76616C75652D3030303032353536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2556, 'wal', 'ack-2556');
COMMIT;
SELECT 'ack', 2556;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2557, 29, X'76616C75652D3030303032353537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2557, 'wal', 'ack-2557');
COMMIT;
SELECT 'ack', 2557;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2558, 30, X'76616C75652D3030303032353538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2558, 'wal', 'ack-2558');
COMMIT;
SELECT 'ack', 2558;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2559, 31, X'76616C75652D3030303032353539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2559, 'wal', 'ack-2559');
COMMIT;
SELECT 'ack', 2559;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2560, 0, X'76616C75652D3030303032353630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2560, 'wal', 'ack-2560');
COMMIT;
SELECT 'ack', 2560;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2561, 1, X'76616C75652D3030303032353631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2561, 'wal', 'ack-2561');
COMMIT;
SELECT 'ack', 2561;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2562, 2, X'76616C75652D3030303032353632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2562, 'wal', 'ack-2562');
COMMIT;
SELECT 'ack', 2562;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2563, 3, X'76616C75652D3030303032353633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2563, 'wal', 'ack-2563');
COMMIT;
SELECT 'ack', 2563;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2564, 4, X'76616C75652D3030303032353634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2564, 'wal', 'ack-2564');
COMMIT;
SELECT 'ack', 2564;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2565, 5, X'76616C75652D3030303032353635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2565, 'wal', 'ack-2565');
COMMIT;
SELECT 'ack', 2565;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2566, 6, X'76616C75652D3030303032353636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2566, 'wal', 'ack-2566');
COMMIT;
SELECT 'ack', 2566;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2567, 7, X'76616C75652D3030303032353637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2567, 'wal', 'ack-2567');
COMMIT;
SELECT 'ack', 2567;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2568, 8, X'76616C75652D3030303032353638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2568, 'wal', 'ack-2568');
COMMIT;
SELECT 'ack', 2568;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2569, 9, X'76616C75652D3030303032353639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2569, 'wal', 'ack-2569');
COMMIT;
SELECT 'ack', 2569;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2570, 10, X'76616C75652D3030303032353730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2570, 'wal', 'ack-2570');
COMMIT;
SELECT 'ack', 2570;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2571, 11, X'76616C75652D3030303032353731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2571, 'wal', 'ack-2571');
COMMIT;
SELECT 'ack', 2571;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2572, 12, X'76616C75652D3030303032353732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2572, 'wal', 'ack-2572');
COMMIT;
SELECT 'ack', 2572;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2573, 13, X'76616C75652D3030303032353733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2573, 'wal', 'ack-2573');
COMMIT;
SELECT 'ack', 2573;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2574, 14, X'76616C75652D3030303032353734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2574, 'wal', 'ack-2574');
COMMIT;
SELECT 'ack', 2574;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2575, 15, X'76616C75652D3030303032353735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2575, 'wal', 'ack-2575');
COMMIT;
SELECT 'ack', 2575;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2576, 16, X'76616C75652D3030303032353736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2576, 'wal', 'ack-2576');
COMMIT;
SELECT 'ack', 2576;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2577, 17, X'76616C75652D3030303032353737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2577, 'wal', 'ack-2577');
COMMIT;
SELECT 'ack', 2577;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2578, 18, X'76616C75652D3030303032353738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2578, 'wal', 'ack-2578');
COMMIT;
SELECT 'ack', 2578;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2579, 19, X'76616C75652D3030303032353739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2579, 'wal', 'ack-2579');
COMMIT;
SELECT 'ack', 2579;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2580, 20, X'76616C75652D3030303032353830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2580, 'wal', 'ack-2580');
COMMIT;
SELECT 'ack', 2580;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2581, 21, X'76616C75652D3030303032353831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2581, 'wal', 'ack-2581');
COMMIT;
SELECT 'ack', 2581;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2582, 22, X'76616C75652D3030303032353832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2582, 'wal', 'ack-2582');
COMMIT;
SELECT 'ack', 2582;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2583, 23, X'76616C75652D3030303032353833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2583, 'wal', 'ack-2583');
COMMIT;
SELECT 'ack', 2583;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2584, 24, X'76616C75652D3030303032353834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2584, 'wal', 'ack-2584');
COMMIT;
SELECT 'ack', 2584;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2585, 25, X'76616C75652D3030303032353835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2585, 'wal', 'ack-2585');
COMMIT;
SELECT 'ack', 2585;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2586, 26, X'76616C75652D3030303032353836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2586, 'wal', 'ack-2586');
COMMIT;
SELECT 'ack', 2586;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2587, 27, X'76616C75652D3030303032353837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2587, 'wal', 'ack-2587');
COMMIT;
SELECT 'ack', 2587;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2588, 28, X'76616C75652D3030303032353838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2588, 'wal', 'ack-2588');
COMMIT;
SELECT 'ack', 2588;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2589, 29, X'76616C75652D3030303032353839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2589, 'wal', 'ack-2589');
COMMIT;
SELECT 'ack', 2589;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2590, 30, X'76616C75652D3030303032353930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2590, 'wal', 'ack-2590');
COMMIT;
SELECT 'ack', 2590;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2591, 31, X'76616C75652D3030303032353931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2591, 'wal', 'ack-2591');
COMMIT;
SELECT 'ack', 2591;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2592, 0, X'76616C75652D3030303032353932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2592, 'wal', 'ack-2592');
COMMIT;
SELECT 'ack', 2592;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2593, 1, X'76616C75652D3030303032353933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2593, 'wal', 'ack-2593');
COMMIT;
SELECT 'ack', 2593;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2594, 2, X'76616C75652D3030303032353934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2594, 'wal', 'ack-2594');
COMMIT;
SELECT 'ack', 2594;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2595, 3, X'76616C75652D3030303032353935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2595, 'wal', 'ack-2595');
COMMIT;
SELECT 'ack', 2595;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2596, 4, X'76616C75652D3030303032353936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2596, 'wal', 'ack-2596');
COMMIT;
SELECT 'ack', 2596;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2597, 5, X'76616C75652D3030303032353937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2597, 'wal', 'ack-2597');
COMMIT;
SELECT 'ack', 2597;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2598, 6, X'76616C75652D3030303032353938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2598, 'wal', 'ack-2598');
COMMIT;
SELECT 'ack', 2598;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2599, 7, X'76616C75652D3030303032353939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2599, 'wal', 'ack-2599');
COMMIT;
SELECT 'ack', 2599;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2600, 8, X'76616C75652D3030303032363030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2600, 'wal', 'ack-2600');
COMMIT;
SELECT 'ack', 2600;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2601, 9, X'76616C75652D3030303032363031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2601, 'wal', 'ack-2601');
COMMIT;
SELECT 'ack', 2601;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2602, 10, X'76616C75652D3030303032363032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2602, 'wal', 'ack-2602');
COMMIT;
SELECT 'ack', 2602;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2603, 11, X'76616C75652D3030303032363033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2603, 'wal', 'ack-2603');
COMMIT;
SELECT 'ack', 2603;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2604, 12, X'76616C75652D3030303032363034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2604, 'wal', 'ack-2604');
COMMIT;
SELECT 'ack', 2604;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2605, 13, X'76616C75652D3030303032363035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2605, 'wal', 'ack-2605');
COMMIT;
SELECT 'ack', 2605;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2606, 14, X'76616C75652D3030303032363036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2606, 'wal', 'ack-2606');
COMMIT;
SELECT 'ack', 2606;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2607, 15, X'76616C75652D3030303032363037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2607, 'wal', 'ack-2607');
COMMIT;
SELECT 'ack', 2607;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2608, 16, X'76616C75652D3030303032363038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2608, 'wal', 'ack-2608');
COMMIT;
SELECT 'ack', 2608;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2609, 17, X'76616C75652D3030303032363039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2609, 'wal', 'ack-2609');
COMMIT;
SELECT 'ack', 2609;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2610, 18, X'76616C75652D3030303032363130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2610, 'wal', 'ack-2610');
COMMIT;
SELECT 'ack', 2610;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2611, 19, X'76616C75652D3030303032363131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2611, 'wal', 'ack-2611');
COMMIT;
SELECT 'ack', 2611;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2612, 20, X'76616C75652D3030303032363132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2612, 'wal', 'ack-2612');
COMMIT;
SELECT 'ack', 2612;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2613, 21, X'76616C75652D3030303032363133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2613, 'wal', 'ack-2613');
COMMIT;
SELECT 'ack', 2613;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2614, 22, X'76616C75652D3030303032363134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2614, 'wal', 'ack-2614');
COMMIT;
SELECT 'ack', 2614;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2615, 23, X'76616C75652D3030303032363135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2615, 'wal', 'ack-2615');
COMMIT;
SELECT 'ack', 2615;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2616, 24, X'76616C75652D3030303032363136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2616, 'wal', 'ack-2616');
COMMIT;
SELECT 'ack', 2616;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2617, 25, X'76616C75652D3030303032363137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2617, 'wal', 'ack-2617');
COMMIT;
SELECT 'ack', 2617;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2618, 26, X'76616C75652D3030303032363138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2618, 'wal', 'ack-2618');
COMMIT;
SELECT 'ack', 2618;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2619, 27, X'76616C75652D3030303032363139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2619, 'wal', 'ack-2619');
COMMIT;
SELECT 'ack', 2619;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2620, 28, X'76616C75652D3030303032363230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2620, 'wal', 'ack-2620');
COMMIT;
SELECT 'ack', 2620;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2621, 29, X'76616C75652D3030303032363231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2621, 'wal', 'ack-2621');
COMMIT;
SELECT 'ack', 2621;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2622, 30, X'76616C75652D3030303032363232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2622, 'wal', 'ack-2622');
COMMIT;
SELECT 'ack', 2622;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2623, 31, X'76616C75652D3030303032363233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2623, 'wal', 'ack-2623');
COMMIT;
SELECT 'ack', 2623;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2624, 0, X'76616C75652D3030303032363234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2624, 'wal', 'ack-2624');
COMMIT;
SELECT 'ack', 2624;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2625, 1, X'76616C75652D3030303032363235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2625, 'wal', 'ack-2625');
COMMIT;
SELECT 'ack', 2625;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2626, 2, X'76616C75652D3030303032363236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2626, 'wal', 'ack-2626');
COMMIT;
SELECT 'ack', 2626;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2627, 3, X'76616C75652D3030303032363237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2627, 'wal', 'ack-2627');
COMMIT;
SELECT 'ack', 2627;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2628, 4, X'76616C75652D3030303032363238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2628, 'wal', 'ack-2628');
COMMIT;
SELECT 'ack', 2628;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2629, 5, X'76616C75652D3030303032363239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2629, 'wal', 'ack-2629');
COMMIT;
SELECT 'ack', 2629;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2630, 6, X'76616C75652D3030303032363330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2630, 'wal', 'ack-2630');
COMMIT;
SELECT 'ack', 2630;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2631, 7, X'76616C75652D3030303032363331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2631, 'wal', 'ack-2631');
COMMIT;
SELECT 'ack', 2631;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2632, 8, X'76616C75652D3030303032363332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2632, 'wal', 'ack-2632');
COMMIT;
SELECT 'ack', 2632;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2633, 9, X'76616C75652D3030303032363333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2633, 'wal', 'ack-2633');
COMMIT;
SELECT 'ack', 2633;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2634, 10, X'76616C75652D3030303032363334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2634, 'wal', 'ack-2634');
COMMIT;
SELECT 'ack', 2634;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2635, 11, X'76616C75652D3030303032363335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2635, 'wal', 'ack-2635');
COMMIT;
SELECT 'ack', 2635;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2636, 12, X'76616C75652D3030303032363336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2636, 'wal', 'ack-2636');
COMMIT;
SELECT 'ack', 2636;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2637, 13, X'76616C75652D3030303032363337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2637, 'wal', 'ack-2637');
COMMIT;
SELECT 'ack', 2637;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2638, 14, X'76616C75652D3030303032363338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2638, 'wal', 'ack-2638');
COMMIT;
SELECT 'ack', 2638;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2639, 15, X'76616C75652D3030303032363339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2639, 'wal', 'ack-2639');
COMMIT;
SELECT 'ack', 2639;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2640, 16, X'76616C75652D3030303032363430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2640, 'wal', 'ack-2640');
COMMIT;
SELECT 'ack', 2640;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2641, 17, X'76616C75652D3030303032363431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2641, 'wal', 'ack-2641');
COMMIT;
SELECT 'ack', 2641;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2642, 18, X'76616C75652D3030303032363432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2642, 'wal', 'ack-2642');
COMMIT;
SELECT 'ack', 2642;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2643, 19, X'76616C75652D3030303032363433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2643, 'wal', 'ack-2643');
COMMIT;
SELECT 'ack', 2643;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2644, 20, X'76616C75652D3030303032363434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2644, 'wal', 'ack-2644');
COMMIT;
SELECT 'ack', 2644;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2645, 21, X'76616C75652D3030303032363435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2645, 'wal', 'ack-2645');
COMMIT;
SELECT 'ack', 2645;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2646, 22, X'76616C75652D3030303032363436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2646, 'wal', 'ack-2646');
COMMIT;
SELECT 'ack', 2646;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2647, 23, X'76616C75652D3030303032363437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2647, 'wal', 'ack-2647');
COMMIT;
SELECT 'ack', 2647;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2648, 24, X'76616C75652D3030303032363438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2648, 'wal', 'ack-2648');
COMMIT;
SELECT 'ack', 2648;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2649, 25, X'76616C75652D3030303032363439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2649, 'wal', 'ack-2649');
COMMIT;
SELECT 'ack', 2649;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2650, 26, X'76616C75652D3030303032363530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2650, 'wal', 'ack-2650');
COMMIT;
SELECT 'ack', 2650;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2651, 27, X'76616C75652D3030303032363531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2651, 'wal', 'ack-2651');
COMMIT;
SELECT 'ack', 2651;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2652, 28, X'76616C75652D3030303032363532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2652, 'wal', 'ack-2652');
COMMIT;
SELECT 'ack', 2652;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2653, 29, X'76616C75652D3030303032363533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2653, 'wal', 'ack-2653');
COMMIT;
SELECT 'ack', 2653;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2654, 30, X'76616C75652D3030303032363534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2654, 'wal', 'ack-2654');
COMMIT;
SELECT 'ack', 2654;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2655, 31, X'76616C75652D3030303032363535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2655, 'wal', 'ack-2655');
COMMIT;
SELECT 'ack', 2655;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2656, 0, X'76616C75652D3030303032363536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2656, 'wal', 'ack-2656');
COMMIT;
SELECT 'ack', 2656;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2657, 1, X'76616C75652D3030303032363537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2657, 'wal', 'ack-2657');
COMMIT;
SELECT 'ack', 2657;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2658, 2, X'76616C75652D3030303032363538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2658, 'wal', 'ack-2658');
COMMIT;
SELECT 'ack', 2658;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2659, 3, X'76616C75652D3030303032363539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2659, 'wal', 'ack-2659');
COMMIT;
SELECT 'ack', 2659;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2660, 4, X'76616C75652D3030303032363630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2660, 'wal', 'ack-2660');
COMMIT;
SELECT 'ack', 2660;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2661, 5, X'76616C75652D3030303032363631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2661, 'wal', 'ack-2661');
COMMIT;
SELECT 'ack', 2661;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2662, 6, X'76616C75652D3030303032363632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2662, 'wal', 'ack-2662');
COMMIT;
SELECT 'ack', 2662;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2663, 7, X'76616C75652D3030303032363633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2663, 'wal', 'ack-2663');
COMMIT;
SELECT 'ack', 2663;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2664, 8, X'76616C75652D3030303032363634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2664, 'wal', 'ack-2664');
COMMIT;
SELECT 'ack', 2664;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2665, 9, X'76616C75652D3030303032363635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2665, 'wal', 'ack-2665');
COMMIT;
SELECT 'ack', 2665;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2666, 10, X'76616C75652D3030303032363636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2666, 'wal', 'ack-2666');
COMMIT;
SELECT 'ack', 2666;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2667, 11, X'76616C75652D3030303032363637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2667, 'wal', 'ack-2667');
COMMIT;
SELECT 'ack', 2667;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2668, 12, X'76616C75652D3030303032363638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2668, 'wal', 'ack-2668');
COMMIT;
SELECT 'ack', 2668;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2669, 13, X'76616C75652D3030303032363639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2669, 'wal', 'ack-2669');
COMMIT;
SELECT 'ack', 2669;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2670, 14, X'76616C75652D3030303032363730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2670, 'wal', 'ack-2670');
COMMIT;
SELECT 'ack', 2670;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2671, 15, X'76616C75652D3030303032363731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2671, 'wal', 'ack-2671');
COMMIT;
SELECT 'ack', 2671;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2672, 16, X'76616C75652D3030303032363732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2672, 'wal', 'ack-2672');
COMMIT;
SELECT 'ack', 2672;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2673, 17, X'76616C75652D3030303032363733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2673, 'wal', 'ack-2673');
COMMIT;
SELECT 'ack', 2673;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2674, 18, X'76616C75652D3030303032363734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2674, 'wal', 'ack-2674');
COMMIT;
SELECT 'ack', 2674;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2675, 19, X'76616C75652D3030303032363735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2675, 'wal', 'ack-2675');
COMMIT;
SELECT 'ack', 2675;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2676, 20, X'76616C75652D3030303032363736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2676, 'wal', 'ack-2676');
COMMIT;
SELECT 'ack', 2676;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2677, 21, X'76616C75652D3030303032363737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2677, 'wal', 'ack-2677');
COMMIT;
SELECT 'ack', 2677;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2678, 22, X'76616C75652D3030303032363738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2678, 'wal', 'ack-2678');
COMMIT;
SELECT 'ack', 2678;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2679, 23, X'76616C75652D3030303032363739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2679, 'wal', 'ack-2679');
COMMIT;
SELECT 'ack', 2679;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2680, 24, X'76616C75652D3030303032363830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2680, 'wal', 'ack-2680');
COMMIT;
SELECT 'ack', 2680;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2681, 25, X'76616C75652D3030303032363831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2681, 'wal', 'ack-2681');
COMMIT;
SELECT 'ack', 2681;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2682, 26, X'76616C75652D3030303032363832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2682, 'wal', 'ack-2682');
COMMIT;
SELECT 'ack', 2682;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2683, 27, X'76616C75652D3030303032363833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2683, 'wal', 'ack-2683');
COMMIT;
SELECT 'ack', 2683;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2684, 28, X'76616C75652D3030303032363834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2684, 'wal', 'ack-2684');
COMMIT;
SELECT 'ack', 2684;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2685, 29, X'76616C75652D3030303032363835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2685, 'wal', 'ack-2685');
COMMIT;
SELECT 'ack', 2685;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2686, 30, X'76616C75652D3030303032363836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2686, 'wal', 'ack-2686');
COMMIT;
SELECT 'ack', 2686;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2687, 31, X'76616C75652D3030303032363837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2687, 'wal', 'ack-2687');
COMMIT;
SELECT 'ack', 2687;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2688, 0, X'76616C75652D3030303032363838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2688, 'wal', 'ack-2688');
COMMIT;
SELECT 'ack', 2688;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2689, 1, X'76616C75652D3030303032363839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2689, 'wal', 'ack-2689');
COMMIT;
SELECT 'ack', 2689;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2690, 2, X'76616C75652D3030303032363930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2690, 'wal', 'ack-2690');
COMMIT;
SELECT 'ack', 2690;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2691, 3, X'76616C75652D3030303032363931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2691, 'wal', 'ack-2691');
COMMIT;
SELECT 'ack', 2691;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2692, 4, X'76616C75652D3030303032363932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2692, 'wal', 'ack-2692');
COMMIT;
SELECT 'ack', 2692;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2693, 5, X'76616C75652D3030303032363933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2693, 'wal', 'ack-2693');
COMMIT;
SELECT 'ack', 2693;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2694, 6, X'76616C75652D3030303032363934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2694, 'wal', 'ack-2694');
COMMIT;
SELECT 'ack', 2694;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2695, 7, X'76616C75652D3030303032363935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2695, 'wal', 'ack-2695');
COMMIT;
SELECT 'ack', 2695;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2696, 8, X'76616C75652D3030303032363936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2696, 'wal', 'ack-2696');
COMMIT;
SELECT 'ack', 2696;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2697, 9, X'76616C75652D3030303032363937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2697, 'wal', 'ack-2697');
COMMIT;
SELECT 'ack', 2697;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2698, 10, X'76616C75652D3030303032363938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2698, 'wal', 'ack-2698');
COMMIT;
SELECT 'ack', 2698;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2699, 11, X'76616C75652D3030303032363939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2699, 'wal', 'ack-2699');
COMMIT;
SELECT 'ack', 2699;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2700, 12, X'76616C75652D3030303032373030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2700, 'wal', 'ack-2700');
COMMIT;
SELECT 'ack', 2700;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2701, 13, X'76616C75652D3030303032373031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2701, 'wal', 'ack-2701');
COMMIT;
SELECT 'ack', 2701;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2702, 14, X'76616C75652D3030303032373032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2702, 'wal', 'ack-2702');
COMMIT;
SELECT 'ack', 2702;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2703, 15, X'76616C75652D3030303032373033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2703, 'wal', 'ack-2703');
COMMIT;
SELECT 'ack', 2703;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2704, 16, X'76616C75652D3030303032373034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2704, 'wal', 'ack-2704');
COMMIT;
SELECT 'ack', 2704;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2705, 17, X'76616C75652D3030303032373035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2705, 'wal', 'ack-2705');
COMMIT;
SELECT 'ack', 2705;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2706, 18, X'76616C75652D3030303032373036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2706, 'wal', 'ack-2706');
COMMIT;
SELECT 'ack', 2706;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2707, 19, X'76616C75652D3030303032373037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2707, 'wal', 'ack-2707');
COMMIT;
SELECT 'ack', 2707;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2708, 20, X'76616C75652D3030303032373038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2708, 'wal', 'ack-2708');
COMMIT;
SELECT 'ack', 2708;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2709, 21, X'76616C75652D3030303032373039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2709, 'wal', 'ack-2709');
COMMIT;
SELECT 'ack', 2709;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2710, 22, X'76616C75652D3030303032373130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2710, 'wal', 'ack-2710');
COMMIT;
SELECT 'ack', 2710;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2711, 23, X'76616C75652D3030303032373131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2711, 'wal', 'ack-2711');
COMMIT;
SELECT 'ack', 2711;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2712, 24, X'76616C75652D3030303032373132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2712, 'wal', 'ack-2712');
COMMIT;
SELECT 'ack', 2712;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2713, 25, X'76616C75652D3030303032373133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2713, 'wal', 'ack-2713');
COMMIT;
SELECT 'ack', 2713;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2714, 26, X'76616C75652D3030303032373134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2714, 'wal', 'ack-2714');
COMMIT;
SELECT 'ack', 2714;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2715, 27, X'76616C75652D3030303032373135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2715, 'wal', 'ack-2715');
COMMIT;
SELECT 'ack', 2715;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2716, 28, X'76616C75652D3030303032373136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2716, 'wal', 'ack-2716');
COMMIT;
SELECT 'ack', 2716;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2717, 29, X'76616C75652D3030303032373137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2717, 'wal', 'ack-2717');
COMMIT;
SELECT 'ack', 2717;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2718, 30, X'76616C75652D3030303032373138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2718, 'wal', 'ack-2718');
COMMIT;
SELECT 'ack', 2718;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2719, 31, X'76616C75652D3030303032373139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2719, 'wal', 'ack-2719');
COMMIT;
SELECT 'ack', 2719;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2720, 0, X'76616C75652D3030303032373230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2720, 'wal', 'ack-2720');
COMMIT;
SELECT 'ack', 2720;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2721, 1, X'76616C75652D3030303032373231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2721, 'wal', 'ack-2721');
COMMIT;
SELECT 'ack', 2721;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2722, 2, X'76616C75652D3030303032373232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2722, 'wal', 'ack-2722');
COMMIT;
SELECT 'ack', 2722;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2723, 3, X'76616C75652D3030303032373233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2723, 'wal', 'ack-2723');
COMMIT;
SELECT 'ack', 2723;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2724, 4, X'76616C75652D3030303032373234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2724, 'wal', 'ack-2724');
COMMIT;
SELECT 'ack', 2724;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2725, 5, X'76616C75652D3030303032373235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2725, 'wal', 'ack-2725');
COMMIT;
SELECT 'ack', 2725;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2726, 6, X'76616C75652D3030303032373236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2726, 'wal', 'ack-2726');
COMMIT;
SELECT 'ack', 2726;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2727, 7, X'76616C75652D3030303032373237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2727, 'wal', 'ack-2727');
COMMIT;
SELECT 'ack', 2727;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2728, 8, X'76616C75652D3030303032373238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2728, 'wal', 'ack-2728');
COMMIT;
SELECT 'ack', 2728;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2729, 9, X'76616C75652D3030303032373239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2729, 'wal', 'ack-2729');
COMMIT;
SELECT 'ack', 2729;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2730, 10, X'76616C75652D3030303032373330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2730, 'wal', 'ack-2730');
COMMIT;
SELECT 'ack', 2730;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2731, 11, X'76616C75652D3030303032373331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2731, 'wal', 'ack-2731');
COMMIT;
SELECT 'ack', 2731;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2732, 12, X'76616C75652D3030303032373332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2732, 'wal', 'ack-2732');
COMMIT;
SELECT 'ack', 2732;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2733, 13, X'76616C75652D3030303032373333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2733, 'wal', 'ack-2733');
COMMIT;
SELECT 'ack', 2733;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2734, 14, X'76616C75652D3030303032373334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2734, 'wal', 'ack-2734');
COMMIT;
SELECT 'ack', 2734;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2735, 15, X'76616C75652D3030303032373335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2735, 'wal', 'ack-2735');
COMMIT;
SELECT 'ack', 2735;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2736, 16, X'76616C75652D3030303032373336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2736, 'wal', 'ack-2736');
COMMIT;
SELECT 'ack', 2736;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2737, 17, X'76616C75652D3030303032373337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2737, 'wal', 'ack-2737');
COMMIT;
SELECT 'ack', 2737;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2738, 18, X'76616C75652D3030303032373338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2738, 'wal', 'ack-2738');
COMMIT;
SELECT 'ack', 2738;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2739, 19, X'76616C75652D3030303032373339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2739, 'wal', 'ack-2739');
COMMIT;
SELECT 'ack', 2739;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2740, 20, X'76616C75652D3030303032373430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2740, 'wal', 'ack-2740');
COMMIT;
SELECT 'ack', 2740;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2741, 21, X'76616C75652D3030303032373431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2741, 'wal', 'ack-2741');
COMMIT;
SELECT 'ack', 2741;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2742, 22, X'76616C75652D3030303032373432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2742, 'wal', 'ack-2742');
COMMIT;
SELECT 'ack', 2742;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2743, 23, X'76616C75652D3030303032373433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2743, 'wal', 'ack-2743');
COMMIT;
SELECT 'ack', 2743;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2744, 24, X'76616C75652D3030303032373434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2744, 'wal', 'ack-2744');
COMMIT;
SELECT 'ack', 2744;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2745, 25, X'76616C75652D3030303032373435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2745, 'wal', 'ack-2745');
COMMIT;
SELECT 'ack', 2745;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2746, 26, X'76616C75652D3030303032373436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2746, 'wal', 'ack-2746');
COMMIT;
SELECT 'ack', 2746;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2747, 27, X'76616C75652D3030303032373437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2747, 'wal', 'ack-2747');
COMMIT;
SELECT 'ack', 2747;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2748, 28, X'76616C75652D3030303032373438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2748, 'wal', 'ack-2748');
COMMIT;
SELECT 'ack', 2748;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2749, 29, X'76616C75652D3030303032373439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2749, 'wal', 'ack-2749');
COMMIT;
SELECT 'ack', 2749;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2750, 30, X'76616C75652D3030303032373530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2750, 'wal', 'ack-2750');
COMMIT;
SELECT 'ack', 2750;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2751, 31, X'76616C75652D3030303032373531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2751, 'wal', 'ack-2751');
COMMIT;
SELECT 'ack', 2751;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2752, 0, X'76616C75652D3030303032373532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2752, 'wal', 'ack-2752');
COMMIT;
SELECT 'ack', 2752;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2753, 1, X'76616C75652D3030303032373533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2753, 'wal', 'ack-2753');
COMMIT;
SELECT 'ack', 2753;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2754, 2, X'76616C75652D3030303032373534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2754, 'wal', 'ack-2754');
COMMIT;
SELECT 'ack', 2754;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2755, 3, X'76616C75652D3030303032373535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2755, 'wal', 'ack-2755');
COMMIT;
SELECT 'ack', 2755;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2756, 4, X'76616C75652D3030303032373536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2756, 'wal', 'ack-2756');
COMMIT;
SELECT 'ack', 2756;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2757, 5, X'76616C75652D3030303032373537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2757, 'wal', 'ack-2757');
COMMIT;
SELECT 'ack', 2757;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2758, 6, X'76616C75652D3030303032373538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2758, 'wal', 'ack-2758');
COMMIT;
SELECT 'ack', 2758;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2759, 7, X'76616C75652D3030303032373539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2759, 'wal', 'ack-2759');
COMMIT;
SELECT 'ack', 2759;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2760, 8, X'76616C75652D3030303032373630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2760, 'wal', 'ack-2760');
COMMIT;
SELECT 'ack', 2760;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2761, 9, X'76616C75652D3030303032373631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2761, 'wal', 'ack-2761');
COMMIT;
SELECT 'ack', 2761;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2762, 10, X'76616C75652D3030303032373632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2762, 'wal', 'ack-2762');
COMMIT;
SELECT 'ack', 2762;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2763, 11, X'76616C75652D3030303032373633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2763, 'wal', 'ack-2763');
COMMIT;
SELECT 'ack', 2763;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2764, 12, X'76616C75652D3030303032373634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2764, 'wal', 'ack-2764');
COMMIT;
SELECT 'ack', 2764;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2765, 13, X'76616C75652D3030303032373635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2765, 'wal', 'ack-2765');
COMMIT;
SELECT 'ack', 2765;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2766, 14, X'76616C75652D3030303032373636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2766, 'wal', 'ack-2766');
COMMIT;
SELECT 'ack', 2766;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2767, 15, X'76616C75652D3030303032373637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2767, 'wal', 'ack-2767');
COMMIT;
SELECT 'ack', 2767;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2768, 16, X'76616C75652D3030303032373638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2768, 'wal', 'ack-2768');
COMMIT;
SELECT 'ack', 2768;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2769, 17, X'76616C75652D3030303032373639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2769, 'wal', 'ack-2769');
COMMIT;
SELECT 'ack', 2769;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2770, 18, X'76616C75652D3030303032373730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2770, 'wal', 'ack-2770');
COMMIT;
SELECT 'ack', 2770;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2771, 19, X'76616C75652D3030303032373731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2771, 'wal', 'ack-2771');
COMMIT;
SELECT 'ack', 2771;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2772, 20, X'76616C75652D3030303032373732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2772, 'wal', 'ack-2772');
COMMIT;
SELECT 'ack', 2772;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2773, 21, X'76616C75652D3030303032373733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2773, 'wal', 'ack-2773');
COMMIT;
SELECT 'ack', 2773;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2774, 22, X'76616C75652D3030303032373734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2774, 'wal', 'ack-2774');
COMMIT;
SELECT 'ack', 2774;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2775, 23, X'76616C75652D3030303032373735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2775, 'wal', 'ack-2775');
COMMIT;
SELECT 'ack', 2775;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2776, 24, X'76616C75652D3030303032373736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2776, 'wal', 'ack-2776');
COMMIT;
SELECT 'ack', 2776;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2777, 25, X'76616C75652D3030303032373737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2777, 'wal', 'ack-2777');
COMMIT;
SELECT 'ack', 2777;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2778, 26, X'76616C75652D3030303032373738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2778, 'wal', 'ack-2778');
COMMIT;
SELECT 'ack', 2778;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2779, 27, X'76616C75652D3030303032373739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2779, 'wal', 'ack-2779');
COMMIT;
SELECT 'ack', 2779;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2780, 28, X'76616C75652D3030303032373830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2780, 'wal', 'ack-2780');
COMMIT;
SELECT 'ack', 2780;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2781, 29, X'76616C75652D3030303032373831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2781, 'wal', 'ack-2781');
COMMIT;
SELECT 'ack', 2781;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2782, 30, X'76616C75652D3030303032373832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2782, 'wal', 'ack-2782');
COMMIT;
SELECT 'ack', 2782;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2783, 31, X'76616C75652D3030303032373833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2783, 'wal', 'ack-2783');
COMMIT;
SELECT 'ack', 2783;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2784, 0, X'76616C75652D3030303032373834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2784, 'wal', 'ack-2784');
COMMIT;
SELECT 'ack', 2784;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2785, 1, X'76616C75652D3030303032373835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2785, 'wal', 'ack-2785');
COMMIT;
SELECT 'ack', 2785;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2786, 2, X'76616C75652D3030303032373836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2786, 'wal', 'ack-2786');
COMMIT;
SELECT 'ack', 2786;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2787, 3, X'76616C75652D3030303032373837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2787, 'wal', 'ack-2787');
COMMIT;
SELECT 'ack', 2787;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2788, 4, X'76616C75652D3030303032373838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2788, 'wal', 'ack-2788');
COMMIT;
SELECT 'ack', 2788;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2789, 5, X'76616C75652D3030303032373839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2789, 'wal', 'ack-2789');
COMMIT;
SELECT 'ack', 2789;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2790, 6, X'76616C75652D3030303032373930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2790, 'wal', 'ack-2790');
COMMIT;
SELECT 'ack', 2790;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2791, 7, X'76616C75652D3030303032373931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2791, 'wal', 'ack-2791');
COMMIT;
SELECT 'ack', 2791;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2792, 8, X'76616C75652D3030303032373932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2792, 'wal', 'ack-2792');
COMMIT;
SELECT 'ack', 2792;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2793, 9, X'76616C75652D3030303032373933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2793, 'wal', 'ack-2793');
COMMIT;
SELECT 'ack', 2793;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2794, 10, X'76616C75652D3030303032373934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2794, 'wal', 'ack-2794');
COMMIT;
SELECT 'ack', 2794;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2795, 11, X'76616C75652D3030303032373935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2795, 'wal', 'ack-2795');
COMMIT;
SELECT 'ack', 2795;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2796, 12, X'76616C75652D3030303032373936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2796, 'wal', 'ack-2796');
COMMIT;
SELECT 'ack', 2796;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2797, 13, X'76616C75652D3030303032373937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2797, 'wal', 'ack-2797');
COMMIT;
SELECT 'ack', 2797;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2798, 14, X'76616C75652D3030303032373938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2798, 'wal', 'ack-2798');
COMMIT;
SELECT 'ack', 2798;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2799, 15, X'76616C75652D3030303032373939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2799, 'wal', 'ack-2799');
COMMIT;
SELECT 'ack', 2799;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2800, 16, X'76616C75652D3030303032383030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2800, 'wal', 'ack-2800');
COMMIT;
SELECT 'ack', 2800;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2801, 17, X'76616C75652D3030303032383031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2801, 'wal', 'ack-2801');
COMMIT;
SELECT 'ack', 2801;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2802, 18, X'76616C75652D3030303032383032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2802, 'wal', 'ack-2802');
COMMIT;
SELECT 'ack', 2802;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2803, 19, X'76616C75652D3030303032383033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2803, 'wal', 'ack-2803');
COMMIT;
SELECT 'ack', 2803;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2804, 20, X'76616C75652D3030303032383034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2804, 'wal', 'ack-2804');
COMMIT;
SELECT 'ack', 2804;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2805, 21, X'76616C75652D3030303032383035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2805, 'wal', 'ack-2805');
COMMIT;
SELECT 'ack', 2805;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2806, 22, X'76616C75652D3030303032383036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2806, 'wal', 'ack-2806');
COMMIT;
SELECT 'ack', 2806;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2807, 23, X'76616C75652D3030303032383037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2807, 'wal', 'ack-2807');
COMMIT;
SELECT 'ack', 2807;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2808, 24, X'76616C75652D3030303032383038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2808, 'wal', 'ack-2808');
COMMIT;
SELECT 'ack', 2808;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2809, 25, X'76616C75652D3030303032383039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2809, 'wal', 'ack-2809');
COMMIT;
SELECT 'ack', 2809;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2810, 26, X'76616C75652D3030303032383130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2810, 'wal', 'ack-2810');
COMMIT;
SELECT 'ack', 2810;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2811, 27, X'76616C75652D3030303032383131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2811, 'wal', 'ack-2811');
COMMIT;
SELECT 'ack', 2811;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2812, 28, X'76616C75652D3030303032383132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2812, 'wal', 'ack-2812');
COMMIT;
SELECT 'ack', 2812;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2813, 29, X'76616C75652D3030303032383133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2813, 'wal', 'ack-2813');
COMMIT;
SELECT 'ack', 2813;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2814, 30, X'76616C75652D3030303032383134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2814, 'wal', 'ack-2814');
COMMIT;
SELECT 'ack', 2814;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2815, 31, X'76616C75652D3030303032383135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2815, 'wal', 'ack-2815');
COMMIT;
SELECT 'ack', 2815;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2816, 0, X'76616C75652D3030303032383136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2816, 'wal', 'ack-2816');
COMMIT;
SELECT 'ack', 2816;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2817, 1, X'76616C75652D3030303032383137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2817, 'wal', 'ack-2817');
COMMIT;
SELECT 'ack', 2817;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2818, 2, X'76616C75652D3030303032383138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2818, 'wal', 'ack-2818');
COMMIT;
SELECT 'ack', 2818;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2819, 3, X'76616C75652D3030303032383139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2819, 'wal', 'ack-2819');
COMMIT;
SELECT 'ack', 2819;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2820, 4, X'76616C75652D3030303032383230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2820, 'wal', 'ack-2820');
COMMIT;
SELECT 'ack', 2820;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2821, 5, X'76616C75652D3030303032383231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2821, 'wal', 'ack-2821');
COMMIT;
SELECT 'ack', 2821;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2822, 6, X'76616C75652D3030303032383232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2822, 'wal', 'ack-2822');
COMMIT;
SELECT 'ack', 2822;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2823, 7, X'76616C75652D3030303032383233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2823, 'wal', 'ack-2823');
COMMIT;
SELECT 'ack', 2823;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2824, 8, X'76616C75652D3030303032383234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2824, 'wal', 'ack-2824');
COMMIT;
SELECT 'ack', 2824;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2825, 9, X'76616C75652D3030303032383235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2825, 'wal', 'ack-2825');
COMMIT;
SELECT 'ack', 2825;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2826, 10, X'76616C75652D3030303032383236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2826, 'wal', 'ack-2826');
COMMIT;
SELECT 'ack', 2826;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2827, 11, X'76616C75652D3030303032383237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2827, 'wal', 'ack-2827');
COMMIT;
SELECT 'ack', 2827;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2828, 12, X'76616C75652D3030303032383238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2828, 'wal', 'ack-2828');
COMMIT;
SELECT 'ack', 2828;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2829, 13, X'76616C75652D3030303032383239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2829, 'wal', 'ack-2829');
COMMIT;
SELECT 'ack', 2829;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2830, 14, X'76616C75652D3030303032383330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2830, 'wal', 'ack-2830');
COMMIT;
SELECT 'ack', 2830;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2831, 15, X'76616C75652D3030303032383331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2831, 'wal', 'ack-2831');
COMMIT;
SELECT 'ack', 2831;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2832, 16, X'76616C75652D3030303032383332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2832, 'wal', 'ack-2832');
COMMIT;
SELECT 'ack', 2832;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2833, 17, X'76616C75652D3030303032383333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2833, 'wal', 'ack-2833');
COMMIT;
SELECT 'ack', 2833;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2834, 18, X'76616C75652D3030303032383334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2834, 'wal', 'ack-2834');
COMMIT;
SELECT 'ack', 2834;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2835, 19, X'76616C75652D3030303032383335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2835, 'wal', 'ack-2835');
COMMIT;
SELECT 'ack', 2835;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2836, 20, X'76616C75652D3030303032383336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2836, 'wal', 'ack-2836');
COMMIT;
SELECT 'ack', 2836;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2837, 21, X'76616C75652D3030303032383337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2837, 'wal', 'ack-2837');
COMMIT;
SELECT 'ack', 2837;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2838, 22, X'76616C75652D3030303032383338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2838, 'wal', 'ack-2838');
COMMIT;
SELECT 'ack', 2838;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2839, 23, X'76616C75652D3030303032383339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2839, 'wal', 'ack-2839');
COMMIT;
SELECT 'ack', 2839;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2840, 24, X'76616C75652D3030303032383430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2840, 'wal', 'ack-2840');
COMMIT;
SELECT 'ack', 2840;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2841, 25, X'76616C75652D3030303032383431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2841, 'wal', 'ack-2841');
COMMIT;
SELECT 'ack', 2841;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2842, 26, X'76616C75652D3030303032383432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2842, 'wal', 'ack-2842');
COMMIT;
SELECT 'ack', 2842;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2843, 27, X'76616C75652D3030303032383433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2843, 'wal', 'ack-2843');
COMMIT;
SELECT 'ack', 2843;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2844, 28, X'76616C75652D3030303032383434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2844, 'wal', 'ack-2844');
COMMIT;
SELECT 'ack', 2844;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2845, 29, X'76616C75652D3030303032383435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2845, 'wal', 'ack-2845');
COMMIT;
SELECT 'ack', 2845;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2846, 30, X'76616C75652D3030303032383436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2846, 'wal', 'ack-2846');
COMMIT;
SELECT 'ack', 2846;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2847, 31, X'76616C75652D3030303032383437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2847, 'wal', 'ack-2847');
COMMIT;
SELECT 'ack', 2847;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2848, 0, X'76616C75652D3030303032383438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2848, 'wal', 'ack-2848');
COMMIT;
SELECT 'ack', 2848;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2849, 1, X'76616C75652D3030303032383439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2849, 'wal', 'ack-2849');
COMMIT;
SELECT 'ack', 2849;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2850, 2, X'76616C75652D3030303032383530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2850, 'wal', 'ack-2850');
COMMIT;
SELECT 'ack', 2850;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2851, 3, X'76616C75652D3030303032383531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2851, 'wal', 'ack-2851');
COMMIT;
SELECT 'ack', 2851;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2852, 4, X'76616C75652D3030303032383532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2852, 'wal', 'ack-2852');
COMMIT;
SELECT 'ack', 2852;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2853, 5, X'76616C75652D3030303032383533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2853, 'wal', 'ack-2853');
COMMIT;
SELECT 'ack', 2853;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2854, 6, X'76616C75652D3030303032383534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2854, 'wal', 'ack-2854');
COMMIT;
SELECT 'ack', 2854;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2855, 7, X'76616C75652D3030303032383535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2855, 'wal', 'ack-2855');
COMMIT;
SELECT 'ack', 2855;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2856, 8, X'76616C75652D3030303032383536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2856, 'wal', 'ack-2856');
COMMIT;
SELECT 'ack', 2856;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2857, 9, X'76616C75652D3030303032383537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2857, 'wal', 'ack-2857');
COMMIT;
SELECT 'ack', 2857;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2858, 10, X'76616C75652D3030303032383538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2858, 'wal', 'ack-2858');
COMMIT;
SELECT 'ack', 2858;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2859, 11, X'76616C75652D3030303032383539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2859, 'wal', 'ack-2859');
COMMIT;
SELECT 'ack', 2859;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2860, 12, X'76616C75652D3030303032383630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2860, 'wal', 'ack-2860');
COMMIT;
SELECT 'ack', 2860;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2861, 13, X'76616C75652D3030303032383631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2861, 'wal', 'ack-2861');
COMMIT;
SELECT 'ack', 2861;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2862, 14, X'76616C75652D3030303032383632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2862, 'wal', 'ack-2862');
COMMIT;
SELECT 'ack', 2862;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2863, 15, X'76616C75652D3030303032383633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2863, 'wal', 'ack-2863');
COMMIT;
SELECT 'ack', 2863;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2864, 16, X'76616C75652D3030303032383634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2864, 'wal', 'ack-2864');
COMMIT;
SELECT 'ack', 2864;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2865, 17, X'76616C75652D3030303032383635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2865, 'wal', 'ack-2865');
COMMIT;
SELECT 'ack', 2865;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2866, 18, X'76616C75652D3030303032383636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2866, 'wal', 'ack-2866');
COMMIT;
SELECT 'ack', 2866;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2867, 19, X'76616C75652D3030303032383637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2867, 'wal', 'ack-2867');
COMMIT;
SELECT 'ack', 2867;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2868, 20, X'76616C75652D3030303032383638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2868, 'wal', 'ack-2868');
COMMIT;
SELECT 'ack', 2868;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2869, 21, X'76616C75652D3030303032383639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2869, 'wal', 'ack-2869');
COMMIT;
SELECT 'ack', 2869;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2870, 22, X'76616C75652D3030303032383730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2870, 'wal', 'ack-2870');
COMMIT;
SELECT 'ack', 2870;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2871, 23, X'76616C75652D3030303032383731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2871, 'wal', 'ack-2871');
COMMIT;
SELECT 'ack', 2871;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2872, 24, X'76616C75652D3030303032383732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2872, 'wal', 'ack-2872');
COMMIT;
SELECT 'ack', 2872;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2873, 25, X'76616C75652D3030303032383733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2873, 'wal', 'ack-2873');
COMMIT;
SELECT 'ack', 2873;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2874, 26, X'76616C75652D3030303032383734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2874, 'wal', 'ack-2874');
COMMIT;
SELECT 'ack', 2874;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2875, 27, X'76616C75652D3030303032383735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2875, 'wal', 'ack-2875');
COMMIT;
SELECT 'ack', 2875;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2876, 28, X'76616C75652D3030303032383736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2876, 'wal', 'ack-2876');
COMMIT;
SELECT 'ack', 2876;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2877, 29, X'76616C75652D3030303032383737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2877, 'wal', 'ack-2877');
COMMIT;
SELECT 'ack', 2877;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2878, 30, X'76616C75652D3030303032383738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2878, 'wal', 'ack-2878');
COMMIT;
SELECT 'ack', 2878;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2879, 31, X'76616C75652D3030303032383739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2879, 'wal', 'ack-2879');
COMMIT;
SELECT 'ack', 2879;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2880, 0, X'76616C75652D3030303032383830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2880, 'wal', 'ack-2880');
COMMIT;
SELECT 'ack', 2880;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2881, 1, X'76616C75652D3030303032383831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2881, 'wal', 'ack-2881');
COMMIT;
SELECT 'ack', 2881;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2882, 2, X'76616C75652D3030303032383832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2882, 'wal', 'ack-2882');
COMMIT;
SELECT 'ack', 2882;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2883, 3, X'76616C75652D3030303032383833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2883, 'wal', 'ack-2883');
COMMIT;
SELECT 'ack', 2883;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2884, 4, X'76616C75652D3030303032383834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2884, 'wal', 'ack-2884');
COMMIT;
SELECT 'ack', 2884;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2885, 5, X'76616C75652D3030303032383835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2885, 'wal', 'ack-2885');
COMMIT;
SELECT 'ack', 2885;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2886, 6, X'76616C75652D3030303032383836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2886, 'wal', 'ack-2886');
COMMIT;
SELECT 'ack', 2886;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2887, 7, X'76616C75652D3030303032383837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2887, 'wal', 'ack-2887');
COMMIT;
SELECT 'ack', 2887;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2888, 8, X'76616C75652D3030303032383838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2888, 'wal', 'ack-2888');
COMMIT;
SELECT 'ack', 2888;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2889, 9, X'76616C75652D3030303032383839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2889, 'wal', 'ack-2889');
COMMIT;
SELECT 'ack', 2889;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2890, 10, X'76616C75652D3030303032383930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2890, 'wal', 'ack-2890');
COMMIT;
SELECT 'ack', 2890;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2891, 11, X'76616C75652D3030303032383931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2891, 'wal', 'ack-2891');
COMMIT;
SELECT 'ack', 2891;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2892, 12, X'76616C75652D3030303032383932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2892, 'wal', 'ack-2892');
COMMIT;
SELECT 'ack', 2892;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2893, 13, X'76616C75652D3030303032383933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2893, 'wal', 'ack-2893');
COMMIT;
SELECT 'ack', 2893;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2894, 14, X'76616C75652D3030303032383934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2894, 'wal', 'ack-2894');
COMMIT;
SELECT 'ack', 2894;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2895, 15, X'76616C75652D3030303032383935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2895, 'wal', 'ack-2895');
COMMIT;
SELECT 'ack', 2895;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2896, 16, X'76616C75652D3030303032383936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2896, 'wal', 'ack-2896');
COMMIT;
SELECT 'ack', 2896;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2897, 17, X'76616C75652D3030303032383937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2897, 'wal', 'ack-2897');
COMMIT;
SELECT 'ack', 2897;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2898, 18, X'76616C75652D3030303032383938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2898, 'wal', 'ack-2898');
COMMIT;
SELECT 'ack', 2898;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2899, 19, X'76616C75652D3030303032383939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2899, 'wal', 'ack-2899');
COMMIT;
SELECT 'ack', 2899;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2900, 20, X'76616C75652D3030303032393030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2900, 'wal', 'ack-2900');
COMMIT;
SELECT 'ack', 2900;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2901, 21, X'76616C75652D3030303032393031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2901, 'wal', 'ack-2901');
COMMIT;
SELECT 'ack', 2901;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2902, 22, X'76616C75652D3030303032393032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2902, 'wal', 'ack-2902');
COMMIT;
SELECT 'ack', 2902;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2903, 23, X'76616C75652D3030303032393033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2903, 'wal', 'ack-2903');
COMMIT;
SELECT 'ack', 2903;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2904, 24, X'76616C75652D3030303032393034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2904, 'wal', 'ack-2904');
COMMIT;
SELECT 'ack', 2904;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2905, 25, X'76616C75652D3030303032393035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2905, 'wal', 'ack-2905');
COMMIT;
SELECT 'ack', 2905;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2906, 26, X'76616C75652D3030303032393036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2906, 'wal', 'ack-2906');
COMMIT;
SELECT 'ack', 2906;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2907, 27, X'76616C75652D3030303032393037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2907, 'wal', 'ack-2907');
COMMIT;
SELECT 'ack', 2907;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2908, 28, X'76616C75652D3030303032393038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2908, 'wal', 'ack-2908');
COMMIT;
SELECT 'ack', 2908;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2909, 29, X'76616C75652D3030303032393039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2909, 'wal', 'ack-2909');
COMMIT;
SELECT 'ack', 2909;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2910, 30, X'76616C75652D3030303032393130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2910, 'wal', 'ack-2910');
COMMIT;
SELECT 'ack', 2910;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2911, 31, X'76616C75652D3030303032393131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2911, 'wal', 'ack-2911');
COMMIT;
SELECT 'ack', 2911;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2912, 0, X'76616C75652D3030303032393132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2912, 'wal', 'ack-2912');
COMMIT;
SELECT 'ack', 2912;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2913, 1, X'76616C75652D3030303032393133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2913, 'wal', 'ack-2913');
COMMIT;
SELECT 'ack', 2913;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2914, 2, X'76616C75652D3030303032393134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2914, 'wal', 'ack-2914');
COMMIT;
SELECT 'ack', 2914;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2915, 3, X'76616C75652D3030303032393135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2915, 'wal', 'ack-2915');
COMMIT;
SELECT 'ack', 2915;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2916, 4, X'76616C75652D3030303032393136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2916, 'wal', 'ack-2916');
COMMIT;
SELECT 'ack', 2916;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2917, 5, X'76616C75652D3030303032393137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2917, 'wal', 'ack-2917');
COMMIT;
SELECT 'ack', 2917;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2918, 6, X'76616C75652D3030303032393138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2918, 'wal', 'ack-2918');
COMMIT;
SELECT 'ack', 2918;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2919, 7, X'76616C75652D3030303032393139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2919, 'wal', 'ack-2919');
COMMIT;
SELECT 'ack', 2919;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2920, 8, X'76616C75652D3030303032393230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2920, 'wal', 'ack-2920');
COMMIT;
SELECT 'ack', 2920;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2921, 9, X'76616C75652D3030303032393231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2921, 'wal', 'ack-2921');
COMMIT;
SELECT 'ack', 2921;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2922, 10, X'76616C75652D3030303032393232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2922, 'wal', 'ack-2922');
COMMIT;
SELECT 'ack', 2922;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2923, 11, X'76616C75652D3030303032393233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2923, 'wal', 'ack-2923');
COMMIT;
SELECT 'ack', 2923;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2924, 12, X'76616C75652D3030303032393234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2924, 'wal', 'ack-2924');
COMMIT;
SELECT 'ack', 2924;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2925, 13, X'76616C75652D3030303032393235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2925, 'wal', 'ack-2925');
COMMIT;
SELECT 'ack', 2925;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2926, 14, X'76616C75652D3030303032393236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2926, 'wal', 'ack-2926');
COMMIT;
SELECT 'ack', 2926;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2927, 15, X'76616C75652D3030303032393237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2927, 'wal', 'ack-2927');
COMMIT;
SELECT 'ack', 2927;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2928, 16, X'76616C75652D3030303032393238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2928, 'wal', 'ack-2928');
COMMIT;
SELECT 'ack', 2928;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2929, 17, X'76616C75652D3030303032393239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2929, 'wal', 'ack-2929');
COMMIT;
SELECT 'ack', 2929;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2930, 18, X'76616C75652D3030303032393330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2930, 'wal', 'ack-2930');
COMMIT;
SELECT 'ack', 2930;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2931, 19, X'76616C75652D3030303032393331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2931, 'wal', 'ack-2931');
COMMIT;
SELECT 'ack', 2931;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2932, 20, X'76616C75652D3030303032393332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2932, 'wal', 'ack-2932');
COMMIT;
SELECT 'ack', 2932;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2933, 21, X'76616C75652D3030303032393333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2933, 'wal', 'ack-2933');
COMMIT;
SELECT 'ack', 2933;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2934, 22, X'76616C75652D3030303032393334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2934, 'wal', 'ack-2934');
COMMIT;
SELECT 'ack', 2934;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2935, 23, X'76616C75652D3030303032393335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2935, 'wal', 'ack-2935');
COMMIT;
SELECT 'ack', 2935;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2936, 24, X'76616C75652D3030303032393336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2936, 'wal', 'ack-2936');
COMMIT;
SELECT 'ack', 2936;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2937, 25, X'76616C75652D3030303032393337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2937, 'wal', 'ack-2937');
COMMIT;
SELECT 'ack', 2937;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2938, 26, X'76616C75652D3030303032393338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2938, 'wal', 'ack-2938');
COMMIT;
SELECT 'ack', 2938;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2939, 27, X'76616C75652D3030303032393339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2939, 'wal', 'ack-2939');
COMMIT;
SELECT 'ack', 2939;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2940, 28, X'76616C75652D3030303032393430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2940, 'wal', 'ack-2940');
COMMIT;
SELECT 'ack', 2940;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2941, 29, X'76616C75652D3030303032393431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2941, 'wal', 'ack-2941');
COMMIT;
SELECT 'ack', 2941;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2942, 30, X'76616C75652D3030303032393432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2942, 'wal', 'ack-2942');
COMMIT;
SELECT 'ack', 2942;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2943, 31, X'76616C75652D3030303032393433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2943, 'wal', 'ack-2943');
COMMIT;
SELECT 'ack', 2943;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2944, 0, X'76616C75652D3030303032393434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2944, 'wal', 'ack-2944');
COMMIT;
SELECT 'ack', 2944;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2945, 1, X'76616C75652D3030303032393435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2945, 'wal', 'ack-2945');
COMMIT;
SELECT 'ack', 2945;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2946, 2, X'76616C75652D3030303032393436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2946, 'wal', 'ack-2946');
COMMIT;
SELECT 'ack', 2946;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2947, 3, X'76616C75652D3030303032393437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2947, 'wal', 'ack-2947');
COMMIT;
SELECT 'ack', 2947;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2948, 4, X'76616C75652D3030303032393438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2948, 'wal', 'ack-2948');
COMMIT;
SELECT 'ack', 2948;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2949, 5, X'76616C75652D3030303032393439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2949, 'wal', 'ack-2949');
COMMIT;
SELECT 'ack', 2949;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2950, 6, X'76616C75652D3030303032393530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2950, 'wal', 'ack-2950');
COMMIT;
SELECT 'ack', 2950;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2951, 7, X'76616C75652D3030303032393531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2951, 'wal', 'ack-2951');
COMMIT;
SELECT 'ack', 2951;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2952, 8, X'76616C75652D3030303032393532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2952, 'wal', 'ack-2952');
COMMIT;
SELECT 'ack', 2952;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2953, 9, X'76616C75652D3030303032393533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2953, 'wal', 'ack-2953');
COMMIT;
SELECT 'ack', 2953;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2954, 10, X'76616C75652D3030303032393534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2954, 'wal', 'ack-2954');
COMMIT;
SELECT 'ack', 2954;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2955, 11, X'76616C75652D3030303032393535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2955, 'wal', 'ack-2955');
COMMIT;
SELECT 'ack', 2955;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2956, 12, X'76616C75652D3030303032393536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2956, 'wal', 'ack-2956');
COMMIT;
SELECT 'ack', 2956;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2957, 13, X'76616C75652D3030303032393537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2957, 'wal', 'ack-2957');
COMMIT;
SELECT 'ack', 2957;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2958, 14, X'76616C75652D3030303032393538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2958, 'wal', 'ack-2958');
COMMIT;
SELECT 'ack', 2958;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2959, 15, X'76616C75652D3030303032393539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2959, 'wal', 'ack-2959');
COMMIT;
SELECT 'ack', 2959;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2960, 16, X'76616C75652D3030303032393630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2960, 'wal', 'ack-2960');
COMMIT;
SELECT 'ack', 2960;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2961, 17, X'76616C75652D3030303032393631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2961, 'wal', 'ack-2961');
COMMIT;
SELECT 'ack', 2961;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2962, 18, X'76616C75652D3030303032393632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2962, 'wal', 'ack-2962');
COMMIT;
SELECT 'ack', 2962;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2963, 19, X'76616C75652D3030303032393633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2963, 'wal', 'ack-2963');
COMMIT;
SELECT 'ack', 2963;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2964, 20, X'76616C75652D3030303032393634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2964, 'wal', 'ack-2964');
COMMIT;
SELECT 'ack', 2964;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2965, 21, X'76616C75652D3030303032393635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2965, 'wal', 'ack-2965');
COMMIT;
SELECT 'ack', 2965;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2966, 22, X'76616C75652D3030303032393636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2966, 'wal', 'ack-2966');
COMMIT;
SELECT 'ack', 2966;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2967, 23, X'76616C75652D3030303032393637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2967, 'wal', 'ack-2967');
COMMIT;
SELECT 'ack', 2967;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2968, 24, X'76616C75652D3030303032393638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2968, 'wal', 'ack-2968');
COMMIT;
SELECT 'ack', 2968;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2969, 25, X'76616C75652D3030303032393639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2969, 'wal', 'ack-2969');
COMMIT;
SELECT 'ack', 2969;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2970, 26, X'76616C75652D3030303032393730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2970, 'wal', 'ack-2970');
COMMIT;
SELECT 'ack', 2970;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2971, 27, X'76616C75652D3030303032393731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2971, 'wal', 'ack-2971');
COMMIT;
SELECT 'ack', 2971;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2972, 28, X'76616C75652D3030303032393732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2972, 'wal', 'ack-2972');
COMMIT;
SELECT 'ack', 2972;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2973, 29, X'76616C75652D3030303032393733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2973, 'wal', 'ack-2973');
COMMIT;
SELECT 'ack', 2973;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2974, 30, X'76616C75652D3030303032393734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2974, 'wal', 'ack-2974');
COMMIT;
SELECT 'ack', 2974;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2975, 31, X'76616C75652D3030303032393735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2975, 'wal', 'ack-2975');
COMMIT;
SELECT 'ack', 2975;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2976, 0, X'76616C75652D3030303032393736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2976, 'wal', 'ack-2976');
COMMIT;
SELECT 'ack', 2976;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2977, 1, X'76616C75652D3030303032393737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2977, 'wal', 'ack-2977');
COMMIT;
SELECT 'ack', 2977;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2978, 2, X'76616C75652D3030303032393738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2978, 'wal', 'ack-2978');
COMMIT;
SELECT 'ack', 2978;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2979, 3, X'76616C75652D3030303032393739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2979, 'wal', 'ack-2979');
COMMIT;
SELECT 'ack', 2979;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2980, 4, X'76616C75652D3030303032393830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2980, 'wal', 'ack-2980');
COMMIT;
SELECT 'ack', 2980;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2981, 5, X'76616C75652D3030303032393831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2981, 'wal', 'ack-2981');
COMMIT;
SELECT 'ack', 2981;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2982, 6, X'76616C75652D3030303032393832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2982, 'wal', 'ack-2982');
COMMIT;
SELECT 'ack', 2982;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2983, 7, X'76616C75652D3030303032393833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2983, 'wal', 'ack-2983');
COMMIT;
SELECT 'ack', 2983;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2984, 8, X'76616C75652D3030303032393834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2984, 'wal', 'ack-2984');
COMMIT;
SELECT 'ack', 2984;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2985, 9, X'76616C75652D3030303032393835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2985, 'wal', 'ack-2985');
COMMIT;
SELECT 'ack', 2985;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2986, 10, X'76616C75652D3030303032393836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2986, 'wal', 'ack-2986');
COMMIT;
SELECT 'ack', 2986;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2987, 11, X'76616C75652D3030303032393837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2987, 'wal', 'ack-2987');
COMMIT;
SELECT 'ack', 2987;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2988, 12, X'76616C75652D3030303032393838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2988, 'wal', 'ack-2988');
COMMIT;
SELECT 'ack', 2988;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2989, 13, X'76616C75652D3030303032393839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2989, 'wal', 'ack-2989');
COMMIT;
SELECT 'ack', 2989;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2990, 14, X'76616C75652D3030303032393930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2990, 'wal', 'ack-2990');
COMMIT;
SELECT 'ack', 2990;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2991, 15, X'76616C75652D3030303032393931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2991, 'wal', 'ack-2991');
COMMIT;
SELECT 'ack', 2991;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2992, 16, X'76616C75652D3030303032393932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2992, 'wal', 'ack-2992');
COMMIT;
SELECT 'ack', 2992;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2993, 17, X'76616C75652D3030303032393933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2993, 'wal', 'ack-2993');
COMMIT;
SELECT 'ack', 2993;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2994, 18, X'76616C75652D3030303032393934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2994, 'wal', 'ack-2994');
COMMIT;
SELECT 'ack', 2994;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2995, 19, X'76616C75652D3030303032393935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2995, 'wal', 'ack-2995');
COMMIT;
SELECT 'ack', 2995;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2996, 20, X'76616C75652D3030303032393936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2996, 'wal', 'ack-2996');
COMMIT;
SELECT 'ack', 2996;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2997, 21, X'76616C75652D3030303032393937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2997, 'wal', 'ack-2997');
COMMIT;
SELECT 'ack', 2997;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2998, 22, X'76616C75652D3030303032393938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2998, 'wal', 'ack-2998');
COMMIT;
SELECT 'ack', 2998;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (2999, 23, X'76616C75652D3030303032393939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (2999, 'wal', 'ack-2999');
COMMIT;
SELECT 'ack', 2999;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3000, 24, X'76616C75652D3030303033303030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3000, 'wal', 'ack-3000');
COMMIT;
SELECT 'ack', 3000;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3001, 25, X'76616C75652D3030303033303031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3001, 'wal', 'ack-3001');
COMMIT;
SELECT 'ack', 3001;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3002, 26, X'76616C75652D3030303033303032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3002, 'wal', 'ack-3002');
COMMIT;
SELECT 'ack', 3002;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3003, 27, X'76616C75652D3030303033303033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3003, 'wal', 'ack-3003');
COMMIT;
SELECT 'ack', 3003;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3004, 28, X'76616C75652D3030303033303034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3004, 'wal', 'ack-3004');
COMMIT;
SELECT 'ack', 3004;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3005, 29, X'76616C75652D3030303033303035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3005, 'wal', 'ack-3005');
COMMIT;
SELECT 'ack', 3005;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3006, 30, X'76616C75652D3030303033303036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3006, 'wal', 'ack-3006');
COMMIT;
SELECT 'ack', 3006;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3007, 31, X'76616C75652D3030303033303037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3007, 'wal', 'ack-3007');
COMMIT;
SELECT 'ack', 3007;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3008, 0, X'76616C75652D3030303033303038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3008, 'wal', 'ack-3008');
COMMIT;
SELECT 'ack', 3008;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3009, 1, X'76616C75652D3030303033303039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3009, 'wal', 'ack-3009');
COMMIT;
SELECT 'ack', 3009;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3010, 2, X'76616C75652D3030303033303130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3010, 'wal', 'ack-3010');
COMMIT;
SELECT 'ack', 3010;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3011, 3, X'76616C75652D3030303033303131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3011, 'wal', 'ack-3011');
COMMIT;
SELECT 'ack', 3011;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3012, 4, X'76616C75652D3030303033303132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3012, 'wal', 'ack-3012');
COMMIT;
SELECT 'ack', 3012;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3013, 5, X'76616C75652D3030303033303133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3013, 'wal', 'ack-3013');
COMMIT;
SELECT 'ack', 3013;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3014, 6, X'76616C75652D3030303033303134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3014, 'wal', 'ack-3014');
COMMIT;
SELECT 'ack', 3014;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3015, 7, X'76616C75652D3030303033303135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3015, 'wal', 'ack-3015');
COMMIT;
SELECT 'ack', 3015;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3016, 8, X'76616C75652D3030303033303136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3016, 'wal', 'ack-3016');
COMMIT;
SELECT 'ack', 3016;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3017, 9, X'76616C75652D3030303033303137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3017, 'wal', 'ack-3017');
COMMIT;
SELECT 'ack', 3017;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3018, 10, X'76616C75652D3030303033303138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3018, 'wal', 'ack-3018');
COMMIT;
SELECT 'ack', 3018;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3019, 11, X'76616C75652D3030303033303139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3019, 'wal', 'ack-3019');
COMMIT;
SELECT 'ack', 3019;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3020, 12, X'76616C75652D3030303033303230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3020, 'wal', 'ack-3020');
COMMIT;
SELECT 'ack', 3020;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3021, 13, X'76616C75652D3030303033303231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3021, 'wal', 'ack-3021');
COMMIT;
SELECT 'ack', 3021;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3022, 14, X'76616C75652D3030303033303232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3022, 'wal', 'ack-3022');
COMMIT;
SELECT 'ack', 3022;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3023, 15, X'76616C75652D3030303033303233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3023, 'wal', 'ack-3023');
COMMIT;
SELECT 'ack', 3023;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3024, 16, X'76616C75652D3030303033303234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3024, 'wal', 'ack-3024');
COMMIT;
SELECT 'ack', 3024;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3025, 17, X'76616C75652D3030303033303235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3025, 'wal', 'ack-3025');
COMMIT;
SELECT 'ack', 3025;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3026, 18, X'76616C75652D3030303033303236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3026, 'wal', 'ack-3026');
COMMIT;
SELECT 'ack', 3026;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3027, 19, X'76616C75652D3030303033303237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3027, 'wal', 'ack-3027');
COMMIT;
SELECT 'ack', 3027;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3028, 20, X'76616C75652D3030303033303238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3028, 'wal', 'ack-3028');
COMMIT;
SELECT 'ack', 3028;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3029, 21, X'76616C75652D3030303033303239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3029, 'wal', 'ack-3029');
COMMIT;
SELECT 'ack', 3029;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3030, 22, X'76616C75652D3030303033303330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3030, 'wal', 'ack-3030');
COMMIT;
SELECT 'ack', 3030;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3031, 23, X'76616C75652D3030303033303331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3031, 'wal', 'ack-3031');
COMMIT;
SELECT 'ack', 3031;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3032, 24, X'76616C75652D3030303033303332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3032, 'wal', 'ack-3032');
COMMIT;
SELECT 'ack', 3032;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3033, 25, X'76616C75652D3030303033303333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3033, 'wal', 'ack-3033');
COMMIT;
SELECT 'ack', 3033;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3034, 26, X'76616C75652D3030303033303334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3034, 'wal', 'ack-3034');
COMMIT;
SELECT 'ack', 3034;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3035, 27, X'76616C75652D3030303033303335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3035, 'wal', 'ack-3035');
COMMIT;
SELECT 'ack', 3035;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3036, 28, X'76616C75652D3030303033303336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3036, 'wal', 'ack-3036');
COMMIT;
SELECT 'ack', 3036;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3037, 29, X'76616C75652D3030303033303337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3037, 'wal', 'ack-3037');
COMMIT;
SELECT 'ack', 3037;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3038, 30, X'76616C75652D3030303033303338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3038, 'wal', 'ack-3038');
COMMIT;
SELECT 'ack', 3038;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3039, 31, X'76616C75652D3030303033303339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3039, 'wal', 'ack-3039');
COMMIT;
SELECT 'ack', 3039;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3040, 0, X'76616C75652D3030303033303430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3040, 'wal', 'ack-3040');
COMMIT;
SELECT 'ack', 3040;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3041, 1, X'76616C75652D3030303033303431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3041, 'wal', 'ack-3041');
COMMIT;
SELECT 'ack', 3041;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3042, 2, X'76616C75652D3030303033303432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3042, 'wal', 'ack-3042');
COMMIT;
SELECT 'ack', 3042;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3043, 3, X'76616C75652D3030303033303433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3043, 'wal', 'ack-3043');
COMMIT;
SELECT 'ack', 3043;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3044, 4, X'76616C75652D3030303033303434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3044, 'wal', 'ack-3044');
COMMIT;
SELECT 'ack', 3044;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3045, 5, X'76616C75652D3030303033303435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3045, 'wal', 'ack-3045');
COMMIT;
SELECT 'ack', 3045;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3046, 6, X'76616C75652D3030303033303436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3046, 'wal', 'ack-3046');
COMMIT;
SELECT 'ack', 3046;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3047, 7, X'76616C75652D3030303033303437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3047, 'wal', 'ack-3047');
COMMIT;
SELECT 'ack', 3047;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3048, 8, X'76616C75652D3030303033303438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3048, 'wal', 'ack-3048');
COMMIT;
SELECT 'ack', 3048;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3049, 9, X'76616C75652D3030303033303439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3049, 'wal', 'ack-3049');
COMMIT;
SELECT 'ack', 3049;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3050, 10, X'76616C75652D3030303033303530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3050, 'wal', 'ack-3050');
COMMIT;
SELECT 'ack', 3050;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3051, 11, X'76616C75652D3030303033303531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3051, 'wal', 'ack-3051');
COMMIT;
SELECT 'ack', 3051;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3052, 12, X'76616C75652D3030303033303532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3052, 'wal', 'ack-3052');
COMMIT;
SELECT 'ack', 3052;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3053, 13, X'76616C75652D3030303033303533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3053, 'wal', 'ack-3053');
COMMIT;
SELECT 'ack', 3053;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3054, 14, X'76616C75652D3030303033303534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3054, 'wal', 'ack-3054');
COMMIT;
SELECT 'ack', 3054;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3055, 15, X'76616C75652D3030303033303535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3055, 'wal', 'ack-3055');
COMMIT;
SELECT 'ack', 3055;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3056, 16, X'76616C75652D3030303033303536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3056, 'wal', 'ack-3056');
COMMIT;
SELECT 'ack', 3056;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3057, 17, X'76616C75652D3030303033303537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3057, 'wal', 'ack-3057');
COMMIT;
SELECT 'ack', 3057;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3058, 18, X'76616C75652D3030303033303538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3058, 'wal', 'ack-3058');
COMMIT;
SELECT 'ack', 3058;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3059, 19, X'76616C75652D3030303033303539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3059, 'wal', 'ack-3059');
COMMIT;
SELECT 'ack', 3059;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3060, 20, X'76616C75652D3030303033303630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3060, 'wal', 'ack-3060');
COMMIT;
SELECT 'ack', 3060;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3061, 21, X'76616C75652D3030303033303631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3061, 'wal', 'ack-3061');
COMMIT;
SELECT 'ack', 3061;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3062, 22, X'76616C75652D3030303033303632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3062, 'wal', 'ack-3062');
COMMIT;
SELECT 'ack', 3062;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3063, 23, X'76616C75652D3030303033303633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3063, 'wal', 'ack-3063');
COMMIT;
SELECT 'ack', 3063;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3064, 24, X'76616C75652D3030303033303634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3064, 'wal', 'ack-3064');
COMMIT;
SELECT 'ack', 3064;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3065, 25, X'76616C75652D3030303033303635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3065, 'wal', 'ack-3065');
COMMIT;
SELECT 'ack', 3065;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3066, 26, X'76616C75652D3030303033303636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3066, 'wal', 'ack-3066');
COMMIT;
SELECT 'ack', 3066;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3067, 27, X'76616C75652D3030303033303637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3067, 'wal', 'ack-3067');
COMMIT;
SELECT 'ack', 3067;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3068, 28, X'76616C75652D3030303033303638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3068, 'wal', 'ack-3068');
COMMIT;
SELECT 'ack', 3068;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3069, 29, X'76616C75652D3030303033303639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3069, 'wal', 'ack-3069');
COMMIT;
SELECT 'ack', 3069;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3070, 30, X'76616C75652D3030303033303730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3070, 'wal', 'ack-3070');
COMMIT;
SELECT 'ack', 3070;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3071, 31, X'76616C75652D3030303033303731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3071, 'wal', 'ack-3071');
COMMIT;
SELECT 'ack', 3071;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3072, 0, X'76616C75652D3030303033303732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3072, 'wal', 'ack-3072');
COMMIT;
SELECT 'ack', 3072;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3073, 1, X'76616C75652D3030303033303733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3073, 'wal', 'ack-3073');
COMMIT;
SELECT 'ack', 3073;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3074, 2, X'76616C75652D3030303033303734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3074, 'wal', 'ack-3074');
COMMIT;
SELECT 'ack', 3074;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3075, 3, X'76616C75652D3030303033303735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3075, 'wal', 'ack-3075');
COMMIT;
SELECT 'ack', 3075;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3076, 4, X'76616C75652D3030303033303736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3076, 'wal', 'ack-3076');
COMMIT;
SELECT 'ack', 3076;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3077, 5, X'76616C75652D3030303033303737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3077, 'wal', 'ack-3077');
COMMIT;
SELECT 'ack', 3077;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3078, 6, X'76616C75652D3030303033303738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3078, 'wal', 'ack-3078');
COMMIT;
SELECT 'ack', 3078;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3079, 7, X'76616C75652D3030303033303739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3079, 'wal', 'ack-3079');
COMMIT;
SELECT 'ack', 3079;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3080, 8, X'76616C75652D3030303033303830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3080, 'wal', 'ack-3080');
COMMIT;
SELECT 'ack', 3080;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3081, 9, X'76616C75652D3030303033303831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3081, 'wal', 'ack-3081');
COMMIT;
SELECT 'ack', 3081;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3082, 10, X'76616C75652D3030303033303832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3082, 'wal', 'ack-3082');
COMMIT;
SELECT 'ack', 3082;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3083, 11, X'76616C75652D3030303033303833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3083, 'wal', 'ack-3083');
COMMIT;
SELECT 'ack', 3083;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3084, 12, X'76616C75652D3030303033303834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3084, 'wal', 'ack-3084');
COMMIT;
SELECT 'ack', 3084;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3085, 13, X'76616C75652D3030303033303835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3085, 'wal', 'ack-3085');
COMMIT;
SELECT 'ack', 3085;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3086, 14, X'76616C75652D3030303033303836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3086, 'wal', 'ack-3086');
COMMIT;
SELECT 'ack', 3086;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3087, 15, X'76616C75652D3030303033303837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3087, 'wal', 'ack-3087');
COMMIT;
SELECT 'ack', 3087;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3088, 16, X'76616C75652D3030303033303838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3088, 'wal', 'ack-3088');
COMMIT;
SELECT 'ack', 3088;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3089, 17, X'76616C75652D3030303033303839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3089, 'wal', 'ack-3089');
COMMIT;
SELECT 'ack', 3089;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3090, 18, X'76616C75652D3030303033303930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3090, 'wal', 'ack-3090');
COMMIT;
SELECT 'ack', 3090;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3091, 19, X'76616C75652D3030303033303931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3091, 'wal', 'ack-3091');
COMMIT;
SELECT 'ack', 3091;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3092, 20, X'76616C75652D3030303033303932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3092, 'wal', 'ack-3092');
COMMIT;
SELECT 'ack', 3092;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3093, 21, X'76616C75652D3030303033303933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3093, 'wal', 'ack-3093');
COMMIT;
SELECT 'ack', 3093;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3094, 22, X'76616C75652D3030303033303934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3094, 'wal', 'ack-3094');
COMMIT;
SELECT 'ack', 3094;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3095, 23, X'76616C75652D3030303033303935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3095, 'wal', 'ack-3095');
COMMIT;
SELECT 'ack', 3095;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3096, 24, X'76616C75652D3030303033303936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3096, 'wal', 'ack-3096');
COMMIT;
SELECT 'ack', 3096;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3097, 25, X'76616C75652D3030303033303937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3097, 'wal', 'ack-3097');
COMMIT;
SELECT 'ack', 3097;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3098, 26, X'76616C75652D3030303033303938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3098, 'wal', 'ack-3098');
COMMIT;
SELECT 'ack', 3098;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3099, 27, X'76616C75652D3030303033303939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3099, 'wal', 'ack-3099');
COMMIT;
SELECT 'ack', 3099;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3100, 28, X'76616C75652D3030303033313030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3100, 'wal', 'ack-3100');
COMMIT;
SELECT 'ack', 3100;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3101, 29, X'76616C75652D3030303033313031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3101, 'wal', 'ack-3101');
COMMIT;
SELECT 'ack', 3101;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3102, 30, X'76616C75652D3030303033313032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3102, 'wal', 'ack-3102');
COMMIT;
SELECT 'ack', 3102;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3103, 31, X'76616C75652D3030303033313033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3103, 'wal', 'ack-3103');
COMMIT;
SELECT 'ack', 3103;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3104, 0, X'76616C75652D3030303033313034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3104, 'wal', 'ack-3104');
COMMIT;
SELECT 'ack', 3104;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3105, 1, X'76616C75652D3030303033313035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3105, 'wal', 'ack-3105');
COMMIT;
SELECT 'ack', 3105;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3106, 2, X'76616C75652D3030303033313036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3106, 'wal', 'ack-3106');
COMMIT;
SELECT 'ack', 3106;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3107, 3, X'76616C75652D3030303033313037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3107, 'wal', 'ack-3107');
COMMIT;
SELECT 'ack', 3107;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3108, 4, X'76616C75652D3030303033313038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3108, 'wal', 'ack-3108');
COMMIT;
SELECT 'ack', 3108;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3109, 5, X'76616C75652D3030303033313039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3109, 'wal', 'ack-3109');
COMMIT;
SELECT 'ack', 3109;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3110, 6, X'76616C75652D3030303033313130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3110, 'wal', 'ack-3110');
COMMIT;
SELECT 'ack', 3110;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3111, 7, X'76616C75652D3030303033313131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3111, 'wal', 'ack-3111');
COMMIT;
SELECT 'ack', 3111;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3112, 8, X'76616C75652D3030303033313132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3112, 'wal', 'ack-3112');
COMMIT;
SELECT 'ack', 3112;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3113, 9, X'76616C75652D3030303033313133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3113, 'wal', 'ack-3113');
COMMIT;
SELECT 'ack', 3113;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3114, 10, X'76616C75652D3030303033313134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3114, 'wal', 'ack-3114');
COMMIT;
SELECT 'ack', 3114;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3115, 11, X'76616C75652D3030303033313135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3115, 'wal', 'ack-3115');
COMMIT;
SELECT 'ack', 3115;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3116, 12, X'76616C75652D3030303033313136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3116, 'wal', 'ack-3116');
COMMIT;
SELECT 'ack', 3116;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3117, 13, X'76616C75652D3030303033313137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3117, 'wal', 'ack-3117');
COMMIT;
SELECT 'ack', 3117;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3118, 14, X'76616C75652D3030303033313138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3118, 'wal', 'ack-3118');
COMMIT;
SELECT 'ack', 3118;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3119, 15, X'76616C75652D3030303033313139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3119, 'wal', 'ack-3119');
COMMIT;
SELECT 'ack', 3119;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3120, 16, X'76616C75652D3030303033313230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3120, 'wal', 'ack-3120');
COMMIT;
SELECT 'ack', 3120;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3121, 17, X'76616C75652D3030303033313231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3121, 'wal', 'ack-3121');
COMMIT;
SELECT 'ack', 3121;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3122, 18, X'76616C75652D3030303033313232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3122, 'wal', 'ack-3122');
COMMIT;
SELECT 'ack', 3122;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3123, 19, X'76616C75652D3030303033313233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3123, 'wal', 'ack-3123');
COMMIT;
SELECT 'ack', 3123;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3124, 20, X'76616C75652D3030303033313234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3124, 'wal', 'ack-3124');
COMMIT;
SELECT 'ack', 3124;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3125, 21, X'76616C75652D3030303033313235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3125, 'wal', 'ack-3125');
COMMIT;
SELECT 'ack', 3125;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3126, 22, X'76616C75652D3030303033313236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3126, 'wal', 'ack-3126');
COMMIT;
SELECT 'ack', 3126;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3127, 23, X'76616C75652D3030303033313237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3127, 'wal', 'ack-3127');
COMMIT;
SELECT 'ack', 3127;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3128, 24, X'76616C75652D3030303033313238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3128, 'wal', 'ack-3128');
COMMIT;
SELECT 'ack', 3128;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3129, 25, X'76616C75652D3030303033313239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3129, 'wal', 'ack-3129');
COMMIT;
SELECT 'ack', 3129;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3130, 26, X'76616C75652D3030303033313330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3130, 'wal', 'ack-3130');
COMMIT;
SELECT 'ack', 3130;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3131, 27, X'76616C75652D3030303033313331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3131, 'wal', 'ack-3131');
COMMIT;
SELECT 'ack', 3131;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3132, 28, X'76616C75652D3030303033313332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3132, 'wal', 'ack-3132');
COMMIT;
SELECT 'ack', 3132;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3133, 29, X'76616C75652D3030303033313333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3133, 'wal', 'ack-3133');
COMMIT;
SELECT 'ack', 3133;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3134, 30, X'76616C75652D3030303033313334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3134, 'wal', 'ack-3134');
COMMIT;
SELECT 'ack', 3134;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3135, 31, X'76616C75652D3030303033313335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3135, 'wal', 'ack-3135');
COMMIT;
SELECT 'ack', 3135;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3136, 0, X'76616C75652D3030303033313336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3136, 'wal', 'ack-3136');
COMMIT;
SELECT 'ack', 3136;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3137, 1, X'76616C75652D3030303033313337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3137, 'wal', 'ack-3137');
COMMIT;
SELECT 'ack', 3137;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3138, 2, X'76616C75652D3030303033313338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3138, 'wal', 'ack-3138');
COMMIT;
SELECT 'ack', 3138;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3139, 3, X'76616C75652D3030303033313339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3139, 'wal', 'ack-3139');
COMMIT;
SELECT 'ack', 3139;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3140, 4, X'76616C75652D3030303033313430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3140, 'wal', 'ack-3140');
COMMIT;
SELECT 'ack', 3140;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3141, 5, X'76616C75652D3030303033313431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3141, 'wal', 'ack-3141');
COMMIT;
SELECT 'ack', 3141;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3142, 6, X'76616C75652D3030303033313432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3142, 'wal', 'ack-3142');
COMMIT;
SELECT 'ack', 3142;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3143, 7, X'76616C75652D3030303033313433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3143, 'wal', 'ack-3143');
COMMIT;
SELECT 'ack', 3143;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3144, 8, X'76616C75652D3030303033313434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3144, 'wal', 'ack-3144');
COMMIT;
SELECT 'ack', 3144;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3145, 9, X'76616C75652D3030303033313435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3145, 'wal', 'ack-3145');
COMMIT;
SELECT 'ack', 3145;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3146, 10, X'76616C75652D3030303033313436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3146, 'wal', 'ack-3146');
COMMIT;
SELECT 'ack', 3146;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3147, 11, X'76616C75652D3030303033313437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3147, 'wal', 'ack-3147');
COMMIT;
SELECT 'ack', 3147;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3148, 12, X'76616C75652D3030303033313438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3148, 'wal', 'ack-3148');
COMMIT;
SELECT 'ack', 3148;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3149, 13, X'76616C75652D3030303033313439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3149, 'wal', 'ack-3149');
COMMIT;
SELECT 'ack', 3149;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3150, 14, X'76616C75652D3030303033313530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3150, 'wal', 'ack-3150');
COMMIT;
SELECT 'ack', 3150;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3151, 15, X'76616C75652D3030303033313531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3151, 'wal', 'ack-3151');
COMMIT;
SELECT 'ack', 3151;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3152, 16, X'76616C75652D3030303033313532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3152, 'wal', 'ack-3152');
COMMIT;
SELECT 'ack', 3152;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3153, 17, X'76616C75652D3030303033313533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3153, 'wal', 'ack-3153');
COMMIT;
SELECT 'ack', 3153;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3154, 18, X'76616C75652D3030303033313534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3154, 'wal', 'ack-3154');
COMMIT;
SELECT 'ack', 3154;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3155, 19, X'76616C75652D3030303033313535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3155, 'wal', 'ack-3155');
COMMIT;
SELECT 'ack', 3155;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3156, 20, X'76616C75652D3030303033313536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3156, 'wal', 'ack-3156');
COMMIT;
SELECT 'ack', 3156;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3157, 21, X'76616C75652D3030303033313537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3157, 'wal', 'ack-3157');
COMMIT;
SELECT 'ack', 3157;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3158, 22, X'76616C75652D3030303033313538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3158, 'wal', 'ack-3158');
COMMIT;
SELECT 'ack', 3158;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3159, 23, X'76616C75652D3030303033313539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3159, 'wal', 'ack-3159');
COMMIT;
SELECT 'ack', 3159;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3160, 24, X'76616C75652D3030303033313630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3160, 'wal', 'ack-3160');
COMMIT;
SELECT 'ack', 3160;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3161, 25, X'76616C75652D3030303033313631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3161, 'wal', 'ack-3161');
COMMIT;
SELECT 'ack', 3161;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3162, 26, X'76616C75652D3030303033313632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3162, 'wal', 'ack-3162');
COMMIT;
SELECT 'ack', 3162;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3163, 27, X'76616C75652D3030303033313633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3163, 'wal', 'ack-3163');
COMMIT;
SELECT 'ack', 3163;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3164, 28, X'76616C75652D3030303033313634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3164, 'wal', 'ack-3164');
COMMIT;
SELECT 'ack', 3164;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3165, 29, X'76616C75652D3030303033313635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3165, 'wal', 'ack-3165');
COMMIT;
SELECT 'ack', 3165;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3166, 30, X'76616C75652D3030303033313636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3166, 'wal', 'ack-3166');
COMMIT;
SELECT 'ack', 3166;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3167, 31, X'76616C75652D3030303033313637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3167, 'wal', 'ack-3167');
COMMIT;
SELECT 'ack', 3167;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3168, 0, X'76616C75652D3030303033313638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3168, 'wal', 'ack-3168');
COMMIT;
SELECT 'ack', 3168;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3169, 1, X'76616C75652D3030303033313639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3169, 'wal', 'ack-3169');
COMMIT;
SELECT 'ack', 3169;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3170, 2, X'76616C75652D3030303033313730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3170, 'wal', 'ack-3170');
COMMIT;
SELECT 'ack', 3170;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3171, 3, X'76616C75652D3030303033313731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3171, 'wal', 'ack-3171');
COMMIT;
SELECT 'ack', 3171;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3172, 4, X'76616C75652D3030303033313732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3172, 'wal', 'ack-3172');
COMMIT;
SELECT 'ack', 3172;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3173, 5, X'76616C75652D3030303033313733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3173, 'wal', 'ack-3173');
COMMIT;
SELECT 'ack', 3173;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3174, 6, X'76616C75652D3030303033313734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3174, 'wal', 'ack-3174');
COMMIT;
SELECT 'ack', 3174;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3175, 7, X'76616C75652D3030303033313735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3175, 'wal', 'ack-3175');
COMMIT;
SELECT 'ack', 3175;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3176, 8, X'76616C75652D3030303033313736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3176, 'wal', 'ack-3176');
COMMIT;
SELECT 'ack', 3176;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3177, 9, X'76616C75652D3030303033313737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3177, 'wal', 'ack-3177');
COMMIT;
SELECT 'ack', 3177;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3178, 10, X'76616C75652D3030303033313738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3178, 'wal', 'ack-3178');
COMMIT;
SELECT 'ack', 3178;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3179, 11, X'76616C75652D3030303033313739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3179, 'wal', 'ack-3179');
COMMIT;
SELECT 'ack', 3179;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3180, 12, X'76616C75652D3030303033313830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3180, 'wal', 'ack-3180');
COMMIT;
SELECT 'ack', 3180;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3181, 13, X'76616C75652D3030303033313831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3181, 'wal', 'ack-3181');
COMMIT;
SELECT 'ack', 3181;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3182, 14, X'76616C75652D3030303033313832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3182, 'wal', 'ack-3182');
COMMIT;
SELECT 'ack', 3182;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3183, 15, X'76616C75652D3030303033313833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3183, 'wal', 'ack-3183');
COMMIT;
SELECT 'ack', 3183;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3184, 16, X'76616C75652D3030303033313834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3184, 'wal', 'ack-3184');
COMMIT;
SELECT 'ack', 3184;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3185, 17, X'76616C75652D3030303033313835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3185, 'wal', 'ack-3185');
COMMIT;
SELECT 'ack', 3185;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3186, 18, X'76616C75652D3030303033313836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3186, 'wal', 'ack-3186');
COMMIT;
SELECT 'ack', 3186;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3187, 19, X'76616C75652D3030303033313837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3187, 'wal', 'ack-3187');
COMMIT;
SELECT 'ack', 3187;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3188, 20, X'76616C75652D3030303033313838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3188, 'wal', 'ack-3188');
COMMIT;
SELECT 'ack', 3188;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3189, 21, X'76616C75652D3030303033313839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3189, 'wal', 'ack-3189');
COMMIT;
SELECT 'ack', 3189;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3190, 22, X'76616C75652D3030303033313930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3190, 'wal', 'ack-3190');
COMMIT;
SELECT 'ack', 3190;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3191, 23, X'76616C75652D3030303033313931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3191, 'wal', 'ack-3191');
COMMIT;
SELECT 'ack', 3191;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3192, 24, X'76616C75652D3030303033313932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3192, 'wal', 'ack-3192');
COMMIT;
SELECT 'ack', 3192;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3193, 25, X'76616C75652D3030303033313933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3193, 'wal', 'ack-3193');
COMMIT;
SELECT 'ack', 3193;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3194, 26, X'76616C75652D3030303033313934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3194, 'wal', 'ack-3194');
COMMIT;
SELECT 'ack', 3194;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3195, 27, X'76616C75652D3030303033313935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3195, 'wal', 'ack-3195');
COMMIT;
SELECT 'ack', 3195;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3196, 28, X'76616C75652D3030303033313936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3196, 'wal', 'ack-3196');
COMMIT;
SELECT 'ack', 3196;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3197, 29, X'76616C75652D3030303033313937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3197, 'wal', 'ack-3197');
COMMIT;
SELECT 'ack', 3197;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3198, 30, X'76616C75652D3030303033313938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3198, 'wal', 'ack-3198');
COMMIT;
SELECT 'ack', 3198;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3199, 31, X'76616C75652D3030303033313939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3199, 'wal', 'ack-3199');
COMMIT;
SELECT 'ack', 3199;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3200, 0, X'76616C75652D3030303033323030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3200, 'wal', 'ack-3200');
COMMIT;
SELECT 'ack', 3200;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3201, 1, X'76616C75652D3030303033323031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3201, 'wal', 'ack-3201');
COMMIT;
SELECT 'ack', 3201;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3202, 2, X'76616C75652D3030303033323032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3202, 'wal', 'ack-3202');
COMMIT;
SELECT 'ack', 3202;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3203, 3, X'76616C75652D3030303033323033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3203, 'wal', 'ack-3203');
COMMIT;
SELECT 'ack', 3203;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3204, 4, X'76616C75652D3030303033323034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3204, 'wal', 'ack-3204');
COMMIT;
SELECT 'ack', 3204;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3205, 5, X'76616C75652D3030303033323035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3205, 'wal', 'ack-3205');
COMMIT;
SELECT 'ack', 3205;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3206, 6, X'76616C75652D3030303033323036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3206, 'wal', 'ack-3206');
COMMIT;
SELECT 'ack', 3206;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3207, 7, X'76616C75652D3030303033323037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3207, 'wal', 'ack-3207');
COMMIT;
SELECT 'ack', 3207;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3208, 8, X'76616C75652D3030303033323038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3208, 'wal', 'ack-3208');
COMMIT;
SELECT 'ack', 3208;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3209, 9, X'76616C75652D3030303033323039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3209, 'wal', 'ack-3209');
COMMIT;
SELECT 'ack', 3209;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3210, 10, X'76616C75652D3030303033323130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3210, 'wal', 'ack-3210');
COMMIT;
SELECT 'ack', 3210;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3211, 11, X'76616C75652D3030303033323131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3211, 'wal', 'ack-3211');
COMMIT;
SELECT 'ack', 3211;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3212, 12, X'76616C75652D3030303033323132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3212, 'wal', 'ack-3212');
COMMIT;
SELECT 'ack', 3212;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3213, 13, X'76616C75652D3030303033323133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3213, 'wal', 'ack-3213');
COMMIT;
SELECT 'ack', 3213;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3214, 14, X'76616C75652D3030303033323134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3214, 'wal', 'ack-3214');
COMMIT;
SELECT 'ack', 3214;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3215, 15, X'76616C75652D3030303033323135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3215, 'wal', 'ack-3215');
COMMIT;
SELECT 'ack', 3215;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3216, 16, X'76616C75652D3030303033323136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3216, 'wal', 'ack-3216');
COMMIT;
SELECT 'ack', 3216;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3217, 17, X'76616C75652D3030303033323137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3217, 'wal', 'ack-3217');
COMMIT;
SELECT 'ack', 3217;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3218, 18, X'76616C75652D3030303033323138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3218, 'wal', 'ack-3218');
COMMIT;
SELECT 'ack', 3218;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3219, 19, X'76616C75652D3030303033323139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3219, 'wal', 'ack-3219');
COMMIT;
SELECT 'ack', 3219;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3220, 20, X'76616C75652D3030303033323230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3220, 'wal', 'ack-3220');
COMMIT;
SELECT 'ack', 3220;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3221, 21, X'76616C75652D3030303033323231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3221, 'wal', 'ack-3221');
COMMIT;
SELECT 'ack', 3221;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3222, 22, X'76616C75652D3030303033323232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3222, 'wal', 'ack-3222');
COMMIT;
SELECT 'ack', 3222;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3223, 23, X'76616C75652D3030303033323233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3223, 'wal', 'ack-3223');
COMMIT;
SELECT 'ack', 3223;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3224, 24, X'76616C75652D3030303033323234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3224, 'wal', 'ack-3224');
COMMIT;
SELECT 'ack', 3224;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3225, 25, X'76616C75652D3030303033323235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3225, 'wal', 'ack-3225');
COMMIT;
SELECT 'ack', 3225;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3226, 26, X'76616C75652D3030303033323236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3226, 'wal', 'ack-3226');
COMMIT;
SELECT 'ack', 3226;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3227, 27, X'76616C75652D3030303033323237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3227, 'wal', 'ack-3227');
COMMIT;
SELECT 'ack', 3227;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3228, 28, X'76616C75652D3030303033323238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3228, 'wal', 'ack-3228');
COMMIT;
SELECT 'ack', 3228;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3229, 29, X'76616C75652D3030303033323239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3229, 'wal', 'ack-3229');
COMMIT;
SELECT 'ack', 3229;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3230, 30, X'76616C75652D3030303033323330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3230, 'wal', 'ack-3230');
COMMIT;
SELECT 'ack', 3230;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3231, 31, X'76616C75652D3030303033323331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3231, 'wal', 'ack-3231');
COMMIT;
SELECT 'ack', 3231;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3232, 0, X'76616C75652D3030303033323332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3232, 'wal', 'ack-3232');
COMMIT;
SELECT 'ack', 3232;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3233, 1, X'76616C75652D3030303033323333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3233, 'wal', 'ack-3233');
COMMIT;
SELECT 'ack', 3233;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3234, 2, X'76616C75652D3030303033323334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3234, 'wal', 'ack-3234');
COMMIT;
SELECT 'ack', 3234;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3235, 3, X'76616C75652D3030303033323335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3235, 'wal', 'ack-3235');
COMMIT;
SELECT 'ack', 3235;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3236, 4, X'76616C75652D3030303033323336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3236, 'wal', 'ack-3236');
COMMIT;
SELECT 'ack', 3236;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3237, 5, X'76616C75652D3030303033323337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3237, 'wal', 'ack-3237');
COMMIT;
SELECT 'ack', 3237;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3238, 6, X'76616C75652D3030303033323338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3238, 'wal', 'ack-3238');
COMMIT;
SELECT 'ack', 3238;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3239, 7, X'76616C75652D3030303033323339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3239, 'wal', 'ack-3239');
COMMIT;
SELECT 'ack', 3239;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3240, 8, X'76616C75652D3030303033323430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3240, 'wal', 'ack-3240');
COMMIT;
SELECT 'ack', 3240;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3241, 9, X'76616C75652D3030303033323431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3241, 'wal', 'ack-3241');
COMMIT;
SELECT 'ack', 3241;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3242, 10, X'76616C75652D3030303033323432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3242, 'wal', 'ack-3242');
COMMIT;
SELECT 'ack', 3242;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3243, 11, X'76616C75652D3030303033323433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3243, 'wal', 'ack-3243');
COMMIT;
SELECT 'ack', 3243;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3244, 12, X'76616C75652D3030303033323434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3244, 'wal', 'ack-3244');
COMMIT;
SELECT 'ack', 3244;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3245, 13, X'76616C75652D3030303033323435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3245, 'wal', 'ack-3245');
COMMIT;
SELECT 'ack', 3245;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3246, 14, X'76616C75652D3030303033323436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3246, 'wal', 'ack-3246');
COMMIT;
SELECT 'ack', 3246;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3247, 15, X'76616C75652D3030303033323437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3247, 'wal', 'ack-3247');
COMMIT;
SELECT 'ack', 3247;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3248, 16, X'76616C75652D3030303033323438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3248, 'wal', 'ack-3248');
COMMIT;
SELECT 'ack', 3248;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3249, 17, X'76616C75652D3030303033323439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3249, 'wal', 'ack-3249');
COMMIT;
SELECT 'ack', 3249;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3250, 18, X'76616C75652D3030303033323530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3250, 'wal', 'ack-3250');
COMMIT;
SELECT 'ack', 3250;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3251, 19, X'76616C75652D3030303033323531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3251, 'wal', 'ack-3251');
COMMIT;
SELECT 'ack', 3251;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3252, 20, X'76616C75652D3030303033323532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3252, 'wal', 'ack-3252');
COMMIT;
SELECT 'ack', 3252;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3253, 21, X'76616C75652D3030303033323533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3253, 'wal', 'ack-3253');
COMMIT;
SELECT 'ack', 3253;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3254, 22, X'76616C75652D3030303033323534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3254, 'wal', 'ack-3254');
COMMIT;
SELECT 'ack', 3254;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3255, 23, X'76616C75652D3030303033323535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3255, 'wal', 'ack-3255');
COMMIT;
SELECT 'ack', 3255;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3256, 24, X'76616C75652D3030303033323536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3256, 'wal', 'ack-3256');
COMMIT;
SELECT 'ack', 3256;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3257, 25, X'76616C75652D3030303033323537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3257, 'wal', 'ack-3257');
COMMIT;
SELECT 'ack', 3257;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3258, 26, X'76616C75652D3030303033323538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3258, 'wal', 'ack-3258');
COMMIT;
SELECT 'ack', 3258;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3259, 27, X'76616C75652D3030303033323539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3259, 'wal', 'ack-3259');
COMMIT;
SELECT 'ack', 3259;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3260, 28, X'76616C75652D3030303033323630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3260, 'wal', 'ack-3260');
COMMIT;
SELECT 'ack', 3260;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3261, 29, X'76616C75652D3030303033323631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3261, 'wal', 'ack-3261');
COMMIT;
SELECT 'ack', 3261;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3262, 30, X'76616C75652D3030303033323632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3262, 'wal', 'ack-3262');
COMMIT;
SELECT 'ack', 3262;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3263, 31, X'76616C75652D3030303033323633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3263, 'wal', 'ack-3263');
COMMIT;
SELECT 'ack', 3263;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3264, 0, X'76616C75652D3030303033323634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3264, 'wal', 'ack-3264');
COMMIT;
SELECT 'ack', 3264;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3265, 1, X'76616C75652D3030303033323635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3265, 'wal', 'ack-3265');
COMMIT;
SELECT 'ack', 3265;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3266, 2, X'76616C75652D3030303033323636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3266, 'wal', 'ack-3266');
COMMIT;
SELECT 'ack', 3266;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3267, 3, X'76616C75652D3030303033323637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3267, 'wal', 'ack-3267');
COMMIT;
SELECT 'ack', 3267;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3268, 4, X'76616C75652D3030303033323638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3268, 'wal', 'ack-3268');
COMMIT;
SELECT 'ack', 3268;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3269, 5, X'76616C75652D3030303033323639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3269, 'wal', 'ack-3269');
COMMIT;
SELECT 'ack', 3269;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3270, 6, X'76616C75652D3030303033323730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3270, 'wal', 'ack-3270');
COMMIT;
SELECT 'ack', 3270;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3271, 7, X'76616C75652D3030303033323731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3271, 'wal', 'ack-3271');
COMMIT;
SELECT 'ack', 3271;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3272, 8, X'76616C75652D3030303033323732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3272, 'wal', 'ack-3272');
COMMIT;
SELECT 'ack', 3272;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3273, 9, X'76616C75652D3030303033323733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3273, 'wal', 'ack-3273');
COMMIT;
SELECT 'ack', 3273;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3274, 10, X'76616C75652D3030303033323734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3274, 'wal', 'ack-3274');
COMMIT;
SELECT 'ack', 3274;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3275, 11, X'76616C75652D3030303033323735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3275, 'wal', 'ack-3275');
COMMIT;
SELECT 'ack', 3275;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3276, 12, X'76616C75652D3030303033323736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3276, 'wal', 'ack-3276');
COMMIT;
SELECT 'ack', 3276;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3277, 13, X'76616C75652D3030303033323737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3277, 'wal', 'ack-3277');
COMMIT;
SELECT 'ack', 3277;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3278, 14, X'76616C75652D3030303033323738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3278, 'wal', 'ack-3278');
COMMIT;
SELECT 'ack', 3278;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3279, 15, X'76616C75652D3030303033323739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3279, 'wal', 'ack-3279');
COMMIT;
SELECT 'ack', 3279;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3280, 16, X'76616C75652D3030303033323830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3280, 'wal', 'ack-3280');
COMMIT;
SELECT 'ack', 3280;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3281, 17, X'76616C75652D3030303033323831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3281, 'wal', 'ack-3281');
COMMIT;
SELECT 'ack', 3281;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3282, 18, X'76616C75652D3030303033323832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3282, 'wal', 'ack-3282');
COMMIT;
SELECT 'ack', 3282;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3283, 19, X'76616C75652D3030303033323833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3283, 'wal', 'ack-3283');
COMMIT;
SELECT 'ack', 3283;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3284, 20, X'76616C75652D3030303033323834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3284, 'wal', 'ack-3284');
COMMIT;
SELECT 'ack', 3284;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3285, 21, X'76616C75652D3030303033323835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3285, 'wal', 'ack-3285');
COMMIT;
SELECT 'ack', 3285;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3286, 22, X'76616C75652D3030303033323836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3286, 'wal', 'ack-3286');
COMMIT;
SELECT 'ack', 3286;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3287, 23, X'76616C75652D3030303033323837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3287, 'wal', 'ack-3287');
COMMIT;
SELECT 'ack', 3287;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3288, 24, X'76616C75652D3030303033323838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3288, 'wal', 'ack-3288');
COMMIT;
SELECT 'ack', 3288;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3289, 25, X'76616C75652D3030303033323839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3289, 'wal', 'ack-3289');
COMMIT;
SELECT 'ack', 3289;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3290, 26, X'76616C75652D3030303033323930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3290, 'wal', 'ack-3290');
COMMIT;
SELECT 'ack', 3290;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3291, 27, X'76616C75652D3030303033323931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3291, 'wal', 'ack-3291');
COMMIT;
SELECT 'ack', 3291;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3292, 28, X'76616C75652D3030303033323932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3292, 'wal', 'ack-3292');
COMMIT;
SELECT 'ack', 3292;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3293, 29, X'76616C75652D3030303033323933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3293, 'wal', 'ack-3293');
COMMIT;
SELECT 'ack', 3293;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3294, 30, X'76616C75652D3030303033323934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3294, 'wal', 'ack-3294');
COMMIT;
SELECT 'ack', 3294;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3295, 31, X'76616C75652D3030303033323935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3295, 'wal', 'ack-3295');
COMMIT;
SELECT 'ack', 3295;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3296, 0, X'76616C75652D3030303033323936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3296, 'wal', 'ack-3296');
COMMIT;
SELECT 'ack', 3296;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3297, 1, X'76616C75652D3030303033323937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3297, 'wal', 'ack-3297');
COMMIT;
SELECT 'ack', 3297;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3298, 2, X'76616C75652D3030303033323938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3298, 'wal', 'ack-3298');
COMMIT;
SELECT 'ack', 3298;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3299, 3, X'76616C75652D3030303033323939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3299, 'wal', 'ack-3299');
COMMIT;
SELECT 'ack', 3299;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3300, 4, X'76616C75652D3030303033333030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3300, 'wal', 'ack-3300');
COMMIT;
SELECT 'ack', 3300;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3301, 5, X'76616C75652D3030303033333031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3301, 'wal', 'ack-3301');
COMMIT;
SELECT 'ack', 3301;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3302, 6, X'76616C75652D3030303033333032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3302, 'wal', 'ack-3302');
COMMIT;
SELECT 'ack', 3302;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3303, 7, X'76616C75652D3030303033333033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3303, 'wal', 'ack-3303');
COMMIT;
SELECT 'ack', 3303;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3304, 8, X'76616C75652D3030303033333034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3304, 'wal', 'ack-3304');
COMMIT;
SELECT 'ack', 3304;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3305, 9, X'76616C75652D3030303033333035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3305, 'wal', 'ack-3305');
COMMIT;
SELECT 'ack', 3305;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3306, 10, X'76616C75652D3030303033333036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3306, 'wal', 'ack-3306');
COMMIT;
SELECT 'ack', 3306;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3307, 11, X'76616C75652D3030303033333037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3307, 'wal', 'ack-3307');
COMMIT;
SELECT 'ack', 3307;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3308, 12, X'76616C75652D3030303033333038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3308, 'wal', 'ack-3308');
COMMIT;
SELECT 'ack', 3308;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3309, 13, X'76616C75652D3030303033333039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3309, 'wal', 'ack-3309');
COMMIT;
SELECT 'ack', 3309;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3310, 14, X'76616C75652D3030303033333130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3310, 'wal', 'ack-3310');
COMMIT;
SELECT 'ack', 3310;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3311, 15, X'76616C75652D3030303033333131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3311, 'wal', 'ack-3311');
COMMIT;
SELECT 'ack', 3311;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3312, 16, X'76616C75652D3030303033333132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3312, 'wal', 'ack-3312');
COMMIT;
SELECT 'ack', 3312;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3313, 17, X'76616C75652D3030303033333133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3313, 'wal', 'ack-3313');
COMMIT;
SELECT 'ack', 3313;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3314, 18, X'76616C75652D3030303033333134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3314, 'wal', 'ack-3314');
COMMIT;
SELECT 'ack', 3314;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3315, 19, X'76616C75652D3030303033333135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3315, 'wal', 'ack-3315');
COMMIT;
SELECT 'ack', 3315;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3316, 20, X'76616C75652D3030303033333136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3316, 'wal', 'ack-3316');
COMMIT;
SELECT 'ack', 3316;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3317, 21, X'76616C75652D3030303033333137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3317, 'wal', 'ack-3317');
COMMIT;
SELECT 'ack', 3317;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3318, 22, X'76616C75652D3030303033333138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3318, 'wal', 'ack-3318');
COMMIT;
SELECT 'ack', 3318;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3319, 23, X'76616C75652D3030303033333139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3319, 'wal', 'ack-3319');
COMMIT;
SELECT 'ack', 3319;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3320, 24, X'76616C75652D3030303033333230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3320, 'wal', 'ack-3320');
COMMIT;
SELECT 'ack', 3320;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3321, 25, X'76616C75652D3030303033333231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3321, 'wal', 'ack-3321');
COMMIT;
SELECT 'ack', 3321;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3322, 26, X'76616C75652D3030303033333232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3322, 'wal', 'ack-3322');
COMMIT;
SELECT 'ack', 3322;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3323, 27, X'76616C75652D3030303033333233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3323, 'wal', 'ack-3323');
COMMIT;
SELECT 'ack', 3323;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3324, 28, X'76616C75652D3030303033333234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3324, 'wal', 'ack-3324');
COMMIT;
SELECT 'ack', 3324;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3325, 29, X'76616C75652D3030303033333235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3325, 'wal', 'ack-3325');
COMMIT;
SELECT 'ack', 3325;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3326, 30, X'76616C75652D3030303033333236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3326, 'wal', 'ack-3326');
COMMIT;
SELECT 'ack', 3326;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3327, 31, X'76616C75652D3030303033333237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3327, 'wal', 'ack-3327');
COMMIT;
SELECT 'ack', 3327;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3328, 0, X'76616C75652D3030303033333238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3328, 'wal', 'ack-3328');
COMMIT;
SELECT 'ack', 3328;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3329, 1, X'76616C75652D3030303033333239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3329, 'wal', 'ack-3329');
COMMIT;
SELECT 'ack', 3329;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3330, 2, X'76616C75652D3030303033333330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3330, 'wal', 'ack-3330');
COMMIT;
SELECT 'ack', 3330;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3331, 3, X'76616C75652D3030303033333331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3331, 'wal', 'ack-3331');
COMMIT;
SELECT 'ack', 3331;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3332, 4, X'76616C75652D3030303033333332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3332, 'wal', 'ack-3332');
COMMIT;
SELECT 'ack', 3332;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3333, 5, X'76616C75652D3030303033333333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3333, 'wal', 'ack-3333');
COMMIT;
SELECT 'ack', 3333;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3334, 6, X'76616C75652D3030303033333334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3334, 'wal', 'ack-3334');
COMMIT;
SELECT 'ack', 3334;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3335, 7, X'76616C75652D3030303033333335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3335, 'wal', 'ack-3335');
COMMIT;
SELECT 'ack', 3335;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3336, 8, X'76616C75652D3030303033333336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3336, 'wal', 'ack-3336');
COMMIT;
SELECT 'ack', 3336;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3337, 9, X'76616C75652D3030303033333337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3337, 'wal', 'ack-3337');
COMMIT;
SELECT 'ack', 3337;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3338, 10, X'76616C75652D3030303033333338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3338, 'wal', 'ack-3338');
COMMIT;
SELECT 'ack', 3338;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3339, 11, X'76616C75652D3030303033333339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3339, 'wal', 'ack-3339');
COMMIT;
SELECT 'ack', 3339;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3340, 12, X'76616C75652D3030303033333430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3340, 'wal', 'ack-3340');
COMMIT;
SELECT 'ack', 3340;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3341, 13, X'76616C75652D3030303033333431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3341, 'wal', 'ack-3341');
COMMIT;
SELECT 'ack', 3341;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3342, 14, X'76616C75652D3030303033333432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3342, 'wal', 'ack-3342');
COMMIT;
SELECT 'ack', 3342;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3343, 15, X'76616C75652D3030303033333433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3343, 'wal', 'ack-3343');
COMMIT;
SELECT 'ack', 3343;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3344, 16, X'76616C75652D3030303033333434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3344, 'wal', 'ack-3344');
COMMIT;
SELECT 'ack', 3344;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3345, 17, X'76616C75652D3030303033333435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3345, 'wal', 'ack-3345');
COMMIT;
SELECT 'ack', 3345;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3346, 18, X'76616C75652D3030303033333436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3346, 'wal', 'ack-3346');
COMMIT;
SELECT 'ack', 3346;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3347, 19, X'76616C75652D3030303033333437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3347, 'wal', 'ack-3347');
COMMIT;
SELECT 'ack', 3347;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3348, 20, X'76616C75652D3030303033333438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3348, 'wal', 'ack-3348');
COMMIT;
SELECT 'ack', 3348;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3349, 21, X'76616C75652D3030303033333439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3349, 'wal', 'ack-3349');
COMMIT;
SELECT 'ack', 3349;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3350, 22, X'76616C75652D3030303033333530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3350, 'wal', 'ack-3350');
COMMIT;
SELECT 'ack', 3350;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3351, 23, X'76616C75652D3030303033333531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3351, 'wal', 'ack-3351');
COMMIT;
SELECT 'ack', 3351;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3352, 24, X'76616C75652D3030303033333532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3352, 'wal', 'ack-3352');
COMMIT;
SELECT 'ack', 3352;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3353, 25, X'76616C75652D3030303033333533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3353, 'wal', 'ack-3353');
COMMIT;
SELECT 'ack', 3353;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3354, 26, X'76616C75652D3030303033333534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3354, 'wal', 'ack-3354');
COMMIT;
SELECT 'ack', 3354;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3355, 27, X'76616C75652D3030303033333535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3355, 'wal', 'ack-3355');
COMMIT;
SELECT 'ack', 3355;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3356, 28, X'76616C75652D3030303033333536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3356, 'wal', 'ack-3356');
COMMIT;
SELECT 'ack', 3356;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3357, 29, X'76616C75652D3030303033333537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3357, 'wal', 'ack-3357');
COMMIT;
SELECT 'ack', 3357;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3358, 30, X'76616C75652D3030303033333538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3358, 'wal', 'ack-3358');
COMMIT;
SELECT 'ack', 3358;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3359, 31, X'76616C75652D3030303033333539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3359, 'wal', 'ack-3359');
COMMIT;
SELECT 'ack', 3359;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3360, 0, X'76616C75652D3030303033333630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3360, 'wal', 'ack-3360');
COMMIT;
SELECT 'ack', 3360;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3361, 1, X'76616C75652D3030303033333631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3361, 'wal', 'ack-3361');
COMMIT;
SELECT 'ack', 3361;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3362, 2, X'76616C75652D3030303033333632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3362, 'wal', 'ack-3362');
COMMIT;
SELECT 'ack', 3362;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3363, 3, X'76616C75652D3030303033333633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3363, 'wal', 'ack-3363');
COMMIT;
SELECT 'ack', 3363;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3364, 4, X'76616C75652D3030303033333634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3364, 'wal', 'ack-3364');
COMMIT;
SELECT 'ack', 3364;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3365, 5, X'76616C75652D3030303033333635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3365, 'wal', 'ack-3365');
COMMIT;
SELECT 'ack', 3365;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3366, 6, X'76616C75652D3030303033333636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3366, 'wal', 'ack-3366');
COMMIT;
SELECT 'ack', 3366;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3367, 7, X'76616C75652D3030303033333637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3367, 'wal', 'ack-3367');
COMMIT;
SELECT 'ack', 3367;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3368, 8, X'76616C75652D3030303033333638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3368, 'wal', 'ack-3368');
COMMIT;
SELECT 'ack', 3368;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3369, 9, X'76616C75652D3030303033333639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3369, 'wal', 'ack-3369');
COMMIT;
SELECT 'ack', 3369;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3370, 10, X'76616C75652D3030303033333730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3370, 'wal', 'ack-3370');
COMMIT;
SELECT 'ack', 3370;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3371, 11, X'76616C75652D3030303033333731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3371, 'wal', 'ack-3371');
COMMIT;
SELECT 'ack', 3371;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3372, 12, X'76616C75652D3030303033333732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3372, 'wal', 'ack-3372');
COMMIT;
SELECT 'ack', 3372;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3373, 13, X'76616C75652D3030303033333733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3373, 'wal', 'ack-3373');
COMMIT;
SELECT 'ack', 3373;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3374, 14, X'76616C75652D3030303033333734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3374, 'wal', 'ack-3374');
COMMIT;
SELECT 'ack', 3374;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3375, 15, X'76616C75652D3030303033333735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3375, 'wal', 'ack-3375');
COMMIT;
SELECT 'ack', 3375;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3376, 16, X'76616C75652D3030303033333736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3376, 'wal', 'ack-3376');
COMMIT;
SELECT 'ack', 3376;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3377, 17, X'76616C75652D3030303033333737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3377, 'wal', 'ack-3377');
COMMIT;
SELECT 'ack', 3377;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3378, 18, X'76616C75652D3030303033333738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3378, 'wal', 'ack-3378');
COMMIT;
SELECT 'ack', 3378;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3379, 19, X'76616C75652D3030303033333739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3379, 'wal', 'ack-3379');
COMMIT;
SELECT 'ack', 3379;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3380, 20, X'76616C75652D3030303033333830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3380, 'wal', 'ack-3380');
COMMIT;
SELECT 'ack', 3380;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3381, 21, X'76616C75652D3030303033333831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3381, 'wal', 'ack-3381');
COMMIT;
SELECT 'ack', 3381;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3382, 22, X'76616C75652D3030303033333832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3382, 'wal', 'ack-3382');
COMMIT;
SELECT 'ack', 3382;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3383, 23, X'76616C75652D3030303033333833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3383, 'wal', 'ack-3383');
COMMIT;
SELECT 'ack', 3383;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3384, 24, X'76616C75652D3030303033333834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3384, 'wal', 'ack-3384');
COMMIT;
SELECT 'ack', 3384;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3385, 25, X'76616C75652D3030303033333835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3385, 'wal', 'ack-3385');
COMMIT;
SELECT 'ack', 3385;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3386, 26, X'76616C75652D3030303033333836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3386, 'wal', 'ack-3386');
COMMIT;
SELECT 'ack', 3386;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3387, 27, X'76616C75652D3030303033333837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3387, 'wal', 'ack-3387');
COMMIT;
SELECT 'ack', 3387;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3388, 28, X'76616C75652D3030303033333838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3388, 'wal', 'ack-3388');
COMMIT;
SELECT 'ack', 3388;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3389, 29, X'76616C75652D3030303033333839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3389, 'wal', 'ack-3389');
COMMIT;
SELECT 'ack', 3389;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3390, 30, X'76616C75652D3030303033333930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3390, 'wal', 'ack-3390');
COMMIT;
SELECT 'ack', 3390;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3391, 31, X'76616C75652D3030303033333931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3391, 'wal', 'ack-3391');
COMMIT;
SELECT 'ack', 3391;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3392, 0, X'76616C75652D3030303033333932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3392, 'wal', 'ack-3392');
COMMIT;
SELECT 'ack', 3392;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3393, 1, X'76616C75652D3030303033333933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3393, 'wal', 'ack-3393');
COMMIT;
SELECT 'ack', 3393;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3394, 2, X'76616C75652D3030303033333934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3394, 'wal', 'ack-3394');
COMMIT;
SELECT 'ack', 3394;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3395, 3, X'76616C75652D3030303033333935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3395, 'wal', 'ack-3395');
COMMIT;
SELECT 'ack', 3395;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3396, 4, X'76616C75652D3030303033333936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3396, 'wal', 'ack-3396');
COMMIT;
SELECT 'ack', 3396;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3397, 5, X'76616C75652D3030303033333937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3397, 'wal', 'ack-3397');
COMMIT;
SELECT 'ack', 3397;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3398, 6, X'76616C75652D3030303033333938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3398, 'wal', 'ack-3398');
COMMIT;
SELECT 'ack', 3398;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3399, 7, X'76616C75652D3030303033333939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3399, 'wal', 'ack-3399');
COMMIT;
SELECT 'ack', 3399;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3400, 8, X'76616C75652D3030303033343030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3400, 'wal', 'ack-3400');
COMMIT;
SELECT 'ack', 3400;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3401, 9, X'76616C75652D3030303033343031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3401, 'wal', 'ack-3401');
COMMIT;
SELECT 'ack', 3401;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3402, 10, X'76616C75652D3030303033343032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3402, 'wal', 'ack-3402');
COMMIT;
SELECT 'ack', 3402;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3403, 11, X'76616C75652D3030303033343033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3403, 'wal', 'ack-3403');
COMMIT;
SELECT 'ack', 3403;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3404, 12, X'76616C75652D3030303033343034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3404, 'wal', 'ack-3404');
COMMIT;
SELECT 'ack', 3404;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3405, 13, X'76616C75652D3030303033343035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3405, 'wal', 'ack-3405');
COMMIT;
SELECT 'ack', 3405;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3406, 14, X'76616C75652D3030303033343036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3406, 'wal', 'ack-3406');
COMMIT;
SELECT 'ack', 3406;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3407, 15, X'76616C75652D3030303033343037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3407, 'wal', 'ack-3407');
COMMIT;
SELECT 'ack', 3407;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3408, 16, X'76616C75652D3030303033343038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3408, 'wal', 'ack-3408');
COMMIT;
SELECT 'ack', 3408;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3409, 17, X'76616C75652D3030303033343039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3409, 'wal', 'ack-3409');
COMMIT;
SELECT 'ack', 3409;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3410, 18, X'76616C75652D3030303033343130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3410, 'wal', 'ack-3410');
COMMIT;
SELECT 'ack', 3410;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3411, 19, X'76616C75652D3030303033343131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3411, 'wal', 'ack-3411');
COMMIT;
SELECT 'ack', 3411;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3412, 20, X'76616C75652D3030303033343132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3412, 'wal', 'ack-3412');
COMMIT;
SELECT 'ack', 3412;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3413, 21, X'76616C75652D3030303033343133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3413, 'wal', 'ack-3413');
COMMIT;
SELECT 'ack', 3413;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3414, 22, X'76616C75652D3030303033343134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3414, 'wal', 'ack-3414');
COMMIT;
SELECT 'ack', 3414;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3415, 23, X'76616C75652D3030303033343135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3415, 'wal', 'ack-3415');
COMMIT;
SELECT 'ack', 3415;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3416, 24, X'76616C75652D3030303033343136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3416, 'wal', 'ack-3416');
COMMIT;
SELECT 'ack', 3416;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3417, 25, X'76616C75652D3030303033343137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3417, 'wal', 'ack-3417');
COMMIT;
SELECT 'ack', 3417;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3418, 26, X'76616C75652D3030303033343138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3418, 'wal', 'ack-3418');
COMMIT;
SELECT 'ack', 3418;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3419, 27, X'76616C75652D3030303033343139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3419, 'wal', 'ack-3419');
COMMIT;
SELECT 'ack', 3419;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3420, 28, X'76616C75652D3030303033343230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3420, 'wal', 'ack-3420');
COMMIT;
SELECT 'ack', 3420;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3421, 29, X'76616C75652D3030303033343231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3421, 'wal', 'ack-3421');
COMMIT;
SELECT 'ack', 3421;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3422, 30, X'76616C75652D3030303033343232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3422, 'wal', 'ack-3422');
COMMIT;
SELECT 'ack', 3422;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3423, 31, X'76616C75652D3030303033343233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3423, 'wal', 'ack-3423');
COMMIT;
SELECT 'ack', 3423;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3424, 0, X'76616C75652D3030303033343234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3424, 'wal', 'ack-3424');
COMMIT;
SELECT 'ack', 3424;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3425, 1, X'76616C75652D3030303033343235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3425, 'wal', 'ack-3425');
COMMIT;
SELECT 'ack', 3425;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3426, 2, X'76616C75652D3030303033343236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3426, 'wal', 'ack-3426');
COMMIT;
SELECT 'ack', 3426;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3427, 3, X'76616C75652D3030303033343237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3427, 'wal', 'ack-3427');
COMMIT;
SELECT 'ack', 3427;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3428, 4, X'76616C75652D3030303033343238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3428, 'wal', 'ack-3428');
COMMIT;
SELECT 'ack', 3428;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3429, 5, X'76616C75652D3030303033343239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3429, 'wal', 'ack-3429');
COMMIT;
SELECT 'ack', 3429;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3430, 6, X'76616C75652D3030303033343330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3430, 'wal', 'ack-3430');
COMMIT;
SELECT 'ack', 3430;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3431, 7, X'76616C75652D3030303033343331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3431, 'wal', 'ack-3431');
COMMIT;
SELECT 'ack', 3431;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3432, 8, X'76616C75652D3030303033343332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3432, 'wal', 'ack-3432');
COMMIT;
SELECT 'ack', 3432;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3433, 9, X'76616C75652D3030303033343333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3433, 'wal', 'ack-3433');
COMMIT;
SELECT 'ack', 3433;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3434, 10, X'76616C75652D3030303033343334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3434, 'wal', 'ack-3434');
COMMIT;
SELECT 'ack', 3434;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3435, 11, X'76616C75652D3030303033343335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3435, 'wal', 'ack-3435');
COMMIT;
SELECT 'ack', 3435;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3436, 12, X'76616C75652D3030303033343336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3436, 'wal', 'ack-3436');
COMMIT;
SELECT 'ack', 3436;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3437, 13, X'76616C75652D3030303033343337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3437, 'wal', 'ack-3437');
COMMIT;
SELECT 'ack', 3437;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3438, 14, X'76616C75652D3030303033343338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3438, 'wal', 'ack-3438');
COMMIT;
SELECT 'ack', 3438;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3439, 15, X'76616C75652D3030303033343339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3439, 'wal', 'ack-3439');
COMMIT;
SELECT 'ack', 3439;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3440, 16, X'76616C75652D3030303033343430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3440, 'wal', 'ack-3440');
COMMIT;
SELECT 'ack', 3440;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3441, 17, X'76616C75652D3030303033343431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3441, 'wal', 'ack-3441');
COMMIT;
SELECT 'ack', 3441;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3442, 18, X'76616C75652D3030303033343432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3442, 'wal', 'ack-3442');
COMMIT;
SELECT 'ack', 3442;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3443, 19, X'76616C75652D3030303033343433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3443, 'wal', 'ack-3443');
COMMIT;
SELECT 'ack', 3443;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3444, 20, X'76616C75652D3030303033343434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3444, 'wal', 'ack-3444');
COMMIT;
SELECT 'ack', 3444;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3445, 21, X'76616C75652D3030303033343435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3445, 'wal', 'ack-3445');
COMMIT;
SELECT 'ack', 3445;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3446, 22, X'76616C75652D3030303033343436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3446, 'wal', 'ack-3446');
COMMIT;
SELECT 'ack', 3446;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3447, 23, X'76616C75652D3030303033343437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3447, 'wal', 'ack-3447');
COMMIT;
SELECT 'ack', 3447;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3448, 24, X'76616C75652D3030303033343438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3448, 'wal', 'ack-3448');
COMMIT;
SELECT 'ack', 3448;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3449, 25, X'76616C75652D3030303033343439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3449, 'wal', 'ack-3449');
COMMIT;
SELECT 'ack', 3449;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3450, 26, X'76616C75652D3030303033343530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3450, 'wal', 'ack-3450');
COMMIT;
SELECT 'ack', 3450;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3451, 27, X'76616C75652D3030303033343531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3451, 'wal', 'ack-3451');
COMMIT;
SELECT 'ack', 3451;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3452, 28, X'76616C75652D3030303033343532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3452, 'wal', 'ack-3452');
COMMIT;
SELECT 'ack', 3452;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3453, 29, X'76616C75652D3030303033343533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3453, 'wal', 'ack-3453');
COMMIT;
SELECT 'ack', 3453;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3454, 30, X'76616C75652D3030303033343534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3454, 'wal', 'ack-3454');
COMMIT;
SELECT 'ack', 3454;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3455, 31, X'76616C75652D3030303033343535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3455, 'wal', 'ack-3455');
COMMIT;
SELECT 'ack', 3455;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3456, 0, X'76616C75652D3030303033343536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3456, 'wal', 'ack-3456');
COMMIT;
SELECT 'ack', 3456;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3457, 1, X'76616C75652D3030303033343537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3457, 'wal', 'ack-3457');
COMMIT;
SELECT 'ack', 3457;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3458, 2, X'76616C75652D3030303033343538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3458, 'wal', 'ack-3458');
COMMIT;
SELECT 'ack', 3458;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3459, 3, X'76616C75652D3030303033343539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3459, 'wal', 'ack-3459');
COMMIT;
SELECT 'ack', 3459;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3460, 4, X'76616C75652D3030303033343630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3460, 'wal', 'ack-3460');
COMMIT;
SELECT 'ack', 3460;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3461, 5, X'76616C75652D3030303033343631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3461, 'wal', 'ack-3461');
COMMIT;
SELECT 'ack', 3461;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3462, 6, X'76616C75652D3030303033343632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3462, 'wal', 'ack-3462');
COMMIT;
SELECT 'ack', 3462;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3463, 7, X'76616C75652D3030303033343633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3463, 'wal', 'ack-3463');
COMMIT;
SELECT 'ack', 3463;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3464, 8, X'76616C75652D3030303033343634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3464, 'wal', 'ack-3464');
COMMIT;
SELECT 'ack', 3464;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3465, 9, X'76616C75652D3030303033343635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3465, 'wal', 'ack-3465');
COMMIT;
SELECT 'ack', 3465;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3466, 10, X'76616C75652D3030303033343636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3466, 'wal', 'ack-3466');
COMMIT;
SELECT 'ack', 3466;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3467, 11, X'76616C75652D3030303033343637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3467, 'wal', 'ack-3467');
COMMIT;
SELECT 'ack', 3467;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3468, 12, X'76616C75652D3030303033343638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3468, 'wal', 'ack-3468');
COMMIT;
SELECT 'ack', 3468;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3469, 13, X'76616C75652D3030303033343639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3469, 'wal', 'ack-3469');
COMMIT;
SELECT 'ack', 3469;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3470, 14, X'76616C75652D3030303033343730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3470, 'wal', 'ack-3470');
COMMIT;
SELECT 'ack', 3470;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3471, 15, X'76616C75652D3030303033343731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3471, 'wal', 'ack-3471');
COMMIT;
SELECT 'ack', 3471;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3472, 16, X'76616C75652D3030303033343732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3472, 'wal', 'ack-3472');
COMMIT;
SELECT 'ack', 3472;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3473, 17, X'76616C75652D3030303033343733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3473, 'wal', 'ack-3473');
COMMIT;
SELECT 'ack', 3473;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3474, 18, X'76616C75652D3030303033343734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3474, 'wal', 'ack-3474');
COMMIT;
SELECT 'ack', 3474;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3475, 19, X'76616C75652D3030303033343735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3475, 'wal', 'ack-3475');
COMMIT;
SELECT 'ack', 3475;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3476, 20, X'76616C75652D3030303033343736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3476, 'wal', 'ack-3476');
COMMIT;
SELECT 'ack', 3476;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3477, 21, X'76616C75652D3030303033343737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3477, 'wal', 'ack-3477');
COMMIT;
SELECT 'ack', 3477;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3478, 22, X'76616C75652D3030303033343738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3478, 'wal', 'ack-3478');
COMMIT;
SELECT 'ack', 3478;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3479, 23, X'76616C75652D3030303033343739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3479, 'wal', 'ack-3479');
COMMIT;
SELECT 'ack', 3479;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3480, 24, X'76616C75652D3030303033343830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3480, 'wal', 'ack-3480');
COMMIT;
SELECT 'ack', 3480;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3481, 25, X'76616C75652D3030303033343831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3481, 'wal', 'ack-3481');
COMMIT;
SELECT 'ack', 3481;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3482, 26, X'76616C75652D3030303033343832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3482, 'wal', 'ack-3482');
COMMIT;
SELECT 'ack', 3482;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3483, 27, X'76616C75652D3030303033343833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3483, 'wal', 'ack-3483');
COMMIT;
SELECT 'ack', 3483;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3484, 28, X'76616C75652D3030303033343834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3484, 'wal', 'ack-3484');
COMMIT;
SELECT 'ack', 3484;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3485, 29, X'76616C75652D3030303033343835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3485, 'wal', 'ack-3485');
COMMIT;
SELECT 'ack', 3485;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3486, 30, X'76616C75652D3030303033343836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3486, 'wal', 'ack-3486');
COMMIT;
SELECT 'ack', 3486;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3487, 31, X'76616C75652D3030303033343837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3487, 'wal', 'ack-3487');
COMMIT;
SELECT 'ack', 3487;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3488, 0, X'76616C75652D3030303033343838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3488, 'wal', 'ack-3488');
COMMIT;
SELECT 'ack', 3488;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3489, 1, X'76616C75652D3030303033343839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3489, 'wal', 'ack-3489');
COMMIT;
SELECT 'ack', 3489;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3490, 2, X'76616C75652D3030303033343930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3490, 'wal', 'ack-3490');
COMMIT;
SELECT 'ack', 3490;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3491, 3, X'76616C75652D3030303033343931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3491, 'wal', 'ack-3491');
COMMIT;
SELECT 'ack', 3491;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3492, 4, X'76616C75652D3030303033343932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3492, 'wal', 'ack-3492');
COMMIT;
SELECT 'ack', 3492;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3493, 5, X'76616C75652D3030303033343933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3493, 'wal', 'ack-3493');
COMMIT;
SELECT 'ack', 3493;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3494, 6, X'76616C75652D3030303033343934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3494, 'wal', 'ack-3494');
COMMIT;
SELECT 'ack', 3494;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3495, 7, X'76616C75652D3030303033343935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3495, 'wal', 'ack-3495');
COMMIT;
SELECT 'ack', 3495;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3496, 8, X'76616C75652D3030303033343936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3496, 'wal', 'ack-3496');
COMMIT;
SELECT 'ack', 3496;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3497, 9, X'76616C75652D3030303033343937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3497, 'wal', 'ack-3497');
COMMIT;
SELECT 'ack', 3497;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3498, 10, X'76616C75652D3030303033343938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3498, 'wal', 'ack-3498');
COMMIT;
SELECT 'ack', 3498;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3499, 11, X'76616C75652D3030303033343939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3499, 'wal', 'ack-3499');
COMMIT;
SELECT 'ack', 3499;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3500, 12, X'76616C75652D3030303033353030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3500, 'wal', 'ack-3500');
COMMIT;
SELECT 'ack', 3500;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3501, 13, X'76616C75652D3030303033353031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3501, 'wal', 'ack-3501');
COMMIT;
SELECT 'ack', 3501;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3502, 14, X'76616C75652D3030303033353032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3502, 'wal', 'ack-3502');
COMMIT;
SELECT 'ack', 3502;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3503, 15, X'76616C75652D3030303033353033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3503, 'wal', 'ack-3503');
COMMIT;
SELECT 'ack', 3503;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3504, 16, X'76616C75652D3030303033353034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3504, 'wal', 'ack-3504');
COMMIT;
SELECT 'ack', 3504;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3505, 17, X'76616C75652D3030303033353035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3505, 'wal', 'ack-3505');
COMMIT;
SELECT 'ack', 3505;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3506, 18, X'76616C75652D3030303033353036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3506, 'wal', 'ack-3506');
COMMIT;
SELECT 'ack', 3506;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3507, 19, X'76616C75652D3030303033353037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3507, 'wal', 'ack-3507');
COMMIT;
SELECT 'ack', 3507;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3508, 20, X'76616C75652D3030303033353038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3508, 'wal', 'ack-3508');
COMMIT;
SELECT 'ack', 3508;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3509, 21, X'76616C75652D3030303033353039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3509, 'wal', 'ack-3509');
COMMIT;
SELECT 'ack', 3509;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3510, 22, X'76616C75652D3030303033353130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3510, 'wal', 'ack-3510');
COMMIT;
SELECT 'ack', 3510;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3511, 23, X'76616C75652D3030303033353131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3511, 'wal', 'ack-3511');
COMMIT;
SELECT 'ack', 3511;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3512, 24, X'76616C75652D3030303033353132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3512, 'wal', 'ack-3512');
COMMIT;
SELECT 'ack', 3512;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3513, 25, X'76616C75652D3030303033353133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3513, 'wal', 'ack-3513');
COMMIT;
SELECT 'ack', 3513;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3514, 26, X'76616C75652D3030303033353134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3514, 'wal', 'ack-3514');
COMMIT;
SELECT 'ack', 3514;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3515, 27, X'76616C75652D3030303033353135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3515, 'wal', 'ack-3515');
COMMIT;
SELECT 'ack', 3515;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3516, 28, X'76616C75652D3030303033353136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3516, 'wal', 'ack-3516');
COMMIT;
SELECT 'ack', 3516;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3517, 29, X'76616C75652D3030303033353137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3517, 'wal', 'ack-3517');
COMMIT;
SELECT 'ack', 3517;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3518, 30, X'76616C75652D3030303033353138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3518, 'wal', 'ack-3518');
COMMIT;
SELECT 'ack', 3518;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3519, 31, X'76616C75652D3030303033353139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3519, 'wal', 'ack-3519');
COMMIT;
SELECT 'ack', 3519;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3520, 0, X'76616C75652D3030303033353230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3520, 'wal', 'ack-3520');
COMMIT;
SELECT 'ack', 3520;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3521, 1, X'76616C75652D3030303033353231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3521, 'wal', 'ack-3521');
COMMIT;
SELECT 'ack', 3521;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3522, 2, X'76616C75652D3030303033353232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3522, 'wal', 'ack-3522');
COMMIT;
SELECT 'ack', 3522;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3523, 3, X'76616C75652D3030303033353233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3523, 'wal', 'ack-3523');
COMMIT;
SELECT 'ack', 3523;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3524, 4, X'76616C75652D3030303033353234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3524, 'wal', 'ack-3524');
COMMIT;
SELECT 'ack', 3524;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3525, 5, X'76616C75652D3030303033353235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3525, 'wal', 'ack-3525');
COMMIT;
SELECT 'ack', 3525;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3526, 6, X'76616C75652D3030303033353236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3526, 'wal', 'ack-3526');
COMMIT;
SELECT 'ack', 3526;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3527, 7, X'76616C75652D3030303033353237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3527, 'wal', 'ack-3527');
COMMIT;
SELECT 'ack', 3527;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3528, 8, X'76616C75652D3030303033353238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3528, 'wal', 'ack-3528');
COMMIT;
SELECT 'ack', 3528;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3529, 9, X'76616C75652D3030303033353239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3529, 'wal', 'ack-3529');
COMMIT;
SELECT 'ack', 3529;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3530, 10, X'76616C75652D3030303033353330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3530, 'wal', 'ack-3530');
COMMIT;
SELECT 'ack', 3530;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3531, 11, X'76616C75652D3030303033353331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3531, 'wal', 'ack-3531');
COMMIT;
SELECT 'ack', 3531;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3532, 12, X'76616C75652D3030303033353332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3532, 'wal', 'ack-3532');
COMMIT;
SELECT 'ack', 3532;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3533, 13, X'76616C75652D3030303033353333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3533, 'wal', 'ack-3533');
COMMIT;
SELECT 'ack', 3533;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3534, 14, X'76616C75652D3030303033353334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3534, 'wal', 'ack-3534');
COMMIT;
SELECT 'ack', 3534;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3535, 15, X'76616C75652D3030303033353335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3535, 'wal', 'ack-3535');
COMMIT;
SELECT 'ack', 3535;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3536, 16, X'76616C75652D3030303033353336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3536, 'wal', 'ack-3536');
COMMIT;
SELECT 'ack', 3536;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3537, 17, X'76616C75652D3030303033353337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3537, 'wal', 'ack-3537');
COMMIT;
SELECT 'ack', 3537;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3538, 18, X'76616C75652D3030303033353338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3538, 'wal', 'ack-3538');
COMMIT;
SELECT 'ack', 3538;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3539, 19, X'76616C75652D3030303033353339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3539, 'wal', 'ack-3539');
COMMIT;
SELECT 'ack', 3539;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3540, 20, X'76616C75652D3030303033353430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3540, 'wal', 'ack-3540');
COMMIT;
SELECT 'ack', 3540;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3541, 21, X'76616C75652D3030303033353431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3541, 'wal', 'ack-3541');
COMMIT;
SELECT 'ack', 3541;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3542, 22, X'76616C75652D3030303033353432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3542, 'wal', 'ack-3542');
COMMIT;
SELECT 'ack', 3542;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3543, 23, X'76616C75652D3030303033353433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3543, 'wal', 'ack-3543');
COMMIT;
SELECT 'ack', 3543;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3544, 24, X'76616C75652D3030303033353434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3544, 'wal', 'ack-3544');
COMMIT;
SELECT 'ack', 3544;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3545, 25, X'76616C75652D3030303033353435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3545, 'wal', 'ack-3545');
COMMIT;
SELECT 'ack', 3545;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3546, 26, X'76616C75652D3030303033353436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3546, 'wal', 'ack-3546');
COMMIT;
SELECT 'ack', 3546;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3547, 27, X'76616C75652D3030303033353437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3547, 'wal', 'ack-3547');
COMMIT;
SELECT 'ack', 3547;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3548, 28, X'76616C75652D3030303033353438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3548, 'wal', 'ack-3548');
COMMIT;
SELECT 'ack', 3548;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3549, 29, X'76616C75652D3030303033353439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3549, 'wal', 'ack-3549');
COMMIT;
SELECT 'ack', 3549;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3550, 30, X'76616C75652D3030303033353530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3550, 'wal', 'ack-3550');
COMMIT;
SELECT 'ack', 3550;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3551, 31, X'76616C75652D3030303033353531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3551, 'wal', 'ack-3551');
COMMIT;
SELECT 'ack', 3551;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3552, 0, X'76616C75652D3030303033353532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3552, 'wal', 'ack-3552');
COMMIT;
SELECT 'ack', 3552;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3553, 1, X'76616C75652D3030303033353533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3553, 'wal', 'ack-3553');
COMMIT;
SELECT 'ack', 3553;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3554, 2, X'76616C75652D3030303033353534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3554, 'wal', 'ack-3554');
COMMIT;
SELECT 'ack', 3554;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3555, 3, X'76616C75652D3030303033353535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3555, 'wal', 'ack-3555');
COMMIT;
SELECT 'ack', 3555;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3556, 4, X'76616C75652D3030303033353536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3556, 'wal', 'ack-3556');
COMMIT;
SELECT 'ack', 3556;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3557, 5, X'76616C75652D3030303033353537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3557, 'wal', 'ack-3557');
COMMIT;
SELECT 'ack', 3557;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3558, 6, X'76616C75652D3030303033353538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3558, 'wal', 'ack-3558');
COMMIT;
SELECT 'ack', 3558;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3559, 7, X'76616C75652D3030303033353539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3559, 'wal', 'ack-3559');
COMMIT;
SELECT 'ack', 3559;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3560, 8, X'76616C75652D3030303033353630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3560, 'wal', 'ack-3560');
COMMIT;
SELECT 'ack', 3560;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3561, 9, X'76616C75652D3030303033353631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3561, 'wal', 'ack-3561');
COMMIT;
SELECT 'ack', 3561;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3562, 10, X'76616C75652D3030303033353632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3562, 'wal', 'ack-3562');
COMMIT;
SELECT 'ack', 3562;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3563, 11, X'76616C75652D3030303033353633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3563, 'wal', 'ack-3563');
COMMIT;
SELECT 'ack', 3563;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3564, 12, X'76616C75652D3030303033353634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3564, 'wal', 'ack-3564');
COMMIT;
SELECT 'ack', 3564;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3565, 13, X'76616C75652D3030303033353635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3565, 'wal', 'ack-3565');
COMMIT;
SELECT 'ack', 3565;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3566, 14, X'76616C75652D3030303033353636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3566, 'wal', 'ack-3566');
COMMIT;
SELECT 'ack', 3566;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3567, 15, X'76616C75652D3030303033353637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3567, 'wal', 'ack-3567');
COMMIT;
SELECT 'ack', 3567;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3568, 16, X'76616C75652D3030303033353638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3568, 'wal', 'ack-3568');
COMMIT;
SELECT 'ack', 3568;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3569, 17, X'76616C75652D3030303033353639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3569, 'wal', 'ack-3569');
COMMIT;
SELECT 'ack', 3569;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3570, 18, X'76616C75652D3030303033353730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3570, 'wal', 'ack-3570');
COMMIT;
SELECT 'ack', 3570;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3571, 19, X'76616C75652D3030303033353731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3571, 'wal', 'ack-3571');
COMMIT;
SELECT 'ack', 3571;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3572, 20, X'76616C75652D3030303033353732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3572, 'wal', 'ack-3572');
COMMIT;
SELECT 'ack', 3572;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3573, 21, X'76616C75652D3030303033353733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3573, 'wal', 'ack-3573');
COMMIT;
SELECT 'ack', 3573;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3574, 22, X'76616C75652D3030303033353734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3574, 'wal', 'ack-3574');
COMMIT;
SELECT 'ack', 3574;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3575, 23, X'76616C75652D3030303033353735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3575, 'wal', 'ack-3575');
COMMIT;
SELECT 'ack', 3575;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3576, 24, X'76616C75652D3030303033353736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3576, 'wal', 'ack-3576');
COMMIT;
SELECT 'ack', 3576;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3577, 25, X'76616C75652D3030303033353737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3577, 'wal', 'ack-3577');
COMMIT;
SELECT 'ack', 3577;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3578, 26, X'76616C75652D3030303033353738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3578, 'wal', 'ack-3578');
COMMIT;
SELECT 'ack', 3578;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3579, 27, X'76616C75652D3030303033353739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3579, 'wal', 'ack-3579');
COMMIT;
SELECT 'ack', 3579;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3580, 28, X'76616C75652D3030303033353830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3580, 'wal', 'ack-3580');
COMMIT;
SELECT 'ack', 3580;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3581, 29, X'76616C75652D3030303033353831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3581, 'wal', 'ack-3581');
COMMIT;
SELECT 'ack', 3581;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3582, 30, X'76616C75652D3030303033353832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3582, 'wal', 'ack-3582');
COMMIT;
SELECT 'ack', 3582;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3583, 31, X'76616C75652D3030303033353833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3583, 'wal', 'ack-3583');
COMMIT;
SELECT 'ack', 3583;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3584, 0, X'76616C75652D3030303033353834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3584, 'wal', 'ack-3584');
COMMIT;
SELECT 'ack', 3584;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3585, 1, X'76616C75652D3030303033353835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3585, 'wal', 'ack-3585');
COMMIT;
SELECT 'ack', 3585;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3586, 2, X'76616C75652D3030303033353836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3586, 'wal', 'ack-3586');
COMMIT;
SELECT 'ack', 3586;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3587, 3, X'76616C75652D3030303033353837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3587, 'wal', 'ack-3587');
COMMIT;
SELECT 'ack', 3587;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3588, 4, X'76616C75652D3030303033353838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3588, 'wal', 'ack-3588');
COMMIT;
SELECT 'ack', 3588;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3589, 5, X'76616C75652D3030303033353839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3589, 'wal', 'ack-3589');
COMMIT;
SELECT 'ack', 3589;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3590, 6, X'76616C75652D3030303033353930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3590, 'wal', 'ack-3590');
COMMIT;
SELECT 'ack', 3590;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3591, 7, X'76616C75652D3030303033353931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3591, 'wal', 'ack-3591');
COMMIT;
SELECT 'ack', 3591;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3592, 8, X'76616C75652D3030303033353932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3592, 'wal', 'ack-3592');
COMMIT;
SELECT 'ack', 3592;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3593, 9, X'76616C75652D3030303033353933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3593, 'wal', 'ack-3593');
COMMIT;
SELECT 'ack', 3593;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3594, 10, X'76616C75652D3030303033353934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3594, 'wal', 'ack-3594');
COMMIT;
SELECT 'ack', 3594;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3595, 11, X'76616C75652D3030303033353935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3595, 'wal', 'ack-3595');
COMMIT;
SELECT 'ack', 3595;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3596, 12, X'76616C75652D3030303033353936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3596, 'wal', 'ack-3596');
COMMIT;
SELECT 'ack', 3596;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3597, 13, X'76616C75652D3030303033353937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3597, 'wal', 'ack-3597');
COMMIT;
SELECT 'ack', 3597;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3598, 14, X'76616C75652D3030303033353938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3598, 'wal', 'ack-3598');
COMMIT;
SELECT 'ack', 3598;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3599, 15, X'76616C75652D3030303033353939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3599, 'wal', 'ack-3599');
COMMIT;
SELECT 'ack', 3599;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3600, 16, X'76616C75652D3030303033363030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3600, 'wal', 'ack-3600');
COMMIT;
SELECT 'ack', 3600;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3601, 17, X'76616C75652D3030303033363031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3601, 'wal', 'ack-3601');
COMMIT;
SELECT 'ack', 3601;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3602, 18, X'76616C75652D3030303033363032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3602, 'wal', 'ack-3602');
COMMIT;
SELECT 'ack', 3602;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3603, 19, X'76616C75652D3030303033363033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3603, 'wal', 'ack-3603');
COMMIT;
SELECT 'ack', 3603;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3604, 20, X'76616C75652D3030303033363034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3604, 'wal', 'ack-3604');
COMMIT;
SELECT 'ack', 3604;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3605, 21, X'76616C75652D3030303033363035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3605, 'wal', 'ack-3605');
COMMIT;
SELECT 'ack', 3605;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3606, 22, X'76616C75652D3030303033363036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3606, 'wal', 'ack-3606');
COMMIT;
SELECT 'ack', 3606;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3607, 23, X'76616C75652D3030303033363037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3607, 'wal', 'ack-3607');
COMMIT;
SELECT 'ack', 3607;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3608, 24, X'76616C75652D3030303033363038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3608, 'wal', 'ack-3608');
COMMIT;
SELECT 'ack', 3608;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3609, 25, X'76616C75652D3030303033363039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3609, 'wal', 'ack-3609');
COMMIT;
SELECT 'ack', 3609;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3610, 26, X'76616C75652D3030303033363130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3610, 'wal', 'ack-3610');
COMMIT;
SELECT 'ack', 3610;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3611, 27, X'76616C75652D3030303033363131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3611, 'wal', 'ack-3611');
COMMIT;
SELECT 'ack', 3611;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3612, 28, X'76616C75652D3030303033363132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3612, 'wal', 'ack-3612');
COMMIT;
SELECT 'ack', 3612;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3613, 29, X'76616C75652D3030303033363133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3613, 'wal', 'ack-3613');
COMMIT;
SELECT 'ack', 3613;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3614, 30, X'76616C75652D3030303033363134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3614, 'wal', 'ack-3614');
COMMIT;
SELECT 'ack', 3614;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3615, 31, X'76616C75652D3030303033363135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3615, 'wal', 'ack-3615');
COMMIT;
SELECT 'ack', 3615;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3616, 0, X'76616C75652D3030303033363136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3616, 'wal', 'ack-3616');
COMMIT;
SELECT 'ack', 3616;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3617, 1, X'76616C75652D3030303033363137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3617, 'wal', 'ack-3617');
COMMIT;
SELECT 'ack', 3617;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3618, 2, X'76616C75652D3030303033363138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3618, 'wal', 'ack-3618');
COMMIT;
SELECT 'ack', 3618;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3619, 3, X'76616C75652D3030303033363139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3619, 'wal', 'ack-3619');
COMMIT;
SELECT 'ack', 3619;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3620, 4, X'76616C75652D3030303033363230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3620, 'wal', 'ack-3620');
COMMIT;
SELECT 'ack', 3620;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3621, 5, X'76616C75652D3030303033363231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3621, 'wal', 'ack-3621');
COMMIT;
SELECT 'ack', 3621;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3622, 6, X'76616C75652D3030303033363232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3622, 'wal', 'ack-3622');
COMMIT;
SELECT 'ack', 3622;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3623, 7, X'76616C75652D3030303033363233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3623, 'wal', 'ack-3623');
COMMIT;
SELECT 'ack', 3623;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3624, 8, X'76616C75652D3030303033363234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3624, 'wal', 'ack-3624');
COMMIT;
SELECT 'ack', 3624;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3625, 9, X'76616C75652D3030303033363235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3625, 'wal', 'ack-3625');
COMMIT;
SELECT 'ack', 3625;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3626, 10, X'76616C75652D3030303033363236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3626, 'wal', 'ack-3626');
COMMIT;
SELECT 'ack', 3626;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3627, 11, X'76616C75652D3030303033363237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3627, 'wal', 'ack-3627');
COMMIT;
SELECT 'ack', 3627;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3628, 12, X'76616C75652D3030303033363238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3628, 'wal', 'ack-3628');
COMMIT;
SELECT 'ack', 3628;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3629, 13, X'76616C75652D3030303033363239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3629, 'wal', 'ack-3629');
COMMIT;
SELECT 'ack', 3629;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3630, 14, X'76616C75652D3030303033363330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3630, 'wal', 'ack-3630');
COMMIT;
SELECT 'ack', 3630;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3631, 15, X'76616C75652D3030303033363331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3631, 'wal', 'ack-3631');
COMMIT;
SELECT 'ack', 3631;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3632, 16, X'76616C75652D3030303033363332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3632, 'wal', 'ack-3632');
COMMIT;
SELECT 'ack', 3632;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3633, 17, X'76616C75652D3030303033363333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3633, 'wal', 'ack-3633');
COMMIT;
SELECT 'ack', 3633;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3634, 18, X'76616C75652D3030303033363334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3634, 'wal', 'ack-3634');
COMMIT;
SELECT 'ack', 3634;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3635, 19, X'76616C75652D3030303033363335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3635, 'wal', 'ack-3635');
COMMIT;
SELECT 'ack', 3635;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3636, 20, X'76616C75652D3030303033363336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3636, 'wal', 'ack-3636');
COMMIT;
SELECT 'ack', 3636;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3637, 21, X'76616C75652D3030303033363337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3637, 'wal', 'ack-3637');
COMMIT;
SELECT 'ack', 3637;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3638, 22, X'76616C75652D3030303033363338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3638, 'wal', 'ack-3638');
COMMIT;
SELECT 'ack', 3638;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3639, 23, X'76616C75652D3030303033363339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3639, 'wal', 'ack-3639');
COMMIT;
SELECT 'ack', 3639;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3640, 24, X'76616C75652D3030303033363430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3640, 'wal', 'ack-3640');
COMMIT;
SELECT 'ack', 3640;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3641, 25, X'76616C75652D3030303033363431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3641, 'wal', 'ack-3641');
COMMIT;
SELECT 'ack', 3641;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3642, 26, X'76616C75652D3030303033363432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3642, 'wal', 'ack-3642');
COMMIT;
SELECT 'ack', 3642;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3643, 27, X'76616C75652D3030303033363433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3643, 'wal', 'ack-3643');
COMMIT;
SELECT 'ack', 3643;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3644, 28, X'76616C75652D3030303033363434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3644, 'wal', 'ack-3644');
COMMIT;
SELECT 'ack', 3644;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3645, 29, X'76616C75652D3030303033363435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3645, 'wal', 'ack-3645');
COMMIT;
SELECT 'ack', 3645;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3646, 30, X'76616C75652D3030303033363436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3646, 'wal', 'ack-3646');
COMMIT;
SELECT 'ack', 3646;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3647, 31, X'76616C75652D3030303033363437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3647, 'wal', 'ack-3647');
COMMIT;
SELECT 'ack', 3647;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3648, 0, X'76616C75652D3030303033363438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3648, 'wal', 'ack-3648');
COMMIT;
SELECT 'ack', 3648;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3649, 1, X'76616C75652D3030303033363439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3649, 'wal', 'ack-3649');
COMMIT;
SELECT 'ack', 3649;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3650, 2, X'76616C75652D3030303033363530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3650, 'wal', 'ack-3650');
COMMIT;
SELECT 'ack', 3650;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3651, 3, X'76616C75652D3030303033363531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3651, 'wal', 'ack-3651');
COMMIT;
SELECT 'ack', 3651;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3652, 4, X'76616C75652D3030303033363532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3652, 'wal', 'ack-3652');
COMMIT;
SELECT 'ack', 3652;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3653, 5, X'76616C75652D3030303033363533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3653, 'wal', 'ack-3653');
COMMIT;
SELECT 'ack', 3653;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3654, 6, X'76616C75652D3030303033363534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3654, 'wal', 'ack-3654');
COMMIT;
SELECT 'ack', 3654;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3655, 7, X'76616C75652D3030303033363535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3655, 'wal', 'ack-3655');
COMMIT;
SELECT 'ack', 3655;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3656, 8, X'76616C75652D3030303033363536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3656, 'wal', 'ack-3656');
COMMIT;
SELECT 'ack', 3656;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3657, 9, X'76616C75652D3030303033363537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3657, 'wal', 'ack-3657');
COMMIT;
SELECT 'ack', 3657;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3658, 10, X'76616C75652D3030303033363538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3658, 'wal', 'ack-3658');
COMMIT;
SELECT 'ack', 3658;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3659, 11, X'76616C75652D3030303033363539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3659, 'wal', 'ack-3659');
COMMIT;
SELECT 'ack', 3659;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3660, 12, X'76616C75652D3030303033363630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3660, 'wal', 'ack-3660');
COMMIT;
SELECT 'ack', 3660;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3661, 13, X'76616C75652D3030303033363631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3661, 'wal', 'ack-3661');
COMMIT;
SELECT 'ack', 3661;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3662, 14, X'76616C75652D3030303033363632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3662, 'wal', 'ack-3662');
COMMIT;
SELECT 'ack', 3662;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3663, 15, X'76616C75652D3030303033363633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3663, 'wal', 'ack-3663');
COMMIT;
SELECT 'ack', 3663;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3664, 16, X'76616C75652D3030303033363634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3664, 'wal', 'ack-3664');
COMMIT;
SELECT 'ack', 3664;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3665, 17, X'76616C75652D3030303033363635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3665, 'wal', 'ack-3665');
COMMIT;
SELECT 'ack', 3665;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3666, 18, X'76616C75652D3030303033363636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3666, 'wal', 'ack-3666');
COMMIT;
SELECT 'ack', 3666;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3667, 19, X'76616C75652D3030303033363637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3667, 'wal', 'ack-3667');
COMMIT;
SELECT 'ack', 3667;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3668, 20, X'76616C75652D3030303033363638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3668, 'wal', 'ack-3668');
COMMIT;
SELECT 'ack', 3668;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3669, 21, X'76616C75652D3030303033363639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3669, 'wal', 'ack-3669');
COMMIT;
SELECT 'ack', 3669;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3670, 22, X'76616C75652D3030303033363730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3670, 'wal', 'ack-3670');
COMMIT;
SELECT 'ack', 3670;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3671, 23, X'76616C75652D3030303033363731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3671, 'wal', 'ack-3671');
COMMIT;
SELECT 'ack', 3671;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3672, 24, X'76616C75652D3030303033363732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3672, 'wal', 'ack-3672');
COMMIT;
SELECT 'ack', 3672;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3673, 25, X'76616C75652D3030303033363733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3673, 'wal', 'ack-3673');
COMMIT;
SELECT 'ack', 3673;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3674, 26, X'76616C75652D3030303033363734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3674, 'wal', 'ack-3674');
COMMIT;
SELECT 'ack', 3674;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3675, 27, X'76616C75652D3030303033363735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3675, 'wal', 'ack-3675');
COMMIT;
SELECT 'ack', 3675;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3676, 28, X'76616C75652D3030303033363736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3676, 'wal', 'ack-3676');
COMMIT;
SELECT 'ack', 3676;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3677, 29, X'76616C75652D3030303033363737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3677, 'wal', 'ack-3677');
COMMIT;
SELECT 'ack', 3677;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3678, 30, X'76616C75652D3030303033363738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3678, 'wal', 'ack-3678');
COMMIT;
SELECT 'ack', 3678;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3679, 31, X'76616C75652D3030303033363739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3679, 'wal', 'ack-3679');
COMMIT;
SELECT 'ack', 3679;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3680, 0, X'76616C75652D3030303033363830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3680, 'wal', 'ack-3680');
COMMIT;
SELECT 'ack', 3680;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3681, 1, X'76616C75652D3030303033363831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3681, 'wal', 'ack-3681');
COMMIT;
SELECT 'ack', 3681;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3682, 2, X'76616C75652D3030303033363832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3682, 'wal', 'ack-3682');
COMMIT;
SELECT 'ack', 3682;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3683, 3, X'76616C75652D3030303033363833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3683, 'wal', 'ack-3683');
COMMIT;
SELECT 'ack', 3683;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3684, 4, X'76616C75652D3030303033363834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3684, 'wal', 'ack-3684');
COMMIT;
SELECT 'ack', 3684;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3685, 5, X'76616C75652D3030303033363835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3685, 'wal', 'ack-3685');
COMMIT;
SELECT 'ack', 3685;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3686, 6, X'76616C75652D3030303033363836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3686, 'wal', 'ack-3686');
COMMIT;
SELECT 'ack', 3686;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3687, 7, X'76616C75652D3030303033363837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3687, 'wal', 'ack-3687');
COMMIT;
SELECT 'ack', 3687;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3688, 8, X'76616C75652D3030303033363838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3688, 'wal', 'ack-3688');
COMMIT;
SELECT 'ack', 3688;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3689, 9, X'76616C75652D3030303033363839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3689, 'wal', 'ack-3689');
COMMIT;
SELECT 'ack', 3689;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3690, 10, X'76616C75652D3030303033363930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3690, 'wal', 'ack-3690');
COMMIT;
SELECT 'ack', 3690;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3691, 11, X'76616C75652D3030303033363931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3691, 'wal', 'ack-3691');
COMMIT;
SELECT 'ack', 3691;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3692, 12, X'76616C75652D3030303033363932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3692, 'wal', 'ack-3692');
COMMIT;
SELECT 'ack', 3692;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3693, 13, X'76616C75652D3030303033363933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3693, 'wal', 'ack-3693');
COMMIT;
SELECT 'ack', 3693;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3694, 14, X'76616C75652D3030303033363934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3694, 'wal', 'ack-3694');
COMMIT;
SELECT 'ack', 3694;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3695, 15, X'76616C75652D3030303033363935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3695, 'wal', 'ack-3695');
COMMIT;
SELECT 'ack', 3695;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3696, 16, X'76616C75652D3030303033363936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3696, 'wal', 'ack-3696');
COMMIT;
SELECT 'ack', 3696;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3697, 17, X'76616C75652D3030303033363937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3697, 'wal', 'ack-3697');
COMMIT;
SELECT 'ack', 3697;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3698, 18, X'76616C75652D3030303033363938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3698, 'wal', 'ack-3698');
COMMIT;
SELECT 'ack', 3698;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3699, 19, X'76616C75652D3030303033363939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3699, 'wal', 'ack-3699');
COMMIT;
SELECT 'ack', 3699;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3700, 20, X'76616C75652D3030303033373030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3700, 'wal', 'ack-3700');
COMMIT;
SELECT 'ack', 3700;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3701, 21, X'76616C75652D3030303033373031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3701, 'wal', 'ack-3701');
COMMIT;
SELECT 'ack', 3701;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3702, 22, X'76616C75652D3030303033373032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3702, 'wal', 'ack-3702');
COMMIT;
SELECT 'ack', 3702;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3703, 23, X'76616C75652D3030303033373033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3703, 'wal', 'ack-3703');
COMMIT;
SELECT 'ack', 3703;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3704, 24, X'76616C75652D3030303033373034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3704, 'wal', 'ack-3704');
COMMIT;
SELECT 'ack', 3704;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3705, 25, X'76616C75652D3030303033373035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3705, 'wal', 'ack-3705');
COMMIT;
SELECT 'ack', 3705;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3706, 26, X'76616C75652D3030303033373036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3706, 'wal', 'ack-3706');
COMMIT;
SELECT 'ack', 3706;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3707, 27, X'76616C75652D3030303033373037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3707, 'wal', 'ack-3707');
COMMIT;
SELECT 'ack', 3707;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3708, 28, X'76616C75652D3030303033373038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3708, 'wal', 'ack-3708');
COMMIT;
SELECT 'ack', 3708;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3709, 29, X'76616C75652D3030303033373039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3709, 'wal', 'ack-3709');
COMMIT;
SELECT 'ack', 3709;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3710, 30, X'76616C75652D3030303033373130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3710, 'wal', 'ack-3710');
COMMIT;
SELECT 'ack', 3710;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3711, 31, X'76616C75652D3030303033373131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3711, 'wal', 'ack-3711');
COMMIT;
SELECT 'ack', 3711;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3712, 0, X'76616C75652D3030303033373132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3712, 'wal', 'ack-3712');
COMMIT;
SELECT 'ack', 3712;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3713, 1, X'76616C75652D3030303033373133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3713, 'wal', 'ack-3713');
COMMIT;
SELECT 'ack', 3713;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3714, 2, X'76616C75652D3030303033373134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3714, 'wal', 'ack-3714');
COMMIT;
SELECT 'ack', 3714;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3715, 3, X'76616C75652D3030303033373135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3715, 'wal', 'ack-3715');
COMMIT;
SELECT 'ack', 3715;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3716, 4, X'76616C75652D3030303033373136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3716, 'wal', 'ack-3716');
COMMIT;
SELECT 'ack', 3716;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3717, 5, X'76616C75652D3030303033373137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3717, 'wal', 'ack-3717');
COMMIT;
SELECT 'ack', 3717;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3718, 6, X'76616C75652D3030303033373138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3718, 'wal', 'ack-3718');
COMMIT;
SELECT 'ack', 3718;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3719, 7, X'76616C75652D3030303033373139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3719, 'wal', 'ack-3719');
COMMIT;
SELECT 'ack', 3719;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3720, 8, X'76616C75652D3030303033373230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3720, 'wal', 'ack-3720');
COMMIT;
SELECT 'ack', 3720;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3721, 9, X'76616C75652D3030303033373231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3721, 'wal', 'ack-3721');
COMMIT;
SELECT 'ack', 3721;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3722, 10, X'76616C75652D3030303033373232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3722, 'wal', 'ack-3722');
COMMIT;
SELECT 'ack', 3722;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3723, 11, X'76616C75652D3030303033373233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3723, 'wal', 'ack-3723');
COMMIT;
SELECT 'ack', 3723;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3724, 12, X'76616C75652D3030303033373234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3724, 'wal', 'ack-3724');
COMMIT;
SELECT 'ack', 3724;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3725, 13, X'76616C75652D3030303033373235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3725, 'wal', 'ack-3725');
COMMIT;
SELECT 'ack', 3725;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3726, 14, X'76616C75652D3030303033373236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3726, 'wal', 'ack-3726');
COMMIT;
SELECT 'ack', 3726;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3727, 15, X'76616C75652D3030303033373237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3727, 'wal', 'ack-3727');
COMMIT;
SELECT 'ack', 3727;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3728, 16, X'76616C75652D3030303033373238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3728, 'wal', 'ack-3728');
COMMIT;
SELECT 'ack', 3728;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3729, 17, X'76616C75652D3030303033373239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3729, 'wal', 'ack-3729');
COMMIT;
SELECT 'ack', 3729;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3730, 18, X'76616C75652D3030303033373330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3730, 'wal', 'ack-3730');
COMMIT;
SELECT 'ack', 3730;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3731, 19, X'76616C75652D3030303033373331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3731, 'wal', 'ack-3731');
COMMIT;
SELECT 'ack', 3731;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3732, 20, X'76616C75652D3030303033373332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3732, 'wal', 'ack-3732');
COMMIT;
SELECT 'ack', 3732;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3733, 21, X'76616C75652D3030303033373333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3733, 'wal', 'ack-3733');
COMMIT;
SELECT 'ack', 3733;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3734, 22, X'76616C75652D3030303033373334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3734, 'wal', 'ack-3734');
COMMIT;
SELECT 'ack', 3734;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3735, 23, X'76616C75652D3030303033373335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3735, 'wal', 'ack-3735');
COMMIT;
SELECT 'ack', 3735;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3736, 24, X'76616C75652D3030303033373336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3736, 'wal', 'ack-3736');
COMMIT;
SELECT 'ack', 3736;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3737, 25, X'76616C75652D3030303033373337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3737, 'wal', 'ack-3737');
COMMIT;
SELECT 'ack', 3737;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3738, 26, X'76616C75652D3030303033373338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3738, 'wal', 'ack-3738');
COMMIT;
SELECT 'ack', 3738;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3739, 27, X'76616C75652D3030303033373339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3739, 'wal', 'ack-3739');
COMMIT;
SELECT 'ack', 3739;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3740, 28, X'76616C75652D3030303033373430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3740, 'wal', 'ack-3740');
COMMIT;
SELECT 'ack', 3740;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3741, 29, X'76616C75652D3030303033373431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3741, 'wal', 'ack-3741');
COMMIT;
SELECT 'ack', 3741;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3742, 30, X'76616C75652D3030303033373432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3742, 'wal', 'ack-3742');
COMMIT;
SELECT 'ack', 3742;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3743, 31, X'76616C75652D3030303033373433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3743, 'wal', 'ack-3743');
COMMIT;
SELECT 'ack', 3743;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3744, 0, X'76616C75652D3030303033373434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3744, 'wal', 'ack-3744');
COMMIT;
SELECT 'ack', 3744;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3745, 1, X'76616C75652D3030303033373435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3745, 'wal', 'ack-3745');
COMMIT;
SELECT 'ack', 3745;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3746, 2, X'76616C75652D3030303033373436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3746, 'wal', 'ack-3746');
COMMIT;
SELECT 'ack', 3746;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3747, 3, X'76616C75652D3030303033373437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3747, 'wal', 'ack-3747');
COMMIT;
SELECT 'ack', 3747;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3748, 4, X'76616C75652D3030303033373438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3748, 'wal', 'ack-3748');
COMMIT;
SELECT 'ack', 3748;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3749, 5, X'76616C75652D3030303033373439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3749, 'wal', 'ack-3749');
COMMIT;
SELECT 'ack', 3749;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3750, 6, X'76616C75652D3030303033373530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3750, 'wal', 'ack-3750');
COMMIT;
SELECT 'ack', 3750;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3751, 7, X'76616C75652D3030303033373531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3751, 'wal', 'ack-3751');
COMMIT;
SELECT 'ack', 3751;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3752, 8, X'76616C75652D3030303033373532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3752, 'wal', 'ack-3752');
COMMIT;
SELECT 'ack', 3752;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3753, 9, X'76616C75652D3030303033373533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3753, 'wal', 'ack-3753');
COMMIT;
SELECT 'ack', 3753;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3754, 10, X'76616C75652D3030303033373534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3754, 'wal', 'ack-3754');
COMMIT;
SELECT 'ack', 3754;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3755, 11, X'76616C75652D3030303033373535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3755, 'wal', 'ack-3755');
COMMIT;
SELECT 'ack', 3755;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3756, 12, X'76616C75652D3030303033373536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3756, 'wal', 'ack-3756');
COMMIT;
SELECT 'ack', 3756;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3757, 13, X'76616C75652D3030303033373537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3757, 'wal', 'ack-3757');
COMMIT;
SELECT 'ack', 3757;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3758, 14, X'76616C75652D3030303033373538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3758, 'wal', 'ack-3758');
COMMIT;
SELECT 'ack', 3758;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3759, 15, X'76616C75652D3030303033373539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3759, 'wal', 'ack-3759');
COMMIT;
SELECT 'ack', 3759;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3760, 16, X'76616C75652D3030303033373630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3760, 'wal', 'ack-3760');
COMMIT;
SELECT 'ack', 3760;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3761, 17, X'76616C75652D3030303033373631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3761, 'wal', 'ack-3761');
COMMIT;
SELECT 'ack', 3761;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3762, 18, X'76616C75652D3030303033373632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3762, 'wal', 'ack-3762');
COMMIT;
SELECT 'ack', 3762;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3763, 19, X'76616C75652D3030303033373633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3763, 'wal', 'ack-3763');
COMMIT;
SELECT 'ack', 3763;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3764, 20, X'76616C75652D3030303033373634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3764, 'wal', 'ack-3764');
COMMIT;
SELECT 'ack', 3764;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3765, 21, X'76616C75652D3030303033373635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3765, 'wal', 'ack-3765');
COMMIT;
SELECT 'ack', 3765;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3766, 22, X'76616C75652D3030303033373636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3766, 'wal', 'ack-3766');
COMMIT;
SELECT 'ack', 3766;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3767, 23, X'76616C75652D3030303033373637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3767, 'wal', 'ack-3767');
COMMIT;
SELECT 'ack', 3767;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3768, 24, X'76616C75652D3030303033373638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3768, 'wal', 'ack-3768');
COMMIT;
SELECT 'ack', 3768;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3769, 25, X'76616C75652D3030303033373639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3769, 'wal', 'ack-3769');
COMMIT;
SELECT 'ack', 3769;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3770, 26, X'76616C75652D3030303033373730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3770, 'wal', 'ack-3770');
COMMIT;
SELECT 'ack', 3770;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3771, 27, X'76616C75652D3030303033373731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3771, 'wal', 'ack-3771');
COMMIT;
SELECT 'ack', 3771;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3772, 28, X'76616C75652D3030303033373732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3772, 'wal', 'ack-3772');
COMMIT;
SELECT 'ack', 3772;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3773, 29, X'76616C75652D3030303033373733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3773, 'wal', 'ack-3773');
COMMIT;
SELECT 'ack', 3773;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3774, 30, X'76616C75652D3030303033373734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3774, 'wal', 'ack-3774');
COMMIT;
SELECT 'ack', 3774;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3775, 31, X'76616C75652D3030303033373735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3775, 'wal', 'ack-3775');
COMMIT;
SELECT 'ack', 3775;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3776, 0, X'76616C75652D3030303033373736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3776, 'wal', 'ack-3776');
COMMIT;
SELECT 'ack', 3776;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3777, 1, X'76616C75652D3030303033373737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3777, 'wal', 'ack-3777');
COMMIT;
SELECT 'ack', 3777;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3778, 2, X'76616C75652D3030303033373738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3778, 'wal', 'ack-3778');
COMMIT;
SELECT 'ack', 3778;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3779, 3, X'76616C75652D3030303033373739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3779, 'wal', 'ack-3779');
COMMIT;
SELECT 'ack', 3779;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3780, 4, X'76616C75652D3030303033373830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3780, 'wal', 'ack-3780');
COMMIT;
SELECT 'ack', 3780;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3781, 5, X'76616C75652D3030303033373831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3781, 'wal', 'ack-3781');
COMMIT;
SELECT 'ack', 3781;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3782, 6, X'76616C75652D3030303033373832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3782, 'wal', 'ack-3782');
COMMIT;
SELECT 'ack', 3782;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3783, 7, X'76616C75652D3030303033373833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3783, 'wal', 'ack-3783');
COMMIT;
SELECT 'ack', 3783;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3784, 8, X'76616C75652D3030303033373834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3784, 'wal', 'ack-3784');
COMMIT;
SELECT 'ack', 3784;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3785, 9, X'76616C75652D3030303033373835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3785, 'wal', 'ack-3785');
COMMIT;
SELECT 'ack', 3785;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3786, 10, X'76616C75652D3030303033373836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3786, 'wal', 'ack-3786');
COMMIT;
SELECT 'ack', 3786;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3787, 11, X'76616C75652D3030303033373837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3787, 'wal', 'ack-3787');
COMMIT;
SELECT 'ack', 3787;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3788, 12, X'76616C75652D3030303033373838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3788, 'wal', 'ack-3788');
COMMIT;
SELECT 'ack', 3788;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3789, 13, X'76616C75652D3030303033373839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3789, 'wal', 'ack-3789');
COMMIT;
SELECT 'ack', 3789;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3790, 14, X'76616C75652D3030303033373930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3790, 'wal', 'ack-3790');
COMMIT;
SELECT 'ack', 3790;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3791, 15, X'76616C75652D3030303033373931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3791, 'wal', 'ack-3791');
COMMIT;
SELECT 'ack', 3791;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3792, 16, X'76616C75652D3030303033373932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3792, 'wal', 'ack-3792');
COMMIT;
SELECT 'ack', 3792;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3793, 17, X'76616C75652D3030303033373933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3793, 'wal', 'ack-3793');
COMMIT;
SELECT 'ack', 3793;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3794, 18, X'76616C75652D3030303033373934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3794, 'wal', 'ack-3794');
COMMIT;
SELECT 'ack', 3794;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3795, 19, X'76616C75652D3030303033373935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3795, 'wal', 'ack-3795');
COMMIT;
SELECT 'ack', 3795;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3796, 20, X'76616C75652D3030303033373936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3796, 'wal', 'ack-3796');
COMMIT;
SELECT 'ack', 3796;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3797, 21, X'76616C75652D3030303033373937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3797, 'wal', 'ack-3797');
COMMIT;
SELECT 'ack', 3797;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3798, 22, X'76616C75652D3030303033373938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3798, 'wal', 'ack-3798');
COMMIT;
SELECT 'ack', 3798;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3799, 23, X'76616C75652D3030303033373939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3799, 'wal', 'ack-3799');
COMMIT;
SELECT 'ack', 3799;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3800, 24, X'76616C75652D3030303033383030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3800, 'wal', 'ack-3800');
COMMIT;
SELECT 'ack', 3800;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3801, 25, X'76616C75652D3030303033383031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3801, 'wal', 'ack-3801');
COMMIT;
SELECT 'ack', 3801;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3802, 26, X'76616C75652D3030303033383032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3802, 'wal', 'ack-3802');
COMMIT;
SELECT 'ack', 3802;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3803, 27, X'76616C75652D3030303033383033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3803, 'wal', 'ack-3803');
COMMIT;
SELECT 'ack', 3803;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3804, 28, X'76616C75652D3030303033383034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3804, 'wal', 'ack-3804');
COMMIT;
SELECT 'ack', 3804;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3805, 29, X'76616C75652D3030303033383035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3805, 'wal', 'ack-3805');
COMMIT;
SELECT 'ack', 3805;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3806, 30, X'76616C75652D3030303033383036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3806, 'wal', 'ack-3806');
COMMIT;
SELECT 'ack', 3806;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3807, 31, X'76616C75652D3030303033383037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3807, 'wal', 'ack-3807');
COMMIT;
SELECT 'ack', 3807;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3808, 0, X'76616C75652D3030303033383038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3808, 'wal', 'ack-3808');
COMMIT;
SELECT 'ack', 3808;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3809, 1, X'76616C75652D3030303033383039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3809, 'wal', 'ack-3809');
COMMIT;
SELECT 'ack', 3809;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3810, 2, X'76616C75652D3030303033383130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3810, 'wal', 'ack-3810');
COMMIT;
SELECT 'ack', 3810;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3811, 3, X'76616C75652D3030303033383131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3811, 'wal', 'ack-3811');
COMMIT;
SELECT 'ack', 3811;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3812, 4, X'76616C75652D3030303033383132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3812, 'wal', 'ack-3812');
COMMIT;
SELECT 'ack', 3812;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3813, 5, X'76616C75652D3030303033383133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3813, 'wal', 'ack-3813');
COMMIT;
SELECT 'ack', 3813;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3814, 6, X'76616C75652D3030303033383134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3814, 'wal', 'ack-3814');
COMMIT;
SELECT 'ack', 3814;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3815, 7, X'76616C75652D3030303033383135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3815, 'wal', 'ack-3815');
COMMIT;
SELECT 'ack', 3815;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3816, 8, X'76616C75652D3030303033383136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3816, 'wal', 'ack-3816');
COMMIT;
SELECT 'ack', 3816;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3817, 9, X'76616C75652D3030303033383137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3817, 'wal', 'ack-3817');
COMMIT;
SELECT 'ack', 3817;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3818, 10, X'76616C75652D3030303033383138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3818, 'wal', 'ack-3818');
COMMIT;
SELECT 'ack', 3818;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3819, 11, X'76616C75652D3030303033383139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3819, 'wal', 'ack-3819');
COMMIT;
SELECT 'ack', 3819;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3820, 12, X'76616C75652D3030303033383230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3820, 'wal', 'ack-3820');
COMMIT;
SELECT 'ack', 3820;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3821, 13, X'76616C75652D3030303033383231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3821, 'wal', 'ack-3821');
COMMIT;
SELECT 'ack', 3821;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3822, 14, X'76616C75652D3030303033383232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3822, 'wal', 'ack-3822');
COMMIT;
SELECT 'ack', 3822;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3823, 15, X'76616C75652D3030303033383233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3823, 'wal', 'ack-3823');
COMMIT;
SELECT 'ack', 3823;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3824, 16, X'76616C75652D3030303033383234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3824, 'wal', 'ack-3824');
COMMIT;
SELECT 'ack', 3824;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3825, 17, X'76616C75652D3030303033383235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3825, 'wal', 'ack-3825');
COMMIT;
SELECT 'ack', 3825;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3826, 18, X'76616C75652D3030303033383236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3826, 'wal', 'ack-3826');
COMMIT;
SELECT 'ack', 3826;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3827, 19, X'76616C75652D3030303033383237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3827, 'wal', 'ack-3827');
COMMIT;
SELECT 'ack', 3827;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3828, 20, X'76616C75652D3030303033383238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3828, 'wal', 'ack-3828');
COMMIT;
SELECT 'ack', 3828;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3829, 21, X'76616C75652D3030303033383239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3829, 'wal', 'ack-3829');
COMMIT;
SELECT 'ack', 3829;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3830, 22, X'76616C75652D3030303033383330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3830, 'wal', 'ack-3830');
COMMIT;
SELECT 'ack', 3830;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3831, 23, X'76616C75652D3030303033383331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3831, 'wal', 'ack-3831');
COMMIT;
SELECT 'ack', 3831;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3832, 24, X'76616C75652D3030303033383332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3832, 'wal', 'ack-3832');
COMMIT;
SELECT 'ack', 3832;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3833, 25, X'76616C75652D3030303033383333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3833, 'wal', 'ack-3833');
COMMIT;
SELECT 'ack', 3833;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3834, 26, X'76616C75652D3030303033383334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3834, 'wal', 'ack-3834');
COMMIT;
SELECT 'ack', 3834;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3835, 27, X'76616C75652D3030303033383335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3835, 'wal', 'ack-3835');
COMMIT;
SELECT 'ack', 3835;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3836, 28, X'76616C75652D3030303033383336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3836, 'wal', 'ack-3836');
COMMIT;
SELECT 'ack', 3836;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3837, 29, X'76616C75652D3030303033383337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3837, 'wal', 'ack-3837');
COMMIT;
SELECT 'ack', 3837;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3838, 30, X'76616C75652D3030303033383338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3838, 'wal', 'ack-3838');
COMMIT;
SELECT 'ack', 3838;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3839, 31, X'76616C75652D3030303033383339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3839, 'wal', 'ack-3839');
COMMIT;
SELECT 'ack', 3839;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3840, 0, X'76616C75652D3030303033383430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3840, 'wal', 'ack-3840');
COMMIT;
SELECT 'ack', 3840;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3841, 1, X'76616C75652D3030303033383431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3841, 'wal', 'ack-3841');
COMMIT;
SELECT 'ack', 3841;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3842, 2, X'76616C75652D3030303033383432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3842, 'wal', 'ack-3842');
COMMIT;
SELECT 'ack', 3842;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3843, 3, X'76616C75652D3030303033383433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3843, 'wal', 'ack-3843');
COMMIT;
SELECT 'ack', 3843;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3844, 4, X'76616C75652D3030303033383434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3844, 'wal', 'ack-3844');
COMMIT;
SELECT 'ack', 3844;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3845, 5, X'76616C75652D3030303033383435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3845, 'wal', 'ack-3845');
COMMIT;
SELECT 'ack', 3845;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3846, 6, X'76616C75652D3030303033383436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3846, 'wal', 'ack-3846');
COMMIT;
SELECT 'ack', 3846;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3847, 7, X'76616C75652D3030303033383437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3847, 'wal', 'ack-3847');
COMMIT;
SELECT 'ack', 3847;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3848, 8, X'76616C75652D3030303033383438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3848, 'wal', 'ack-3848');
COMMIT;
SELECT 'ack', 3848;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3849, 9, X'76616C75652D3030303033383439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3849, 'wal', 'ack-3849');
COMMIT;
SELECT 'ack', 3849;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3850, 10, X'76616C75652D3030303033383530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3850, 'wal', 'ack-3850');
COMMIT;
SELECT 'ack', 3850;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3851, 11, X'76616C75652D3030303033383531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3851, 'wal', 'ack-3851');
COMMIT;
SELECT 'ack', 3851;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3852, 12, X'76616C75652D3030303033383532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3852, 'wal', 'ack-3852');
COMMIT;
SELECT 'ack', 3852;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3853, 13, X'76616C75652D3030303033383533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3853, 'wal', 'ack-3853');
COMMIT;
SELECT 'ack', 3853;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3854, 14, X'76616C75652D3030303033383534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3854, 'wal', 'ack-3854');
COMMIT;
SELECT 'ack', 3854;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3855, 15, X'76616C75652D3030303033383535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3855, 'wal', 'ack-3855');
COMMIT;
SELECT 'ack', 3855;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3856, 16, X'76616C75652D3030303033383536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3856, 'wal', 'ack-3856');
COMMIT;
SELECT 'ack', 3856;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3857, 17, X'76616C75652D3030303033383537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3857, 'wal', 'ack-3857');
COMMIT;
SELECT 'ack', 3857;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3858, 18, X'76616C75652D3030303033383538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3858, 'wal', 'ack-3858');
COMMIT;
SELECT 'ack', 3858;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3859, 19, X'76616C75652D3030303033383539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3859, 'wal', 'ack-3859');
COMMIT;
SELECT 'ack', 3859;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3860, 20, X'76616C75652D3030303033383630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3860, 'wal', 'ack-3860');
COMMIT;
SELECT 'ack', 3860;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3861, 21, X'76616C75652D3030303033383631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3861, 'wal', 'ack-3861');
COMMIT;
SELECT 'ack', 3861;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3862, 22, X'76616C75652D3030303033383632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3862, 'wal', 'ack-3862');
COMMIT;
SELECT 'ack', 3862;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3863, 23, X'76616C75652D3030303033383633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3863, 'wal', 'ack-3863');
COMMIT;
SELECT 'ack', 3863;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3864, 24, X'76616C75652D3030303033383634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3864, 'wal', 'ack-3864');
COMMIT;
SELECT 'ack', 3864;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3865, 25, X'76616C75652D3030303033383635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3865, 'wal', 'ack-3865');
COMMIT;
SELECT 'ack', 3865;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3866, 26, X'76616C75652D3030303033383636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3866, 'wal', 'ack-3866');
COMMIT;
SELECT 'ack', 3866;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3867, 27, X'76616C75652D3030303033383637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3867, 'wal', 'ack-3867');
COMMIT;
SELECT 'ack', 3867;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3868, 28, X'76616C75652D3030303033383638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3868, 'wal', 'ack-3868');
COMMIT;
SELECT 'ack', 3868;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3869, 29, X'76616C75652D3030303033383639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3869, 'wal', 'ack-3869');
COMMIT;
SELECT 'ack', 3869;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3870, 30, X'76616C75652D3030303033383730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3870, 'wal', 'ack-3870');
COMMIT;
SELECT 'ack', 3870;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3871, 31, X'76616C75652D3030303033383731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3871, 'wal', 'ack-3871');
COMMIT;
SELECT 'ack', 3871;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3872, 0, X'76616C75652D3030303033383732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3872, 'wal', 'ack-3872');
COMMIT;
SELECT 'ack', 3872;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3873, 1, X'76616C75652D3030303033383733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3873, 'wal', 'ack-3873');
COMMIT;
SELECT 'ack', 3873;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3874, 2, X'76616C75652D3030303033383734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3874, 'wal', 'ack-3874');
COMMIT;
SELECT 'ack', 3874;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3875, 3, X'76616C75652D3030303033383735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3875, 'wal', 'ack-3875');
COMMIT;
SELECT 'ack', 3875;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3876, 4, X'76616C75652D3030303033383736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3876, 'wal', 'ack-3876');
COMMIT;
SELECT 'ack', 3876;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3877, 5, X'76616C75652D3030303033383737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3877, 'wal', 'ack-3877');
COMMIT;
SELECT 'ack', 3877;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3878, 6, X'76616C75652D3030303033383738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3878, 'wal', 'ack-3878');
COMMIT;
SELECT 'ack', 3878;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3879, 7, X'76616C75652D3030303033383739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3879, 'wal', 'ack-3879');
COMMIT;
SELECT 'ack', 3879;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3880, 8, X'76616C75652D3030303033383830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3880, 'wal', 'ack-3880');
COMMIT;
SELECT 'ack', 3880;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3881, 9, X'76616C75652D3030303033383831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3881, 'wal', 'ack-3881');
COMMIT;
SELECT 'ack', 3881;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3882, 10, X'76616C75652D3030303033383832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3882, 'wal', 'ack-3882');
COMMIT;
SELECT 'ack', 3882;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3883, 11, X'76616C75652D3030303033383833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3883, 'wal', 'ack-3883');
COMMIT;
SELECT 'ack', 3883;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3884, 12, X'76616C75652D3030303033383834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3884, 'wal', 'ack-3884');
COMMIT;
SELECT 'ack', 3884;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3885, 13, X'76616C75652D3030303033383835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3885, 'wal', 'ack-3885');
COMMIT;
SELECT 'ack', 3885;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3886, 14, X'76616C75652D3030303033383836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3886, 'wal', 'ack-3886');
COMMIT;
SELECT 'ack', 3886;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3887, 15, X'76616C75652D3030303033383837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3887, 'wal', 'ack-3887');
COMMIT;
SELECT 'ack', 3887;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3888, 16, X'76616C75652D3030303033383838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3888, 'wal', 'ack-3888');
COMMIT;
SELECT 'ack', 3888;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3889, 17, X'76616C75652D3030303033383839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3889, 'wal', 'ack-3889');
COMMIT;
SELECT 'ack', 3889;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3890, 18, X'76616C75652D3030303033383930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3890, 'wal', 'ack-3890');
COMMIT;
SELECT 'ack', 3890;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3891, 19, X'76616C75652D3030303033383931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3891, 'wal', 'ack-3891');
COMMIT;
SELECT 'ack', 3891;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3892, 20, X'76616C75652D3030303033383932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3892, 'wal', 'ack-3892');
COMMIT;
SELECT 'ack', 3892;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3893, 21, X'76616C75652D3030303033383933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3893, 'wal', 'ack-3893');
COMMIT;
SELECT 'ack', 3893;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3894, 22, X'76616C75652D3030303033383934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3894, 'wal', 'ack-3894');
COMMIT;
SELECT 'ack', 3894;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3895, 23, X'76616C75652D3030303033383935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3895, 'wal', 'ack-3895');
COMMIT;
SELECT 'ack', 3895;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3896, 24, X'76616C75652D3030303033383936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3896, 'wal', 'ack-3896');
COMMIT;
SELECT 'ack', 3896;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3897, 25, X'76616C75652D3030303033383937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3897, 'wal', 'ack-3897');
COMMIT;
SELECT 'ack', 3897;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3898, 26, X'76616C75652D3030303033383938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3898, 'wal', 'ack-3898');
COMMIT;
SELECT 'ack', 3898;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3899, 27, X'76616C75652D3030303033383939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3899, 'wal', 'ack-3899');
COMMIT;
SELECT 'ack', 3899;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3900, 28, X'76616C75652D3030303033393030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3900, 'wal', 'ack-3900');
COMMIT;
SELECT 'ack', 3900;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3901, 29, X'76616C75652D3030303033393031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3901, 'wal', 'ack-3901');
COMMIT;
SELECT 'ack', 3901;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3902, 30, X'76616C75652D3030303033393032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3902, 'wal', 'ack-3902');
COMMIT;
SELECT 'ack', 3902;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3903, 31, X'76616C75652D3030303033393033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3903, 'wal', 'ack-3903');
COMMIT;
SELECT 'ack', 3903;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3904, 0, X'76616C75652D3030303033393034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3904, 'wal', 'ack-3904');
COMMIT;
SELECT 'ack', 3904;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3905, 1, X'76616C75652D3030303033393035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3905, 'wal', 'ack-3905');
COMMIT;
SELECT 'ack', 3905;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3906, 2, X'76616C75652D3030303033393036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3906, 'wal', 'ack-3906');
COMMIT;
SELECT 'ack', 3906;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3907, 3, X'76616C75652D3030303033393037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3907, 'wal', 'ack-3907');
COMMIT;
SELECT 'ack', 3907;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3908, 4, X'76616C75652D3030303033393038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3908, 'wal', 'ack-3908');
COMMIT;
SELECT 'ack', 3908;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3909, 5, X'76616C75652D3030303033393039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3909, 'wal', 'ack-3909');
COMMIT;
SELECT 'ack', 3909;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3910, 6, X'76616C75652D3030303033393130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3910, 'wal', 'ack-3910');
COMMIT;
SELECT 'ack', 3910;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3911, 7, X'76616C75652D3030303033393131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3911, 'wal', 'ack-3911');
COMMIT;
SELECT 'ack', 3911;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3912, 8, X'76616C75652D3030303033393132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3912, 'wal', 'ack-3912');
COMMIT;
SELECT 'ack', 3912;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3913, 9, X'76616C75652D3030303033393133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3913, 'wal', 'ack-3913');
COMMIT;
SELECT 'ack', 3913;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3914, 10, X'76616C75652D3030303033393134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3914, 'wal', 'ack-3914');
COMMIT;
SELECT 'ack', 3914;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3915, 11, X'76616C75652D3030303033393135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3915, 'wal', 'ack-3915');
COMMIT;
SELECT 'ack', 3915;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3916, 12, X'76616C75652D3030303033393136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3916, 'wal', 'ack-3916');
COMMIT;
SELECT 'ack', 3916;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3917, 13, X'76616C75652D3030303033393137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3917, 'wal', 'ack-3917');
COMMIT;
SELECT 'ack', 3917;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3918, 14, X'76616C75652D3030303033393138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3918, 'wal', 'ack-3918');
COMMIT;
SELECT 'ack', 3918;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3919, 15, X'76616C75652D3030303033393139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3919, 'wal', 'ack-3919');
COMMIT;
SELECT 'ack', 3919;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3920, 16, X'76616C75652D3030303033393230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3920, 'wal', 'ack-3920');
COMMIT;
SELECT 'ack', 3920;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3921, 17, X'76616C75652D3030303033393231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3921, 'wal', 'ack-3921');
COMMIT;
SELECT 'ack', 3921;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3922, 18, X'76616C75652D3030303033393232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3922, 'wal', 'ack-3922');
COMMIT;
SELECT 'ack', 3922;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3923, 19, X'76616C75652D3030303033393233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3923, 'wal', 'ack-3923');
COMMIT;
SELECT 'ack', 3923;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3924, 20, X'76616C75652D3030303033393234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3924, 'wal', 'ack-3924');
COMMIT;
SELECT 'ack', 3924;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3925, 21, X'76616C75652D3030303033393235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3925, 'wal', 'ack-3925');
COMMIT;
SELECT 'ack', 3925;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3926, 22, X'76616C75652D3030303033393236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3926, 'wal', 'ack-3926');
COMMIT;
SELECT 'ack', 3926;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3927, 23, X'76616C75652D3030303033393237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3927, 'wal', 'ack-3927');
COMMIT;
SELECT 'ack', 3927;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3928, 24, X'76616C75652D3030303033393238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3928, 'wal', 'ack-3928');
COMMIT;
SELECT 'ack', 3928;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3929, 25, X'76616C75652D3030303033393239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3929, 'wal', 'ack-3929');
COMMIT;
SELECT 'ack', 3929;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3930, 26, X'76616C75652D3030303033393330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3930, 'wal', 'ack-3930');
COMMIT;
SELECT 'ack', 3930;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3931, 27, X'76616C75652D3030303033393331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3931, 'wal', 'ack-3931');
COMMIT;
SELECT 'ack', 3931;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3932, 28, X'76616C75652D3030303033393332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3932, 'wal', 'ack-3932');
COMMIT;
SELECT 'ack', 3932;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3933, 29, X'76616C75652D3030303033393333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3933, 'wal', 'ack-3933');
COMMIT;
SELECT 'ack', 3933;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3934, 30, X'76616C75652D3030303033393334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3934, 'wal', 'ack-3934');
COMMIT;
SELECT 'ack', 3934;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3935, 31, X'76616C75652D3030303033393335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3935, 'wal', 'ack-3935');
COMMIT;
SELECT 'ack', 3935;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3936, 0, X'76616C75652D3030303033393336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3936, 'wal', 'ack-3936');
COMMIT;
SELECT 'ack', 3936;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3937, 1, X'76616C75652D3030303033393337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3937, 'wal', 'ack-3937');
COMMIT;
SELECT 'ack', 3937;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3938, 2, X'76616C75652D3030303033393338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3938, 'wal', 'ack-3938');
COMMIT;
SELECT 'ack', 3938;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3939, 3, X'76616C75652D3030303033393339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3939, 'wal', 'ack-3939');
COMMIT;
SELECT 'ack', 3939;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3940, 4, X'76616C75652D3030303033393430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3940, 'wal', 'ack-3940');
COMMIT;
SELECT 'ack', 3940;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3941, 5, X'76616C75652D3030303033393431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3941, 'wal', 'ack-3941');
COMMIT;
SELECT 'ack', 3941;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3942, 6, X'76616C75652D3030303033393432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3942, 'wal', 'ack-3942');
COMMIT;
SELECT 'ack', 3942;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3943, 7, X'76616C75652D3030303033393433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3943, 'wal', 'ack-3943');
COMMIT;
SELECT 'ack', 3943;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3944, 8, X'76616C75652D3030303033393434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3944, 'wal', 'ack-3944');
COMMIT;
SELECT 'ack', 3944;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3945, 9, X'76616C75652D3030303033393435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3945, 'wal', 'ack-3945');
COMMIT;
SELECT 'ack', 3945;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3946, 10, X'76616C75652D3030303033393436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3946, 'wal', 'ack-3946');
COMMIT;
SELECT 'ack', 3946;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3947, 11, X'76616C75652D3030303033393437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3947, 'wal', 'ack-3947');
COMMIT;
SELECT 'ack', 3947;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3948, 12, X'76616C75652D3030303033393438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3948, 'wal', 'ack-3948');
COMMIT;
SELECT 'ack', 3948;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3949, 13, X'76616C75652D3030303033393439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3949, 'wal', 'ack-3949');
COMMIT;
SELECT 'ack', 3949;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3950, 14, X'76616C75652D3030303033393530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3950, 'wal', 'ack-3950');
COMMIT;
SELECT 'ack', 3950;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3951, 15, X'76616C75652D3030303033393531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3951, 'wal', 'ack-3951');
COMMIT;
SELECT 'ack', 3951;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3952, 16, X'76616C75652D3030303033393532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3952, 'wal', 'ack-3952');
COMMIT;
SELECT 'ack', 3952;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3953, 17, X'76616C75652D3030303033393533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3953, 'wal', 'ack-3953');
COMMIT;
SELECT 'ack', 3953;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3954, 18, X'76616C75652D3030303033393534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3954, 'wal', 'ack-3954');
COMMIT;
SELECT 'ack', 3954;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3955, 19, X'76616C75652D3030303033393535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3955, 'wal', 'ack-3955');
COMMIT;
SELECT 'ack', 3955;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3956, 20, X'76616C75652D3030303033393536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3956, 'wal', 'ack-3956');
COMMIT;
SELECT 'ack', 3956;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3957, 21, X'76616C75652D3030303033393537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3957, 'wal', 'ack-3957');
COMMIT;
SELECT 'ack', 3957;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3958, 22, X'76616C75652D3030303033393538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3958, 'wal', 'ack-3958');
COMMIT;
SELECT 'ack', 3958;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3959, 23, X'76616C75652D3030303033393539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3959, 'wal', 'ack-3959');
COMMIT;
SELECT 'ack', 3959;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3960, 24, X'76616C75652D3030303033393630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3960, 'wal', 'ack-3960');
COMMIT;
SELECT 'ack', 3960;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3961, 25, X'76616C75652D3030303033393631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3961, 'wal', 'ack-3961');
COMMIT;
SELECT 'ack', 3961;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3962, 26, X'76616C75652D3030303033393632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3962, 'wal', 'ack-3962');
COMMIT;
SELECT 'ack', 3962;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3963, 27, X'76616C75652D3030303033393633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3963, 'wal', 'ack-3963');
COMMIT;
SELECT 'ack', 3963;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3964, 28, X'76616C75652D3030303033393634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3964, 'wal', 'ack-3964');
COMMIT;
SELECT 'ack', 3964;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3965, 29, X'76616C75652D3030303033393635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3965, 'wal', 'ack-3965');
COMMIT;
SELECT 'ack', 3965;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3966, 30, X'76616C75652D3030303033393636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3966, 'wal', 'ack-3966');
COMMIT;
SELECT 'ack', 3966;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3967, 31, X'76616C75652D3030303033393637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3967, 'wal', 'ack-3967');
COMMIT;
SELECT 'ack', 3967;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3968, 0, X'76616C75652D3030303033393638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3968, 'wal', 'ack-3968');
COMMIT;
SELECT 'ack', 3968;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3969, 1, X'76616C75652D3030303033393639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3969, 'wal', 'ack-3969');
COMMIT;
SELECT 'ack', 3969;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3970, 2, X'76616C75652D3030303033393730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3970, 'wal', 'ack-3970');
COMMIT;
SELECT 'ack', 3970;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3971, 3, X'76616C75652D3030303033393731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3971, 'wal', 'ack-3971');
COMMIT;
SELECT 'ack', 3971;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3972, 4, X'76616C75652D3030303033393732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3972, 'wal', 'ack-3972');
COMMIT;
SELECT 'ack', 3972;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3973, 5, X'76616C75652D3030303033393733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3973, 'wal', 'ack-3973');
COMMIT;
SELECT 'ack', 3973;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3974, 6, X'76616C75652D3030303033393734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3974, 'wal', 'ack-3974');
COMMIT;
SELECT 'ack', 3974;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3975, 7, X'76616C75652D3030303033393735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3975, 'wal', 'ack-3975');
COMMIT;
SELECT 'ack', 3975;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3976, 8, X'76616C75652D3030303033393736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3976, 'wal', 'ack-3976');
COMMIT;
SELECT 'ack', 3976;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3977, 9, X'76616C75652D3030303033393737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3977, 'wal', 'ack-3977');
COMMIT;
SELECT 'ack', 3977;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3978, 10, X'76616C75652D3030303033393738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3978, 'wal', 'ack-3978');
COMMIT;
SELECT 'ack', 3978;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3979, 11, X'76616C75652D3030303033393739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3979, 'wal', 'ack-3979');
COMMIT;
SELECT 'ack', 3979;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3980, 12, X'76616C75652D3030303033393830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3980, 'wal', 'ack-3980');
COMMIT;
SELECT 'ack', 3980;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3981, 13, X'76616C75652D3030303033393831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3981, 'wal', 'ack-3981');
COMMIT;
SELECT 'ack', 3981;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3982, 14, X'76616C75652D3030303033393832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3982, 'wal', 'ack-3982');
COMMIT;
SELECT 'ack', 3982;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3983, 15, X'76616C75652D3030303033393833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3983, 'wal', 'ack-3983');
COMMIT;
SELECT 'ack', 3983;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3984, 16, X'76616C75652D3030303033393834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3984, 'wal', 'ack-3984');
COMMIT;
SELECT 'ack', 3984;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3985, 17, X'76616C75652D3030303033393835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3985, 'wal', 'ack-3985');
COMMIT;
SELECT 'ack', 3985;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3986, 18, X'76616C75652D3030303033393836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3986, 'wal', 'ack-3986');
COMMIT;
SELECT 'ack', 3986;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3987, 19, X'76616C75652D3030303033393837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3987, 'wal', 'ack-3987');
COMMIT;
SELECT 'ack', 3987;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3988, 20, X'76616C75652D3030303033393838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3988, 'wal', 'ack-3988');
COMMIT;
SELECT 'ack', 3988;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3989, 21, X'76616C75652D3030303033393839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3989, 'wal', 'ack-3989');
COMMIT;
SELECT 'ack', 3989;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3990, 22, X'76616C75652D3030303033393930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3990, 'wal', 'ack-3990');
COMMIT;
SELECT 'ack', 3990;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3991, 23, X'76616C75652D3030303033393931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3991, 'wal', 'ack-3991');
COMMIT;
SELECT 'ack', 3991;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3992, 24, X'76616C75652D3030303033393932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3992, 'wal', 'ack-3992');
COMMIT;
SELECT 'ack', 3992;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3993, 25, X'76616C75652D3030303033393933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3993, 'wal', 'ack-3993');
COMMIT;
SELECT 'ack', 3993;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3994, 26, X'76616C75652D3030303033393934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3994, 'wal', 'ack-3994');
COMMIT;
SELECT 'ack', 3994;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3995, 27, X'76616C75652D3030303033393935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3995, 'wal', 'ack-3995');
COMMIT;
SELECT 'ack', 3995;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3996, 28, X'76616C75652D3030303033393936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3996, 'wal', 'ack-3996');
COMMIT;
SELECT 'ack', 3996;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3997, 29, X'76616C75652D3030303033393937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3997, 'wal', 'ack-3997');
COMMIT;
SELECT 'ack', 3997;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3998, 30, X'76616C75652D3030303033393938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3998, 'wal', 'ack-3998');
COMMIT;
SELECT 'ack', 3998;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (3999, 31, X'76616C75652D3030303033393939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (3999, 'wal', 'ack-3999');
COMMIT;
SELECT 'ack', 3999;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4000, 0, X'76616C75652D3030303034303030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4000, 'wal', 'ack-4000');
COMMIT;
SELECT 'ack', 4000;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4001, 1, X'76616C75652D3030303034303031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4001, 'wal', 'ack-4001');
COMMIT;
SELECT 'ack', 4001;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4002, 2, X'76616C75652D3030303034303032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4002, 'wal', 'ack-4002');
COMMIT;
SELECT 'ack', 4002;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4003, 3, X'76616C75652D3030303034303033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4003, 'wal', 'ack-4003');
COMMIT;
SELECT 'ack', 4003;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4004, 4, X'76616C75652D3030303034303034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4004, 'wal', 'ack-4004');
COMMIT;
SELECT 'ack', 4004;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4005, 5, X'76616C75652D3030303034303035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4005, 'wal', 'ack-4005');
COMMIT;
SELECT 'ack', 4005;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4006, 6, X'76616C75652D3030303034303036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4006, 'wal', 'ack-4006');
COMMIT;
SELECT 'ack', 4006;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4007, 7, X'76616C75652D3030303034303037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4007, 'wal', 'ack-4007');
COMMIT;
SELECT 'ack', 4007;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4008, 8, X'76616C75652D3030303034303038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4008, 'wal', 'ack-4008');
COMMIT;
SELECT 'ack', 4008;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4009, 9, X'76616C75652D3030303034303039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4009, 'wal', 'ack-4009');
COMMIT;
SELECT 'ack', 4009;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4010, 10, X'76616C75652D3030303034303130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4010, 'wal', 'ack-4010');
COMMIT;
SELECT 'ack', 4010;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4011, 11, X'76616C75652D3030303034303131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4011, 'wal', 'ack-4011');
COMMIT;
SELECT 'ack', 4011;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4012, 12, X'76616C75652D3030303034303132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4012, 'wal', 'ack-4012');
COMMIT;
SELECT 'ack', 4012;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4013, 13, X'76616C75652D3030303034303133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4013, 'wal', 'ack-4013');
COMMIT;
SELECT 'ack', 4013;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4014, 14, X'76616C75652D3030303034303134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4014, 'wal', 'ack-4014');
COMMIT;
SELECT 'ack', 4014;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4015, 15, X'76616C75652D3030303034303135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4015, 'wal', 'ack-4015');
COMMIT;
SELECT 'ack', 4015;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4016, 16, X'76616C75652D3030303034303136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4016, 'wal', 'ack-4016');
COMMIT;
SELECT 'ack', 4016;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4017, 17, X'76616C75652D3030303034303137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4017, 'wal', 'ack-4017');
COMMIT;
SELECT 'ack', 4017;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4018, 18, X'76616C75652D3030303034303138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4018, 'wal', 'ack-4018');
COMMIT;
SELECT 'ack', 4018;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4019, 19, X'76616C75652D3030303034303139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4019, 'wal', 'ack-4019');
COMMIT;
SELECT 'ack', 4019;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4020, 20, X'76616C75652D3030303034303230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4020, 'wal', 'ack-4020');
COMMIT;
SELECT 'ack', 4020;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4021, 21, X'76616C75652D3030303034303231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4021, 'wal', 'ack-4021');
COMMIT;
SELECT 'ack', 4021;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4022, 22, X'76616C75652D3030303034303232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4022, 'wal', 'ack-4022');
COMMIT;
SELECT 'ack', 4022;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4023, 23, X'76616C75652D3030303034303233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4023, 'wal', 'ack-4023');
COMMIT;
SELECT 'ack', 4023;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4024, 24, X'76616C75652D3030303034303234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4024, 'wal', 'ack-4024');
COMMIT;
SELECT 'ack', 4024;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4025, 25, X'76616C75652D3030303034303235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4025, 'wal', 'ack-4025');
COMMIT;
SELECT 'ack', 4025;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4026, 26, X'76616C75652D3030303034303236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4026, 'wal', 'ack-4026');
COMMIT;
SELECT 'ack', 4026;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4027, 27, X'76616C75652D3030303034303237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4027, 'wal', 'ack-4027');
COMMIT;
SELECT 'ack', 4027;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4028, 28, X'76616C75652D3030303034303238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4028, 'wal', 'ack-4028');
COMMIT;
SELECT 'ack', 4028;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4029, 29, X'76616C75652D3030303034303239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4029, 'wal', 'ack-4029');
COMMIT;
SELECT 'ack', 4029;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4030, 30, X'76616C75652D3030303034303330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4030, 'wal', 'ack-4030');
COMMIT;
SELECT 'ack', 4030;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4031, 31, X'76616C75652D3030303034303331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4031, 'wal', 'ack-4031');
COMMIT;
SELECT 'ack', 4031;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4032, 0, X'76616C75652D3030303034303332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4032, 'wal', 'ack-4032');
COMMIT;
SELECT 'ack', 4032;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4033, 1, X'76616C75652D3030303034303333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4033, 'wal', 'ack-4033');
COMMIT;
SELECT 'ack', 4033;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4034, 2, X'76616C75652D3030303034303334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4034, 'wal', 'ack-4034');
COMMIT;
SELECT 'ack', 4034;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4035, 3, X'76616C75652D3030303034303335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4035, 'wal', 'ack-4035');
COMMIT;
SELECT 'ack', 4035;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4036, 4, X'76616C75652D3030303034303336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4036, 'wal', 'ack-4036');
COMMIT;
SELECT 'ack', 4036;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4037, 5, X'76616C75652D3030303034303337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4037, 'wal', 'ack-4037');
COMMIT;
SELECT 'ack', 4037;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4038, 6, X'76616C75652D3030303034303338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4038, 'wal', 'ack-4038');
COMMIT;
SELECT 'ack', 4038;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4039, 7, X'76616C75652D3030303034303339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4039, 'wal', 'ack-4039');
COMMIT;
SELECT 'ack', 4039;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4040, 8, X'76616C75652D3030303034303430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4040, 'wal', 'ack-4040');
COMMIT;
SELECT 'ack', 4040;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4041, 9, X'76616C75652D3030303034303431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4041, 'wal', 'ack-4041');
COMMIT;
SELECT 'ack', 4041;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4042, 10, X'76616C75652D3030303034303432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4042, 'wal', 'ack-4042');
COMMIT;
SELECT 'ack', 4042;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4043, 11, X'76616C75652D3030303034303433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4043, 'wal', 'ack-4043');
COMMIT;
SELECT 'ack', 4043;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4044, 12, X'76616C75652D3030303034303434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4044, 'wal', 'ack-4044');
COMMIT;
SELECT 'ack', 4044;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4045, 13, X'76616C75652D3030303034303435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4045, 'wal', 'ack-4045');
COMMIT;
SELECT 'ack', 4045;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4046, 14, X'76616C75652D3030303034303436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4046, 'wal', 'ack-4046');
COMMIT;
SELECT 'ack', 4046;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4047, 15, X'76616C75652D3030303034303437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4047, 'wal', 'ack-4047');
COMMIT;
SELECT 'ack', 4047;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4048, 16, X'76616C75652D3030303034303438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4048, 'wal', 'ack-4048');
COMMIT;
SELECT 'ack', 4048;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4049, 17, X'76616C75652D3030303034303439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4049, 'wal', 'ack-4049');
COMMIT;
SELECT 'ack', 4049;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4050, 18, X'76616C75652D3030303034303530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4050, 'wal', 'ack-4050');
COMMIT;
SELECT 'ack', 4050;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4051, 19, X'76616C75652D3030303034303531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4051, 'wal', 'ack-4051');
COMMIT;
SELECT 'ack', 4051;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4052, 20, X'76616C75652D3030303034303532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4052, 'wal', 'ack-4052');
COMMIT;
SELECT 'ack', 4052;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4053, 21, X'76616C75652D3030303034303533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4053, 'wal', 'ack-4053');
COMMIT;
SELECT 'ack', 4053;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4054, 22, X'76616C75652D3030303034303534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4054, 'wal', 'ack-4054');
COMMIT;
SELECT 'ack', 4054;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4055, 23, X'76616C75652D3030303034303535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4055, 'wal', 'ack-4055');
COMMIT;
SELECT 'ack', 4055;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4056, 24, X'76616C75652D3030303034303536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4056, 'wal', 'ack-4056');
COMMIT;
SELECT 'ack', 4056;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4057, 25, X'76616C75652D3030303034303537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4057, 'wal', 'ack-4057');
COMMIT;
SELECT 'ack', 4057;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4058, 26, X'76616C75652D3030303034303538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4058, 'wal', 'ack-4058');
COMMIT;
SELECT 'ack', 4058;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4059, 27, X'76616C75652D3030303034303539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4059, 'wal', 'ack-4059');
COMMIT;
SELECT 'ack', 4059;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4060, 28, X'76616C75652D3030303034303630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4060, 'wal', 'ack-4060');
COMMIT;
SELECT 'ack', 4060;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4061, 29, X'76616C75652D3030303034303631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4061, 'wal', 'ack-4061');
COMMIT;
SELECT 'ack', 4061;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4062, 30, X'76616C75652D3030303034303632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4062, 'wal', 'ack-4062');
COMMIT;
SELECT 'ack', 4062;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4063, 31, X'76616C75652D3030303034303633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4063, 'wal', 'ack-4063');
COMMIT;
SELECT 'ack', 4063;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4064, 0, X'76616C75652D3030303034303634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4064, 'wal', 'ack-4064');
COMMIT;
SELECT 'ack', 4064;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4065, 1, X'76616C75652D3030303034303635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4065, 'wal', 'ack-4065');
COMMIT;
SELECT 'ack', 4065;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4066, 2, X'76616C75652D3030303034303636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4066, 'wal', 'ack-4066');
COMMIT;
SELECT 'ack', 4066;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4067, 3, X'76616C75652D3030303034303637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4067, 'wal', 'ack-4067');
COMMIT;
SELECT 'ack', 4067;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4068, 4, X'76616C75652D3030303034303638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4068, 'wal', 'ack-4068');
COMMIT;
SELECT 'ack', 4068;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4069, 5, X'76616C75652D3030303034303639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4069, 'wal', 'ack-4069');
COMMIT;
SELECT 'ack', 4069;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4070, 6, X'76616C75652D3030303034303730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4070, 'wal', 'ack-4070');
COMMIT;
SELECT 'ack', 4070;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4071, 7, X'76616C75652D3030303034303731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4071, 'wal', 'ack-4071');
COMMIT;
SELECT 'ack', 4071;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4072, 8, X'76616C75652D3030303034303732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4072, 'wal', 'ack-4072');
COMMIT;
SELECT 'ack', 4072;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4073, 9, X'76616C75652D3030303034303733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4073, 'wal', 'ack-4073');
COMMIT;
SELECT 'ack', 4073;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4074, 10, X'76616C75652D3030303034303734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4074, 'wal', 'ack-4074');
COMMIT;
SELECT 'ack', 4074;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4075, 11, X'76616C75652D3030303034303735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4075, 'wal', 'ack-4075');
COMMIT;
SELECT 'ack', 4075;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4076, 12, X'76616C75652D3030303034303736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4076, 'wal', 'ack-4076');
COMMIT;
SELECT 'ack', 4076;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4077, 13, X'76616C75652D3030303034303737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4077, 'wal', 'ack-4077');
COMMIT;
SELECT 'ack', 4077;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4078, 14, X'76616C75652D3030303034303738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4078, 'wal', 'ack-4078');
COMMIT;
SELECT 'ack', 4078;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4079, 15, X'76616C75652D3030303034303739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4079, 'wal', 'ack-4079');
COMMIT;
SELECT 'ack', 4079;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4080, 16, X'76616C75652D3030303034303830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4080, 'wal', 'ack-4080');
COMMIT;
SELECT 'ack', 4080;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4081, 17, X'76616C75652D3030303034303831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4081, 'wal', 'ack-4081');
COMMIT;
SELECT 'ack', 4081;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4082, 18, X'76616C75652D3030303034303832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4082, 'wal', 'ack-4082');
COMMIT;
SELECT 'ack', 4082;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4083, 19, X'76616C75652D3030303034303833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4083, 'wal', 'ack-4083');
COMMIT;
SELECT 'ack', 4083;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4084, 20, X'76616C75652D3030303034303834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4084, 'wal', 'ack-4084');
COMMIT;
SELECT 'ack', 4084;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4085, 21, X'76616C75652D3030303034303835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4085, 'wal', 'ack-4085');
COMMIT;
SELECT 'ack', 4085;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4086, 22, X'76616C75652D3030303034303836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4086, 'wal', 'ack-4086');
COMMIT;
SELECT 'ack', 4086;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4087, 23, X'76616C75652D3030303034303837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4087, 'wal', 'ack-4087');
COMMIT;
SELECT 'ack', 4087;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4088, 24, X'76616C75652D3030303034303838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4088, 'wal', 'ack-4088');
COMMIT;
SELECT 'ack', 4088;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4089, 25, X'76616C75652D3030303034303839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4089, 'wal', 'ack-4089');
COMMIT;
SELECT 'ack', 4089;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4090, 26, X'76616C75652D3030303034303930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4090, 'wal', 'ack-4090');
COMMIT;
SELECT 'ack', 4090;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4091, 27, X'76616C75652D3030303034303931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4091, 'wal', 'ack-4091');
COMMIT;
SELECT 'ack', 4091;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4092, 28, X'76616C75652D3030303034303932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4092, 'wal', 'ack-4092');
COMMIT;
SELECT 'ack', 4092;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4093, 29, X'76616C75652D3030303034303933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4093, 'wal', 'ack-4093');
COMMIT;
SELECT 'ack', 4093;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4094, 30, X'76616C75652D3030303034303934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4094, 'wal', 'ack-4094');
COMMIT;
SELECT 'ack', 4094;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4095, 31, X'76616C75652D3030303034303935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4095, 'wal', 'ack-4095');
COMMIT;
SELECT 'ack', 4095;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4096, 0, X'76616C75652D3030303034303936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4096, 'wal', 'ack-4096');
COMMIT;
SELECT 'ack', 4096;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4097, 1, X'76616C75652D3030303034303937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4097, 'wal', 'ack-4097');
COMMIT;
SELECT 'ack', 4097;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4098, 2, X'76616C75652D3030303034303938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4098, 'wal', 'ack-4098');
COMMIT;
SELECT 'ack', 4098;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4099, 3, X'76616C75652D3030303034303939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4099, 'wal', 'ack-4099');
COMMIT;
SELECT 'ack', 4099;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4100, 4, X'76616C75652D3030303034313030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4100, 'wal', 'ack-4100');
COMMIT;
SELECT 'ack', 4100;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4101, 5, X'76616C75652D3030303034313031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4101, 'wal', 'ack-4101');
COMMIT;
SELECT 'ack', 4101;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4102, 6, X'76616C75652D3030303034313032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4102, 'wal', 'ack-4102');
COMMIT;
SELECT 'ack', 4102;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4103, 7, X'76616C75652D3030303034313033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4103, 'wal', 'ack-4103');
COMMIT;
SELECT 'ack', 4103;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4104, 8, X'76616C75652D3030303034313034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4104, 'wal', 'ack-4104');
COMMIT;
SELECT 'ack', 4104;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4105, 9, X'76616C75652D3030303034313035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4105, 'wal', 'ack-4105');
COMMIT;
SELECT 'ack', 4105;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4106, 10, X'76616C75652D3030303034313036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4106, 'wal', 'ack-4106');
COMMIT;
SELECT 'ack', 4106;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4107, 11, X'76616C75652D3030303034313037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4107, 'wal', 'ack-4107');
COMMIT;
SELECT 'ack', 4107;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4108, 12, X'76616C75652D3030303034313038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4108, 'wal', 'ack-4108');
COMMIT;
SELECT 'ack', 4108;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4109, 13, X'76616C75652D3030303034313039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4109, 'wal', 'ack-4109');
COMMIT;
SELECT 'ack', 4109;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4110, 14, X'76616C75652D3030303034313130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4110, 'wal', 'ack-4110');
COMMIT;
SELECT 'ack', 4110;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4111, 15, X'76616C75652D3030303034313131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4111, 'wal', 'ack-4111');
COMMIT;
SELECT 'ack', 4111;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4112, 16, X'76616C75652D3030303034313132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4112, 'wal', 'ack-4112');
COMMIT;
SELECT 'ack', 4112;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4113, 17, X'76616C75652D3030303034313133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4113, 'wal', 'ack-4113');
COMMIT;
SELECT 'ack', 4113;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4114, 18, X'76616C75652D3030303034313134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4114, 'wal', 'ack-4114');
COMMIT;
SELECT 'ack', 4114;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4115, 19, X'76616C75652D3030303034313135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4115, 'wal', 'ack-4115');
COMMIT;
SELECT 'ack', 4115;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4116, 20, X'76616C75652D3030303034313136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4116, 'wal', 'ack-4116');
COMMIT;
SELECT 'ack', 4116;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4117, 21, X'76616C75652D3030303034313137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4117, 'wal', 'ack-4117');
COMMIT;
SELECT 'ack', 4117;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4118, 22, X'76616C75652D3030303034313138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4118, 'wal', 'ack-4118');
COMMIT;
SELECT 'ack', 4118;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4119, 23, X'76616C75652D3030303034313139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4119, 'wal', 'ack-4119');
COMMIT;
SELECT 'ack', 4119;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4120, 24, X'76616C75652D3030303034313230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4120, 'wal', 'ack-4120');
COMMIT;
SELECT 'ack', 4120;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4121, 25, X'76616C75652D3030303034313231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4121, 'wal', 'ack-4121');
COMMIT;
SELECT 'ack', 4121;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4122, 26, X'76616C75652D3030303034313232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4122, 'wal', 'ack-4122');
COMMIT;
SELECT 'ack', 4122;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4123, 27, X'76616C75652D3030303034313233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4123, 'wal', 'ack-4123');
COMMIT;
SELECT 'ack', 4123;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4124, 28, X'76616C75652D3030303034313234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4124, 'wal', 'ack-4124');
COMMIT;
SELECT 'ack', 4124;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4125, 29, X'76616C75652D3030303034313235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4125, 'wal', 'ack-4125');
COMMIT;
SELECT 'ack', 4125;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4126, 30, X'76616C75652D3030303034313236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4126, 'wal', 'ack-4126');
COMMIT;
SELECT 'ack', 4126;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4127, 31, X'76616C75652D3030303034313237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4127, 'wal', 'ack-4127');
COMMIT;
SELECT 'ack', 4127;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4128, 0, X'76616C75652D3030303034313238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4128, 'wal', 'ack-4128');
COMMIT;
SELECT 'ack', 4128;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4129, 1, X'76616C75652D3030303034313239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4129, 'wal', 'ack-4129');
COMMIT;
SELECT 'ack', 4129;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4130, 2, X'76616C75652D3030303034313330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4130, 'wal', 'ack-4130');
COMMIT;
SELECT 'ack', 4130;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4131, 3, X'76616C75652D3030303034313331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4131, 'wal', 'ack-4131');
COMMIT;
SELECT 'ack', 4131;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4132, 4, X'76616C75652D3030303034313332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4132, 'wal', 'ack-4132');
COMMIT;
SELECT 'ack', 4132;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4133, 5, X'76616C75652D3030303034313333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4133, 'wal', 'ack-4133');
COMMIT;
SELECT 'ack', 4133;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4134, 6, X'76616C75652D3030303034313334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4134, 'wal', 'ack-4134');
COMMIT;
SELECT 'ack', 4134;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4135, 7, X'76616C75652D3030303034313335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4135, 'wal', 'ack-4135');
COMMIT;
SELECT 'ack', 4135;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4136, 8, X'76616C75652D3030303034313336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4136, 'wal', 'ack-4136');
COMMIT;
SELECT 'ack', 4136;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4137, 9, X'76616C75652D3030303034313337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4137, 'wal', 'ack-4137');
COMMIT;
SELECT 'ack', 4137;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4138, 10, X'76616C75652D3030303034313338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4138, 'wal', 'ack-4138');
COMMIT;
SELECT 'ack', 4138;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4139, 11, X'76616C75652D3030303034313339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4139, 'wal', 'ack-4139');
COMMIT;
SELECT 'ack', 4139;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4140, 12, X'76616C75652D3030303034313430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4140, 'wal', 'ack-4140');
COMMIT;
SELECT 'ack', 4140;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4141, 13, X'76616C75652D3030303034313431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4141, 'wal', 'ack-4141');
COMMIT;
SELECT 'ack', 4141;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4142, 14, X'76616C75652D3030303034313432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4142, 'wal', 'ack-4142');
COMMIT;
SELECT 'ack', 4142;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4143, 15, X'76616C75652D3030303034313433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4143, 'wal', 'ack-4143');
COMMIT;
SELECT 'ack', 4143;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4144, 16, X'76616C75652D3030303034313434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4144, 'wal', 'ack-4144');
COMMIT;
SELECT 'ack', 4144;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4145, 17, X'76616C75652D3030303034313435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4145, 'wal', 'ack-4145');
COMMIT;
SELECT 'ack', 4145;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4146, 18, X'76616C75652D3030303034313436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4146, 'wal', 'ack-4146');
COMMIT;
SELECT 'ack', 4146;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4147, 19, X'76616C75652D3030303034313437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4147, 'wal', 'ack-4147');
COMMIT;
SELECT 'ack', 4147;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4148, 20, X'76616C75652D3030303034313438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4148, 'wal', 'ack-4148');
COMMIT;
SELECT 'ack', 4148;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4149, 21, X'76616C75652D3030303034313439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4149, 'wal', 'ack-4149');
COMMIT;
SELECT 'ack', 4149;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4150, 22, X'76616C75652D3030303034313530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4150, 'wal', 'ack-4150');
COMMIT;
SELECT 'ack', 4150;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4151, 23, X'76616C75652D3030303034313531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4151, 'wal', 'ack-4151');
COMMIT;
SELECT 'ack', 4151;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4152, 24, X'76616C75652D3030303034313532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4152, 'wal', 'ack-4152');
COMMIT;
SELECT 'ack', 4152;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4153, 25, X'76616C75652D3030303034313533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4153, 'wal', 'ack-4153');
COMMIT;
SELECT 'ack', 4153;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4154, 26, X'76616C75652D3030303034313534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4154, 'wal', 'ack-4154');
COMMIT;
SELECT 'ack', 4154;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4155, 27, X'76616C75652D3030303034313535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4155, 'wal', 'ack-4155');
COMMIT;
SELECT 'ack', 4155;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4156, 28, X'76616C75652D3030303034313536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4156, 'wal', 'ack-4156');
COMMIT;
SELECT 'ack', 4156;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4157, 29, X'76616C75652D3030303034313537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4157, 'wal', 'ack-4157');
COMMIT;
SELECT 'ack', 4157;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4158, 30, X'76616C75652D3030303034313538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4158, 'wal', 'ack-4158');
COMMIT;
SELECT 'ack', 4158;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4159, 31, X'76616C75652D3030303034313539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4159, 'wal', 'ack-4159');
COMMIT;
SELECT 'ack', 4159;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4160, 0, X'76616C75652D3030303034313630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4160, 'wal', 'ack-4160');
COMMIT;
SELECT 'ack', 4160;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4161, 1, X'76616C75652D3030303034313631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4161, 'wal', 'ack-4161');
COMMIT;
SELECT 'ack', 4161;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4162, 2, X'76616C75652D3030303034313632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4162, 'wal', 'ack-4162');
COMMIT;
SELECT 'ack', 4162;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4163, 3, X'76616C75652D3030303034313633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4163, 'wal', 'ack-4163');
COMMIT;
SELECT 'ack', 4163;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4164, 4, X'76616C75652D3030303034313634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4164, 'wal', 'ack-4164');
COMMIT;
SELECT 'ack', 4164;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4165, 5, X'76616C75652D3030303034313635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4165, 'wal', 'ack-4165');
COMMIT;
SELECT 'ack', 4165;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4166, 6, X'76616C75652D3030303034313636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4166, 'wal', 'ack-4166');
COMMIT;
SELECT 'ack', 4166;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4167, 7, X'76616C75652D3030303034313637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4167, 'wal', 'ack-4167');
COMMIT;
SELECT 'ack', 4167;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4168, 8, X'76616C75652D3030303034313638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4168, 'wal', 'ack-4168');
COMMIT;
SELECT 'ack', 4168;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4169, 9, X'76616C75652D3030303034313639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4169, 'wal', 'ack-4169');
COMMIT;
SELECT 'ack', 4169;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4170, 10, X'76616C75652D3030303034313730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4170, 'wal', 'ack-4170');
COMMIT;
SELECT 'ack', 4170;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4171, 11, X'76616C75652D3030303034313731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4171, 'wal', 'ack-4171');
COMMIT;
SELECT 'ack', 4171;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4172, 12, X'76616C75652D3030303034313732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4172, 'wal', 'ack-4172');
COMMIT;
SELECT 'ack', 4172;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4173, 13, X'76616C75652D3030303034313733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4173, 'wal', 'ack-4173');
COMMIT;
SELECT 'ack', 4173;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4174, 14, X'76616C75652D3030303034313734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4174, 'wal', 'ack-4174');
COMMIT;
SELECT 'ack', 4174;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4175, 15, X'76616C75652D3030303034313735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4175, 'wal', 'ack-4175');
COMMIT;
SELECT 'ack', 4175;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4176, 16, X'76616C75652D3030303034313736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4176, 'wal', 'ack-4176');
COMMIT;
SELECT 'ack', 4176;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4177, 17, X'76616C75652D3030303034313737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4177, 'wal', 'ack-4177');
COMMIT;
SELECT 'ack', 4177;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4178, 18, X'76616C75652D3030303034313738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4178, 'wal', 'ack-4178');
COMMIT;
SELECT 'ack', 4178;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4179, 19, X'76616C75652D3030303034313739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4179, 'wal', 'ack-4179');
COMMIT;
SELECT 'ack', 4179;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4180, 20, X'76616C75652D3030303034313830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4180, 'wal', 'ack-4180');
COMMIT;
SELECT 'ack', 4180;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4181, 21, X'76616C75652D3030303034313831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4181, 'wal', 'ack-4181');
COMMIT;
SELECT 'ack', 4181;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4182, 22, X'76616C75652D3030303034313832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4182, 'wal', 'ack-4182');
COMMIT;
SELECT 'ack', 4182;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4183, 23, X'76616C75652D3030303034313833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4183, 'wal', 'ack-4183');
COMMIT;
SELECT 'ack', 4183;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4184, 24, X'76616C75652D3030303034313834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4184, 'wal', 'ack-4184');
COMMIT;
SELECT 'ack', 4184;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4185, 25, X'76616C75652D3030303034313835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4185, 'wal', 'ack-4185');
COMMIT;
SELECT 'ack', 4185;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4186, 26, X'76616C75652D3030303034313836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4186, 'wal', 'ack-4186');
COMMIT;
SELECT 'ack', 4186;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4187, 27, X'76616C75652D3030303034313837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4187, 'wal', 'ack-4187');
COMMIT;
SELECT 'ack', 4187;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4188, 28, X'76616C75652D3030303034313838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4188, 'wal', 'ack-4188');
COMMIT;
SELECT 'ack', 4188;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4189, 29, X'76616C75652D3030303034313839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4189, 'wal', 'ack-4189');
COMMIT;
SELECT 'ack', 4189;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4190, 30, X'76616C75652D3030303034313930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4190, 'wal', 'ack-4190');
COMMIT;
SELECT 'ack', 4190;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4191, 31, X'76616C75652D3030303034313931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4191, 'wal', 'ack-4191');
COMMIT;
SELECT 'ack', 4191;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4192, 0, X'76616C75652D3030303034313932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4192, 'wal', 'ack-4192');
COMMIT;
SELECT 'ack', 4192;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4193, 1, X'76616C75652D3030303034313933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4193, 'wal', 'ack-4193');
COMMIT;
SELECT 'ack', 4193;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4194, 2, X'76616C75652D3030303034313934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4194, 'wal', 'ack-4194');
COMMIT;
SELECT 'ack', 4194;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4195, 3, X'76616C75652D3030303034313935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4195, 'wal', 'ack-4195');
COMMIT;
SELECT 'ack', 4195;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4196, 4, X'76616C75652D3030303034313936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4196, 'wal', 'ack-4196');
COMMIT;
SELECT 'ack', 4196;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4197, 5, X'76616C75652D3030303034313937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4197, 'wal', 'ack-4197');
COMMIT;
SELECT 'ack', 4197;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4198, 6, X'76616C75652D3030303034313938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4198, 'wal', 'ack-4198');
COMMIT;
SELECT 'ack', 4198;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4199, 7, X'76616C75652D3030303034313939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4199, 'wal', 'ack-4199');
COMMIT;
SELECT 'ack', 4199;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4200, 8, X'76616C75652D3030303034323030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4200, 'wal', 'ack-4200');
COMMIT;
SELECT 'ack', 4200;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4201, 9, X'76616C75652D3030303034323031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4201, 'wal', 'ack-4201');
COMMIT;
SELECT 'ack', 4201;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4202, 10, X'76616C75652D3030303034323032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4202, 'wal', 'ack-4202');
COMMIT;
SELECT 'ack', 4202;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4203, 11, X'76616C75652D3030303034323033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4203, 'wal', 'ack-4203');
COMMIT;
SELECT 'ack', 4203;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4204, 12, X'76616C75652D3030303034323034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4204, 'wal', 'ack-4204');
COMMIT;
SELECT 'ack', 4204;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4205, 13, X'76616C75652D3030303034323035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4205, 'wal', 'ack-4205');
COMMIT;
SELECT 'ack', 4205;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4206, 14, X'76616C75652D3030303034323036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4206, 'wal', 'ack-4206');
COMMIT;
SELECT 'ack', 4206;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4207, 15, X'76616C75652D3030303034323037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4207, 'wal', 'ack-4207');
COMMIT;
SELECT 'ack', 4207;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4208, 16, X'76616C75652D3030303034323038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4208, 'wal', 'ack-4208');
COMMIT;
SELECT 'ack', 4208;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4209, 17, X'76616C75652D3030303034323039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4209, 'wal', 'ack-4209');
COMMIT;
SELECT 'ack', 4209;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4210, 18, X'76616C75652D3030303034323130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4210, 'wal', 'ack-4210');
COMMIT;
SELECT 'ack', 4210;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4211, 19, X'76616C75652D3030303034323131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4211, 'wal', 'ack-4211');
COMMIT;
SELECT 'ack', 4211;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4212, 20, X'76616C75652D3030303034323132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4212, 'wal', 'ack-4212');
COMMIT;
SELECT 'ack', 4212;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4213, 21, X'76616C75652D3030303034323133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4213, 'wal', 'ack-4213');
COMMIT;
SELECT 'ack', 4213;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4214, 22, X'76616C75652D3030303034323134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4214, 'wal', 'ack-4214');
COMMIT;
SELECT 'ack', 4214;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4215, 23, X'76616C75652D3030303034323135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4215, 'wal', 'ack-4215');
COMMIT;
SELECT 'ack', 4215;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4216, 24, X'76616C75652D3030303034323136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4216, 'wal', 'ack-4216');
COMMIT;
SELECT 'ack', 4216;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4217, 25, X'76616C75652D3030303034323137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4217, 'wal', 'ack-4217');
COMMIT;
SELECT 'ack', 4217;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4218, 26, X'76616C75652D3030303034323138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4218, 'wal', 'ack-4218');
COMMIT;
SELECT 'ack', 4218;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4219, 27, X'76616C75652D3030303034323139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4219, 'wal', 'ack-4219');
COMMIT;
SELECT 'ack', 4219;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4220, 28, X'76616C75652D3030303034323230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4220, 'wal', 'ack-4220');
COMMIT;
SELECT 'ack', 4220;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4221, 29, X'76616C75652D3030303034323231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4221, 'wal', 'ack-4221');
COMMIT;
SELECT 'ack', 4221;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4222, 30, X'76616C75652D3030303034323232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4222, 'wal', 'ack-4222');
COMMIT;
SELECT 'ack', 4222;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4223, 31, X'76616C75652D3030303034323233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4223, 'wal', 'ack-4223');
COMMIT;
SELECT 'ack', 4223;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4224, 0, X'76616C75652D3030303034323234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4224, 'wal', 'ack-4224');
COMMIT;
SELECT 'ack', 4224;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4225, 1, X'76616C75652D3030303034323235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4225, 'wal', 'ack-4225');
COMMIT;
SELECT 'ack', 4225;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4226, 2, X'76616C75652D3030303034323236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4226, 'wal', 'ack-4226');
COMMIT;
SELECT 'ack', 4226;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4227, 3, X'76616C75652D3030303034323237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4227, 'wal', 'ack-4227');
COMMIT;
SELECT 'ack', 4227;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4228, 4, X'76616C75652D3030303034323238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4228, 'wal', 'ack-4228');
COMMIT;
SELECT 'ack', 4228;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4229, 5, X'76616C75652D3030303034323239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4229, 'wal', 'ack-4229');
COMMIT;
SELECT 'ack', 4229;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4230, 6, X'76616C75652D3030303034323330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4230, 'wal', 'ack-4230');
COMMIT;
SELECT 'ack', 4230;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4231, 7, X'76616C75652D3030303034323331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4231, 'wal', 'ack-4231');
COMMIT;
SELECT 'ack', 4231;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4232, 8, X'76616C75652D3030303034323332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4232, 'wal', 'ack-4232');
COMMIT;
SELECT 'ack', 4232;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4233, 9, X'76616C75652D3030303034323333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4233, 'wal', 'ack-4233');
COMMIT;
SELECT 'ack', 4233;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4234, 10, X'76616C75652D3030303034323334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4234, 'wal', 'ack-4234');
COMMIT;
SELECT 'ack', 4234;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4235, 11, X'76616C75652D3030303034323335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4235, 'wal', 'ack-4235');
COMMIT;
SELECT 'ack', 4235;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4236, 12, X'76616C75652D3030303034323336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4236, 'wal', 'ack-4236');
COMMIT;
SELECT 'ack', 4236;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4237, 13, X'76616C75652D3030303034323337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4237, 'wal', 'ack-4237');
COMMIT;
SELECT 'ack', 4237;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4238, 14, X'76616C75652D3030303034323338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4238, 'wal', 'ack-4238');
COMMIT;
SELECT 'ack', 4238;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4239, 15, X'76616C75652D3030303034323339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4239, 'wal', 'ack-4239');
COMMIT;
SELECT 'ack', 4239;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4240, 16, X'76616C75652D3030303034323430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4240, 'wal', 'ack-4240');
COMMIT;
SELECT 'ack', 4240;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4241, 17, X'76616C75652D3030303034323431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4241, 'wal', 'ack-4241');
COMMIT;
SELECT 'ack', 4241;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4242, 18, X'76616C75652D3030303034323432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4242, 'wal', 'ack-4242');
COMMIT;
SELECT 'ack', 4242;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4243, 19, X'76616C75652D3030303034323433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4243, 'wal', 'ack-4243');
COMMIT;
SELECT 'ack', 4243;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4244, 20, X'76616C75652D3030303034323434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4244, 'wal', 'ack-4244');
COMMIT;
SELECT 'ack', 4244;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4245, 21, X'76616C75652D3030303034323435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4245, 'wal', 'ack-4245');
COMMIT;
SELECT 'ack', 4245;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4246, 22, X'76616C75652D3030303034323436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4246, 'wal', 'ack-4246');
COMMIT;
SELECT 'ack', 4246;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4247, 23, X'76616C75652D3030303034323437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4247, 'wal', 'ack-4247');
COMMIT;
SELECT 'ack', 4247;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4248, 24, X'76616C75652D3030303034323438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4248, 'wal', 'ack-4248');
COMMIT;
SELECT 'ack', 4248;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4249, 25, X'76616C75652D3030303034323439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4249, 'wal', 'ack-4249');
COMMIT;
SELECT 'ack', 4249;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4250, 26, X'76616C75652D3030303034323530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4250, 'wal', 'ack-4250');
COMMIT;
SELECT 'ack', 4250;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4251, 27, X'76616C75652D3030303034323531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4251, 'wal', 'ack-4251');
COMMIT;
SELECT 'ack', 4251;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4252, 28, X'76616C75652D3030303034323532', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4252, 'wal', 'ack-4252');
COMMIT;
SELECT 'ack', 4252;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4253, 29, X'76616C75652D3030303034323533', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4253, 'wal', 'ack-4253');
COMMIT;
SELECT 'ack', 4253;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4254, 30, X'76616C75652D3030303034323534', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4254, 'wal', 'ack-4254');
COMMIT;
SELECT 'ack', 4254;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4255, 31, X'76616C75652D3030303034323535', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4255, 'wal', 'ack-4255');
COMMIT;
SELECT 'ack', 4255;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4256, 0, X'76616C75652D3030303034323536', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4256, 'wal', 'ack-4256');
COMMIT;
SELECT 'ack', 4256;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4257, 1, X'76616C75652D3030303034323537', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4257, 'wal', 'ack-4257');
COMMIT;
SELECT 'ack', 4257;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4258, 2, X'76616C75652D3030303034323538', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4258, 'wal', 'ack-4258');
COMMIT;
SELECT 'ack', 4258;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4259, 3, X'76616C75652D3030303034323539', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4259, 'wal', 'ack-4259');
COMMIT;
SELECT 'ack', 4259;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4260, 4, X'76616C75652D3030303034323630', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4260, 'wal', 'ack-4260');
COMMIT;
SELECT 'ack', 4260;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4261, 5, X'76616C75652D3030303034323631', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4261, 'wal', 'ack-4261');
COMMIT;
SELECT 'ack', 4261;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4262, 6, X'76616C75652D3030303034323632', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4262, 'wal', 'ack-4262');
COMMIT;
SELECT 'ack', 4262;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4263, 7, X'76616C75652D3030303034323633', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4263, 'wal', 'ack-4263');
COMMIT;
SELECT 'ack', 4263;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4264, 8, X'76616C75652D3030303034323634', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4264, 'wal', 'ack-4264');
COMMIT;
SELECT 'ack', 4264;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4265, 9, X'76616C75652D3030303034323635', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4265, 'wal', 'ack-4265');
COMMIT;
SELECT 'ack', 4265;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4266, 10, X'76616C75652D3030303034323636', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4266, 'wal', 'ack-4266');
COMMIT;
SELECT 'ack', 4266;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4267, 11, X'76616C75652D3030303034323637', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4267, 'wal', 'ack-4267');
COMMIT;
SELECT 'ack', 4267;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4268, 12, X'76616C75652D3030303034323638', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4268, 'wal', 'ack-4268');
COMMIT;
SELECT 'ack', 4268;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4269, 13, X'76616C75652D3030303034323639', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4269, 'wal', 'ack-4269');
COMMIT;
SELECT 'ack', 4269;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4270, 14, X'76616C75652D3030303034323730', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4270, 'wal', 'ack-4270');
COMMIT;
SELECT 'ack', 4270;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4271, 15, X'76616C75652D3030303034323731', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4271, 'wal', 'ack-4271');
COMMIT;
SELECT 'ack', 4271;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4272, 16, X'76616C75652D3030303034323732', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4272, 'wal', 'ack-4272');
COMMIT;
SELECT 'ack', 4272;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4273, 17, X'76616C75652D3030303034323733', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4273, 'wal', 'ack-4273');
COMMIT;
SELECT 'ack', 4273;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4274, 18, X'76616C75652D3030303034323734', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4274, 'wal', 'ack-4274');
COMMIT;
SELECT 'ack', 4274;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4275, 19, X'76616C75652D3030303034323735', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4275, 'wal', 'ack-4275');
COMMIT;
SELECT 'ack', 4275;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4276, 20, X'76616C75652D3030303034323736', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4276, 'wal', 'ack-4276');
COMMIT;
SELECT 'ack', 4276;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4277, 21, X'76616C75652D3030303034323737', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4277, 'wal', 'ack-4277');
COMMIT;
SELECT 'ack', 4277;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4278, 22, X'76616C75652D3030303034323738', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4278, 'wal', 'ack-4278');
COMMIT;
SELECT 'ack', 4278;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4279, 23, X'76616C75652D3030303034323739', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4279, 'wal', 'ack-4279');
COMMIT;
SELECT 'ack', 4279;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4280, 24, X'76616C75652D3030303034323830', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4280, 'wal', 'ack-4280');
COMMIT;
SELECT 'ack', 4280;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4281, 25, X'76616C75652D3030303034323831', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4281, 'wal', 'ack-4281');
COMMIT;
SELECT 'ack', 4281;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4282, 26, X'76616C75652D3030303034323832', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4282, 'wal', 'ack-4282');
COMMIT;
SELECT 'ack', 4282;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4283, 27, X'76616C75652D3030303034323833', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4283, 'wal', 'ack-4283');
COMMIT;
SELECT 'ack', 4283;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4284, 28, X'76616C75652D3030303034323834', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4284, 'wal', 'ack-4284');
COMMIT;
SELECT 'ack', 4284;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4285, 29, X'76616C75652D3030303034323835', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4285, 'wal', 'ack-4285');
COMMIT;
SELECT 'ack', 4285;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4286, 30, X'76616C75652D3030303034323836', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4286, 'wal', 'ack-4286');
COMMIT;
SELECT 'ack', 4286;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4287, 31, X'76616C75652D3030303034323837', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4287, 'wal', 'ack-4287');
COMMIT;
SELECT 'ack', 4287;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4288, 0, X'76616C75652D3030303034323838', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4288, 'wal', 'ack-4288');
COMMIT;
SELECT 'ack', 4288;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4289, 1, X'76616C75652D3030303034323839', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4289, 'wal', 'ack-4289');
COMMIT;
SELECT 'ack', 4289;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4290, 2, X'76616C75652D3030303034323930', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4290, 'wal', 'ack-4290');
COMMIT;
SELECT 'ack', 4290;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4291, 3, X'76616C75652D3030303034323931', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4291, 'wal', 'ack-4291');
COMMIT;
SELECT 'ack', 4291;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4292, 4, X'76616C75652D3030303034323932', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4292, 'wal', 'ack-4292');
COMMIT;
SELECT 'ack', 4292;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4293, 5, X'76616C75652D3030303034323933', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4293, 'wal', 'ack-4293');
COMMIT;
SELECT 'ack', 4293;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4294, 6, X'76616C75652D3030303034323934', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4294, 'wal', 'ack-4294');
COMMIT;
SELECT 'ack', 4294;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4295, 7, X'76616C75652D3030303034323935', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4295, 'wal', 'ack-4295');
COMMIT;
SELECT 'ack', 4295;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4296, 8, X'76616C75652D3030303034323936', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4296, 'wal', 'ack-4296');
COMMIT;
SELECT 'ack', 4296;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4297, 9, X'76616C75652D3030303034323937', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4297, 'wal', 'ack-4297');
COMMIT;
SELECT 'ack', 4297;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4298, 10, X'76616C75652D3030303034323938', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4298, 'wal', 'ack-4298');
COMMIT;
SELECT 'ack', 4298;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4299, 11, X'76616C75652D3030303034323939', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4299, 'wal', 'ack-4299');
COMMIT;
SELECT 'ack', 4299;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4300, 12, X'76616C75652D3030303034333030', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4300, 'wal', 'ack-4300');
COMMIT;
SELECT 'ack', 4300;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4301, 13, X'76616C75652D3030303034333031', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4301, 'wal', 'ack-4301');
COMMIT;
SELECT 'ack', 4301;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4302, 14, X'76616C75652D3030303034333032', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4302, 'wal', 'ack-4302');
COMMIT;
SELECT 'ack', 4302;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4303, 15, X'76616C75652D3030303034333033', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4303, 'wal', 'ack-4303');
COMMIT;
SELECT 'ack', 4303;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4304, 16, X'76616C75652D3030303034333034', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4304, 'wal', 'ack-4304');
COMMIT;
SELECT 'ack', 4304;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4305, 17, X'76616C75652D3030303034333035', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4305, 'wal', 'ack-4305');
COMMIT;
SELECT 'ack', 4305;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4306, 18, X'76616C75652D3030303034333036', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4306, 'wal', 'ack-4306');
COMMIT;
SELECT 'ack', 4306;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4307, 19, X'76616C75652D3030303034333037', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4307, 'wal', 'ack-4307');
COMMIT;
SELECT 'ack', 4307;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4308, 20, X'76616C75652D3030303034333038', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4308, 'wal', 'ack-4308');
COMMIT;
SELECT 'ack', 4308;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4309, 21, X'76616C75652D3030303034333039', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4309, 'wal', 'ack-4309');
COMMIT;
SELECT 'ack', 4309;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4310, 22, X'76616C75652D3030303034333130', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4310, 'wal', 'ack-4310');
COMMIT;
SELECT 'ack', 4310;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4311, 23, X'76616C75652D3030303034333131', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4311, 'wal', 'ack-4311');
COMMIT;
SELECT 'ack', 4311;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4312, 24, X'76616C75652D3030303034333132', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4312, 'wal', 'ack-4312');
COMMIT;
SELECT 'ack', 4312;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4313, 25, X'76616C75652D3030303034333133', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4313, 'wal', 'ack-4313');
COMMIT;
SELECT 'ack', 4313;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4314, 26, X'76616C75652D3030303034333134', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4314, 'wal', 'ack-4314');
COMMIT;
SELECT 'ack', 4314;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4315, 27, X'76616C75652D3030303034333135', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4315, 'wal', 'ack-4315');
COMMIT;
SELECT 'ack', 4315;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4316, 28, X'76616C75652D3030303034333136', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4316, 'wal', 'ack-4316');
COMMIT;
SELECT 'ack', 4316;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4317, 29, X'76616C75652D3030303034333137', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4317, 'wal', 'ack-4317');
COMMIT;
SELECT 'ack', 4317;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4318, 30, X'76616C75652D3030303034333138', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4318, 'wal', 'ack-4318');
COMMIT;
SELECT 'ack', 4318;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4319, 31, X'76616C75652D3030303034333139', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4319, 'wal', 'ack-4319');
COMMIT;
SELECT 'ack', 4319;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4320, 0, X'76616C75652D3030303034333230', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4320, 'wal', 'ack-4320');
COMMIT;
SELECT 'ack', 4320;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4321, 1, X'76616C75652D3030303034333231', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4321, 'wal', 'ack-4321');
COMMIT;
SELECT 'ack', 4321;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4322, 2, X'76616C75652D3030303034333232', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4322, 'wal', 'ack-4322');
COMMIT;
SELECT 'ack', 4322;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4323, 3, X'76616C75652D3030303034333233', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4323, 'wal', 'ack-4323');
COMMIT;
SELECT 'ack', 4323;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4324, 4, X'76616C75652D3030303034333234', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4324, 'wal', 'ack-4324');
COMMIT;
SELECT 'ack', 4324;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4325, 5, X'76616C75652D3030303034333235', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4325, 'wal', 'ack-4325');
COMMIT;
SELECT 'ack', 4325;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4326, 6, X'76616C75652D3030303034333236', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4326, 'wal', 'ack-4326');
COMMIT;
SELECT 'ack', 4326;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4327, 7, X'76616C75652D3030303034333237', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4327, 'wal', 'ack-4327');
COMMIT;
SELECT 'ack', 4327;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4328, 8, X'76616C75652D3030303034333238', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4328, 'wal', 'ack-4328');
COMMIT;
SELECT 'ack', 4328;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4329, 9, X'76616C75652D3030303034333239', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4329, 'wal', 'ack-4329');
COMMIT;
SELECT 'ack', 4329;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4330, 10, X'76616C75652D3030303034333330', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4330, 'wal', 'ack-4330');
COMMIT;
SELECT 'ack', 4330;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4331, 11, X'76616C75652D3030303034333331', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4331, 'wal', 'ack-4331');
COMMIT;
SELECT 'ack', 4331;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4332, 12, X'76616C75652D3030303034333332', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4332, 'wal', 'ack-4332');
COMMIT;
SELECT 'ack', 4332;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4333, 13, X'76616C75652D3030303034333333', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4333, 'wal', 'ack-4333');
COMMIT;
SELECT 'ack', 4333;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4334, 14, X'76616C75652D3030303034333334', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4334, 'wal', 'ack-4334');
COMMIT;
SELECT 'ack', 4334;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4335, 15, X'76616C75652D3030303034333335', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4335, 'wal', 'ack-4335');
COMMIT;
SELECT 'ack', 4335;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4336, 16, X'76616C75652D3030303034333336', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4336, 'wal', 'ack-4336');
COMMIT;
SELECT 'ack', 4336;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4337, 17, X'76616C75652D3030303034333337', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4337, 'wal', 'ack-4337');
COMMIT;
SELECT 'ack', 4337;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4338, 18, X'76616C75652D3030303034333338', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4338, 'wal', 'ack-4338');
COMMIT;
SELECT 'ack', 4338;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4339, 19, X'76616C75652D3030303034333339', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4339, 'wal', 'ack-4339');
COMMIT;
SELECT 'ack', 4339;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4340, 20, X'76616C75652D3030303034333430', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4340, 'wal', 'ack-4340');
COMMIT;
SELECT 'ack', 4340;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4341, 21, X'76616C75652D3030303034333431', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4341, 'wal', 'ack-4341');
COMMIT;
SELECT 'ack', 4341;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4342, 22, X'76616C75652D3030303034333432', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4342, 'wal', 'ack-4342');
COMMIT;
SELECT 'ack', 4342;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4343, 23, X'76616C75652D3030303034333433', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4343, 'wal', 'ack-4343');
COMMIT;
SELECT 'ack', 4343;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4344, 24, X'76616C75652D3030303034333434', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4344, 'wal', 'ack-4344');
COMMIT;
SELECT 'ack', 4344;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4345, 25, X'76616C75652D3030303034333435', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4345, 'wal', 'ack-4345');
COMMIT;
SELECT 'ack', 4345;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4346, 26, X'76616C75652D3030303034333436', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4346, 'wal', 'ack-4346');
COMMIT;
SELECT 'ack', 4346;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4347, 27, X'76616C75652D3030303034333437', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4347, 'wal', 'ack-4347');
COMMIT;
SELECT 'ack', 4347;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4348, 28, X'76616C75652D3030303034333438', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4348, 'wal', 'ack-4348');
COMMIT;
SELECT 'ack', 4348;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4349, 29, X'76616C75652D3030303034333439', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4349, 'wal', 'ack-4349');
COMMIT;
SELECT 'ack', 4349;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4350, 30, X'76616C75652D3030303034333530', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4350, 'wal', 'ack-4350');
COMMIT;
SELECT 'ack', 4350;
.output stdout
BEGIN;
INSERT INTO kv(k, tenant, v, version) VALUES (4351, 31, X'76616C75652D3030303034333531', 1);
INSERT INTO crash_progress(id, scenario, note) VALUES (4351, 'wal', 'ack-4351');
COMMIT;
SELECT 'ack', 4351;
.output stdout

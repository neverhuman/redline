#!/usr/bin/env python3
"""Read-only comparison of stripped ELF .text instruction structure.

This reproduces the completed static comparison; it does not benchmark, build,
write files, or establish performance causality. RIP-relative referenced data
values are deliberately outside this instruction-structure comparison.
"""

import argparse
import hashlib
import json
from pathlib import Path
import re
import struct
import subprocess


def normalized_instructions(path):
    data = path.read_bytes()
    if data[:6] != b"\x7fELF\x02\x01":
        raise ValueError("comparison requires ELF64 little-endian files")
    section_offset = struct.unpack_from("<Q", data, 40)[0]
    entry_size, count, names_index = struct.unpack_from("<HHH", data, 58)
    headers = [
        struct.unpack_from("<IIQQQQIIQQ", data, section_offset + i * entry_size)
        for i in range(count)
    ]
    names_header = headers[names_index]
    names = data[names_header[4] : names_header[4] + names_header[5]]
    sections = {
        names[h[0] :].split(b"\0", 1)[0].decode(): (h[3], h[5])
        for h in headers
    }
    base = sections[".text"][0]
    process = subprocess.Popen(
        ["objdump", "-d", "--no-show-raw-insn", "-j", ".text", "-M", "intel", str(path)],
        stdout=subprocess.PIPE,
        text=True,
    )
    instructions = {}
    for line in process.stdout:
        match = re.match(r"^\s*([0-9a-f]+):\s+(.+)$", line)
        if not match:
            continue
        offset = int(match[1], 16) - base
        instruction = re.sub(r"\s+", " ", match[2]).strip()
        if "rip" in instruction:
            instruction = re.sub(r"rip[+-]0x[0-9a-f]+", "rip+DATA_ADDRESS", instruction)
        instruction = instruction.split("#", 1)[0].strip()
        if re.match(r"^(?:call|j[a-z]+|loop[a-z]*) ", instruction):
            instruction = re.sub(
                r"\b([0-9a-f]+)(?= <)",
                lambda value: hex(int(value[1], 16) - base),
                instruction,
            )
        instructions[offset] = re.sub(r" <[^>]*>", "", instruction)
    exit_code = process.wait()
    if exit_code:
        raise RuntimeError(f"objdump exited {exit_code} for {path}")
    normalized = "\n".join(
        f"{offset:x} {instruction}"
        for offset, instruction in sorted(instructions.items())
    ).encode()
    return instructions, {
        "path": str(path),
        "binarySha256": hashlib.sha256(data).hexdigest(),
        "objdumpExit": exit_code,
        "textVirtualAddress": hex(base),
        "textBytes": sections[".text"][1],
        "instructions": len(instructions),
        "normalizedSha256": hashlib.sha256(normalized).hexdigest(),
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("historical", type=Path)
    parser.add_argument("rebuilt", type=Path)
    arguments = parser.parse_args()
    old, old_receipt = normalized_instructions(arguments.historical)
    fresh, fresh_receipt = normalized_instructions(arguments.rebuilt)
    shared = old.keys() & fresh.keys()
    differences = [offset for offset in sorted(shared) if old[offset] != fresh[offset]]
    print(json.dumps({
        "schema": "redline-normalized-elf-instructions-v1",
        "historical": old_receipt,
        "rebuilt": fresh_receipt,
        "differentInstructionOffsets": len(old.keys() ^ fresh.keys()),
        "normalizedDifferentInstructions": len(differences),
        "firstDifferences": [
            {"offset": hex(offset), "historical": old[offset], "rebuilt": fresh[offset]}
            for offset in differences[:45]
        ],
        "performanceCauseEstablished": False,
        "limitation": "RIP-relative data values are not compared; instruction structure cannot establish timing causality.",
    }, indent=2))


if __name__ == "__main__":
    main()

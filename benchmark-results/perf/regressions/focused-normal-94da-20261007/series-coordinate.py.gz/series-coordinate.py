from pathlib import Path
import sys,json,time,subprocess,datetime
scratch=Path('/home/ubuntu/redlineDB/target/review/focused-regressions-20261007')
series=scratch/'source-bisect-series.json';steps=json.loads(series.read_text())['steps']
for index,(label,tag,reference) in enumerate(steps):
 if index<int(sys.argv[1] if len(sys.argv)>1 else 0):continue
 if index and not (scratch/(tag+'-launch.json')).exists():
  subprocess.run(['python3',str(scratch/'launch-study.py'),label,tag,reference,str(series)],check=True)
 launch=json.loads((scratch/(tag+'-launch.json')).read_text());h=launch['host'];r=launch['remote']
 while True:
  check=subprocess.run(['ssh','-o','BatchMode=yes',h,'test ! -f '+r+'/measure.exit || cat '+r+'/measure.exit; if test -f '+r+'/bundle/records.jsonl; then wc -l < '+r+'/bundle/records.jsonl; else printf \"0\\n\"; fi'],text=True,capture_output=True)
  print(datetime.datetime.now(datetime.timezone.utc).isoformat(),tag,repr(check.stdout),flush=True)
  if check.returncode:raise RuntimeError(check.stderr)
  lines=check.stdout.splitlines()
  if len(lines)==2:
   assert lines==['0','260'],lines
   break
  time.sleep(15)
 subprocess.run(['python3',str(scratch/'collect-study.py'),tag],check=True)
 print('collected',tag,flush=True)
(scratch/'source-bisect-series.exit').write_text('0\n')

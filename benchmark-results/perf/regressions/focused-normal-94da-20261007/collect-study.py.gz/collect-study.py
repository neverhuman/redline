from pathlib import Path
import json,sys,subprocess
root=Path('/home/ubuntu/redlineDB');scratch=root/'target/review/focused-regressions-20261007'
tag=sys.argv[1];launch=json.loads((scratch/(tag+'-launch.json')).read_text());host=launch['host'];remote=launch['remote']
assert host in ['xbabe1','xbabe2','xbabe3']
assert remote=='/dev/shm/redline-'+tag
check=subprocess.check_output(['ssh','-o','BatchMode=yes',host,'cat '+remote+'/measure.exit; wc -l < '+remote+'/bundle/records.jsonl'],text=True).splitlines()
assert check==['0','260'],check
out=Path('/mnt/fast-scratch/jope-prime-offroot/redlinedb-v511-tests')/tag
assert not out.exists();out.mkdir()
subprocess.run(['rsync','-a',host+':'+remote+'/',str(out)+'/'],check=True)
(out/'launch.json').write_text(json.dumps(launch,indent=2)+'\n')
node='/home/ubuntu/.nvm/versions/node/v22.23.2/bin/node'
for args in [[str(out/'bundle')],[str(out/'bundle'),'--check']]:
 subprocess.run([node,'scripts/perf/focused-summary.mjs',*args],cwd=root/'.agent/worktrees/audit',check=True)
print(out)

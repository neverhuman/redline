from pathlib import Path
import subprocess,json,hashlib,time,shlex,sys
host='xbabe3';base='/dev/shm/redline-focused-matched-main-20261007';out='/dev/shm/redline-profile-group-minimal-20261007'
subprocess.run(['ssh',host,'test \"$(cat '+base+'/measure.exit)\" = 0; test ! -e '+out+'; mkdir '+out],check=True)
rows=[]
for i,label in enumerate(['release','main','main','release']*12):
 binary=base+'/inputs/'+label+'/redline-scoreboard';image=base+'/work/images/'+label+'/base';work=out+'/case-'+str(i)
 args=['taskset','-c','2-3','nice','-n19','ionice','-c3','strace','-f','--seccomp-bpf','-v','-tt','-T','-e','trace=getrusage,madvise,mprotect','-o',out+'/'+str(i)+'-'+label+'.trace',binary,'case','--engine','redline','--workload','join_group_by_city','--rows','20000','--pair','normal','--work-divisor','1','--image',image,'--work',work]
 started=time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime());cmd=shlex.join(args)+' > '+out+'/'+str(i)+'-'+label+'.stdout 2> '+out+'/'+str(i)+'-'+label+'.stderr'
 r=subprocess.run(['ssh',host,cmd]);rows.append({'label':label,'slot':i,'command':args,'exit':r.returncode,'startedAt':started,'finishedAt':time.strftime('%Y-%m-%dT%H:%M:%SZ',time.gmtime()),'diagnosticOnly':True,'notBenchmarkAcceptance':True});assert r.returncode==0
print(json.dumps({'host':host,'remote':out,'executions':rows},indent=2))

from pathlib import Path
import sys,json,subprocess,concurrent.futures,datetime
label,tag=sys.argv[1:3];referenceLabel=sys.argv[3] if len(sys.argv)>3 else 'v5.1.1';root=Path('/home/ubuntu/redlineDB');lane=root/'.agent/worktrees/audit';scratch=root/'target/review/focused-regressions-20261007'
expr='import os,json,time; print(json.dumps({"at":time.strftime("%Y-%m-%dT%H:%M:%SZ",time.gmtime()),"host":os.uname().nodename,"load":os.getloadavg()}))'
def sample(h):
 args=['python3','-c',expr] if h=='xbabe2' else ['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',h,'python3 -c '+subprocess.list2cmdline([expr])]
 # list2cmdline is Windows quoting; use POSIX shlex for the remote shell.
 if h!='xbabe2':
  import shlex;args[-1]='python3 -c '+shlex.quote(expr)
 return json.loads(subprocess.check_output(args,text=True,timeout=20))
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:h=list(pool.map(sample,['xbabe1','xbabe2','xbabe3']))
series=None
if len(sys.argv)>4:
 series=json.loads(Path(sys.argv[4]).read_text())
 assert series['steps']==[['bisect-7bdf4c8c','series-recovery7b-20261007','bisect-release-af4-rebuilt'],['bisect-8f880b21','series-wal8f-20261007','bisect-7bdf4c8c'],['bisect-8f880b21','series-main8f-20261007','bisect-release-af4-rebuilt']]
 assert [label,tag,referenceLabel] in series['steps']
 h=series['hostSelection']
best=min(h,key=lambda x:x['load'][0]);host=best['host'];assert host in ['xbabe1','xbabe2','xbabe3'];r='/dev/shm/redline-'+tag
p=json.loads((scratch/'plan.json').read_text());b=json.loads((lane/'target/scoreboard'/label/'build.json').read_text());reference=json.loads((lane/'target/scoreboard'/referenceLabel/'build.json').read_text());p['versions']['release'].update(engineCommit=reference['engine_commit'],binarySha256=reference['binary_sha256']);p['referenceBuildLabel']=referenceLabel;p['comparisonMain']=p['measuredMainEngine']=b['engine_commit'];p['sourceInputsSha256']=b['source_inputs_sha256'];p['mainEngineEquivalenceCommand']='exact-SHA package-only build, same harness/flags';p['productionParent']='94da3b131d6d50009d2d24e026b9010681e1f04d';p['comparisonRole']=('candidate-fix' if reference['engine_commit']=='8f880b2162413dfff2e7d5ee0a5dc4a979a851e4' else 'candidate-release') if label.startswith('candidate-') else 'adjacent-bisect' if reference['engine_commit']=='7bdf4c8c55d51e0b9895d53299bd0ae442b67fe3' else 'bisect';p['bisectHypothesis']='Predeclared exact-SHA reduced history comparison; same five cases,12blocks, full operations; no result-dependent case/rep changes.'
p['hostSelection']={'at':best['at'],'chosen':host,**{x['host']:x['load'] for x in h}};p['host']={'name':host,'cpu':next(x['cpu'] for x in p['hostSelectionInitial']['snapshots'] if x['hostname']==host),'normalMount':'tmpfs'};p['output']=r+'/bundle';p['workRoots']={'normal':r+'/work'}
for v in ['release','main']:
 p['versions'][v]['binary']=r+'/inputs/'+v+'/redline-scoreboard';p['versions'][v]['build']=r+'/inputs/'+v+'/build.json'
p['versions']['main'].update(engineCommit=b['engine_commit'],binarySha256=b['binary_sha256'])
if series: p['sourceBisectSeries']=series
plan=scratch/(tag+'-plan.json');assert not plan.exists();plan.write_text(json.dumps(p,indent=2)+'\n')
# Starting a duplicate on this host fails before any staging changes.
remotecheck='ps -eo args | python3 -c '+__import__('shlex').quote('import sys; rows=[x for x in sys.stdin if "node" in x and "/focused-compare.mjs" in x and not "python3 -c" in x]; print("".join(rows));sys.exit(2 if rows else 0)')
subprocess.run(['ssh','-o','BatchMode=yes',host,remotecheck],check=True)
assert subprocess.check_output(['ssh','-o','BatchMode=yes',host,'hostname'],text=True).strip()==host, 'SSH host alias does not match measurement host'
subprocess.run(['ssh','-o','BatchMode=yes',host,'test ! -e '+r+'; mkdir -p '+r+'/inputs/release '+r+'/inputs/main '+r+'/work'],check=True)
for v,l in [('release',referenceLabel),('main',label)]:subprocess.run(['rsync','-a',str(lane/'target/scoreboard'/l/'redline-scoreboard'),str(lane/'target/scoreboard'/l/'build.json'),host+':'+r+'/inputs/'+v+'/'],check=True)
subprocess.run(['rsync','-a',str(scratch/'focused-compare.mjs'),str(scratch/'abba-summary.mjs'),str(plan),host+':'+r+'/'],check=True)
import shlex
probe=subprocess.run(['ssh','-o','BatchMode=yes',host,'find /home/ubuntu/.nvm/versions/node -maxdepth 3 -path \"*/v22.*/bin/node\" -type f 2>/dev/null'],text=True,capture_output=True)
node=probe.stdout.splitlines()[-1] if probe.stdout.splitlines() else r+'/inputs/node-v22.23.2'
if not probe.stdout.splitlines():
 subprocess.run(['rsync','-a','/home/ubuntu/.nvm/versions/node/v22.23.2/bin/node',host+':'+node],check=True)
 subprocess.run(['ssh','-o','BatchMode=yes',host,'test \"$(sha256sum '+node+' | cut -d\" \" -f1)\" = '+subprocess.check_output(['sha256sum','/home/ubuntu/.nvm/versions/node/v22.23.2/bin/node'],text=True).split()[0]],check=True)
body='p='+shlex.quote(r)+'; taskset -c 2-3 nice -n19 ionice -c3 '+shlex.quote(node)+' "$p/focused-compare.mjs" "$p/'+plan.name+'" > "$p/measure.log" 2>&1; rc=$?; printf "%s\n" "$rc" > "$p/measure.exit"; exit "$rc"'
launch='nohup setsid bash -c '+shlex.quote(body)+' </dev/null > '+r+'/launch.log 2>&1 & printf "%s\n" "$!" > '+r+'/measure.pid; cat '+r+'/measure.pid'
pid=subprocess.check_output(['ssh','-o','BatchMode=yes',host,launch],text=True).strip();receipt={'host':host,'remote':r,'pid':int(pid),'label':label,'plan':str(plan),'hostSelection':h}
(scratch/(tag+'-launch.json')).write_text(json.dumps(receipt,indent=2)+'\n');print(json.dumps(receipt))

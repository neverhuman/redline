import os
import pathlib
import shutil
import subprocess
import tempfile
import unittest

SOURCE = pathlib.Path(os.environ.get('TARGET_TEST_SOURCE', pathlib.Path.cwd()))

class TargetDirectory(unittest.TestCase):
    def check_lane(self, lane, external, relative=False):
        scratch = pathlib.Path(os.environ.get('TMPDIR', SOURCE / 'target/review/ci-target-test'))
        scratch.mkdir(parents=True, exist_ok=True)
        with tempfile.TemporaryDirectory(prefix='target-contract-', dir=scratch) as tmp:
            root = pathlib.Path(tmp) / 'source'
            root.mkdir()
            for name in ['scripts/ci-family.sh', 'ops/ci/lib.sh', 'ops/ci/check-report.sh']:
                dest = root / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                shutil.copyfile(SOURCE / name, dest)
            commands = root / 'commands'
            commands.mkdir()
            trace = root / 'trace'
            target = root / 'relative cache' if relative else pathlib.Path(tmp) / 'external cache' if external else root / 'target'
            def script(name, body):
                dest = root / name
                dest.parent.mkdir(parents=True, exist_ok=True)
                dest.write_text('#!/usr/bin/env bash\nset -euo pipefail\n' + body + '\n')
                dest.chmod(0o755)
            script('commands/cargo', 'printf "%s\\n" "$CARGO_TARGET_DIR" >> "$TRACE"')
            script('commands/git', 'printf "%s\\n" "3e8b2d5b6f13a4440c10ad5c56bff73d3d967538"')
            script('commands/npx', 'if [[ "$*" == *"playwright test"* ]]; then test "$REDLINE_WEB_TARGET_BIN" = "$EXPECTED/release/redlinedb"; fi')
            script('scripts/build-from-source.sh', 'test "$CARGO_TARGET_DIR" = "$EXPECTED"')
            script('scripts/test-binaries.sh', 'test "$1" = "$EXPECTED/release"')
            (root / 'subrepos/redline-web/apps/web').mkdir(parents=True)
            (root / 'README.md').write_text('fixture\n')
            # A stale checkout-local reporter must never win over an explicit target.
            script('target/release/redline-testing', 'exit 91' if external else 'printf "%s\\n" "$1" >> "$TRACE"')
            if external:
                runner = target / 'release/redline-testing'
                runner.parent.mkdir(parents=True)
                runner.write_text('#!/usr/bin/env bash\nprintf "%s\\n" "$1" >> "$TRACE"\n')
                runner.chmod(0o755)
            env = os.environ.copy()
            env.update(PATH=str(commands) + ':' + env['PATH'], EXPECTED=str(target), TRACE=str(trace))
            env.pop('CARGO_TARGET_DIR', None)
            if external:
                env['CARGO_TARGET_DIR'] = target.name if relative else str(target)
            if lane == 'runner':
                command = ['bash', '-c', '. ops/ci/lib.sh; ci_install_redline_testing_local() { test "$CI_REDLINE_TESTING_LOCAL_BIN" = "$EXPECTED/release/redline-testing"; }; ci_install_redline_testing']
            elif lane == 'report':
                command = ['bash', 'ops/ci/check-report.sh']
            else:
                command = ['bash', 'scripts/ci-family.sh', lane]
            result = subprocess.run(command, cwd=root, env=env, capture_output=True, text=True)
            self.assertEqual(result.returncode, 0, result.stderr)
            if lane == 'report':
                self.assertEqual(trace.read_text().splitlines(), ['report', 'check-postgres'])
            elif lane == 'testing':
                self.assertEqual(trace.read_text().splitlines(), [str(target), str(target)])

for lane in ['testing', 'runner', 'report', 'integration']:
    for external in [False, True]:
        setattr(TargetDirectory, 'test_' + lane + ('_external' if external else '_default'),
                lambda self, lane=lane, external=external: self.check_lane(lane, external))
for lane in ['runner', 'integration']:
    setattr(TargetDirectory, 'test_' + lane + '_relative',
            lambda self, lane=lane: self.check_lane(lane, True, True))

if __name__ == '__main__':
    unittest.main(verbosity=2)

import json
import pathlib
import re
import subprocess

lane = pathlib.Path('/home/ubuntu/redlineDB/.agent/worktrees/audit')
base = '3e8b2d5b6f13a4440c10ad5c56bff73d3d967538'

class Pairs(list):
    pass

def original(path):
    return subprocess.check_output(['git', 'show', base + ':' + path], cwd=lane).decode()

def preserve(old, new):
    if isinstance(old, Pairs):
        assert isinstance(new, Pairs)
        cursor = 0
        for key, value in old:
            while cursor < len(new) and new[cursor][0] != key:
                cursor += 1
            assert cursor < len(new), ('missing/reordered occurrence', key)
            preserve(value, new[cursor][1])
            cursor += 1
    else:
        assert old == new, ('changed old value', old, new)

for directory in ['agent', '.jankurai']:
    for name in ['owner-map.json', 'test-map.json']:
        path = directory + '/' + name
        preserve(json.loads(original(path), object_pairs_hook=Pairs),
                 json.loads((lane / path).read_text(), object_pairs_hook=Pairs))
    path = directory + '/generated-zones.toml'
    assert (lane / path).read_text().startswith(original(path)), path

pattern = re.compile(r'<!-- ([a-zA-Z0-9_-]+):begin -->.*?<!-- \1:end -->', re.S)
old_readme = original('README.md')
new_readme = (lane / 'README.md').read_text()
blocks = pattern.findall(old_readme)
assert blocks
for match in pattern.finditer(old_readme):
    assert match.group(0) in new_readme, ('changed generated block', match.group(1))
assert not subprocess.check_output(['git', 'diff', base, '--', 'crates', 'Cargo.toml',
                                    'Cargo.lock', '.cargo'], cwd=lane).strip()
print(json.dumps(dict(oldMapOccurrencesPreserved=True, oldGeneratedZonesPreserved=True,
                      readmeBlocksPreserved=blocks, productionUnchanged=True)))

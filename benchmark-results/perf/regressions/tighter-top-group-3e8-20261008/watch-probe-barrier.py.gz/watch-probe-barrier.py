import datetime, json, pathlib, subprocess, time
p = pathlib.Path(__file__).resolve().parent
remote = """import json,pathlib,os
p=pathlib.Path('/dev/shm/redline-tight-top-group-20261008/probe-barrier')
f=p/'bundle/records.jsonl';e=p/'coordinator.exit'
r=dict(records=f.read_bytes().count(b'\\n') if f.exists() else 0,exit=int(e.read_text()) if e.exists() else None,load=list(os.getloadavg()))
print(json.dumps(r))
"""
while True:
    r = subprocess.run(['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10','xbabe3','python3 -'], input=remote, capture_output=True, text=True, timeout=25)
    assert r.returncode == 0, r.stderr
    state = json.loads(r.stdout)
    state['at'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    with (p/'probe-barrier-observer.jsonl').open('a') as f:
        f.write(json.dumps(state)+'\n')
    print(json.dumps(state), flush=True)
    if state['exit'] is not None:
        (p/'probe-barrier-observer.exit').write_text(str(state['exit'])+'\n')
        raise SystemExit(state['exit'])
    time.sleep(30)

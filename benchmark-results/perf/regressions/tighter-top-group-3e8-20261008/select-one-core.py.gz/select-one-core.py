import datetime,json,os,pathlib,time
p=pathlib.Path(__file__).parent
def counters():
    result={}
    for line in pathlib.Path('/proc/stat').read_text().splitlines():
        a=line.split()
        if a and a[0].startswith('cpu') and a[0][3:].isdigit():result[int(a[0][3:])]=list(map(int,a[1:9]))
    return result
a=counters();time.sleep(10);b=counters();util={}
for c in a:
    d=[y-x for x,y in zip(a[c],b[c])];util[c]=1-(d[3]+d[4])/sum(d) if sum(d) else 0
candidates=[]
for c in sorted(os.sched_getaffinity(0)):
    root=pathlib.Path('/sys/devices/system/cpu')/('cpu'+str(c))
    core=int((root/'topology/core_id').read_text())
    sib=[]
    for part in (root/'topology/thread_siblings_list').read_text().strip().split(','):
        bounds=list(map(int,part.split('-')));sib.extend(range(bounds[0],bounds[-1]+1))
    if c!=min(sib) or core<16:continue
    nodes=list(root.glob('node*'));node=int(nodes[0].name[4:]) if nodes else 0
    candidates.append({'cpu':c,'core':core,'siblings':sib,'node':node,'busy':util[c],'score':sum(util[s] for s in sib)/len(sib)})
x=min(candidates,key=lambda c:c['score']);selected=[x['cpu']];cpus=str(x['cpu'])
topology={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'sampleSeconds':10,'candidateCountersBefore':a,'candidateCountersAfter':b,'candidates':candidates,'selected':[x],'selectedCPUs':selected,'sampleCPUs':sorted(set(x['siblings'])),'cpus':cpus,'exclusive':False,'kernelIsolated':False}
print(json.dumps(topology))

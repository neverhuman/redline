import hashlib
import json
import pathlib
import subprocess
import tarfile

lane = pathlib.Path('/home/ubuntu/redlineDB/.agent/worktrees/audit')
proof = pathlib.Path(__file__).resolve().parent
study = pathlib.Path('/mnt/fast-scratch/jope-prime-offroot/redlinedb-v511-tests/tighter-top-group-20261008')
remote = study / 'remote'
remote_path = '/dev/shm/redline-tight-top-group-20261008/'
assert not remote.exists(), 'custody destination already exists'
assert (proof / 'study-observer.exit').read_text().strip() == '0'

def run(args):
    result = subprocess.run(args, cwd=lane, capture_output=True, text=True)
    assert result.returncode == 0, (args, result.returncode, result.stderr)
    return result.stdout

def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
    return h.hexdigest()

# Copy only after the sole coordinator has closed both immutable receipts.
run(['rsync', '-a', 'xbabe3:' + remote_path, str(remote) + '/'])
assert (remote / 'coordinator.exit').read_text().strip() == '0'
assert (remote / 'binary-hashes-before.txt').read_bytes() == (remote / 'binary-hashes-after.txt').read_bytes()
method = json.loads((remote / 'method-predeclared.json').read_text())
for number in [1, 2]:
    session = remote / f'session-{number}'
    assert (session / 'measure.exit').read_text().strip() == '0'
    bundle = session / 'bundle'
    receipt = json.loads((bundle / 'receipt.json').read_text())
    plan = json.loads((bundle / 'plan.json').read_text())
    assert receipt['exit'] == 0 and not receipt.get('error') and not receipt.get('interrupted')
    assert plan['session'] == number and plan['methodSha256'] == digest(remote / 'method-predeclared.json')
    assert (bundle / 'records.jsonl').read_bytes().count(b'\n') == 780
    assert plan['comparisonMain'] == method['main'] and plan['releaseTagCommit'] == method['release']
    for entry in receipt['files']:
        assert digest(bundle / entry['path']) == entry['sha256'], entry['path']
    for label in ['release', 'main']:
        metadata = json.loads((remote / 'inputs' / label / 'build.json').read_text())
        assert metadata['engine_commit'] == method[label]
        assert digest(remote / 'inputs' / label / 'redline-scoreboard') == metadata['binary_sha256']
        assert metadata == json.loads((bundle / (label + '-build.json')).read_text())

files = []
for path in sorted(remote.rglob('*')):
    assert not path.is_symlink(), path
    if path.is_file():
        files.append(dict(path=path.relative_to(remote).as_posix(), size=path.stat().st_size, sha256=digest(path)))
archive = study / 'complete-remote.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as output:
    for entry in files:
        output.add(remote / entry['path'], arcname=entry['path'], recursive=False)
with tarfile.open(archive, 'r:gz') as saved:
    assert [m.name for m in saved.getmembers()] == [f['path'] for f in files]
    for member, entry in zip(saved.getmembers(), files):
        stream = saved.extractfile(member)
        assert stream is not None and member.size == entry['size']
        h = hashlib.sha256()
        for block in iter(lambda: stream.read(1048576), b''):
            h.update(block)
        assert h.hexdigest() == entry['sha256'], member.name
manifest = dict(schema='redline-complete-custody-v1', host='xbabe3', remotePath=remote_path,
                archive=str(archive), archiveSha256=digest(archive), files=files)
(proof / 'complete-custody.json').write_text(json.dumps(manifest, indent=2) + '\n')
(proof / 'collect-complete.exit').write_text('0\n')
print(json.dumps(dict(archive=str(archive), sha256=manifest['archiveSha256'], payloads=len(files))))

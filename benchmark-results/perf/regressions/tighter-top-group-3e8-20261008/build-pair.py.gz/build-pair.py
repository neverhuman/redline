import datetime,hashlib,json,os,pathlib,shutil,subprocess,tarfile,time
lane=pathlib.Path('/home/ubuntu/redlineDB/.agent/worktrees/audit'); p=lane/'target/review/tighter-top-group-20261008'; study=pathlib.Path('/mnt/fast-scratch/jope-prime-offroot/redlinedb-v511-tests/tighter-top-group-20261008'); sandbox=lane/'.agent/sandbox/tighter-build'
method=json.loads((p/'method-predeclared.json').read_text()); assert not sandbox.exists()
def run(args,cwd=lane,env=None,log=None):
    r=subprocess.run(args,cwd=cwd,env=env,stdout=log or subprocess.PIPE,stderr=subprocess.STDOUT,text=True)
    assert r.returncode==0,(args,r.returncode,r.stdout)
    return r.stdout.strip() if log is None else ''
def digest(f):
    h=hashlib.sha256()
    with open(f,'rb') as s:
        for b in iter(lambda:s.read(1048576),b''):h.update(b)
    return h.hexdigest()
archive=study.parent/'archive/focused-mitigation-31f-lane-evidence-20261008.tar.gz';manifest=archive.with_name('focused-mitigation-31f-lane-evidence-20261008.manifest.json')
assert digest(archive)=='fd34f7c68ed646cf4115c747a2171a6c8bbaf18b04e8dc75b3f21cd67b6ab6a8'
assert digest(manifest)=='fb47281b0eceb180e273933d8a68eff03885709c6abaefade85792b1a88d3936'
assert not (lane/'target/release').exists()
with tarfile.open(archive,'r:gz') as t:
    members=[m for m in t.getmembers() if m.name=='target/release' or m.name.startswith('target/release/')]
    assert members and all('..' not in pathlib.PurePosixPath(m.name).parts for m in members)
    t.extractall(study/'cache-root',members=members,filter='data')
print('Restored only owned release dependency cache; production artifacts will be cleaned',flush=True)
sandbox.parent.mkdir(parents=True,exist_ok=True)
run(['git','clone','--quiet','--no-local','--no-checkout',str(lane),str(sandbox)])
env=os.environ.copy()
for k in list(env):
    if k.startswith(('CARGO_PROFILE_','CARGO_BUILD_')) or k in ['CARGO_ENCODED_RUSTFLAGS','CARGO_TARGET_DIR','RUSTC_WRAPPER','RUSTC_WORKSPACE_WRAPPER']:env.pop(k)
env.update(RUSTFLAGS='',CARGO_INCREMENTAL='0',CARGO_PROFILE_DEV_DEBUG='line-tables-only')
try:
    for label in ['release','main']:
        sha=method[label];out=study/'inputs'/label;assert not out.exists();out.mkdir(parents=True)
        run(['git','checkout','--quiet','--detach',sha],sandbox)
        assert run(['git','rev-parse','HEAD'],sandbox)==sha
        assert run(['git','status','--porcelain'],sandbox)==''
        assert run(['git','rev-parse','HEAD:crates/scoreboard'],sandbox)==method['harnessTree']
        target=str(lane/'target')
        with (p/f'build-{label}.log').open('x') as log:
            clean=['cargo','clean','--release','--target-dir',target]
            for pkg in ['redlinedb-kernel','redlinedb-sql','redlinedb','redlinedb-scoreboard']:clean+=['-p',pkg]
            run(clean,sandbox,env,log)
            args=['cargo','build','--release','--locked','--offline','--jobs','2','-p','redlinedb-scoreboard','--target-dir',target]
            started=datetime.datetime.now(datetime.timezone.utc).isoformat();run(args,sandbox,env,log)
        assert run(['git','status','--porcelain'],sandbox)==''
        binary=lane/'target/release/redline-scoreboard';assert binary.is_file()
        run(['bash','-c','source "$1"; perf_check_release_binary "$2" "$3"','bash',str(sandbox/'scripts/perf/lib.sh'),label,str(binary)],sandbox,env)
        shutil.copy2(binary,out/'redline-scoreboard');info=json.loads(run([str(binary),'info'],sandbox,env))
        profile=run(['git','show',sha+':Cargo.toml'],sandbox).split('[profile.release]',1)[1].split('\n[',1)[0]
        r={'schema_version':'redline-scoreboard-build-v1','label':label,'engine_ref':sha,'engine_commit':sha,'harness_commit':method['main'],'harness_tree':method['harnessTree'],'engines':info,'rustc_verbose_version':run(['rustc','-vV'],sandbox,env).splitlines(),'cargo_version':run(['cargo','-V'],sandbox,env),'cargo_command':' '.join(args),'profile':'release','profile_release':profile,'rustflags':'','pgo':False,'failpoints':False,'binary_sha256':digest(binary),'source_tree':run(['git','rev-parse','HEAD^{tree}'],sandbox),'source_inputs_sha256':run(['bash','ops/ci/source-inputs-sha256.sh'],sandbox,env),'source_dirty':False,'started_at':started,'built_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'productionArtifactsCleaned':True,'build_jobs':2,'affinity':pathlib.Path('/proc/self/status').read_text().split('Cpus_allowed_list:',1)[1].splitlines()[0].strip(),'nice':os.getpriority(os.PRIO_PROCESS,0)}
        (out/'build.json').write_text(json.dumps(r,indent=2)+'\n');(p/f'build-{label}.exit').write_text('0\n')
        print('Built',label,sha,r['binary_sha256'],flush=True)
finally:
    assert sandbox.parent==lane/'.agent/sandbox' and sandbox.name=='tighter-build'
    shutil.rmtree(sandbox)
(p/'build-pair.exit').write_text('0\n');print('Exact source build pair finished; own unregistered sandbox removed',flush=True)

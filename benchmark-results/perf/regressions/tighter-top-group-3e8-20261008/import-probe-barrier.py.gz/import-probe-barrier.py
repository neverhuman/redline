import gzip
import hashlib
import json
from pathlib import Path
import shutil
import tarfile

proof = Path(__file__).resolve().parent
study = proof.parents[3]
root = Path('/home/ubuntu/redlineDB/.agent/worktrees/audit/benchmark-results/perf/regressions/tighter-top-group-3e8-20261008')
manifest = json.loads((root / 'investigation.json').read_text())
assert 'diagnostic' not in manifest, 'already imported'

def sha(data):
    return hashlib.sha256(data).hexdigest()

def evidence(relative, source, compressed=False):
    raw = source.read_bytes()
    data = gzip.compress(raw, mtime=0) if compressed else raw
    dest = root / relative
    dest.parent.mkdir(parents=True, exist_ok=True)
    dest.write_bytes(data)
    item = dict(path=relative, sha256=sha(data))
    if compressed:
        item['rawSha256'] = sha(raw)
    assert not any(f['path'] == relative for f in manifest['evidence'])
    manifest['evidence'].append(item)

for name in ['probe-barrier-observer', 'collect-probe-barrier', 'collect-probe-barrier-wrapper',
             'summary-probe-barrier', 'method-barrier-controls-final', 'build-bisect', 'build-bisect-wrapper']:
    assert (proof / (name + '.exit')).read_text() == '0\n', name

for name, source, custody_name, eligible in [
    ('scheduling-barrier', study / 'probe-barrier/remote', 'probe-barrier-custody.json', True),
    ('rejected-affinity', study / 'probe-interference-rejected/remote', 'probe-first-rejected-custody.json', False),
]:
    custody = json.loads((proof / custody_name).read_text())
    assert sha(Path(custody['archive']).read_bytes()) == custody['archiveSha256']
    with tarfile.open(custody['archive'], 'r:gz') as archive:
        members = {m.name.removeprefix('./'): m for m in archive.getmembers() if m.isfile()}
        assert set(members) == {f['path'] for f in custody['files']}
        for f in custody['files']:
            data = archive.extractfile(members[f['path']]).read()
            assert len(data) == f['size'] and sha(data) == f['sha256']
            assert (source / f['path']).read_bytes() == data
    receipt = json.loads((source / 'bundle/receipt.json').read_text())
    assert receipt['exit'] == (0 if eligible else 1)
    assert (source / 'coordinator.exit').read_text() == ('0\n' if eligible else '1\n')
    shutil.copytree(source / 'bundle', root / name / 'bundle')
    for file in source.iterdir():
        if file.is_file():
            evidence(name + '/' + file.name, file)
    evidence(custody_name, proof / custody_name)
    descriptor = dict(name=name, receiptSha256=sha((source / 'bundle/receipt.json').read_bytes()),
                      archiveSha256=custody['archiveSha256'])
    if eligible:
        manifest['diagnostic'] = descriptor
    else:
        descriptor.update(records=custody['records'], eligible=False)
        manifest['rejected'] = descriptor

for name in ['probe-barrier-observer', 'collect-probe-barrier', 'collect-probe-barrier-wrapper',
             'summary-probe-barrier', 'method-barrier-controls-final', 'build-bisect', 'build-bisect-wrapper']:
    evidence(name + '.exit', proof / (name + '.exit'))
for name in ['probe-barrier-launch.json', 'probe-launch.json']:
    evidence(name, proof / name)
for name in ['probe-barrier-observer.log', 'collect-probe-barrier.log', 'method-barrier-controls-final.log',
             'build-bisect.log', 'build-bisect.py', 'collect-probe-barrier.py',
             'probe-interference-first-failed.mjs', 'probe-interference-first-failed-plan.json',
             'probe-interference-summary-rejected.mjs', 'run-probe-first-failed.sh',
             'run-probe-barrier.sh', 'watch-probe-barrier.py', 'import-probe-barrier.py']:
    evidence(name + '.gz', proof / name, True)
for version in ['rowid-route', 'recovery-directory', 'wal-window']:
    source = study / 'bisect/inputs' / version
    assert (source / 'build.exit').read_text() == '0\n'
    build = json.loads((source / 'build.json').read_text())
    assert sha((source / 'redline-scoreboard').read_bytes()) == build['binary_sha256']
    for name in ['build.json', 'build.exit', 'build.log']:
        evidence('historical-builds/' + version + '/' + name + ('.gz' if name.endswith('.log') else ''), source / name, name.endswith('.log'))
(root / 'investigation.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(diagnostic=manifest['diagnostic'], rejected=manifest['rejected'], evidence=len(manifest['evidence']))))

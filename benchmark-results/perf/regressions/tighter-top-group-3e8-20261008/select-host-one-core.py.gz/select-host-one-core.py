import concurrent.futures,datetime,json,os,pathlib,subprocess,time
p=pathlib.Path(__file__).parent
assert os.uname().nodename=='xbabe2'
def snapshot(host):
    at=datetime.datetime.now(datetime.timezone.utc).isoformat()
    if host=='xbabe2':return {'name':host,'at':at,'load':list(os.getloadavg()),'logicalCPUs':os.cpu_count(),'transport':'local Linux, not ssh alias'}
    args=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=10',host,"python3 -c 'import os,json;print(json.dumps(dict(name=os.uname().nodename,load=list(os.getloadavg()),logicalCPUs=os.cpu_count())))'"]
    r=subprocess.run(args,capture_output=True,text=True,timeout=20)
    assert r.returncode==0,(host,r.stderr)
    x=json.loads(r.stdout);assert x['name']==host;x.update(at=at,transport='SSH read-only proc snapshot');return x
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: hosts=list(pool.map(snapshot,['xbabe1','xbabe2','xbabe3']))
chosen=min(hosts,key=lambda h:h['load'][0])['name']
selection={'at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'chosen':chosen,'snapshots':hosts,**{x['name']:x['load'] for x in hosts}}
(p/'host-selection-one-core.json').write_text(json.dumps(selection,indent=2)+'\n');print(json.dumps(selection),flush=True)

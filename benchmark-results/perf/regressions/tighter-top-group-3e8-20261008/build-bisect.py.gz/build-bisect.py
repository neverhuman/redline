import datetime, hashlib, json, os, pathlib, shutil, subprocess

lane = pathlib.Path('/home/ubuntu/redlineDB/.agent/worktrees/audit')
proof = pathlib.Path(__file__).resolve().parent
study = pathlib.Path('/mnt/fast-scratch/jope-prime-offroot/redlinedb-v511-tests/tighter-top-group-20261008')
target = study / 'cache-root/target'
sandbox = lane / '.agent/sandbox/tighter-bisect-build'
assert not sandbox.exists()

def run(args, cwd=lane, env=None, log=None):
    r = subprocess.run(args, cwd=cwd, env=env, stdout=log or subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    assert r.returncode == 0, (args, r.returncode, r.stdout)
    return r.stdout.strip() if log is None else ''

def digest(file):
    return hashlib.sha256(file.read_bytes()).hexdigest()

env = os.environ.copy()
for key in list(env):
    if key.startswith(('CARGO_PROFILE_', 'CARGO_BUILD_')) or key in ['CARGO_ENCODED_RUSTFLAGS', 'CARGO_TARGET_DIR', 'RUSTC_WRAPPER', 'RUSTC_WORKSPACE_WRAPPER']:
        env.pop(key)
env.update(RUSTFLAGS='', CARGO_INCREMENTAL='0', CARGO_PROFILE_DEV_DEBUG='line-tables-only', CARGO_TARGET_DIR=str(target))
reference = json.loads((study / 'inputs/release/build.json').read_text())
assert target.is_dir() and not target.is_symlink()
sandbox.parent.mkdir(parents=True, exist_ok=True)
run(['git', 'clone', '--quiet', '--no-local', '--no-checkout', str(lane), str(sandbox)])
try:
    for label, ref in [('rowid-route', 'e9afed9e7'), ('recovery-directory', '7bdf4c8c5'), ('wal-window', '8f880b216')]:
        sha = run(['git', 'rev-parse', ref])
        out = study / 'bisect/inputs' / label
        assert not out.exists(), 'immutable binary label exists'
        out.mkdir(parents=True)
        run(['git', 'checkout', '--quiet', '--detach', sha], sandbox)
        assert run(['git', 'status', '--porcelain'], sandbox) == ''
        assert run(['git', 'rev-parse', 'HEAD:crates/scoreboard'], sandbox) == reference['harness_tree']
        with (out / 'build.log').open('x') as log:
            clean = ['cargo', 'clean', '--release']
            for pkg in ['redlinedb-kernel', 'redlinedb-sql', 'redlinedb', 'redlinedb-scoreboard']:
                clean += ['-p', pkg]
            run(clean, sandbox, env, log)
            command = ['cargo', 'build', '--release', '--locked', '--offline', '--jobs', '2', '-p', 'redlinedb-scoreboard']
            start = datetime.datetime.now(datetime.timezone.utc).isoformat()
            run(command, sandbox, env, log)
        assert run(['git', 'status', '--porcelain'], sandbox) == ''
        binary = target / 'release/redline-scoreboard'
        run(['bash', '-c', 'source "$1"; perf_check_release_binary "$2" "$3"', 'bash', str(sandbox / 'scripts/perf/lib.sh'), label, str(binary)], sandbox, env)
        shutil.copy2(binary, out / 'redline-scoreboard')
        metadata = dict(schema_version='redline-scoreboard-build-v1', label=label, engine_ref=sha, engine_commit=sha,
            harness_commit='3e8b2d5b6f13a4440c10ad5c56bff73d3d967538', harness_tree=reference['harness_tree'],
            engines=json.loads(run([str(binary), 'info'], sandbox, env)),
            rustc_verbose_version=run(['rustc', '-vV'], sandbox, env).splitlines(), cargo_version=run(['cargo', '-V'], sandbox, env),
            cargo_command=' '.join(command), profile='release', profile_release=run(['git', 'show', sha + ':Cargo.toml'], sandbox).split('[profile.release]', 1)[1].split('\n[', 1)[0],
            rustflags='', pgo=False, failpoints=False, binary_sha256=digest(binary),
            source_tree=run(['git', 'rev-parse', 'HEAD^{tree}'], sandbox), source_inputs_sha256=run(['bash', 'ops/ci/source-inputs-sha256.sh'], sandbox, env),
            source_dirty=False, started_at=start, built_at_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
            productionArtifactsCleaned=True, build_jobs=2, affinity=pathlib.Path('/proc/self/status').read_text().split('Cpus_allowed_list:', 1)[1].splitlines()[0].strip(),
            nice=os.getpriority(os.PRIO_PROCESS, 0))
        for key in ['engines', 'rustc_verbose_version', 'cargo_version', 'profile_release', 'harness_tree']:
            assert metadata[key] == reference[key], key
        (out / 'build.json').write_text(json.dumps(metadata, indent=2) + '\n')
        (out / 'build.exit').write_text('0\n')
        print(json.dumps(dict(label=label, commit=sha, sha256=metadata['binary_sha256'])), flush=True)
finally:
    assert sandbox.parent == lane / '.agent/sandbox' and sandbox.name == 'tighter-bisect-build'
    assert str(sandbox) not in run(['git', 'worktree', 'list', '--porcelain'])
    assert run(['git', 'status', '--porcelain'], sandbox) == ''
    shutil.rmtree(sandbox)
(proof / 'build-bisect.exit').write_text('0\n')

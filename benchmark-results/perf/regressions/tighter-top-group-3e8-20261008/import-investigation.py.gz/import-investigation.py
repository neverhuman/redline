import gzip
import hashlib
import json
import pathlib
import shutil

lane = pathlib.Path('/home/ubuntu/redlineDB/.agent/worktrees/audit')
proof = pathlib.Path(__file__).resolve().parent
study = pathlib.Path('/mnt/fast-scratch/jope-prime-offroot/redlinedb-v511-tests/tighter-top-group-20261008')
root = lane / 'benchmark-results/perf/regressions/tighter-top-group-3e8-20261008'
assert not root.exists(), 'immutable import already exists'
assert (proof / 'one-core-observer.exit').read_text().strip() == '0'
assert (proof / 'collect-one-core.exit').read_text().strip() == '0'

def digest(data):
    return hashlib.sha256(data).hexdigest()

manifest = dict(schema='redline-tighter-investigation-v1', studies=[], evidence=[])
for name, source, custody_name in [
    ('two-core', study / 'remote', 'complete-custody.json'),
    ('one-core', study / 'one-core/remote', 'one-core-custody.json'),
]:
    assert (source / 'coordinator.exit').read_text().strip() == '0'
    custody = json.loads((proof / custody_name).read_text())
    assert digest(pathlib.Path(custody['archive']).read_bytes()) == custody['archiveSha256']
    receipts = []
    for n in [1, 2]:
        bundle = source / f'session-{n}/bundle'
        receipt = json.loads((bundle / 'receipt.json').read_text())
        assert receipt['exit'] == 0 and not receipt.get('error') and not receipt.get('interrupted')
        for f in receipt['files']:
            assert digest((bundle / f['path']).read_bytes()) == f['sha256']
        dest = root / name / f'session-{n}/bundle'
        dest.parent.mkdir(parents=True, exist_ok=True)
        shutil.copytree(bundle, dest)
        receipts.append(digest((bundle / 'receipt.json').read_bytes()))
    manifest['studies'].append(dict(name=name, sessionReceipts=receipts, archiveSha256=custody['archiveSha256']))

plain = [
    'complete-custody.json', 'one-core-custody.json', 'link-removal-before.json', 'link-removal.json',
    'jope-cache-owner-note.json', 'selection-scratch-correction.json', 'external-target-parent-source.json',
    'initial-analysis-summary.json', 'initial-analysis-README.md', 'setup-receipt.json',
    'build-pair.exit', 'build-pair-wrapper.exit', 'build-release.exit', 'build-main.exit',
    'method-one-core-exact.exit', 'external-target-parent.exit', 'external-target-parent-final.exit',
    'external-target-head-final.exit', 'collect-complete.exit', 'collect-one-core.exit',
    'external-target-node-parent.exit', 'external-target-node-head.exit', 'method-review-final.exit',
    'source-preservation-final.exit',
    'collect-one-core-wrapper.exit', 'collect-one-core-first-rejected.exit',
]
compressed = [
    'build-release.log', 'build-main.log', 'build-pair.log', 'method-unit.log', 'method-one-core-exact.log',
    'external-target-parent.log', 'external-target-parent-final.log', 'external-target-head-final.log',
    'summary-first.log', 'study-observer.log', 'one-core-observer.log',
    'build-pair.py', 'select-host-final.py', 'select-host-one-core.py', 'select-one-core.py',
    'collect-complete.py', 'collect-one-core.py', 'import-investigation.py',
    'external-target-node-parent.log', 'external-target-node-head.log', 'method-review-final.log',
    'test-ci-target-directory-final.py',
    'source-preservation-final.log', 'verify-source-preservation.py',
    'collect-one-core.log', 'collect-one-core-first-rejected.log',
]
for name in plain + compressed:
    raw = (proof / name).read_bytes()
    filename = name + '.gz' if name in compressed else name
    data = gzip.compress(raw, mtime=0) if name in compressed else raw
    (root / filename).write_bytes(data)
    item = dict(path=filename, sha256=digest(data))
    if name in compressed:
        item['rawSha256'] = digest(raw)
    manifest['evidence'].append(item)
for name, source in [('two-core', study / 'remote'), ('one-core', study / 'one-core/remote')]:
    for filename in ['coordinator.log', 'coordinator.exit', 'coordinator.started', 'run-study.sh',
                     'binary-hashes-before.txt', 'binary-hashes-after.txt', 'core-selection.json']:
        data = (source / filename).read_bytes()
        relative = name + '/' + filename
        (root / relative).write_bytes(data)
        manifest['evidence'].append(dict(path=relative, sha256=digest(data)))
    for n in [1, 2]:
        for filename in ['measure.log', 'measure.exit']:
            relative = name + f'/session-{n}/' + filename
            data = (source / f'session-{n}' / filename).read_bytes()
            (root / relative).write_bytes(data)
            manifest['evidence'].append(dict(path=relative, sha256=digest(data)))
(root / 'investigation.json').write_text(json.dumps(manifest, indent=2) + '\n')
print(json.dumps(dict(root=str(root), studies=len(manifest['studies']), supplementalFiles=len(manifest['evidence']))))
